<?php
/**
 * Removes everything the plugin created: one `studiare_ext_<module>` option per
 * module, page templates and their per-product settings.
 *
 * @package StudiareExt
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/**
 * Deletes plugin options on the current site.
 */
function studiare_ext_uninstall_site(): void {
	global $wpdb;

	// Page templates (Elementor documents of the `stx_template` post type).
	$studiare_ext_templates = get_posts(
		array(
			'post_type'      => 'stx_template',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	);
	foreach ( $studiare_ext_templates as $studiare_ext_template_id ) {
		wp_delete_post( $studiare_ext_template_id, true );
	}

	// Per-product choices saved by the page templates module.
	delete_post_meta_by_key( '_stx_template' );
	delete_post_meta_by_key( '_stx_highlights' );

	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'studiare_ext_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- one-off cleanup.
	wp_cache_flush();
}

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids' ) ) as $studiare_ext_site_id ) {
		switch_to_blog( $studiare_ext_site_id );
		studiare_ext_uninstall_site();
		restore_current_blog();
	}
} else {
	studiare_ext_uninstall_site();
}
