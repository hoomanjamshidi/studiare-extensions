<?php
/**
 * Heading with optional eyebrow label and subtitle. Inherits the theme font.
 *
 * @package StudiareExt
 */

namespace StudiareExt\Modules\Builder\Elementor\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit;

final class Heading extends Base {

	public function get_name(): string {
		return 'stx-heading';
	}

	public function get_title(): string {
		/* translators: %s: widget name. */
		return sprintf( __( '%s (Studiare+)', 'studiare-extensions' ), __( 'Heading', 'studiare-extensions' ) );
	}

	public function get_icon(): string {
		return 'eicon-t-letter';
	}

	protected function is_dynamic_content(): bool {
		return false;
	}

	protected function register_controls(): void {
		$this->start_content_section( 'section_content', __( 'Heading', 'studiare-extensions' ) );

		$this->add_control(
			'eyebrow',
			array(
				'label'       => __( 'Small label above', 'studiare-extensions' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => __( 'Title', 'studiare-extensions' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 2,
				'default'     => __( 'Section title', 'studiare-extensions' ),
				'label_block' => true,
			)
		);

		$this->add_control(
			'subtitle',
			array(
				'label'       => __( 'Text below', 'studiare-extensions' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 3,
				'default'     => '',
				'label_block' => true,
			)
		);

		$this->add_control(
			'link',
			array(
				'label'   => __( 'Link', 'studiare-extensions' ),
				'type'    => Controls_Manager::URL,
				'dynamic' => array( 'active' => true ),
			)
		);

		$this->add_control(
			'tag',
			array(
				'label'   => __( 'HTML tag', 'studiare-extensions' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => array(
					'h1'   => 'H1',
					'h2'   => 'H2',
					'h3'   => 'H3',
					'h4'   => 'H4',
					'h5'   => 'H5',
					'h6'   => 'H6',
					'div'  => 'div',
					'p'    => 'p',
					'span' => 'span',
				),
			)
		);

		$this->add_control(
			'size',
			array(
				'label'   => __( 'Size', 'studiare-extensions' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'md',
				'options' => array(
					'xl' => __( 'Extra large', 'studiare-extensions' ),
					'lg' => __( 'Large', 'studiare-extensions' ),
					'md' => __( 'Medium', 'studiare-extensions' ),
					'sm' => __( 'Small', 'studiare-extensions' ),
					'xs' => __( 'Extra small', 'studiare-extensions' ),
				),
			)
		);

		$this->add_align_control( 'align', '.stx-heading' );

		$this->end_controls_section();

		$this->start_style_section( 'section_style', __( 'Heading', 'studiare-extensions' ) );
		$this->add_text_style( 'title', '.stx-heading__title', array( 'hover' => '.stx-heading__title a:hover' ) );
		$this->add_text_style( 'eyebrow', '.stx-heading__eyebrow', array( 'label' => __( 'Small label', 'studiare-extensions' ) ) );
		$this->add_text_style( 'subtitle', '.stx-heading__sub', array( 'label' => __( 'Text below', 'studiare-extensions' ) ) );

		$this->add_responsive_control(
			'spacing',
			array(
				'label'      => __( 'Spacing', 'studiare-extensions' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'separator'  => 'before',
				'selectors'  => array( '{{WRAPPER}} .stx-heading' => 'gap: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();
	}

	protected function render(): void {
		$s     = $this->get_settings_for_display();
		$tag   = in_array( $s['tag'], array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'p', 'span' ), true ) ? $s['tag'] : 'h2';
		$title = wp_kses_post( nl2br( (string) $s['title'] ) );

		if ( ! empty( $s['link']['url'] ) ) {
			$this->add_link_attributes( 'link', $s['link'] );
			$title = '<a ' . $this->get_render_attribute_string( 'link' ) . '>' . $title . '</a>';
		}
		?>
		<div class="stx-heading stx-heading--<?php echo esc_attr( $s['size'] ); ?>">
			<?php if ( '' !== (string) $s['eyebrow'] ) : ?>
				<span class="stx-heading__eyebrow"><?php echo esc_html( $s['eyebrow'] ); ?></span>
			<?php endif; ?>
			<<?php echo esc_html( $tag ); ?> class="stx-heading__title"><?php echo $title; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- kses above. ?></<?php echo esc_html( $tag ); ?>>
			<?php if ( '' !== (string) $s['subtitle'] ) : ?>
				<p class="stx-heading__sub"><?php echo wp_kses_post( nl2br( (string) $s['subtitle'] ) ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}
}
