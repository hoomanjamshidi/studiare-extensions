/**
 * Studiare Extensions — blog widgets.
 *
 * Everything here enhances markup that already works on its own: share
 * links open the networks, the table of contents is a native <details> with
 * plain anchor links, the category drop-down is a native <details>. This
 * adds "Copy link" and the phone's share sheet (hidden until now), marks the
 * section being read, shows the table of contents bar that follows the
 * reader once the list has scrolled away, fills the reading progress bar, brings the current
 * category into view in rows that scroll sideways, and closes the category
 * drop-down on an outside tap, with Esc or when focus leaves it, and adds
 * "Read more" to a shortened category description. Scroll work is batched into one animation frame and only
 * writes transforms and classes.
 */
( function () {
	'use strict';

	/**
	 * Options for tap, click and key listeners. WP Rocket's "Delay JavaScript"
	 * (3.17+) holds such listeners back, also in scripts it does not delay like
	 * this one, until the scripts it delays have loaded, and then replays the
	 * first tap as an untrusted copy (iOS will not start audio from one). Its
	 * own `isRocket` option lets a listener through; browsers ignore it.
	 */
	const UNDELAYED = { isRocket: true };

	const config = window.stxBlog || {};
	const i18n = config.i18n || {};
	const doc = document;

	/* ---------------------------------------------------------------------
	 * Shared scroll loop (table of contents, progress bar)
	 * ------------------------------------------------------------------- */

	const onScroll = [];
	let scheduled = false;

	function runScroll() {
		scheduled = false;
		onScroll.forEach( ( callback ) => callback() );
	}

	function schedule() {
		if ( ! scheduled ) {
			scheduled = true;
			window.requestAnimationFrame( runScroll );
		}
	}

	function watchScroll( callback ) {
		if ( ! onScroll.length ) {
			window.addEventListener( 'scroll', schedule, { passive: true } );
			window.addEventListener( 'resize', schedule, { passive: true } );
		}
		onScroll.push( callback );
		schedule();
	}

	/** Height the sticky header and admin bar cover at the top of the screen. */
	function topOffset() {
		const style = getComputedStyle( doc.documentElement );
		const header = parseFloat( style.getPropertyValue( '--stx-header-offset' ) ) || 0;
		const bar = parseFloat( style.getPropertyValue( '--stx-admin-bar' ) ) || 0;

		return header + bar;
	}

	/* ---------------------------------------------------------------------
	 * Share: copy link and the phone's share sheet
	 * ------------------------------------------------------------------- */

	let live = null;
	function announce( message ) {
		if ( ! live ) {
			live = doc.createElement( 'span' );
			live.className = 'screen-reader-text';
			live.setAttribute( 'aria-live', 'polite' );
			doc.body.appendChild( live );
		}
		live.textContent = '';
		window.setTimeout( () => {
			live.textContent = message;
		}, 50 );
	}

	function copyText( text ) {
		if ( navigator.clipboard && window.isSecureContext ) {
			return navigator.clipboard.writeText( text );
		}

		// Plain http sites have no clipboard API: fall back to a selected field.
		return new Promise( ( resolve, reject ) => {
			const field = doc.createElement( 'textarea' );
			field.value = text;
			field.setAttribute( 'readonly', '' );
			field.style.position = 'fixed';
			field.style.opacity = '0';
			doc.body.appendChild( field );
			field.select();
			const ok = doc.execCommand( 'copy' );
			field.remove();
			( ok ? resolve : reject )();
		} );
	}

	function initShare( root ) {
		root.querySelectorAll( '[data-stx-needs-js]' ).forEach( ( item ) => {
			item.hidden = false;
		} );

		if ( typeof navigator.share === 'function' ) {
			root.querySelectorAll( '[data-stx-needs-share]' ).forEach( ( item ) => {
				item.hidden = false;
			} );
		}

		root.addEventListener( 'click', ( event ) => {
			const copy = event.target.closest( '[data-stx-copy]' );
			if ( copy ) {
				copyText( copy.dataset.stxCopy ).then( () => {
					copy.classList.add( 'is-done' );
					announce( i18n.copied || '' );
					window.setTimeout( () => copy.classList.remove( 'is-done' ), 2000 );
				} ).catch( () => {} );
				return;
			}

			const share = event.target.closest( '[data-stx-share]' );
			if ( share ) {
				// Closing the share sheet rejects the promise; nothing to report.
				navigator.share( { title: share.dataset.title, url: share.dataset.url } ).catch( () => {} );
			}
		}, UNDELAYED );
	}

	/* ---------------------------------------------------------------------
	 * Table of contents: mark the section being read
	 * ------------------------------------------------------------------- */

	function initToc( root ) {
		const entries = Array.from( root.querySelectorAll( '.stx-toc__link' ) ).map( ( link ) => {
			let id = link.getAttribute( 'href' ).slice( 1 );
			try {
				id = decodeURIComponent( id );
			} catch ( error ) {
				// Keep the raw id.
			}
			return { link, heading: doc.getElementById( id ) };
		} ).filter( ( entry ) => entry.heading );

		if ( ! entries.length ) {
			return;
		}

		const bar = followBar( root );
		let active = null;
		watchScroll( () => {
			const line = topOffset() + window.innerHeight * 0.25;
			let current = null;
			entries.forEach( ( entry ) => {
				if ( entry.heading.getBoundingClientRect().top <= line ) {
					current = entry;
				}
			} );

			if ( current !== active ) {
				if ( active ) {
					active.link.classList.remove( 'is-active' );
					active.link.removeAttribute( 'aria-current' );
				}
				if ( current ) {
					current.link.classList.add( 'is-active' );
					current.link.setAttribute( 'aria-current', 'location' );
				}
				active = current;
				if ( bar ) {
					bar.mark( current ? current.link : null );
				}
			}

			if ( bar ) {
				bar.update();
			}
		} );
	}

	/**
	 * The bar of a table of contents that follows the reader (Post_Toc
	 * "Follow the reader"). It lives fixed under the header, so it moves to
	 * <body>, out of any transformed or clipped Elementor container. It shows
	 * while its list is visible on this device but scrolled above the screen
	 * and the article is still being read; it only ever moves by transform.
	 *
	 * @param {HTMLElement} details The table of contents.
	 * @return {?{mark: Function, update: Function}} Null without a bar.
	 */
	function followBar( details ) {
		const bar = details.parentElement && details.parentElement.querySelector( ':scope > [data-stx-tocbar]' );
		if ( ! bar ) {
			return null;
		}

		const toggle = bar.querySelector( '.stx-tocbar__toggle' );
		const panel = bar.querySelector( '.stx-tocbar__panel' );
		const current = bar.querySelector( '[data-stx-tocbar-current]' );
		const progress = bar.querySelector( '[data-stx-tocbar-progress]' );
		const links = Array.from( panel.querySelectorAll( '.stx-toc__link' ) );
		const article = doc.querySelector( '.stx-prose' );
		let shown = false;

		doc.body.appendChild( bar );
		bar.hidden = false;

		// A reading progress widget on the page already shows how far the reader is.
		if ( progress && doc.querySelector( '[data-stx-progress]' ) ) {
			progress.parentElement.remove();
		}

		function setOpen( open ) {
			panel.hidden = ! open;
			toggle.setAttribute( 'aria-expanded', String( open ) );
			bar.classList.toggle( 'is-open', open );
		}

		toggle.addEventListener( 'click', () => setOpen( panel.hidden ), UNDELAYED );
		// The jump itself is the link's own; the list gets out of the way first.
		links.forEach( ( link ) => link.addEventListener( 'click', () => setOpen( false ), UNDELAYED ) );
		doc.addEventListener( 'click', ( event ) => {
			if ( ! panel.hidden && ! bar.contains( event.target ) ) {
				setOpen( false );
			}
		}, UNDELAYED );
		doc.addEventListener( 'keydown', ( event ) => {
			if ( event.key === 'Escape' && ! panel.hidden ) {
				setOpen( false );
				toggle.focus();
			}
		}, UNDELAYED );

		return {
			/** Marks the section being read (a link of the original list, or null). */
			mark( source ) {
				const href = source ? source.getAttribute( 'href' ) : null;
				links.forEach( ( link ) => {
					const on = link.getAttribute( 'href' ) === href;
					link.classList.toggle( 'is-active', on );
					if ( on ) {
						link.setAttribute( 'aria-current', 'location' );
					} else {
						link.removeAttribute( 'aria-current' );
					}
				} );
				current.textContent = source ? source.textContent : '';
			},

			update() {
				// The Elementor editor re-renders widgets: a bar whose list is gone goes too.
				if ( ! details.isConnected ) {
					bar.remove();
					return;
				}

				const top = topOffset();
				const end = article ? article.getBoundingClientRect() : null;
				// A copy hidden on this device (Elementor's visibility) has no box; the stylesheet hides "mobile" bars on computers.
				const visible = details.getClientRects().length > 0
					&& getComputedStyle( bar ).display !== 'none'
					&& details.getBoundingClientRect().bottom < top
					&& ( ! end || end.bottom > top + 120 );

				if ( visible !== shown ) {
					shown = visible;
					bar.classList.toggle( 'is-visible', visible );
					if ( ! visible ) {
						setOpen( false );
					}
				}

				if ( visible && progress && progress.isConnected && end ) {
					const ratio = ( top - end.top ) / Math.max( 1, end.height - ( window.innerHeight - top ) );
					progress.style.transform = 'scaleX(' + Math.min( 1, Math.max( 0, ratio ) ).toFixed( 3 ) + ')';
				}
			},
		};
	}

	/* ---------------------------------------------------------------------
	 * Reading progress
	 * ------------------------------------------------------------------- */

	function initProgress( root ) {
		const bar = root.querySelector( '.stx-progress__bar' );
		const content = doc.querySelector( '.stx-prose' );

		watchScroll( () => {
			let done;
			if ( content ) {
				const box = content.getBoundingClientRect();
				const span = box.height - window.innerHeight * 0.6;
				done = span > 0 ? ( window.innerHeight * 0.4 - box.top ) / span : 1;
			} else {
				const span = doc.documentElement.scrollHeight - window.innerHeight;
				done = span > 0 ? window.scrollY / span : 1;
			}
			bar.style.setProperty( '--stx-read', Math.min( 1, Math.max( 0, done ) ).toFixed( 4 ) );
		} );
	}

	/* ---------------------------------------------------------------------
	 * Blog categories
	 * ------------------------------------------------------------------- */

	/**
	 * Rows of buttons or tabs scroll sideways on phones, so on a category page
	 * the current one can start off screen: centre it, instantly (the visitor
	 * did not ask for motion).
	 */
	function initCategoryRow( list ) {
		const current = list.querySelector( '.is-active' );
		if ( ! current || list.scrollWidth <= list.clientWidth ) {
			return;
		}

		const box = list.getBoundingClientRect();
		const item = current.getBoundingClientRect();
		// A visual distance, so it scrolls the right way in RTL and LTR alike.
		list.scrollBy( { left: item.left + ( item.width / 2 ) - ( box.left + ( box.width / 2 ) ), behavior: 'instant' } );
	}

	function initCategoryMenu( menu ) {
		const toggle = menu.querySelector( 'summary' );

		doc.addEventListener( 'click', ( event ) => {
			if ( menu.open && ! menu.contains( event.target ) ) {
				menu.open = false;
			}
		}, UNDELAYED );

		menu.addEventListener( 'keydown', ( event ) => {
			if ( 'Escape' === event.key && menu.open ) {
				menu.open = false;
				toggle.focus();
			}
		}, UNDELAYED );

		menu.addEventListener( 'focusout', ( event ) => {
			if ( menu.open && event.relatedTarget && ! menu.contains( event.relatedTarget ) ) {
				menu.open = false;
			}
		} );
	}

	/* ---------------------------------------------------------------------
	 * Page title: shortened category description
	 * ------------------------------------------------------------------- */

	function initClamp( box ) {
		const text = box.querySelector( '.stx-archive__text' );
		const button = box.querySelector( '.stx-archive__more' );
		// Two lines that fit need no button.
		if ( ! text || ! button || text.scrollHeight <= text.clientHeight + 1 ) {
			return;
		}

		const more = button.textContent;
		button.hidden = false;
		button.addEventListener( 'click', () => {
			const open = box.classList.toggle( 'is-open' );
			button.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			button.textContent = open ? button.getAttribute( 'data-less' ) : more;
		}, UNDELAYED );
	}

	/* ---------------------------------------------------------------------
	 * Boot (page load and widgets added in the Elementor editor)
	 * ------------------------------------------------------------------- */

	function initScope( scope ) {
		const once = ( selector, init ) => {
			scope.querySelectorAll( selector ).forEach( ( element ) => {
				if ( ! element.hasAttribute( 'data-stx-ready' ) ) {
					element.setAttribute( 'data-stx-ready', '' );
					init( element );
				}
			} );
		};

		once( '.stx-share', initShare );
		once( '[data-stx-toc]', initToc );
		once( '[data-stx-progress]', initProgress );
		once( '.stx-terms--chips .stx-terms__list, .stx-terms--tabs .stx-terms__list', initCategoryRow );
		once( '[data-stx-cat-menu]', initCategoryMenu );
		once( '[data-stx-clamp]', initClamp );
	}

	if ( doc.readyState === 'loading' ) {
		doc.addEventListener( 'DOMContentLoaded', () => initScope( doc ) );
	} else {
		initScope( doc );
	}

	let hooked = false;
	function hookElementor() {
		if ( hooked || ! window.elementorFrontend || ! window.elementorFrontend.hooks ) {
			return;
		}
		hooked = true;
		window.elementorFrontend.hooks.addAction( 'frontend/element_ready/global', ( $scope ) => {
			if ( $scope && $scope[ 0 ] ) {
				initScope( $scope[ 0 ] );
			}
		} );
	}

	// Elementor announces itself with a jQuery event (native listeners do not see it).
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', hookElementor );
	}
	window.addEventListener( 'elementor/frontend/init', hookElementor );
	hookElementor();
}() );
