<?php
/**
 * Product page of an audio product: adds the player to the description
 * (before or after the text) and loads its assets on those pages only.
 *
 * Added through `the_content`, which Studiare's product page
 * (`woocommerce/sc_templates/studi_content.php`) and WooCommerce's
 * description tab run. Studiare+ product templates ask first through
 * `studiare_ext_product_description_extras`, so the player sits outside
 * their collapsible description instead of behind "Show more". What a
 * visitor may hear is decided per visitor, and the files themselves are
 * checked again by Stream on every request, so a cached page never opens
 * a paid track.
 *
 * @package StudiareExt
 */

namespace StudiareExt\Modules\Audio_Products;

use StudiareExt\Core\Asset;
use StudiareExt\Core\Persian;

defined( 'ABSPATH' ) || exit;

final class Frontend {

	public const HANDLE = 'stx-audio-products';

	/** After wpautop (10) and shortcodes (11), so the markup is left as written. */
	private const CONTENT_PRIORITY = 20;

	/** @var Module */
	private $module;

	/** @var bool Whether the player was already added (the description can be filtered twice). */
	private $printed = false;

	/**
	 * @param Module $module Owning module.
	 */
	public function __construct( Module $module ) {
		$this->module = $module;
	}

	public function register(): void {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_filter( 'the_content', array( $this, 'filter_content' ), self::CONTENT_PRIORITY );
		add_filter( 'studiare_ext_product_description_extras', array( $this, 'description_extras' ), 10, 2 );
		add_filter( 'studiare_ext_is_digital_product', array( $this, 'is_digital' ), 10, 2 );
	}

	/**
	 * An audio product is listened to on the site, never shipped (the
	 * Studiare+ thank-you page then shows no packing and delivery steps).
	 *
	 * @param bool        $digital Detected value.
	 * @param \WC_Product $product Product or variation.
	 */
	public function is_digital( $digital, $product ): bool {
		if ( $digital || ! $product instanceof \WC_Product ) {
			return (bool) $digital;
		}

		return '' !== get_post_meta( $product->get_parent_id() ? $product->get_parent_id() : $product->get_id(), Album::META, true );
	}

	public function enqueue_assets(): void {
		if ( $this->viewed_product() ) {
			self::enqueue();
		}
	}

	/** Loads the player's stylesheet and script (also used by the account tab). */
	public static function enqueue(): void {
		wp_enqueue_style( self::HANDLE, Asset::url( 'assets/modules/audio-products/css/audio-products.css' ), array(), STUDIARE_EXT_VERSION );
		wp_enqueue_script(
			self::HANDLE,
			Asset::url( 'assets/modules/audio-products/js/audio-products.js' ),
			array(),
			STUDIARE_EXT_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_add_inline_script( self::HANDLE, 'window.stxAudioProducts = ' . wp_json_encode( self::script_data() ) . ';', 'before' );
	}

	/**
	 * Adds the player to the description of the product being viewed.
	 *
	 * @param string $content Filtered content.
	 */
	public function filter_content( $content ) {
		if ( doing_filter( 'get_the_excerpt' ) || doing_action( 'wp_head' ) || (int) get_the_ID() !== (int) get_queried_object_id() ) {
			return $content;
		}

		$player = $this->take_player();
		if ( '' === $player ) {
			return $content;
		}

		return $this->at_bottom() ? $content . $player : $player . $content;
	}

	/**
	 * Hands the player to a Studiare+ template's description, to print beside it.
	 *
	 * @param array       $extras  `before` / `after` markup.
	 * @param \WC_Product $product Product whose description is printed.
	 */
	public function description_extras( $extras, $product ): array {
		$extras = (array) $extras;
		$player = $product instanceof \WC_Product && (int) $product->get_id() === (int) get_queried_object_id() ? $this->take_player() : '';
		if ( '' !== $player ) {
			$place            = $this->at_bottom() ? 'after' : 'before';
			$extras[ $place ] = ( $extras[ $place ] ?? '' ) . $player;
		}

		return $extras;
	}

	/** The player of the viewed product, once per request ('' afterwards or without audio). */
	private function take_player(): string {
		$product = $this->printed ? null : $this->viewed_product();
		$player  = $product ? $this->module->player( $product, 'product' ) : '';

		$this->printed = $this->printed || '' !== $player;

		return $player;
	}

	private function at_bottom(): bool {
		return 'bottom' === $this->module->settings()['player']['position'];
	}

	/** The product being viewed, when it has audio. */
	private function viewed_product(): ?\WC_Product {
		if ( ! is_singular( 'product' ) || is_feed() || is_embed() || $this->is_page_builder_preview() ) {
			return null;
		}

		$product_id = (int) get_queried_object_id();
		if ( ! metadata_exists( 'post', $product_id, Album::META ) || post_password_required( $product_id ) ) {
			return null;
		}

		$product = wc_get_product( $product_id );

		return $product instanceof \WC_Product ? $product : null;
	}

	/** Inside Elementor's editing canvas the player would sit on top of the template being designed. */
	private function is_page_builder_preview(): bool {
		return class_exists( '\Elementor\Plugin' )
			&& isset( \Elementor\Plugin::$instance->preview )
			&& \Elementor\Plugin::$instance->preview->is_preview_mode();
	}

	/** Strings and settings for audio-products.js. */
	private static function script_data(): array {
		return array(
			'persian' => Persian::is_site_persian(),
			'i18n'    => array(
				/* translators: %s: track title. */
				'play'     => __( 'Play: %s', 'studiare-extensions' ),
				/* translators: %s: track title. */
				'pause'    => __( 'Pause: %s', 'studiare-extensions' ),
				/* translators: %s: playback speed, e.g. 1.5×. */
				'speed'    => __( 'Playback speed: %s', 'studiare-extensions' ),
				/* translators: 1: time listened, 2: length of the track. */
				'position' => __( '%1$s of %2$s', 'studiare-extensions' ),
			),
		);
	}
}
