=== Studiare Extensions ===
Tags: studiare, bottom navigation, elementor, woocommerce, rtl
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.11.11
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Extra features for the Studiare LMS theme: a customizable mobile bottom navigation, Elementor page templates for courses, products, headers, footers and the blog, ready-made home, about us and contact us pages, a floating support button, a "Save as PDF" button and podcast player for blog posts, audio products that buyers listen to on the site, and fixes for known theme problems.

== Description ==

= Mobile bottom navigation =

* Five styles: Classic, Floating glass, Center button (notch), Bubble and Expanding pill — each with a live preview.
* Any number of buttons (up to 8); the layout adapts so it always looks balanced.
* Button types: home, custom link, search sheet, cart (live WooCommerce count, opens the Studiare mini cart), account (avatar and guest label), menu, content sheet (Elementor/shortcode), back to top, dark mode, and "click an element".
* Six bundled SVG icon packs (Lucide, Tabler, Phosphor, Phosphor Duotone, Heroicons, Bootstrap Icons) plus Studiare's Font Awesome, custom images or custom SVG per button.
* Colours, fonts and dark mode follow the Studiare theme by default; every colour, size and font can be overridden.
* Cache friendly (no server-side device detection), accessible (keyboard, screen readers, reduced motion) and RTL-first.

= Page templates (Elementor) =

* 36 ready-made designs, installed as normal Elementor templates: 3 course pages, 3 product pages, 7 headers, 8 footers, 3 home pages, 3 about us pages, 3 contact us pages, 3 blog post lists and 3 blog posts.
* Pages: pick a home, about us or contact us design and create a real WordPress page from it in one click (a home design can become the site's home page), then edit it like any Elementor page. Products, categories, posts and Studiare teachers fill in from the site.
* Blog: one design for post lists (the blog page, categories, tags, authors, dates and blog searches, with page numbers) and one for single posts, with a table of contents, share buttons, author box, related posts and Studiare's own comments.
* Use Studiare's own layout or a template — for all courses/products, per product category (with or without subcategories), or per product from its edit screen.
* Separate header and footer for desktop and for phones/tablets (template, the theme's own, or nothing). Both are printed and switched with CSS, so page caching keeps working.
* 68 Elementor widgets in a "Studiare+" category: product title, price, add to cart (variations, quantity, "already enrolled", "in cart"), gallery with the course intro video, course facts, curriculum from Studiare's lessons, teacher, tabs, reviews, related products, mobile buy bar, logo, menu with mobile drawer, search, cart, login, dark mode switch, copyright (Solar Hijri year), e-Namad badges; for home pages: a fast slider in six designs, hero slides, promo card, product grid (seven card designs, category buttons), product spotlight with a sale countdown, category grid, post grid (blog, magazine, podcasts), features, countdown, offer price, testimonials, teachers & team, events, FAQ (with FAQ structured data), key numbers, picture/video (YouTube, Aparat, Vimeo), logo strip, pricing plans and a newsletter form with a built-in list (CSV download, WordPress privacy tools); for about and contact pages: contact form, map, contact details and timeline; and for the blog: page title, breadcrumb, categories, post title, post details, featured image, post content, table of contents, share buttons, tags, author box, previous/next post, comments and a reading progress bar.
* Persian-first: RTL layouts, Persian digits and separators, widgets inherit the site's Persian font instead of Elementor's default fonts.
* Brand colours in one place (with Studiare dark mode); container "brand surface" and "sticky" options in Elementor.
* Live preview of every design on desktop, tablet and phone before saving.
* Needs Elementor (free) 3.16 or newer with Flexbox Containers; tested with Elementor 3.35 and 4.3 and WooCommerce 11.

= Floating support button =

* One corner button for Telegram, WhatsApp, Bale, Eitaa, Instagram, phone, email and any support page. Type a username, a number (Persian digits and 09… mobiles work) or a link; the admin shows the exact link each channel opens.
* Two designs: a card with a heading and one row per channel, or round brand-coloured bubbles. A single channel turns the button into a direct link with that app's logo.
* WhatsApp can open with a ready-made first message; an optional greeting appears once per visit after a delay you choose.
* Rises automatically above the Studiare+ bottom navigation, sticky buy bars and the theme's "back to top" button, and follows Studiare's colours and dark mode.
* Works without JavaScript (a native disclosure), is cache friendly, and is keyboard and screen reader accessible.

= Cart & checkout =

* New designs for WooCommerce's cart and checkout pages (the classic pages Studiare uses): purchase steps (cart, details & payment, access to the courses or order tracking), items as cards, a sticky order summary beside the form (a folding bar on phones), payment methods as cards and a total bar at the bottom of phones. The cart updates a moment after a quantity changes.
* A coupon box in the summary that shows its answer, right or wrong, under the box instead of a bar at the top; removing a coupon answers there too. WooCommerce's notices are restyled, and cart and checkout messages are in Persian even without WooCommerce's Persian language pack.
* A mini cart to match (the cart that opens from the header and the bottom navigation): items as cards with "Free" for free courses, the total and what sale prices and coupons save, the checkout button first and always in view while the list scrolls, and an inviting empty state. Works in dark mode; the theme's design can be kept.
* A thank-you page to match: an animated tick (with a little confetti after a successful payment), the buyer's name, buttons to their courses or order, the order number, date, total and payment method, a "Ready to start" card for each purchase with its own buttons (start the course, download each file, listen to an audio product in "My audio") and a "What happens next" timeline. Bank transfer, cash on delivery and failed payments each get their own wording and colours (a failed payment offers to pay again). The gateways' details, downloads and addresses are restyled as cards.
* Billing field settings: switch each field on or off, rename it, make it required or optional, choose half or full width and drag fields into order. A cart of only courses and downloads asks only for the fields marked for it (by default name, mobile and email). Add your own fields (text, number, phone, email, list, checkbox, national code with check-digit validation); their answers are saved with the order and shown in the order screen, emails and order details. Mobile numbers typed with Persian digits, +98 or 0098 are accepted and saved as 09….
* Works with Persian WooCommerce and Persian WooCommerce Shipping (Iranian provinces, cities and districts, Pishtaz, courier), shipping to another address, free shipping and every payment gateway. Each page can keep the theme's design while the field settings still apply. Off until switched on.

= Article tools =

* "Save as PDF" on every blog post: a button above the text, a box after it, or both. It opens the browser's print window, where "Save as PDF" is one of the printers, so Persian text, fonts and pictures come out exactly as on the site. Only the article is printed (title, author, date, featured picture, text, a link back to the post and page numbers), also with the browser's own Print command and in dark mode. Authors can hide the button on a single post.
* Podcast player at the top of posts that have an audio version: choose the file from the media library (or paste a link) in the post editor's "Studiare+ article tools" box, with an episode title, narrator, cover and duration. Waveform timeline, 15 seconds back / 30 forward, playback speed, download, "continue where you stopped" and the phone's lock screen controls. Two looks (soft, following dark mode, or an always dark studio). Nothing is downloaded until play is tapped, and without JavaScript the browser's own player shows.

= Audio products =

* Sell audio (audio books, courses, podcasts) as WooCommerce products: add the tracks in the product editor's "Studiare+ audio" box, and buyers listen on the product page and in a "My audio" tab of their account, not only by downloading.
* A free preview for every track: its first seconds (MP3; the site sends only that part of the file), a separate short preview file, the whole track free, or none. When a preview ends the player offers the buy button.
* Files uploaded from the box go to WooCommerce's protected folder and are sent by the site only to visitors allowed to hear them, with seeking; their address never appears on the page. Links to another file host work too.
* Full access only for customers who paid for the product (not subscriptions, roles or being logged in). Downloads for buyers can be switched off per product.
* The audio of a course's Studiare lessons can join the player, with the access set in Studiare (open, logged-in users, buyers, release dates).
* Playlist player with 15 seconds back / 30 forward, previous/next, playback speed, "continue where you stopped", lock screen controls, dark mode and two looks.

= Theme fixes =

* Repairs known problems of the Studiare theme without editing its files, so the fixes survive theme updates. Every fix has its own switch, and the admin shows whether the theme feature it repairs is in use on the site.
* Persian digits in the mobile login: the OTP forms accept numbers typed with a Persian keyboard, pasted with spaces, or written with +98, 0098 or without the first zero.

== Installation ==

1. Upload the `studiare-extensions` folder to `/wp-content/plugins/`.
2. Activate the plugin.
3. Open **Studiare+ → Mobile bottom navigation**, **Studiare+ → Page templates**, **Studiare+ → Floating support button**, **Studiare+ → Cart & checkout** or **Studiare+ → Theme fixes** in the admin menu.

== Changelog ==

= 1.11.11 =
* Theme fixes: "Change mobile number" in the mobile sign-up now starts over from the number. 1.11.10 kept refusing the old email after the change, while the email field was hidden. Now a member's number logs in, and a new number brings the sign-up fields back (still filled in) to be checked again. The send button also comes back after "Change mobile number" once a code has been sent; the theme left it hidden until the page was reloaded.

= 1.11.10 =
* Theme fixes: "Taken email or mobile in the mobile sign-up" also checks the details after "Change mobile number". The theme hid the sign-up fields but kept the terms box ticked, and then sent a code to the new number without checking the email again.

= 1.11.9 =
* Podcast list: every row and card now has a handle on its progress line, so an episode can be moved forward or back right in the list, like the player's timeline. The handle shows on the episode being played and on hover.
* Podcasts: the volume control added in 1.11.8 is removed again; the player looks as before.

= 1.11.8 =
* Podcasts: every podcast player has a volume control: the post player, the Podcast list player, and the current row or card of the list. One level and mute switch for all players on the page, remembered between visits (on iPhone and iPad the button mutes; their volume buttons set the level).
* Podcast list: new "Player side" setting for the player beside the list, so the player can sit on the other side.
* Theme fixes: new "Taken email or mobile in the mobile sign-up" fix. When someone signs up through the theme's mobile login with an email, username or mobile number that already has an account, they now see which one is already registered, before any code is sent, instead of "unknown error".

= 1.11.7 =
* Page templates: the feature is now hidden in the admin (menu, dashboard card, settings page, product template box) until an administrator opens its private unlock link. Templates already in use keep working for visitors, and pages are still edited in Elementor with every Studiare+ widget.

= 1.11.6 =
* Theme fixes: with WordPress 7.1 and WooCommerce before 11.1, ticking an order's checkbox in the WooCommerce orders list opened the order instead of selecting it. The new "Order list checkboxes" fix makes the checkboxes select orders again, so bulk actions work.

= 1.11.5 =
* Checkout: "Login before checkout" opened the login popup only once the whole page had loaded, which on a slow site came while the visitor was already typing their number, and closed the popup. It now opens as soon as the page is ready and never closes an open popup.
* Page templates: the "added to cart" message of Studiare+ product cards and the Offer price widget was in English ("Notification", "Product added to cart!"); it now names the product in the site's language.

= 1.11.4 =
* Checkout: new "Login before checkout" setting (Cart & checkout → Checkout page). Guests cannot open the checkout from any link; they get the theme's login popup over the cart or the account page, with your own message, and go straight on to the checkout after logging in instead of their account.

= 1.11.3 =
* Theme fixes: on hosts that switch off PHP's mail(), every order email crashed the order half way, so Persian WooCommerce SMS never sent the buyer's and the admin's texts and the payment return page failed. The new "Order emails on hosts without PHP mail()" fix sends through sendmail when possible, or skips the email, and the order carries on (install an SMTP plugin to deliver the emails).
* Checkout: while Persian WooCommerce SMS is active, the mobile field it reads always stays in the checkout form (that plugin refuses an order without it).

= 1.11.2 =
* Performance: whether a logged-in student owns a course is remembered until their next order change. The theme's purchase check is a slow database query and ran once per listed product on every page a student opened (shop page: 16 queries from the plugin, now 2).
* Performance: the "My audio" tab rebuilds the site's rewrite rules at most once an hour when its address is missing, never on every page view.

= 1.11.1 =
* Fix: the thank-you page showed packing and delivery steps for courses that are not marked "virtual" (for example paid cash on delivery). Courses (the theme's course switch or lessons), audio products, virtual and downloadable products now always get the learning steps, and cash on delivery for them reads "you pay later, in the way you chose".
* Audio products: choose the place of the "My audio" tab in the account menu (Audio products → Customer account): automatic (after Downloads) or any place counted from the top; "Log out" stays last.
* Audio courses: the "Study and learning" button in Studiare's "My courses" tab opens the course's player in "My audio" instead of an empty lesson list (courses with lessons open as before). A switch in Audio products → Customer account turns it off.
* Audio products on the thank-you page open the buyer's audio in "My audio" ("Listen", also the main button; several audio products lead to the "My audio" tab) instead of "Start the course" with an empty lesson list.

= 1.11.0 =
* New: thank-you page design (Cart & checkout → Checkout page → Thank-you page). An animated tick (confetti after a successful payment), the buyer's name, the order number, date, total and payment method, its own wording and colour for paid, cash on delivery, awaiting payment (bank transfer, cheque) and failed payments ("Try paying again"), and a "What happens next" timeline. The gateway's details (bank account), downloads and addresses are cards.
* New: "Ready to start" on the thank-you page: each purchase with its own buttons, "Start the course", one per download file (then "All downloads"), and "Listen" for audio products, which opens that product's player in "My audio". With one item, its button is the main button of the page.
* New: mini cart design (Cart & checkout → Cart page → Mini cart) for the cart that opens from the header and the bottom navigation: items as cards, "Free" for free courses, what sale prices and coupons save, the checkout button first and always in view, a designed empty cart, dark mode. The theme's design can be kept.
* Fix: with bank transfer or cheque, the buyer saw "Your order could not be completed because of an error on the site" when the order email (or another plugin) failed while the order was put on hold, although the order was placed. Such an order now opens its thank-you page; the error is still saved in the order notes and WooCommerce's log.
* WP Rocket (Delay JavaScript): the thank-you page's buttons open on the first tap.

= 1.10.2 =
* Fix: on sites with a Studiare+ header the cart page lost its layout: the items and the order summary sat apart at different heights (and squeezed together on phones), because the header's cart button shared a class name with the cart page. The cart page now has its own class names.
* Fix: the cart's order summary stays beside the items and sticks while scrolling; the theme's own cart rules moved it 150px down.
* Fix: the phone total bar sits at the bottom of the screen above the bottom navigation; with Studiare's page wrapper it appeared near the footer.
* Cart & checkout: a free course reads "Free" instead of a zero price.

= 1.10.1 =
* Fix: with the Cart & checkout module on, the cart page stopped loading on WooCommerce older than 11.2 (only the theme's preloader showed) as soon as the cart held a product. The cart works with every recent WooCommerce again.

= 1.10.0 =
* New: Cart & checkout module (Studiare+ → Cart & checkout). New cart and checkout designs with purchase steps, a sticky order summary, a coupon box with its messages under it, a phone total bar and restyled notices; billing field settings (order, labels, required, width, fields for courses and downloads, your own fields such as a national code). Compatible with Persian WooCommerce and Persian WooCommerce Shipping.
* Compatibility: WP Rocket's "Delay JavaScript" (3.17 and newer) held back the plugin's tap listeners until the delayed scripts had loaded, even though the plugin's scripts are excluded from delaying, and then replayed the first tap: the bottom navigation, support button and audio players reacted only after a second or more on phones, iOS refused to start audio from the replay, and a replayed tap could close a sheet that had just opened. The plugin's listeners now react at once and Rocket no longer replays taps they handled.
* Compatibility: WP Rocket's "Load JavaScript deferred" and "Combine JavaScript files" leave the plugin's inline settings in place.
* Bottom navigation: the cart badge shows the right count at once on pages served from a page cache, also before the first tap under "Delay JavaScript".

= 1.9.3 =
* Theme fix: no second purchase of an owned course. A course added to the cart before logging in, or through a learning path bundle, used to reach checkout again. Students now see "You are a student of this course" instead of the buy button, an owned course leaves the cart with a short note, and checkout never takes it (products set to "can be bought again" are not affected).
* Theme fix: checkout error after placing an order. When another plugin fails while an order is placed (for example the order email on a host without mail()), a completed free or 100% coupon order now opens its thank-you page instead of "There was an error processing your order", other orders get a clear message, and the error is saved in the order notes and WooCommerce > Status > Logs.
* Audio products: the "My audio" account tab lists each product as a card; a card opens that product's player on its own page.

= 1.9.2 =
* Compatibility: WP Rocket and LiteSpeed Cache. The plugin's scripts stay out of "Delay JavaScript" (LiteSpeed does not replay the first tap, so the first tap on play, a sheet or the menu button was lost), and its stylesheets are kept whole by "Remove Unused CSS" / "UCSS" (states the scripts add later would lose their styles). Hooks that need jQuery attach whenever it arrives, also when the cache plugin delays it.
* Compatibility: audio stream answers tell LiteSpeed not to cache them before its output buffer closes.
* Theme fix "Account page after popup login" also covers LiteSpeed's "Instant Click" (links to the account, cart and checkout pages get `data-no-instant`).

= 1.9.1 =
* Security: Audio products open in full only for customers who paid for that product. A Studiare subscription, being logged in, or a role that can edit products (such as teachers) no longer unlocks the tracks; Studiare lessons for "logged-in users" also need the purchase in the player. Store managers still hear every track to check the files, and the player says so.
* Security: contact form and newsletter CSV exports neutralise cells that a spreadsheet would run as formulas (CSV injection).
* Fix: the "My audio" tab shows in every Studiare account menu (top icons, side menu, mobile menu) for every logged-in customer, with the headphones icon, and its address keeps working when rewrite rules are rebuilt.
* Fix: audio stream answers tell page caches and CDNs (LiteSpeed, Cloudflare and others) never to store them.
* New theme fix: after logging in through Studiare's login popup the account page opened with the login form until refreshed (the browser had prefetched it as a guest). Account, cart and checkout pages are no longer prefetched.

= 1.9.0 =
* New: Audio products. Buyers listen to a product's audio on the site (product page and a "My audio" account tab) with a dedicated player; other visitors hear a free preview of each track (its first seconds, a separate file, or the whole track). Files are sent only to those allowed to hear them. The audio of Studiare lessons can join the player.

= 1.8.4 =
* New: Floating support button: Rubika as a contact channel (username or rubika.ir link).
* New: Floating support button: make up to 6 channels of your own for any other social network or page, each with its name, link, note, colour and icon (from the icon library, an image from the media library, or SVG code). They are ordered with the others and also show in the Contact details widget.
* New: Contact details widget: Rubika, and "Other network" items with an icon from Elementor's library (or an uploaded SVG) and a brand colour.

= 1.8.3 =
* Fix: Add to cart widget: a sold-out product (a full course) no longer shows Studiare's grey box with hard-to-read red text; the «Capacity is full!» message takes the buy button's place and size, in a soft red that follows the brand colours and dark mode.
* New: Theme fixes: "Sold-out course button" does the same on Studiare's own course pages.

= 1.8.2 =
* New: Podcast list: an "Episode page" button that opens the episode's post, in the player, on every row and on every card (its text is editable; empty hides it).

= 1.8.1 =
* New: Podcast list widget with four looks. Three play the episodes right on the page (a player beside or above the episode list, episode cards, playable rows), with seeking, 15/30 second jumps, speed, previous/next and "continue where you stopped"; the fourth is a list of links beside a picture. Show every podcast or only chosen categories (or the category being viewed). Its small stylesheet is printed inline and its script is deferred, and nothing is downloaded before play is tapped.
* New: "Page · Podcasts" page design, and the podcast sections of the Complete and Studiare home designs now play their episodes.
* New: Blog page title: a category's description can be shortened to two lines with "Read more" (the whole text stays in the page for search engines) or left out.

= 1.8.0 =
* New: Article tools (Studiare+ → Article tools): a "Save as PDF" button on every blog post that prints a clean copy of the article (Persian text and fonts as on the site, dark mode turned light on paper), and a podcast player at the top of posts with an audio version, set from the post editor.
* New: Table of contents: "Follow the reader" (on for phones and tablets by default). Once the list scrolls away, a slim bar under the header names the section being read, shows the reading progress and opens the list; it never moves the article.

= 1.7.1 =
* Fix: Add to cart widget: choosing a variation no longer fails with "please choose product options" (Studiare's hidden radio list overrode the choice), and the buttons look no longer shows Studiare's select box or repeats the buttons after each change.
* Fix: Contact form: a chosen topic is no longer dropped when the default topics are translated or the page is cached, and a host without PHP mail() no longer makes a saved message answer "not sent".

= 1.7.0 =
* New: Theme fixes (Studiare+ → Theme fixes). Repairs known problems of the Studiare theme without editing its files; each fix has its own switch.
* Fix: the theme's mobile login (OTP) now accepts numbers typed with a Persian keyboard (۰۹۱۲…) instead of saying "must be exactly 11 digits", and numbers written with +98, 0098 or without the first zero. Covers the combined login/registration form and the older separate forms.
* New: Blog categories widget in nine looks. Navigation (marks the category being viewed): row of buttons, tabs, list with post counts, list with subcategories and a drop-down. Showcase: icon cards, picture cards, name over the picture, and each category with its newest posts. Categories from the site, the subcategories of the category being viewed, or a hand-picked list with a picture and icon each; uses the colour and icon set for each category in Studiare.
* New: Navigation menu: optional second tab in the mobile drawer (product categories or another menu).
* Fix: Category grid now shows the icon Studiare saves for blog categories (it read the product category icon).

= 1.6.0 =
* New: Page templates → Blog. Three designs for post lists (Magazine, With sidebar, Minimal) and three for single posts (Classic, Focus, Cover). Post lists cover the blog page, categories, tags, authors and dates (and, when switched on, blog searches), with page numbers.
* New: 14 blog widgets: blog page title, blog breadcrumb, blog categories, post title, post details (author, date, last update, reading time, comments), featured image (loads first for PageSpeed), post content styled for reading (headings, quotes, code, tables that scroll on phones), table of contents (marks the section being read), share buttons (Telegram, WhatsApp, X, LinkedIn, email, copy link and the phone's share sheet), tags, author box, previous/next post, comments (Studiare's own comment form) and a reading progress bar.
* New: Post grid lists "Posts of the page being viewed" with page numbers and "Related to the post being viewed", has a Magazine layout and "Highlight the first post", and three new cards: Editorial, Row and Compact list (with numbers).
* New: five more product card designs in Product grid: Course (teacher, lessons, duration, students), Picture, Minimal, Classic shop and Row (with numbers, for "Top 5" lists).
* New home widgets: Product spotlight (a deal of the day with a countdown to the end of its sale and a sold/left bar), Logo strip (a moving row or a grid) and Pricing plans.
* New: About us and contact us pages. Page templates → Pages (formerly "Home pages") has three about designs (Story, Minimal, Academy) and three contact designs (Cards, Split, Support centre). "Create page" makes a normal Elementor page from any of them.
* New: Contact form widget. Messages are kept in Studiare+ → Contact messages (a list with a "new" count, reply by email, CSV download, WordPress privacy tools) and can also be emailed to an address set on the widget. Works without JavaScript and on cached pages (honeypot + rate limit, no nonce). A form plugin's shortcode can replace it.
* New: Map widget: OpenStreetMap or Google Maps with no API key, or a pasted Neshan/Balad embed. Optional "load on click", an address card, and directions buttons for Neshan, Balad, Google Maps and Waze.
* New: Contact details widget (phone, email, address, hours, Telegram, WhatsApp, Bale, Eitaa, Instagram) as cards, a list or brand buttons. It can show the floating support button's channels, so they are typed once.
* New: Timeline widget (line, both sides, or steps in a row).
* Improved: Key numbers widget: icons, "Tiles" and "Large numbers" looks, columns, and a count-up that keeps the layout still and leaves the real number for search engines and screen readers.
* Improved: X and LinkedIn icons in every icon pack.
* Fix: a centred Heading now also centres its small label and its (narrower) subtitle.

= 1.5.0 =
* New: Floating support button (Studiare+ → Floating support button). Telegram, WhatsApp, Bale and Eitaa, plus Instagram, phone, email and a custom support page; drag to reorder. Card or bubbles design, brand colours, WhatsApp first message, optional greeting, left or right corner, per-device display.
* The button moves up by itself above the bottom navigation (and back down when the navigation hides while scrolling), above sticky buy bars and above the theme's "back to top" button.

= 1.4.0 =
* New: Slider widget in six designs: banner, hero with text, centre with side peeks, cards (several at once), with side banners, and with title tabs. Separate phone pictures, slide or fade effect, autoplay with a pause button, arrows, dots and keyboard/swipe control.
* New: Slider picture loading for PageSpeed and GTmetrix: "Top of the page" loads the first picture at once with high priority (and tells caching plugins not to lazy-load it) and each next picture only when it is needed; "Lower on the page" lazy-loads them all; or no lazy loading. The slider keeps its exact space before pictures load (no layout shift), needs no jQuery or carousel library, prints its few kilobytes of CSS inline and loads one small deferred script.
* Improved: the plugin serves minified CSS and JavaScript (readable files with SCRIPT_DEBUG); the brand colours are printed inline, so a page with only the slider does not load the page templates stylesheet.

= 1.3.1 =
* New: Product grid → "Slide on every screen": the cards sit in one row that slides sideways on computers too, with arrow buttons and mouse dragging; "Columns" sets how many are in view. The shop grid of the home page designs uses it and shows 8 products.

= 1.3.0 =
* New: Page templates → Home pages. Three ready-made home page designs (Complete, Studiare, Bright shop); "Create page" makes a normal Elementor page from a design, published or as a draft, and can make it the site's home page. Studiare's title bar is switched off on these pages.
* New: 15 widgets for home pages (see the description). Grids can become a swipe row on phones; picture placeholders keep a page looking finished until real pictures are added.
* New: newsletter list for the Newsletter widget: no setup needed, spam-protected without breaking cached pages, downloadable as CSV, and included in WordPress's personal data export and erase tools. Any newsletter plugin's form can be used instead (shortcode).
* New: Heading widget: section-title style (« title ——— link), a link at the end of the row, pill labels and <mark> highlights. Icon list: numbered steps. Button: "White" style. Containers: "Accent gradient" surface.
* Fix: in Studiare's dark mode, text on light and amber buttons turned white (the theme colours every link white); buttons now keep their own colours. Highlighted text and sale prices no longer get the theme's dark highlight box.

= 1.2.1 =
* Fix: live search no longer lists the home page (or the blog, shop, cart, checkout, account and Studiare header/footer pages) for almost every term. Elementor stores a text copy of everything these pages show, so they matched any search.
* Fix: with the admin bar on phones, the sticky header stopped 46px below the top and page content showed above it.
* Fix: a smart sticky header no longer covers the sticky buy box or the section jump bar when it slides back in.
* Change: the sticky header setting is now the first card of Page templates → Header, named "Sticky header" (Off / Always / Smart).
* Change: the floating header fades the page out behind its bar while stuck.

= 1.2.0 =
* Fix: course pages showed "You are enrolled" to every logged-in user (Studiare's purchase check returns the text "false", which counted as yes). Enrollment now uses the same test as Studiare's lesson list, subscriptions included.
* Fix: the header cart button did not open Studiare's mini cart (the theme closed it again on the same click).
* Fix: on phones the course cover collapsed and covered the title and excerpt.
* Fix: Studiare's product-page script no longer throws on every scroll when the footer is replaced.
* New: every header design has its own compact phone bar (menu, logo, search, cart); logos are sized by height so square logos stay small. Two new headers: Dark and Minimal.
* New: live search results under the header search field and in the search overlay (can be switched off per widget).
* New: three new footers (Split, Support, Soft); every footer centres its content on phones.
* New: Course · Spotlight keeps the buy card beside the title from the top of the page.
* New: bottom navigation can be hidden on single course or product pages.
* New: live search results in the bottom navigation's search sheet (can be switched off per button), and the button can search several post types at once.
* New: the search sheet's results show course covers, highlighted matches, prices (sale prices included) or dates, a result count, a "See all results" button, and loading placeholders.
* Change: the course curriculum shows Studiare's own lesson list to everyone by default.
* Change: templates use Elementor's site container width, so headers and footers line up with the page content; unedited ready-made templates are updated automatically.
* Change: darker muted and accent text colours for readable small text.

= 1.1.0 =
* New: Page templates — Elementor designs for course pages, product pages, headers and footers, with category rules, per-device headers/footers and live previews.

= 1.0.0 =
* First release: mobile bottom navigation.

== Credits ==

* Vazirmatn font — SIL Open Font License 1.1 (assets/admin/fonts/OFL.txt).
* Icons: Lucide (ISC), Tabler Icons (MIT), Phosphor Icons (MIT), Heroicons (MIT), Bootstrap Icons (MIT).
