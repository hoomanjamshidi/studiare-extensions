<?php
/**
 * Single Roadmap
 * since version 13.4
 */






add_filter('studi_custom_dynamic_css', function($css){
            $css .= "
                p.bun_price_nor { text-decoration: line-through; color: #3d3d3d; font-size: 14px; }
                p.bun_price_dis {  color: #b41474; font-size: 16px; }
                .rm_dis { background: var(--primary_color); color: white; padding: 4px 8px; border-radius: 999px; font-weight: 700; font-size: 10px; display: flex; align-items: center; justify-content: center; width: auto; line-height: 1; }
                
                .roadmap-body i { font-style: normal; }
                .roadmap_second_row{transform:translateY(-11px);} 
                .rdesc{margin:20px 0;}
                .roadmap_descriptions { width: 40%; }
                .roadmap_featured_img { width: 100%; }
                .roadmap_featured_img img { aspect-ratio: 16 / 9; width: 100%; border-radius: 10px;border-radius: 10px;max-height: 270px; object-fit: contain;}
                .roadmap-header { display: flex; gap: 15px; align-items: top;margin-top:50px; }
                .base-player{ display: flex; font-size: 1.25em; overflow: hidden; position: relative; width: 100%; z-index: 0; }
                video.base-player__video { border-radius: 10px; -o-object-fit: contain; object-fit: contain; height: 100%; width: 100%; }
                span.st_road_icon svg { font-size: 32px; }
                
                .roadmap-card { background: #fff; border-radius: 10px; box-shadow: 0 0 10px #3d3d3d33; display: flex; flex-direction: column; margin-top: 40px; padding-bottom: 10px; padding-left: 15px; padding-right: 15px; position: relative; z-index: 2; }
                .roadmap-card__number { height: 37.7%; top: -2px; font-size: 17px; font-weight: 500; }
                
                .roadmap-body {position:relative;}
                .roadmap-body__img { max-width: 434px;max-height: 330px; }
                .roadmap-body__road--first{display: flex; margin-top: -2.54%; max-width: 50%; position: relative; width: 100%; z-index: 1;}
                .roadmap-body__img-box { max-width: 100%; }
                .roadmap-body__road svg, .roadmap-body__road--first svg, .roadmap-body__road--left svg, .roadmap-body__road--right svg { width: 100%; }
                .roadmap-card--right:last-of-type, .roadmap-card:last-of-type { margin-bottom: 55px; } 
                .roadmap-card, .roadmap-card--right { background: #fff; border-radius: 10px; box-shadow: 0 0 10px #3d3d3d33; display: flex; flex-direction: column; margin-top: 40px; padding-bottom: 10px; padding-left: 15px; padding-right: 15px; position: relative; z-index: 2; }
                
                .roadmap-body__road--right { transform: rotate(180deg); } 
                .roadmap-body__road, .roadmap-body__road--first, .roadmap-body__road--left, .roadmap-body__road--right { display: flex; margin-top: -2.54%; max-width: 50%; position: relative; width: 100%; z-index: 1; }
                
                .roadmap-body__road--left{ transform: translate(calc(-100% + 1px)); }
                .roadmap-card__text-box p { font-size: 16px; font-weight: 500; }
                .roadmap-body__half-road-svg svg { display: flex; max-width: 45%; width: 100%; }
                .roadmap-body__half-road-box, .roadmap-body__half-road-box--right { display: flex; margin-top: -2.5%; max-width: 30%; transform: translate(-94%); width: 100%; }
                .rhalf_left { transform: rotatey(180deg) translateX(38%); transform-origin: left; }
                button.button.add-bundle-to-cart.single_add_to_cart_button.alt {padding-inline-start: 60px;}
                
                @media only screen and (max-width: 768px) {
                    .roadmap-header { flex-direction: column-reverse; margin-top: 0;}
                    .roadmap_descriptions { width: 100%; }
                    .roadmap_first_row { flex-direction: column; }
                    .roadmap-body__road--right { transform: rotate(0deg); }
                    .roadmap-body__road, .roadmap-body__road--first, .roadmap-body__road--left, .roadmap-body__road--right { max-width: 100%; }
                    .roadmap-body__half-road-box, .roadmap-body__half-road-box--right { display: none; }
                    .roadmap-body__road--left { transform: translate(0, 0); }
                    .roadmap_price_box { flex-direction: column; margin: 20px 0; }
                    .roadmap_price_box .roadmap_addtocart { width:100%;justify-content: center; }
                    .roadmap_price_box button { width: calc(100% - 20px); }
                    .roadmap-body__img { max-width: 284px; }
                    
                    .st_hide_inmob{display:none;}
                    
                }
                @media only screen and (min-width: 900px) {
                    .roadmap-body { padding-top: 85px; }
                    .roadmap-body__img-box { margin-top: -3.5%; max-width: 50%; } 
                    .roadmap-body__road--first { display: block; } 
                    .roadmap-card--right:last-of-type, .roadmap-card:last-of-type { margin-bottom: 0; } 
                    .roadmap-card, .roadmap-card--right { flex-direction: row; margin-top: 0; padding-top: 10px; position: absolute; right: 0; top: 50%; transform: translate(10%, -25%) scale(.65); z-index: 1; } 
                    .roadmap-card__text-box { max-width: 236px; }
                }
                
                 
                 @media only screen and (min-width: 1801px) { 
                 .roadmap-card, .roadmap-card--right { transform: translate(0); } 
                 } 
                 @media only screen and (min-width: 1200px) { 
                 .roadmap-card, .roadmap-card--right { transform: translate(-5%, -15%) scale(1); } 
                 .roadmap-card--right { transform: rotate(180deg) translate(10%, 40%) scale(1); }
                 } 
                  
                             "; 
            return $css;
        });
//remove page title        
remove_filter('load_studipage_title','st_loading_page_title');
get_header(); 
 

//get roadmap data
$post_id = get_the_ID();

$roadmap_title   = get_post_meta($post_id, 'st_rm_title', true)?:get_the_title();
$roadmap_video   = get_post_meta($post_id, 'st_rm_video_url', true)?:null;
$roadmap_data    = get_post_meta($post_id, 'roads_group', true)?:null;
$sell_as_bundle  = get_post_meta($post_id, 'st_rm_sab', true)?:null;
$discount        = get_post_meta($post_id, 'st_rm_discount', true)?:0;
$icon_color      = get_post_meta($post_id, 'st_rm_icon_color', true)?:'#87b7ff';
$start_img       = get_post_meta($post_id, 'st_rm_start_img', true)?:get_template_directory_uri().'/assets/images/roadmap_start_default_img.webp';

$road_icon  = '<svg xmlns="http://www.w3.org/2000/svg" width="1em" fill="none" viewBox="0 0 40 40" style="--svg-origin-width:1000;--svg-origin-width--with-unit:1000px;" data-svg-origin-width="1000" data-svg-origin-height="" font-size="1000"><g stroke="#e37c32" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"><path d="m19.994 35 .003-5M20.006 8.333 20.008 5M20 21.667l.003-5M10.131 8.889a1.67 1.67 0 0 1 1.242-.556l17.8.003c.92 0 1.667.746 1.667 1.666v5.007c0 .92-.747 1.667-1.667 1.667l-17.8-.002c-.474 0-.926-.202-1.242-.556l-2.24-2.503a1.667 1.667 0 0 1 0-2.223zM29.869 22.216a1.67 1.67 0 0 0-1.242-.556l-17.8.003c-.92 0-1.667.746-1.667 1.666v5.007c0 .92.746 1.667 1.667 1.667l17.8-.003c.474 0 .926-.201 1.242-.555l2.24-2.503a1.667 1.667 0 0 0 0-2.223z"></path></g></svg>';
$step_icon  = '<svg width="1000" viewBox="0 0 64 93" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M28.7831 76.5164L8.07436 53.1971C-4.69268 38.8236 -1.97843 16.5095 13.8045 5.65392C24.762 -1.88464 39.238 -1.88464 50.1955 5.65392C65.9784 16.61 68.6927 38.8236 55.9256 53.1971L35.2169 76.5164C33.5079 78.5267 30.4921 78.5267 28.7831 76.5164Z" fill="'.$icon_color.'"></path><path d="M32.0075 49.2797C41.668 49.2797 49.4993 41.4494 49.4993 31.7903C49.4993 22.1311 41.668 14.3008 32.0075 14.3008C22.347 14.3008 14.5156 22.1311 14.5156 31.7903C14.5156 41.4494 22.347 49.2797 32.0075 49.2797Z" fill="white"></path><path d="M32.0036 92.9985C43.5517 92.9985 52.9134 90.7035 52.9134 87.8723C52.9134 85.0412 43.5517 82.7461 32.0036 82.7461C20.4554 82.7461 11.0938 85.0412 11.0938 87.8723C11.0938 90.7035 20.4554 92.9985 32.0036 92.9985Z" fill="'.$icon_color.'"></path></svg>';
$leftroad   = '<svg class="st_hide_inmob" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 652 336"><g clip-path="url(#clip0_1406_9974)"><path fill="#c5c3c3" d="M161 336c-21.143 0-42.079-4.345-61.612-12.788s-37.282-20.818-52.232-36.418-26.81-34.12-34.9-54.503C4.163 211.908 0 190.062 0 168s4.164-43.908 12.255-64.291 19.95-38.903 34.9-54.503c14.951-15.6 32.7-27.975 52.233-36.418S139.857 0 161 0v33c-16.914 0-33.663 4.076-49.29 10.83-15.626 6.755-29.825 16.655-41.785 29.135s-21.448 27.296-27.92 43.602C35.53 132.874 32.2 150.35 32.2 168s3.331 35.127 9.804 51.433 15.96 31.122 27.92 43.602 26.16 22.38 41.786 29.134S144.086 303 161 303z"></path><path fill="url(#paint0_linear_1406_9974)" d="M652 33h491v33H652z" transform="rotate(180 652 33)"></path><path stroke="#fff" stroke-dasharray="30 30" stroke-width="2" d="M170 321a153.001 153.001 0 0 1 0-306"></path><path stroke="#fff" stroke-dasharray="30 30" stroke-width="4" d="M670 15H170m139 306H170"></path><path fill="#c3c1c1" d="M161 336h491v-33H161z"></path><path stroke="#fff" stroke-dasharray="30 30" stroke-width="4" d="M161 320h486.463"></path></g><defs><linearGradient id="paint0_linear_1406_9974" x1="960.5" x2="652" y1="66" y2="66" gradientUnits="userSpaceOnUse"><stop stop-color="#c5c3c3"></stop><stop offset="1" stop-color="#c5c3c3" stop-opacity="0"></stop></linearGradient><clipPath id="clip0_1406_9974"><path fill="#fff" d="M0 0h652v336H0z"></path></clipPath></defs></svg>';
$right_road = '<svg class="st_hide_inmob" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 652 336"><g clip-path="url(#clip0_1406_9973)"><path fill="#c5c3c3" d="M161 336c-21.143 0-42.079-4.345-61.612-12.788s-37.282-20.818-52.232-36.418-26.81-34.12-34.9-54.503C4.163 211.908 0 190.062 0 168s4.164-43.908 12.255-64.291 19.95-38.903 34.9-54.503c14.951-15.6 32.7-27.975 52.233-36.418S139.857 0 161 0v33c-16.914 0-33.663 4.076-49.29 10.83-15.626 6.755-29.825 16.655-41.785 29.135s-21.448 27.296-27.92 43.602C35.53 132.874 32.2 150.35 32.2 168s3.331 35.127 9.804 51.433 15.96 31.122 27.92 43.602 26.16 22.38 41.786 29.134S144.086 303 161 303zM786 33H161V0h625z"></path><path stroke="#fff" stroke-dasharray="30 30" stroke-width="2" d="M170 321a153.001 153.001 0 0 1 0-306"></path><path stroke="#fff" stroke-dasharray="30 30" stroke-width="4" d="M670 15H170m139 306H170"></path><path fill="#c3c1c1" d="M161 336h491v-33H161z"></path><path stroke="#fff" stroke-dasharray="30 30" stroke-width="4" d="M161 320h486.463"></path></g><defs><clipPath id="clip0_1406_9973"><path fill="#fff" d="M0 0h652v336H0z"></path></clipPath></defs></svg>';
$half_road  = '<svg class="st_hide_inmob" xmlns="http://www.w3.org/2000/svg" width="1000" fill="none" viewBox="0 0 179 276"><path fill="#c3c1c1" d="m178.105 168.305-1.667 106.99-33.398-.42 1.668-106.99z"></path><path fill="#c3c1c1" d="M0 .023C23.337.021 46.475 5.628 68.035 14.036s41.151 20.731 57.652 36.269c16.502 15.538 29.592 33.984 38.522 54.287s13.527 42.063 13.527 64.039l-33.237.382c0-18.021-2.519-36.242-9.842-52.89S116.6 84.348 103.069 71.608 73.474 48.76 55.794 41.867 19.136 33.047 0 33.049z"></path><path stroke="#fff" stroke-dasharray="30 30" stroke-width="2" d="M19.996 15.543C66.496 21.02 119.704 50.798 148 111.02c28.296 60.221 11.498 148.001 11.498 148.001"></path></svg>';

// Container start
$site_inner = array('site-content-inner container');
$container  = array('main-page-content default-margin');
?>
<div class="<?php echo esc_attr( implode( ' ', $container ) ); ?>" id="content">
    
	<div class="<?php echo esc_attr( implode( ' ', $site_inner ) ); ?>" role="main">
	    
	    <section class="roadmap-header">
	        
	        <div class="roadmap_descriptions flex flex-2 flex-col justify-between">
	            <?php
	                echo "<div class='flex flex-col  gap-4'>";
	                    echo "<div class='st_rd_top flex items-center'><span class='st_road_icon'>$road_icon</span><h1> $roadmap_title</h1></div>"; 
	                
	                    echo "<div>";
	                        echo the_content(); 
	                    echo "</div>";
	                echo "</div>";
	                if($sell_as_bundle){
    	                if($roadmap_data){
    	                    $ids =[];
    	                    foreach($roadmap_data as $item){
    	                        $ids[] = $item['course'];
    	                    }
    	                    $ids = implode(',',$ids);
    	                    echo do_shortcode('[st_bundle_add_to_cart ids="'.$ids.'" discount="'.$discount.'" bundle_id="'.$post_id.'"]');
    	                }
    	                
	                }
	            ?>
            </div>
            
	        <div class="roadmap_featured_img flex-1">
	            <?php
	                if($roadmap_video != null){
	                    $poster = get_the_post_thumbnail_url( $post_id, 'full' )?:''; 
	                    ?>
	                    <div class="base-player">
    	                    <video  class="base-player__video " height="100%" width="100%" controls="" type="video/mp4" preload="none" poster="<?php echo $poster;?>" controlslist="nodownload" oncontextmenu="return false;">
            	                <source  src="<?php echo $roadmap_video;?>" type="video/mp4" preload="none">
            	            </video>
        	            </div>
	                    <?php
	                }else{
	                    echo the_post_thumbnail('large');
	                }
	             ?>
	            
	        </div>
	        
	    </section>
	    
	    <div class="roadmap-body">
	        <?php   
	        $rstep = 1;
	        $road_side = "--left";
	        foreach($roadmap_data as $roadmap_item){
	            $title   = $roadmap_item['title'];
	            $desc    = $roadmap_item['desc'];
	            $course  = $roadmap_item['course'];
	            $product = wc_get_product( $course );
	            
	            
	            if($rstep == 1){
	                
	                echo "<div class='roadmap_first_row w-full flex items-start justify-center'>";
	                
	                    echo "<span class='roadmap-body__img-box w-full flex self-center justify-center'><img class='roadmap-body__img' alt='$roadmap_title' src='$start_img'></span>";
	                    echo "<i class='flex items-center justify-center roadmap-body__road--first'>$leftroad";
	                        
	                        echo "<div class='roadmap-card gap-3'>";
	            
            	                echo "<div class='roadmap-card__text-box w-full flex-1'>";
                	                echo "<div class='h-full flex flex-col justify-between'><div>";
                	                    echo "<i class='flex justify-center items-center relative' style='margin: 20px 0;width: 40px; height: 40px;'>$step_icon<span class='roadmap-card__number absolute'>$rstep</span></i>";
                	                    echo "<p>$title</p>";
                	                    echo "<div class='rdesc'>$desc</div>";
                	                echo "</div></div>"; 
                	             echo "</div>";      
                	                echo "<div class='roadmap-card__text-box w-full flex-1'><div class='roadmap-card__content'>";
                	                    include locate_template('woocommerce/product_cards/pro_card_layout_06.php');
                	                echo "</div></div>";     
            	                
            	                
            	           echo "</div>";
	           
	                    echo "</i>";
	                echo "</div>";
	                
	            }
	            
	            
	            if($rstep == 2){
	                $sec_row = "<div class='roadmap_second_row flex-col w-full justify-center'>";
	            }
	            
	            if($road_side == '--right'){$bholder = $road_side;$rholder = $road_side;}else{$bholder = '--left';$rholder = '';}
	             
	             $sec_row .= "<i class='flex items-center justify-center roadmap-body__road$bholder'>$right_road";
	             $sec_row .= "<div class='roadmap-card$rholder gap-3'>";
	            
	                $sec_row .= "<div class='roadmap-card__text-box  w-full  flex-1'>";
    	                $sec_row .= "<div class='h-full flex flex-col justify-between'><div>";
    	                    $sec_row .= "<i class='flex justify-center items-center relative' style='margin: 20px 0;width: 40px; height: 40px;'>$step_icon<span class='roadmap-card__number absolute'>$rstep</span></i>";
    	                    $sec_row .= "<p>$title</p>";
    	                    $sec_row .= "<div>$desc</div>";
    	                $sec_row .= "</div></div>"; 
    	                 $sec_row .= "</div>";  
    	                $sec_row .= "<div class='roadmap-card__text-box w-full flex-1'><div class='roadmap-card__content'>";
    	                ob_start();
    	                     include locate_template('woocommerce/product_cards/pro_card_layout_06.php');
    	                $sec_row .= ob_get_clean();    
    	                $sec_row .= "</div>";     
    	                $sec_row .= "</div>";     
	                //$sec_row .= "</div>"; 
	                
	           $sec_row .= "</div>";   
	           $sec_row .= "</i>";   
	           
	           if($rstep == count($roadmap_data)){
	               if(count($roadmap_data) %2 == 0){$end_svg = "rhalf_left";}else{$end_svg = "rhalf_right";}
	                $sec_row .= "<i class='flex items-center justify-center roadmap-body__half-road-svg roadmap-body__half-road-box $end_svg'>$half_road</i>";
	                $sec_row .= "</div>";
	            }
	           
	           $rstep ++;
	           
	           if($road_side == '--right'){$road_side = '--left';}else{$road_side = '--right';}
	           wp_reset_postdata(); 
	        } 
	        
	        
	        echo $sec_row;
	        
	        ?> 
	    </div>

	</div>
	
</div>
	 
<?php



get_footer();