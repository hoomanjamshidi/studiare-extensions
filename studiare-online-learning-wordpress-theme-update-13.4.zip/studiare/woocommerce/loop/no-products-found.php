<?php
/**
 * Displayed when no products are found matching the current query
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/no-products-found.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.8.0
 */

defined( 'ABSPATH' ) || exit;
$empty_resault_img = get_stylesheet_directory_uri() . '/assets/images/not-found.svg';
?>

<div class="container flex justify-center items-center flex-col lg:flex-row gap-3 woocommerce-no-products-found">
    <div class='studi_empty_resault'>
        <img src='<?php echo $empty_resault_img ; ?>' class='studi_empty_resault_img' alt='not found' width='186' height='136'>
    </div>
	<?php wc_print_notice( esc_html__( 'No products were found matching your selection.', 'studiare' ), 'notice' ); ?>
</div>
