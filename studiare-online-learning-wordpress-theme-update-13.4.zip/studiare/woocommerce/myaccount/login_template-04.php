<?php
/**
 * Combined Login/Register Template
 * created date:1405-01-31
 */
$custom_logo_image = get_theme_file_uri('assets/images/logo_default.svg'); 
$showLogo = true;
if (class_exists('Redux')) {
    $showLogo = codebean_option('show_logo_in_login') ?: $showLogo;
    $logo_uploaded = codebean_option('custom_logo_image');
    if (isset($logo_uploaded['url']) && $logo_uploaded['url'] != '') {
        $custom_logo_image = $logo_uploaded['url'];
    }
    
}
?>
<div class="sc_login_temp4 st_rl_t4_holder">
    
    <?php if ($showLogo == 1) { ?>
        <div class="main-site-logo">
            <div class="studiare-logo-wrap">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="studiare-logo studiare-main-logo" rel="home">
                    <img src="<?php echo esc_url($custom_logo_image); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
                </a>
            </div>
        </div>
    <?php } ?>
    
    <?php
        echo do_shortcode("[combined_otp_form]");
    ?>
</div>


<style>
    .st_rl_t4_holder #verify-otp, .st_rl_t4_holder #otp_phone {letter-spacing: 13px;text-align:center; }
    .sc_login_temp4 { background: #fff; padding: 25px; border-radius: 7px; max-width: 400px; margin: 0 auto; }
    .sc_login_temp4 .main-site-logo { margin: 0 auto; max-width: 200px; }
    .Msc_login_temp4 input[type="text"], .Msc_login_temp4 input[type="password"]{ padding: 8px 10px; display: block; box-shadow: 0 0px 1px 0px rgba(0, 0, 0, 0.25); margin-bottom: 10px; width: 100%; border: none; border-radius: 7px; }
    .sc_login_temp4 #terms-container { margin-bottom: 10px; }
    .sc_login_temp4 button { width: 100%; }
    
    @keyframes sc_otp_spinner {
      to {transform: rotate(360deg);}
    }
     
    .sc_otp_spinner:before {
      content: '';
      box-sizing: border-box;
      position: absolute;
      top: 50%;
      left: 50%;
      width: 20px;
      height: 20px;
      margin-top: -10px;
      margin-left: -10px;
      border-radius: 50%;
      border: 1px solid #f6f;
      border-top-color: #0e0;
      border-right-color: #0dd;
      border-bottom-color: #f90;
      animation: sc_otp_spinner .6s linear infinite;
    }
</style>