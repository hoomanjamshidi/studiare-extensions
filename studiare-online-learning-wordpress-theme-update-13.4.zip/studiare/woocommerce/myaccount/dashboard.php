<?php
/**
 * My Account Dashboard
 *
 * Shows the first intro screen on the account dashboard.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/dashboard.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes. old 2.6.0
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce/Templates
 * @version     4.4.0
 */

if (!defined('ABSPATH')) {
    exit;
}

$custom_dashboard_page_id = '';

if (class_exists('Redux')) {
    $custom_dashboard_page_id = codebean_option('sc_custom_dashboard_page');
}

if (!empty($custom_dashboard_page_id) && function_exists('icl_object_id')) {
    $custom_dashboard_page_id = icl_object_id($custom_dashboard_page_id, 'page', true);
}

$custom_dashboard_page_id = absint($custom_dashboard_page_id);

if (
    $custom_dashboard_page_id > 0 &&
    function_exists('studiare_render_custom_dashboard_page') &&
    studiare_can_render_custom_dashboard_page($custom_dashboard_page_id)
) {
    echo studiare_render_custom_dashboard_page($custom_dashboard_page_id);
} else {
    if (function_exists('studiare_render_default_dashboard')) {
        echo studiare_render_default_dashboard();
    } else {
        echo do_shortcode('[default_dashboard]');
    }
}

/**
 * My Account dashboard.
 *
 * @since 2.6.0
 */
do_action('woocommerce_account_dashboard');

/**
 * Deprecated woocommerce_before_my_account action.
 *
 * @deprecated 2.6.0
 */
do_action('woocommerce_before_my_account');

/**
 * Deprecated woocommerce_after_my_account action.
 *
 * @deprecated 2.6.0
 */
do_action('woocommerce_after_my_account');