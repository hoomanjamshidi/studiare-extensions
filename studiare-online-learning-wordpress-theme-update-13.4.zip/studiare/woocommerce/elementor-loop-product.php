<?php
defined( 'ABSPATH' ) || exit;

$loop_id = $GLOBALS['studiare_current_loop_id'] ?? '';

if ( empty( $loop_id ) || ! class_exists( '\Elementor\Plugin' ) ) {
    return;
}

$plugin = \Elementor\Plugin::instance();

// Enqueue global Elementor assets (important for JS widgets)
$plugin->frontend->enqueue_styles();
$plugin->frontend->enqueue_scripts();

echo '<div class="course-item elementor-loop-item">';
echo $plugin->frontend->get_builder_content( $loop_id, true ); // true = print inline CSS
echo '</div>';