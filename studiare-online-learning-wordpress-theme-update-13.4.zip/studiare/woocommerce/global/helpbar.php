<?php
$catalog_ordering_view = codebean_option('catalog_ordering_view');

if (empty($catalog_ordering_view)) {
    $catalog_ordering_view = 'inline';
}

$show_mode = codebean_option('courses_layout_mode');
if ($show_mode == 'grid') {
    $grid_active = "active";
    $list_active = "";
} else {
    $grid_active = "";
    $list_active = "active";
}
?>

<div class="courses-top-bar">
    <div class="courses-top-bar-inner flex flex-wrap items-center">

        <?php if (have_posts()) : ?>
            <div class="courses-top-bar-left flex flex-wrap items-center gap-2">
                <div class="ordering-filter <?php echo esc_attr($catalog_ordering_view === 'inline' ? 'scorderby-inline-mode' : 'scorderby'); ?>">
                    <?php if ($catalog_ordering_view === 'inline') : ?>
                        <?php studiare_catalog_ordering_inline(); ?>
                    <?php else : ?>
                        <?php woocommerce_catalog_ordering(); ?>
                    <?php endif; ?>
                </div>

                <div class="results-count">
                    <?php woocommerce_result_count(); ?>
                </div>
            </div>

            <div class="courses-top-bar-right flex items-center gap-2">
                <div class="layout-switcher switch-courses-layout" data-layout="grid-view">
                    <a href="#" class="switcher-view-grid <?php echo esc_attr($grid_active); ?> hint--top" aria-label="<?php esc_html_e('grid view', 'studiare'); ?>">
                        <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 13c1.105 0 2 .895 2 2v4c0 1.105-.895 2-2 2H5c-1.105 0-2-.895-2-2v-4c0-1.105.895-2 2-2h4zm10 0c1.054 0 1.918.816 1.995 1.851L21 15v4c0 1.054-.816 1.918-1.851 1.995L19 21h-4c-1.054 0-1.918-.816-1.995-1.851L13 19v-4c0-1.054.816-1.918 1.851-1.995L15 13h4zM9 15H5v4h4v-4zm10 0h-4v4h4v-4zM19 3c1.054 0 1.918.816 1.995 1.851L21 5v4c0 1.054-.816 1.918-1.851 1.995L19 11h-4c-1.054 0-1.918-.816-1.995-1.851L13 9V5c0-1.054.816-1.918 1.851-1.995L15 3h4zM9 3c1.054 0 1.918.816 1.995 1.851L11 5v4c0 1.054-.816 1.918-1.851 1.995L9 11H5c-1.054 0-1.918-.816-1.995-1.851L3 9V5c0-1.054.816-1.918 1.851-1.995L5 3h4zM19 5h-4v4h4V5zM9 5H5v4h4V5z" fill="currentColor"/>
                        </svg>
                    </a>

                    <a href="#" class="switcher-view-list <?php echo esc_attr($list_active); ?> hint--top" aria-label="<?php esc_html_e('list view', 'studiare'); ?>">
                        <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M7 13c1.054 0 1.918.816 1.995 1.851L9 15v3c0 1.054-.816 1.918-1.851 1.995L7 20H4c-1.054 0-1.918-.816-1.995-1.851L2 18v-3c0-1.054.816-1.918 1.851-1.995L4 13h3zm13 0c.552 0 1 .448 1 1s-.448 1-1 1H12c-.552 0-1-.448-1-1s.448-1 1-1h8zM7 15H4v3h3v-3zm9 2c.552 0 1 .448 1 1s-.448 1-1 1H12c-.552 0-1-.448-1-1s.448-1 1-1h4zM7 3c1.105 0 2 .895 2 2v3c0 1.105-.895 2-2 2H4c-1.105 0-2-.895-2-2V5c0-1.105.895-2 2-2h3zm13 0c.552 0 1 .448 1 1s-.448 1-1 1H12c-.552 0-1-.448-1-1s.448-1 1-1h8zM7 5H4v3h3V5zm9 2c.552 0 1 .448 1 1s-.448 1-1 1H12c-.552 0-1-.448-1-1s.448-1 1-1h4z" fill="currentColor"/>
                        </svg>
                    </a>
                </div>

                <div class="courses-search">
                    <?php get_product_search_form(); ?>
                </div>
            </div>
        <?php else : ?>
            <div class="courses-top-bar-right flex items-center gap-2">
                <div class="courses-search">
                    <?php get_product_search_form(); ?>
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>
