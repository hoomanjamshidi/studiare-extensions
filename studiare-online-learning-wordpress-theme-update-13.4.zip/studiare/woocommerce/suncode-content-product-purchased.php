<?php
/**
 * product card for use anywhere
 * pro_card_layout_06
 * maktabkhooneh style
 * created: 1404-12-07 
 * */

/**
 * Ensure $product and $post_id are available even outside loops
 */
if ( ! isset( $product ) || ! is_a( $product, 'WC_Product' ) ) {
    global $post;

    if ( isset($post->ID) ) {
        $post_id = $post->ID;
        $product = wc_get_product( $post_id );
    } elseif ( isset( $post_id ) ) {
        $product = wc_get_product( $post_id );
    }
}

if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
    return; // stop if not a valid product
}

$post_id = $product->get_id();

$meta = studiare_get_course_meta($post_id);  


$day_for_new = codebean_option('days_for_new') ?: "7";

// get all product info
$info_args = array("rating", "rating_count", "is_new", "has_certificate", "discount_percent", "studiare_badges"); 
$pro_info = sc_get_pro_info($info_args);
$img_size = codebean_option('shop_pro_image_size', 'studiare-course-thumb');
?>

<div class="course-item">
        <div class="pro_card_layout_06_box">
            <a href="<?php echo get_the_permalink($post_id); ?>" class="pro_card_layout_06_link"></a>
            <div class="pcl06_card" >
                
                <span class="pcl06_object-cover">
                <?php 
                    if (has_post_thumbnail($post_id)) {
                        echo get_the_post_thumbnail($post_id, $img_size, ['class' => 'img-fluid']);
                    } else {
                        $default_img = codebean_option('product_no_image', 'default') == 'custom' ? codebean_option('product_no_image_custom')['thumbnail'] : get_template_directory_uri().'/assets/images/noimage.jpg';
                        echo '<img src="'.esc_url($default_img).'" class="img-fluid" alt="'.get_the_title($post_id).'">';
                    }
                ?>
                </span>

                <div class="pcl06_top text-center">
                    <div class="pcl06_th_alt"  >
                        <div class="pcl06_title_alt font-semibold mb-10"><?php echo get_the_title( $post_id ); ?></div>
                    </div>
                    <?php
                    $purchase_date = sc_get_purchase_date( $post_id );
                    if ( $purchase_date ) :
                    
                        // Check if it's a course
                        if ( is_sc_course( $post_id ) ) {
                            $label = esc_html__( 'Enrollment date:', 'studiare' );
                        } else {
                            $label = esc_html__( 'Purchase date:', 'studiare' );
                        }
                        ?>
                        
                        <div class="purchased-date">
                            <?php echo $label . ' ' . esc_html( $purchase_date ); ?>
                        </div>
                    
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>