<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ) {
    return;
}

add_filter( 'excerpt_length', 'studiare_product_custom_excerpt_length', 999 );

$post_id = get_the_ID();
$meta    = studiare_get_course_meta( $post_id );
?>

<div <?php wc_product_class( 'studiProGrid course-item' ); ?>>

<div class="education_block_list_layout">

    <?php sc_render_product_badges(); ?>

    <div class="education_block_thumb n-shadow">
        <?php if ( has_post_thumbnail() ) : ?>
            <?php woocommerce_template_loop_product_link_open(); ?>
                <span class="image-item">
                    <?php
                    $image_size = codebean_option("shop_pro_image_size");
                    the_post_thumbnail($image_size, array('class'=>'img-fluid'));
                    ?>
                </span>
            <?php woocommerce_template_loop_product_link_close(); ?>
        <?php endif; ?>
    </div>

    <div class="list_layout_ecucation_caption">

        <h4 class="course-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h4>

        <div class="course-content-main">

            <?php if ( $meta['sc_course_type_selector'] == 2 ) : ?>
                <div class="course-loop-element__course-type course-loop-element__course-type--onsite">
                    <?php echo esc_html( $meta['sc_course_type_title_2'] ); ?>
                </div>
            <?php elseif ( $meta['sc_course_type_selector'] == 1 ) : ?>
                <div class="course-loop-element__course-type course-loop-element__course-type--online">
                    <?php echo esc_html( $meta['sc_course_type_title_1'] ); ?>
                </div>
            <?php endif; ?>

            <div class="course-rating-teacher">

                <?php
                $product_stars = class_exists('Redux') ? codebean_option("product_stars") : true;
                $st_icon = $product_stars ? '' : '<i class="fal fa-star"></i>';
                ?>

                <div class="sc-rating">
                    <?php echo $st_icon; ?>
                    <?php woocommerce_template_loop_rating(); ?>
                </div>

                <?php
                // Teachers (modular)
                echo studiare_get_teachers_html( $meta );
                ?>

            </div>

            <?php
            // Optional excerpt (modular)
            echo studiare_get_course_excerpt( $post_id );
            ?>

        </div>

        <div class="course-content-bottom">

            <?php
            // Students counter
            if ( codebean_option('product_danshjou_icon_view') ) :

                $icon_raw  = !empty($meta['course_buyers_text_icon'])
                    ? $meta['course_buyers_text_icon']
                    : codebean_option('danshjou_icon');

                $icon_class = studiare_normalize_icon_class( $icon_raw );

                $hint = !empty($meta['course_buyers_text_hint'])
                    ? $meta['course_buyers_text_hint']
                    : "تعداد دانشجویان";

                $count = get_post_meta($post_id,'total_sales', true);
            ?>
                <div class="course-students hint--top-left" aria-label="<?php echo esc_attr($hint); ?>">
                    <i class="<?php echo esc_attr($icon_class); ?>"></i>
                    <span><?php echo number_format_i18n($count); ?></span>
                </div>
            <?php endif; ?>

            <div class="course-price flex gap-0.5">
                <?php echo studiare_get_course_price_html( $product ); ?>
            </div>

        </div>

        <?php
        // Main Feature
        if ( codebean_option('product_sc_loop_main_feature') ) :

            $feat_text = $meta['sc_loop_main_feature'] ?: $meta['course_duration'];
            $feat_hint = $meta['sc_loop_main_feature_hint'] ?: $meta['course_duration_hint'];
            $feat_icon = !empty($meta['sc_loop_main_feature_icon'])
                ? studiare_normalize_icon_class($meta['sc_loop_main_feature_icon'])
                : 'fal fa-clock';

            if ( !empty($feat_text) ) :
        ?>
            <div class="course-content-mid">
                <div class="course-info-unit-time hint--top" aria-label="<?php echo esc_attr($feat_hint); ?>">
                    <div class="value">
                        <i class="<?php echo esc_attr($feat_icon); ?>"></i>
                        <?php echo esc_html($feat_text); ?>
                    </div>
                </div>
            </div>
        <?php
            endif;
        endif;
        ?>

    </div>

</div>

</div>