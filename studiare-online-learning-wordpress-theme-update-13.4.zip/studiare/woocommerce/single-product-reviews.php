<?php
/**
 * Display single product reviews (comments)
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product-reviews.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.7.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! comments_open() ) {
	return;
}

if (class_exists('Redux')) {
    $use_emojis = codebean_option('product_single_rating_mode');
    $rating_enabled = codebean_option("woocommerce_enable_review_rating");
} else {
    $use_emojis = false;
    $rating_enabled ="1";
}

//https://codepen.io/suez/details/MezwON
?>
<div id="reviews" class="woocommerce-Reviews">
    <div class="product-reviews-inner">
                <?php
                    if($rating_enabled == '1'):
                        $product = wc_get_product(get_the_id());
                        $rating_count = $product->get_rating_count();
                        $average      = $product->get_average_rating();
                        $average = round($average, 1); ?>
                        <div class="product-reviews-stats flex flex-col lg:flex-row gap-6">
                            <!-- Averate Rating -->
                            <div class="average-rating flex-1">
                                <p class="rating-subtitle"><?php esc_html_e('Average Rating', 'studiare');?></p>
                                <div class="avareage-rating-inner flex flex-col items-center">
                                    <div class="average-rating-number"><?php echo esc_attr($average); ?></div>
                                    <div class="average-rating-stars">
                                        <?php do_action( 'woocommerce_after_shop_loop_item_title' ); ?>
                                    </div>
                                    <div class="average-rating-label">
                                        <?php echo esc_attr($rating_count.' '.esc_html__('Ratings', 'studiare')); ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Detailed Ratings-->
                            <?php
                            // WP_Comment_Query arguments
                            $args = array (
                                'status'         => 'approve',
                                'type'           => 'review',
                                'post_id'        => get_the_id(),
                            );

                            // The Comment Query
                            $woo_reviews = new WP_Comment_Query;
                            $comments = $woo_reviews->query( $args );

                            $rate1 = $rate2 = $rate3 = $rate4 = $rate5 = 0;
                            // The Comment Loop
                            if ( $comments ) {
                                foreach ( $comments as $comment ) {
                                    $rate = get_comment_meta($comment->comment_ID, 'rating', true);
                                    switch($rate) {
                                        case 1:
                                            $rate1++;
                                            break;
                                        case 2:
                                            $rate2++;
                                            break;
                                        case 3:
                                            $rate3++;
                                            break;
                                        case 4:
                                            $rate4++;
                                            break;
                                        case 5:
                                            $rate5++;
                                            break;
                                    } // switch
                                }
                            }
                            $rates = array('5'=>$rate5,'4'=>$rate4,'3'=>$rate3,'2'=>$rate2,'1'=>$rate1);
                            ?>
                            <div class="detailed-ratings flex-3">
                                <p class="rating-subtitle"><?php esc_html_e('Detailed Rating', 'studiare');?></p>
                                <div class="detailed-ratings-inner flex flex-col gap-5">
	                                <?php foreach($rates as $key => $rate): ?>
		                                <?php
		                                if($rate !=0 or $rating_count != 0) {
			                                $fill_value = round($rate*100/$rating_count, 2);
		                                } else {
			                                $fill_value = 0;
		                                }
		                                ?>
                                        <div class="course-rating flex items-center gap-1.5">
                                            <span class="number"><?php echo esc_attr($key.' '.__('Stars', 'studiare')); ?></span>
                                            <div class="bar">
                                                <div class="bar-fill" style="width:<?php echo esc_attr($fill_value); ?>%"></div>
                                            </div>
                                            <span class="counter"><?php echo esc_attr($rate); ?></span>
                                        </div>
	                                <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
    <div id="comments">
        <h2 class="woocommerce-Reviews-title">
            <?php
            $count = $product->get_review_count();
			if ( $count && wc_review_ratings_enabled() ) {
                $reviews_title = sprintf( esc_html( _n( '%1$s review for %2$s', '%1$s reviews for %2$s', $count, 'studiare' ) ), esc_html( $count ), '<span>' . get_the_title() . '</span>' );

				echo apply_filters( 'woocommerce_reviews_title', $reviews_title, $count, $product ); // WPCS: XSS ok.
            } else {
				esc_html_e( 'Reviews', 'studiare' );
            }
            ?>
        </h2>

		<?php if ( have_comments() ) : ?>
			<ol class="commentlist">
				<?php wp_list_comments( apply_filters( 'woocommerce_product_review_list_args', array( 'callback' => 'woocommerce_comments' ) ) ); ?>
            </ol>
            <?php
			if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
                echo '<nav class="woocommerce-pagination">';
                paginate_comments_links(
                    apply_filters(
                        'woocommerce_comment_pagination_args',
                        array(
                            'prev_text' => is_rtl() ? '&rarr;' : '&larr;',
                            'next_text' => is_rtl() ? '&larr;' : '&rarr;',
                            'type'      => 'list',
                        )
                    )
                );
                echo '</nav>';
            endif;
            ?>
        <?php else : ?>
			<p class="woocommerce-noreviews"><?php esc_html_e( 'There are no reviews yet.', 'studiare' ); ?></p>
        <?php endif; ?>
    </div>

	<?php if ( get_option( 'woocommerce_review_rating_verification_required' ) === 'no' || wc_customer_bought_product( '', get_current_user_id(), $product->get_id() ) ) : ?>
        <div id="review_form_wrapper">
            <div id="review_form">
                <?php
				$commenter    = wp_get_current_commenter();
                $comment_form = array(
					'title_reply'         => have_comments() ? esc_html__( 'Add a review', 'studiare' ) : sprintf( esc_html__( 'Be the first to review &ldquo;%s&rdquo;', 'studiare' ), get_the_title() ),
					'title_reply_to'      => esc_html__( 'Leave a Reply to %s', 'studiare' ),
					'title_reply_before'  => '<span id="reply-title" class="comment-reply-title" role="heading" aria-level="3">',
                    'title_reply_after'   => '</span>',
                    'comment_notes_after' => '',
					'label_submit'        => esc_html__( 'Submit', 'studiare' ),
                    'logged_in_as'        => '',
                    'comment_field'       => '',
                );

                if ($use_emojis && wc_review_ratings_enabled()) {
                    $comment_form['comment_field'] = '
                    <svg class="fb-emotes-svg" style="display: none;">
                    <symbol id="fb-emote-terrible" data-emote="terrible" viewBox="0 0 100 100">
                    <path class="fb-emote__eye fb-emote__eye--left" d="M32,25 l10,10 a10,10 0 0,1 -20,0 a10,10 0 0,1 10,-10"/>
                    <path class="fb-emote__eye fb-emote__eye--right" d="M58,35 l10,-10 a10,10 0 0,1 0,20 a10,10 0 0,1 -10,-10"/>
                    <path class="fb-emote__smile" d="M30,68 q20,-13 40,0 M30,68 q20,-13 40,0"/>
                    </symbol>
                    <symbol id="fb-emote-bad" data-emote="bad" viewBox="0 0 100 100">
                    <path class="fb-emote__eye fb-emote__eye--left" d="M22,35 l10,-10 a10,10 0 0,1 0,20 a10,10 0 0,1 -10,-10"/>
                    <path class="fb-emote__eye fb-emote__eye--right" d="M68,25 l10,10 a10,10 0 0,1 -20,0 a10,10 0 0,1 10,-10"/>
                    <path class="fb-emote__smile" d="M30,68 q20,-10 40,0 M30,68 q20,-10 40,0"/>
                    </symbol>
                    <symbol id="fb-emote-okay" viewBox="0 0 100 100">
                    <path class="fb-emote__eye fb-emote__eye--left" d="M32,25 a10,10 0 0,1 0,20 a10,10 0 0,1 0,-20"/>
                    <path class="fb-emote__eye fb-emote__eye--right" d="M68,25 a10,10 0 0,1 0,20 a10,10 0 0,1 0,-20"/>
                    <path class="fb-emote__smile" d="M35,73 q20,-4 35,-8 M35,73 q20,-4 35,-8"/>
                    </symbol>
                    <symbol id="fb-emote-good" viewBox="0 0 100 100">
                    <path class="fb-emote__eye fb-emote__eye--left" d="M32,25 a10,10 0 0,1 0,20 a10,10 0 0,1 0,-20"/>
                    <path class="fb-emote__eye fb-emote__eye--right" d="M68,25 a10,10 0 0,1 0,20 a10,10 0 0,1 0,-20"/>
                    <path class="fb-emote__smile" d="M30,68 q20,10 40,0 M30,68 q20,10 40,0"/>
                    </symbol>
                    <symbol id="fb-emote-great" viewBox="0 0 100 100">
                    <path class="fb-emote__eye fb-emote__eye--left" d="M32,25 a10,10 0 0,1 0,20 a10,10 0 0,1 0,-20"/>
                    <path class="fb-emote__eye fb-emote__eye--right" d="M68,25 a10,10 0 0,1 0,20 a10,10 0 0,1 0,-20"/>
                    <path class="fb-emote__smile" d="M30,68 q20,15 40,0 M30,68 q20,0 40,0"/>
                    </symbol>
                    </svg>
                    <div class="comment-form-rating ">
                     <label>' . esc_html__('Your rating', 'studiare') . '</label>
                     <div class="fb-cont">
                        <div class="fb-cont__inner">
                            <div class="fb-emote" data-rating="1" data-emote="terrible">
                                <svg><use xlink:href="#fb-emote-terrible"></use></svg>
                                <p class="fb-emote__caption">' . esc_html__('Very poor', 'studiare') . '</p>
                            </div>
                            <div class="fb-emote" data-rating="2" data-emote="bad">
                                <svg><use xlink:href="#fb-emote-bad"></use></svg>
                                <p class="fb-emote__caption">' . esc_html__('Not that bad', 'studiare') . '</p>
                            </div>
                            <div class="fb-emote" data-rating="3" data-emote="okay">
                                <svg><use xlink:href="#fb-emote-okay"></use></svg>
                                <p class="fb-emote__caption">' . esc_html__('Average', 'studiare') . '</p>
                            </div>
                            <div class="fb-emote" data-rating="4" data-emote="good">
                                <svg><use xlink:href="#fb-emote-good"></use></svg>
                                <p class="fb-emote__caption">' . esc_html__('Good', 'studiare') . '</p>
                            </div>
                            <div class="fb-emote" data-rating="5" data-emote="great">
                                <svg><use xlink:href="#fb-emote-great"></use></svg>
                                <p class="fb-emote__caption">' . esc_html__('Perfect', 'studiare') . '</p>
                            </div>
                            
                             <input type="hidden" name="rating" id="rating" value="" />
                        </div>
                        </div>
                    </div>';
                } else {
                    $comment_form['comment_field'] = '<div class="comment-form-rating"><label for="rating" id="comment-form-rating-label">' . esc_html__( 'Your rating', 'studiare' ) . ( wc_review_ratings_required() ? '&nbsp;<span class="required">*</span>' : '' ) . '</label><select name="rating" id="rating" required>

                    <option value="">' . esc_html__( 'Rate&hellip;', 'studiare' ) . '</option>
						<option value="5">' . esc_html__( 'Perfect', 'studiare' ) . '</option>
						<option value="4">' . esc_html__( 'Good', 'studiare' ) . '</option>
						<option value="3">' . esc_html__( 'Average', 'studiare' ) . '</option>
						<option value="2">' . esc_html__( 'Not that bad', 'studiare' ) . '</option>
						<option value="1">' . esc_html__( 'Very poor', 'studiare' ) . '</option>
					</select></div>';
				}
				$comment_form['comment_field'] .= '<p class="comment-form-comment"><label for="comment">' . esc_html__( 'Your review', 'studiare' ) . '&nbsp;<span class="required">*</span></label><textarea id="comment" name="comment" cols="45" rows="8" required></textarea></p>';

				comment_form( apply_filters( 'woocommerce_product_review_comment_form_args', $comment_form ) );
                ?>
            </div>
        </div>
    <?php else : ?>
		<p class="woocommerce-verification-required"><?php esc_html_e( 'Only logged in customers who have purchased this product may leave a review.', 'studiare' ); ?></p>
    <?php endif; ?>
    <div class="clear"></div>
</div>
<?php if ($use_emojis && wc_review_ratings_enabled()) { ?>
    <?php
    // Enqueue custom CSS for emoji rating
    wp_enqueue_style(
        'emoji-rating-css',
        get_template_directory_uri() . '/assets/css/emoji-rating.css',
        array(),
        '1.0'
    );

    // Enqueue custom JS for emoji rating
    wp_enqueue_script(
        'emoji-rating-js',
        get_template_directory_uri() . '/assets/js/emoji-rating.js',
        array('jquery'),
        '1.0',
        true
    );
    ?>
<?php } ?>