<?php
/**
 * product card for use anywhere
 * pro_card_layout_06
 * maktabkhooneh style
 * created: 1404-12-07 
 * */

/**
 * Ensure $product and $post_id are available even outside loops
 */
if ( ! isset( $product ) || ! is_a( $product, 'WC_Product' ) ) {
    global $post;

    if ( isset($post->ID) ) {
        $post_id = $post->ID;
        $product = wc_get_product( $post_id );
    } elseif ( isset( $post_id ) ) {
        $product = wc_get_product( $post_id );
    }
}

if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
    return; // stop if not a valid product
}

$post_id = $product->get_id();

$meta = studiare_get_course_meta($post_id);  


$day_for_new = codebean_option('days_for_new') ?: "7";

// get all product info
$info_args = array("rating", "rating_count", "is_new", "has_certificate", "discount_percent", "studiare_badges"); 
$pro_info = sc_get_pro_info($info_args); 
$img_size = codebean_option('shop_pro_image_size', 'studiare-course-thumb');

?>

<div class="course-item">
        <div class="pro_card_layout_06_box">
            <a href="<?php echo get_the_permalink($post_id); ?>" class="pro_card_layout_06_link" aria-label="<?php echo get_the_title( $post_id ); ?>"></a>
            <div class="pcl06_card" >
                
                <span class="pcl06_object-cover">
                <?php 
                    if (has_post_thumbnail($post_id)) {
                        echo get_the_post_thumbnail($post_id, $img_size, ['class' => 'img-fluid']);
                    } else {
                        $default_img = codebean_option('product_no_image', 'default') == 'custom' ? codebean_option('product_no_image_custom')['thumbnail'] : get_template_directory_uri().'/assets/images/noimage.jpg';
                        echo '<img src="'.esc_url($default_img).'" class="img-fluid" alt="'.get_the_title($post_id).'">';
                    }
                ?>
                </span>

                <div class="pcl06_top">
                    <div class="pcl06_th"  >
                        <h3 class="pcl06_title"><?php echo get_the_title( $post_id ); ?></h3>
                    </div>

                    <div class="pcl06_teacher">
                        <?php echo studiare_get_teachers_html($meta); ?>
                    </div>
                </div>

                <div class="pcl06_bottom flex flex-col">
                    <div class="pcl06_bottom_box" >
                        <div class="pcl06_bottom_r1 flex flex-wrap items-center gap-1"  >
                            <div class="cmeta_info flex items-center gap-1">
                                <span ><?php echo number_format_i18n($product->get_total_sales()); ?></span>
                                <span ><?php echo esc_attr($meta['course_buyers_text_hint'] ?: __("Student", "studiare")); ?></span>
                            </div>
                            
                            <?php if($pro_info['rating']){ ?>
                                <div class="cmeta_info flex items-center gap-1"style=" background:#fefbec;  color:#334155; ">
                                    <span class="nuxt-svg-icon custom-size -mt-2" style="display:inline-flex; margin-top:-2px;" >
                                        <svg xmlns="http://www.w3.org/2000/svg" width="1em" fill="#ffab17" viewBox="0 0 12 12" style="width:14px; height:14px;">
                                            <path d="M8.96 7.16a.55.55 0 0 0-.16.485l.444 2.46a.54.54 0 0 1-.225.54.55.55 0 0 1-.585.04L6.22 9.53a.6.6 0 0 0-.25-.066h-.136a.4.4 0 0 0-.135.045L3.484 10.67a.6.6 0 0 1-.355.055.556.556 0 0 1-.445-.636l.445-2.46a.56.56 0 0 0-.16-.489L1.165 5.39a.54.54 0 0 1-.134-.565.56.56 0 0 1 .444-.375l2.485-.36a.56.56 0 0 0 .44-.305L5.494 1.54a.5.5 0 0 1 .1-.135l.045-.035a.3.3 0 0 1 .08-.065l.055-.02.085-.035h.21a.56.56 0 0 1 .44.3l1.11 2.235a.56.56 0 0 0 .415.305l2.485.36c.21.03.386.175.455.375.066.2.01.42-.145.565z"></path>
                                        </svg>
                                    </span>
                                    <span ><?php echo $pro_info['rating'];?></span> 
                                    <!---->
                                </div>
                                <div class="cmeta_info flex items-center gap-1" >
                                    <?php echo sprintf( esc_html__( '%s Votes', 'studiare' ), $pro_info['rating_count'] );?>  
                                </div>
                            <?php } ?> 
                            
                        </div> 

                        <div class="pcl06_bottom_r2 flex flex-wrap items-center gap-1"  >
                            
                            <?php if($pro_info['studiare_badges'] ){ echo $pro_info['studiare_badges'];} ?>
                            <?php if($pro_info['studiare_course_levels'] ){ echo $pro_info['studiare_course_levels'];} ?>
                            
                        </div>
                    </div>

                    <div class="pcl06_price flex justify-end items-center gap-1">
                        <?php echo studiare_get_course_price_html($product); ?>
                        <?php if($pro_info['discount_percent']){ ?>
                            <div class="pcl06_discount">
                                 <?php echo $pro_info['discount_percent']."%";?> 
                            </div>
                        <?php } ?>
                    </div>
                     
                </div>
            </div>
        </div>
    </div>