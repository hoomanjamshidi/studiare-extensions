<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.4.0
 */

defined('ABSPATH') || exit;

global $product;
if (empty($product) || !$product->is_visible()) return;

$post_id = $product->get_id();
$meta = studiare_get_course_meta($post_id);
$img_size = codebean_option('shop_pro_image_size', 'studiare-course-thumb');
$icon_raw = !empty($meta['course_buyers_text_icon']) 
    ? $meta['course_buyers_text_icon'] 
    : 'fal fa-users';
$icon_class = studiare_normalize_icon_class($icon_raw);

?>

<div <?php wc_product_class('course-item'); ?>>
    <div class="course-item-inner" <?php echo $border_style; ?>>
        
        <!-- Thumbnail Section -->
        <div class="course-thumbnail-holder">
            <?php 
                sc_render_product_badges( array(
                    'discount'    => false,
                ) );
                woocommerce_template_loop_product_link_open(); 
            ?>
            <span class="image-item">
                <?php 
                if (has_post_thumbnail()) {
                    the_post_thumbnail($img_size, ['class' => 'img-fluid']);
                } else {
                    $default_img = codebean_option('product_no_image', 'default') == 'custom' ? codebean_option('product_no_image_custom')['thumbnail'] : get_template_directory_uri().'/assets/images/noimage.jpg';
                    echo '<img src="'.esc_url($default_img).'" class="img-fluid" alt="'.get_the_title().'">';
                }
                ?>
            </span>
            <?php if (codebean_option('sc_shop_page_qv') || codebean_option('sc_shop_page_aw')) : ?>
                <div class="sc-buttons-sq-sw">
                    <?php if (shortcode_exists('woosq')) echo do_shortcode('[woosq]'); ?>
                    <?php if (shortcode_exists('woosw')) echo do_shortcode('[woosw]'); ?>
                </div>
            <?php endif; ?>
            <?php woocommerce_template_loop_product_link_close(); ?>
        </div>

        <!-- Content Section -->
        <div class="course-content-holder sc_equal_height_item">
            <div class="course-content-main">
                <h4 class="course-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                
                <?php if ($meta['sc_course_type_selector'] == 2): ?>
                    <div class="course-loop-element__course-type course-loop-element__course-type--onsite"><?php echo esc_html($meta['sc_course_type_title_2']); ?></div>
                <?php elseif ($meta['sc_course_type_selector'] == 1): ?>
                    <div class="course-loop-element__course-type course-loop-element__course-type--online"><?php echo esc_html($meta['sc_course_type_title_1']); ?></div>
                <?php endif; ?>

                <div class="course-rating-teacher">
                    <?php echo studiare_get_teachers_html($meta); ?>
                </div>

                <?php echo studiare_get_course_excerpt($post_id); ?>
            </div>
            <!-- Footer Section -->
            <div class="course-content-bottom">
                <div class="course-content-bottom-start flex justify-start items-center">
                    <?php if (codebean_option('product_danshjou_icon_view', false)): ?>
                        <div class="course-students flex items-center flex-col justify-center ">
                            <span class="numofStudents"><?php echo number_format_i18n($product->get_total_sales()); ?></span>
                            <span><?php  echo esc_attr($meta['course_buyers_text'] ?: __("Student", "studiare")); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if (codebean_option('product_rating_view', true)): ?>
                            <div class="sc-satisfaction"><?php echo studiare_woocommerce_template_loop_rating_percentage($product); ?></div>
                    <?php endif; ?>
                    
                </div>
                <div class="course-content-bottom-end">
                    <div class="course-loop-price">
                        <?php echo studiare_get_course_price_plus_html($product); ?>
                    </div>
                </div>
            </div>
            <div class="auto-hide-add-to-cart-button">
                <?php echo studiare_get_add_to_cart_layout4($product); ?>
            </div>
        </div>
    </div>
</div>