<?php
/**
 * single product layout 06
 **/
defined('ABSPATH') || exit;
if (class_exists("Redux")) {
    $course_post_share = codebean_option("course_share_story");
    $course_share_text = codebean_option("course_share_text");
    $product_meta_info_comment_number = codebean_option(
        "product_meta_info_comment_number"
    );
} else {
    $course_post_share = false;
    $course_share_text = "";
}
global $product;

$product = wc_get_product(get_the_ID());

if (!$product instanceof WC_Product) {
    return;
}


$product_meta_info_top_stuts = codebean_option('product_meta_info_top_stuts');
// get all product info since version 13.4
$info_args = array("rating", "rating_count", "is_new",  "discount_percent", "studiare_badges", "studiare_course_levels"); 
$pro_info = sc_get_pro_info($info_args); 
?>
<div id="product-<?php the_ID(); ?>" <?php post_class(); ?>>

       <?php
       $product_sidebar_position = codebean_option("product_sidebar_position");
       if ($product_sidebar_position == 1) {
           $position_of_single_sidebar = "screversed";
       } else {
           $position_of_single_sidebar = "";
       }
       ?>
    	
    <div class="row <?php echo esc_attr($position_of_single_sidebar); ?> flex flex-col-reverse lg:flex-row">
        <div class="product-single-main">
            <?php get_template_part( 'woocommerce/sc_templates/sc_pro_offer_box' ); ?>
        <div class="productintro_col1">
            
       <?php
       $mycontent_post = get_post(get_the_ID());
       $my_excerpt = $mycontent_post->post_excerpt;
       ?>
		<?php if ($my_excerpt != null) { ?>
            <div class="product-single-content-lfive" id="sc-product-single-excerpt">
               <?php echo wp_kses_post($my_excerpt); ?>
            </div>
            
        <?php } ?>


        <div class="single-course-info flex items-center gap-2 mb-10 flex-wrap">
                
                <?php
                if (!empty($pro_info['studiare_badges'])) {
    echo wp_kses_post($pro_info['studiare_badges']);
}

                ?>
                <div class="scball"></div><div class="course-rating"> <?php woocommerce_template_loop_rating(); ?></div>
                <?php
                if (!empty($pro_info['studiare_course_levels'])) {
    echo '<div class="scball"></div>' . wp_kses_post($pro_info['studiare_course_levels']);
}
                ?>
        </div>
        <?php
        if ($product_meta_info_top_stuts == 1) {
            echo studiare_render_teachers([
                'post_id'         => get_the_ID(),
                'link_type'       => 'anchor',
                'show_name'       => true,
                'show_avatar'     => true,
                'image_size'      => 'thumbnail',
                'image_width'     => 30,
                'image_height'    => 30,
                'separator_style' => 'and',
            ]);
        }
        ?>


       </div>
        <!-- Product Top Part-->
<div class="prolayoutfive single_middle_info_five row mb-30">
<?php
$pro_id = get_the_ID();

$product_meta_info_list = codebean_option('product_meta_info_list');
$product_buyers_insingle = codebean_option('product_buyers_insingle');
$product_meta_info_list_date_published = codebean_option('product_meta_info_list_date_published');
$product_meta_info_list_date_modified = codebean_option('product_meta_info_list_date_modified');

if ($product_meta_info_list == 1 && $pro_id) {

    $info_types = [];

    if ($product_buyers_insingle == 1) {
        $info_types[] = 'total_sells';
    }

    $info_types = array_merge($info_types, [
        'course_language',
        'course_duration',
        'sc_course_type_1',
        'sc_course_type_2',
        'course_lesseons',
        'course_sessions',
        'course_level',
        'sc_file_type',
        'sc_file_size',
        'course_certificate',
    ]);

    if ($product_meta_info_list_date_published == 1) {
        $info_types[] = 'published_date';
    }

    if ($product_meta_info_list_date_modified == 1) {
        $info_types[] = 'updated_date';
    }

    $items = sc_get_product_info_items($pro_id, $info_types, true);

    $allowed_icon_html = [
        'i' => [
            'class' => [],
        ],
    ];
    ?>
    <div class="product-meta-info-holders col-md-12 col-xs-12">
        <?php foreach ($items as $item) : ?>
            <?php if (empty($item['show'])) { continue; } ?>
            <div class="col-md-4 col-xs-6">
                <div class="meta-info-unit-box">
                    <div class="icon">
                        <?php echo wp_kses($item['icon_html'], $allowed_icon_html); ?>
                    </div>
                    <div>
                        <div><?php echo esc_html($item['title']); ?></div>
                        <div class="value"><?php echo esc_html($item['value']); ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php } ?>
</div>
<?php get_template_part( 'woocommerce/sc_templates/sc_public_items' ); ?>



                
<?php
$product_single_sc_message = codebean_option("product_single_sc_message");
$sale_price = $product->get_sale_price();
$regular_price = $product->get_regular_price();

if (
    ($product_single_sc_message == 1 && !empty($regular_price)) ||
    ($product_single_sc_message == 1 && $sale_price === "0")
) {
    // since version 12.6
    $prefix = "_studiare_";
$sc_sections_off_raw = get_post_meta(get_the_ID(), $prefix . 'sc_sections_off', false);

$sc_sections_off = [];
if (!empty($sc_sections_off_raw) && is_array($sc_sections_off_raw)) {
    foreach ($sc_sections_off_raw as $section) {
        if (is_array($section)) {
            $sc_sections_off = array_merge($sc_sections_off, $section);
        }
    }
}

    if (!in_array("discount_message", $sc_sections_off, true)) {

        ?>
        <div class="sc-single-product-message">
            <span class="sc-amazing-offer-final-price-icon"> <i class="fal fa-gift"></i> </span>
            <?php
            $product_single_sc_message_0 = codebean_option("product_single_sc_message_0");
            echo do_shortcode($product_single_sc_message_0);
            ?>
        </div>
        <?php
    }
}
?>

        <?php

        do_action("woocommerce_single_product_summary_bysuncode");
        ?>
        
<?php
$product_meta_info_teacher_profile = codebean_option('product_meta_info_teacher_profile');

if ($product_meta_info_teacher_profile == 1) {
    $teachers = get_post_meta(get_the_ID(), '_studiare_course_teachers', true);

    if (is_array($teachers)) {
        // Keep only valid teacher IDs.
        $teachers = array_filter($teachers, function ($teacher_id) {
            return !empty($teacher_id) && $teacher_id !== 'no-teacher';
        });

        if (!empty($teachers)) {
            sc_adding_teachers_to_layout($teachers);
        }
    }
}
?>

               
        
        <?php sc_related_courses(); ?>

        </div>
            <div class="product-single-aside sticky-sidebar">
                <div class="course-single-gallery mb-30">
                    <?php 
                       do_action( "woocommerce_before_single_product_summary" );
                    ?>
                </div> 
                <div class="theiaStickySidebar">
                        <div class="studi_simple_box studi_price_box">
                        
                            <div class="h3 sticky-product-title">
                                <?php echo esc_html( get_the_title() ); ?>
                            </div>
                        
                            <?php do_action( "woocommerce_single_product_summary" ); ?>
                        
                        </div>
                
                    
                </div>
            </div>

    </div>

</div> 