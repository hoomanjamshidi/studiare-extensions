<?php
/**
 * Optimized amazing offer template - Per variation display for variable products
 * - One card per on-sale variation
 * - Early exits & caching friendly
 * - Clean & minimal database calls
 */
?>

<!-- start sc-amazing-offer -->
<?php
global $product;

if (! $product->is_on_sale()) {
    return;
}

$currency_symbol = get_woocommerce_currency_symbol();
$space           = str_repeat('&nbsp;', 1);

$is_variable = $product->is_type('variable');

// ── Simple product ───────────────────────────────────────────────
if (! $is_variable) {

    $regular = (float) $product->get_regular_price();
    $sale    = (float) $product->get_sale_price();
    $saving  = $regular - $sale;

    if ($saving <= 0) {
        return;
    }

    $date_to = $product->get_date_on_sale_to();
    $end_ts  = ($date_to instanceof WC_DateTime) ? $date_to->getTimestamp() : 0;

    if ($end_ts === 0) {
        return;
    }

    $formatted_saving = number_format($saving);
    $countdown_date   = date('m/d/Y 23:59', $end_ts);
    ?>

    <div class="product-info-box sc-amazing-offer flex justify-between items-center gap-3">
        <div class="sc-amazing-offer-discount">
            <?php echo $formatted_saving; ?><?php echo $space; ?><?php echo $currency_symbol; ?>
            <?php esc_html_e('Discount', 'studiare'); ?>
        </div>

        <div class="countdown-timer-holder center standard light cdstdire flex items-center gap-2">
            <div class="countdown-item-plus flex gap-1 dirLTR font-semibold" data-date="<?php echo esc_attr($countdown_date); ?>"></div>
            <div class="sc-amazing-offer-in">
                <?php esc_html_e('Time remaining', 'studiare'); ?>
            </div>
        </div>
    </div>

    <?php
    return; // simple product done
}

// ── Variable product - one block per on-sale variation ───────────
$children_ids = $product->get_children();

if (empty($children_ids)) {
    return;
}

$has_any_sale = false;

foreach ($children_ids as $var_id) {

    $variation = wc_get_product($var_id);
    if (! $variation || ! $variation->is_on_sale()) {
        continue;
    }

    $regular = (float) $variation->get_regular_price();
    $sale    = (float) $variation->get_sale_price();
    $saving  = $regular - $sale;

    if ($saving <= 0) {
        continue;
    }

    $date_to = $variation->get_date_on_sale_to();
    $end_ts  = ($date_to instanceof WC_DateTime) ? $date_to->getTimestamp() : 0;

    if ($end_ts === 0) {
        continue;
    }

    $formatted_saving   = number_format($saving);
    $countdown_date     = date('m/d/Y 23:59', $end_ts);
    $variation_name     = $variation->get_name();           // or wc_get_formatted_variation_attributes() if you want attributes only
    $has_any_sale       = true;
    ?>

    <div class="product-info-box sc-amazing-offer flex justify-between items-center gap-3">
        <div class="sc-amazing-offer-discount">
            <?php echo $formatted_saving; ?><?php echo $space; ?><?php echo $currency_symbol; ?>
            <?php esc_html_e('Discount', 'studiare'); ?>
        </div>

        <div class="variation-title">
            <?php echo esc_html($variation_name); ?>
        </div>

        <div class="countdown-timer-holder center standard light cdstdire flex items-center gap-2">
            <div class="countdown-item-plus flex gap-1 dirLTR font-semibold" data-date="<?php echo esc_attr($countdown_date); ?>"></div>
            <div class="icon sc-amazing-offer-in">
                <?php esc_html_e('Time remaining', 'studiare'); ?>
            </div>
        </div>
    </div>

    <?php
}

if (! $has_any_sale) {
    // Optional: you can echo a fallback message here if needed
}
?>

<!-- end sc-amazing-offer -->