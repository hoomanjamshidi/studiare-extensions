<?php
/**
 * Single Product Layout 03
 * Optimized for performance, readability, and WordPress/WooCommerce standards
 */

defined('ABSPATH') || exit;
global $product;
// Retrieve Redux settings efficiently
$course_post_share = class_exists('Redux') ? codebean_option('course_share_story') : false;
$course_share_text = class_exists('Redux') ? codebean_option('course_share_text') : '';
$product_meta_info_list = class_exists('Redux') ? codebean_option('product_meta_info_list') : false;
$product_buyers_insingle = class_exists('Redux') ? codebean_option('product_buyers_insingle') : false;
$product_meta_info_list_short_link = class_exists('Redux') ? codebean_option('product_meta_info_list_short_link') : false;
$product_meta_info_list_cats = class_exists('Redux') ? codebean_option('product_meta_info_list_cats') : false;
$product_meta_info_list_stars = class_exists('Redux') ? codebean_option('product_meta_info_list_stars') : false;
$product_meta_info_list_date_published = class_exists('Redux') ? codebean_option('product_meta_info_list_date_published') : false;
$product_meta_info_list_date_modified = class_exists('Redux') ? codebean_option('product_meta_info_list_date_modified') : false;
$product_meta_info_list_tags = class_exists('Redux') ? codebean_option('product_meta_info_list_tags') : false;
$product_sidebar_position = class_exists('Redux') ? codebean_option('product_sidebar_position') : 0;
$tickets_status = class_exists('Redux') ? codebean_option('tickets_status') : false;
$tickets_in_product_page = class_exists('Redux') ? codebean_option('tickets_in_product_page') : true;
$product_single_sc_show_buyers = class_exists('Redux') ? codebean_option('product_single_sc_show_buyers') : '0';

// Define meta keys with defaults
$prefix = '_studiare_';
$meta_keys = [
    '_stock' => '',
    $prefix . 'course_duration' => '',
    $prefix . 'course_lesseons' => '',
    $prefix . 'course_level' => '',
    $prefix . 'sc_file_type' => '',
    $prefix . 'sc_file_size' => '',
    $prefix . 'sc_file_type_icon' => '',
    $prefix . 'course_certificate' => '',
    $prefix . 'course_language' => '',
    $prefix . 'course_sessions' => '',
    $prefix . 'sc_course_type_selector' => '',
    $prefix . 'course_buyers_text' => 'دانشجو',
    $prefix . 'course_buyers_text_hint' => 'تعداد دانشجویان',
    $prefix . 'course_buyers_text_icon' => 'fal fa-users',
    $prefix . 'course_duration_hint' => 'مدت زمان آموزش',
    $prefix . 'course_lesseons_hint' => 'تعداد سرفصل ها',
    $prefix . 'course_level_hint' => 'سطح آموزش',
    $prefix . 'sc_file_type_hint' => 'نوع فایل',
    $prefix . 'sc_file_size_hint' => 'حجم فایل',
    $prefix . 'course_certificate_hint' => 'نوع گواهی',
    $prefix . 'course_language_hint' => 'زبان آموزش',
    $prefix . 'course_sessions_hint' => 'تعداد جلسات',
    $prefix . 'sc_course_type_title_1' => '',
    $prefix . 'sc_course_type_title_2' => '',
    $prefix . 'metaboxjff_sections' => '',
    $prefix . 'course_teachers' => '',
    '_studiare_woo_course_date_update' => '',
    'total_sales' => 0,
];

// Fetch all meta values in one go
$meta_values = [];
$post_id = get_the_ID();
foreach ($meta_keys as $key => $default) {
    $meta_values[$key] = get_post_meta($post_id, $key, true) ?: $default;
}

// Determine sidebar position class
$position_of_single_sidebar = ($product_sidebar_position == 1) ? 'screversed' : '';

// Helper function to display meta units
function display_meta_unit_box($icon, $label, $value, $hint) {
    if (!empty($value)) {
        ?>
        <div class="col-md-2 col-xs-6">
            <div class="meta-info-unit-box hint--top" aria-label="<?php echo esc_attr($hint); ?>">
                <div class="icon"><i class="<?php echo esc_attr($icon); ?>"></i></div>
                <div class="value"><?php echo esc_html($value); ?></div>
            </div>
        </div>
        <?php
    }
}
?>

<div id="product-<?php the_ID(); ?>" <?php post_class("studi_single_pro_" . $product_layout); ?>>
    <div class="container <?php echo esc_attr($position_of_single_sidebar); ?>">
        <?php include_once "sc_pro_offer_box.php"; ?>
        <!-- Product Top Part -->
        <div class="single_pro_top row">
            <div class="col-md-3 col-xs-12">
                <div class="desktopfreespace" style="height: 48px;"></div>
                <div class="studi_simple_box studi_price_box">
                    <?php do_action('woocommerce_single_product_summary'); ?>
                </div>
            </div>
            <!-- Product Gallery -->
            <div class="col-md-6 col-xs-12 pro_gallery_holder">
                <div class="course-single-gallery">
                    <?php do_action('woocommerce_before_single_product_summary'); ?>
                </div>
            </div>
            <div class="col-md-3 col-xs-12">
                <div class="desktopfreespace" style="height: 40px;"></div>
                <div class="studi_share_view">
                    <?php if ($course_post_share): ?>
                        <div class="sc_studi_share_box studi_simple_box">
                            <span><?php esc_html_e('Share', 'studiare'); ?> :</span><?php echo do_shortcode('[sc_studiare_product_share_box]'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (class_exists('Redux') && codebean_option('product_meta_info_comment_number')): ?>
                    <div class="sccommentnumber studi_simple_box">
                        <div class="inline-flex gap-1">
                            <span class="icon"><i class="fal fa-comments-alt"></i></span><?php echo get_comments_number(); ?> <?php esc_html_e('Comment', 'studiare'); ?>
                        </div>
                        <span class="sc_studi_number_of_views"><i class="fal fa-eye"></i><?php echo sc_studi_gt_get_post_view(); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <?php if ($product_meta_info_list_short_link): ?>
                    <div class="studi_shortlink studi_simple_box">
                        <span class="icon"><i class="fal fa-link"></i></span>
                        <span class="info"><?php esc_html_e('Short Link :', 'studiare'); ?></span>
                        <span class="scshort-link">
                            <span class="scshort-link__text"><?php echo esc_url(wp_get_shortlink()); ?></span>
                            <span class="sc_autocopy sc_autocopy_l3 hint--top" aria-label="<?php esc_attr_e('Copy Link', 'studiare'); ?>"
                                  onclick="sc_auto_copy_text('<?php echo esc_js(wp_get_shortlink()); ?>', '<?php esc_js(_e('Copy Link', 'studiare')); ?>', '<?php esc_js(_e('Copied', 'studiare')); ?>')">
                                <i class="fal fa-clone"></i>
                            </span>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
            <!-- Middle Box Bottom Start -->
            <div class="studi_public_pro_data_bottom col-xs-12">
                <?php if ($product_meta_info_list_cats): ?>
                    <?php $product_cats = get_the_terms($post_id, 'product_cat'); ?>
                    <?php if ($product_cats): ?>
                        <div class="col-md-4 col-xs-12">
                            <div class="studi_simple_box pro_cat_holder">
                                <span class="icon"><i class="fal fa-folder-open"></i></span>
                                <span class="info">
                                    <span class="label"><?php esc_html_e('Category', 'studiare'); ?></span>
                                    <span class="value">
                                        <?php foreach ($product_cats as $cat): ?>
                                            <a href="<?php echo esc_url(get_term_link($cat)); ?>"><?php echo esc_html($cat->name); ?><span></span></a>
                                        <?php endforeach; ?>
                                    </span>
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if ($product_meta_info_list_stars): ?>
                    <div class="col-md-2 col-xs-12">
                        <div class="studi_simple_box proRating_holder">
                            <?php if (!codebean_option('product_stars')): ?>
                                <span class="icon"><i class="fal fa-star"></i></span>
                            <?php endif; ?>
                            <span class="info"><?php woocommerce_template_loop_rating(); ?></span>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($product_meta_info_list_date_published): ?>
                    <div class="col-md-3 col-xs-12">
                        <div class="studi_simple_box">
                            <i class="fal fa-calendar-alt"></i> <span class="date_published"><?php esc_html_e('Published on', 'studiare'); ?>: <?php echo get_the_date(); ?></span>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($product_meta_info_list_date_modified && !empty($meta_values['_studiare_woo_course_date_update'])): ?>
                    <div class="col-md-3 col-xs-12">
                        <div class="studi_simple_box">
                            <i class="fal fa-sync"></i> <span class="date_published"><?php esc_html_e('Updated on', 'studiare'); ?>: <?php echo date_i18n("j F Y", $meta_values['_studiare_woo_course_date_update']); ?></span>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <!-- Middle Box Bottom End -->
            <div class="container">
                <?php include_once "sc_post_excerpt.php"; ?>
            </div>
        </div>

        <!-- Start Tab Header Section -->
        <div class="tab studi_simple_box">
            <button id="sctdescr" class="tablinks active" onclick="studi_tab(event, 'description')"><?php esc_html_e('Description', 'studiare'); ?></button>
            <button class="tablinks" onclick="studi_tab(event, 'proinfos')"><?php esc_html_e('Information', 'studiare'); ?></button>
            <?php if (!empty($teacher_id) && $teacher_id != 'no-teacher'): ?>
                <button class="tablinks" onclick="studi_tab(event, 'teacherTab')"><?php esc_html_e('About Teacher', 'studiare'); ?></button>
            <?php endif; ?>
            <button class="tablinks" onclick="studi_tab(event, 'commentstab')"><?php esc_html_e('Reviews', 'studiare'); ?><span class="sc-numberofcomments"><?php echo get_comments_number(); ?></span></button>
            <?php if ($tickets_status && $tickets_in_product_page && class_exists('SWSS_ProductPageTab')): ?>
                <button class="tablinks" onclick="studi_tab(event, 'supporttab')"><?php esc_html_e('Support', 'studiare'); ?></button>
            <?php endif; ?>

            <?php if (is_user_logged_in() && $product_single_sc_show_buyers != '0' && current_user_can('administrator')): ?>
                <button class="tablinks" onclick="studi_tab(event, 'sc_pro_buyers_list')"><?php esc_html_e('Buyers List', 'studiare'); ?></button>
            <?php endif; ?>
        </div>
        <!-- End Tab Header Section -->

        <!-- Start Tab Content Section -->
        <div class="row prothree_tabholder">
            <?php if ($tickets_status && $tickets_in_product_page && class_exists('SWSS_ProductPageTab')): ?>
                <div id="supporttab" class="tabcontent">
                    <?php
                    $SWSS_ProductPageTab = new SWSS_ProductPageTab();
                    $SWSS_ProductPageTab->render_ticket_product_tab();
                    ?>
                </div>
            <?php endif; ?>


            <?php if ($product_single_sc_show_buyers != '0' && current_user_can('administrator')): ?>
                <div id="sc_pro_buyers_list" class="tabcontent">
                    <div class="sc_pro_buyers_list">
                        <?php sc_pro_buyers_list_render(); ?>
                    </div>
                </div>
            <?php endif; ?>

            <div id="description" class="tabcontent" style="display: block;">
                <?php include_once "sc_public_items.php"; ?>
                <?php include_once "studi_content.php"; ?>
            </div>

            <div id="proinfos" class="tabcontent">
                <div class="single_middle_info row">
                    <?php if ($product_meta_info_list): ?>
                        <div class="product-meta-info-holders col-md-12 col-xs-12">
                            <?php if ($product_buyers_insingle): ?>
                            <?php 
                    $icon = $meta_values[$prefix . 'course_buyers_text_icon'];
                    if (strpos($icon, 'fal') === 0) {
                        $icon_class = substr($icon, 0, 3) . ' ' . substr($icon, 3);
                    } else {
                        $icon_class = $icon;
                    }
                    ?>
                                <div class="col-md-2 col-xs-6">
                                    <div class="meta-info-unit-box hint--top" aria-label="<?php echo esc_attr($meta_values[$prefix . 'course_buyers_text_hint']); ?>">
                                        <div class="icon"><i class="<?php echo esc_attr($icon_class); ?>"></i></div>
                                        <div class="value"><?php $count = $meta_values['total_sales']; $text = sprintf(_n("%s %s", "%s %s", $count, 'studiare'), number_format_i18n($count), $meta_values[$prefix . 'course_buyers_text']); echo esc_html($text); ?></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php
                            // Define meta info array for display
                            $meta_info = [
                                ['icon' => 'fal fa-language', 'hint' => $meta_values[$prefix . 'course_language_hint'], 'value' => $meta_values[$prefix . 'course_language']],
                                ['icon' => 'fal fa-clock', 'hint' => $meta_values[$prefix . 'course_duration_hint'], 'value' => $meta_values[$prefix . 'course_duration']],
                                ['icon' => 'fal fa-list-alt', 'hint' => $meta_values[$prefix . 'course_lesseons_hint'], 'value' => $meta_values[$prefix . 'course_lesseons']],
                                ['icon' => 'fal fa-list', 'hint' => $meta_values[$prefix . 'course_sessions_hint'], 'value' => $meta_values[$prefix . 'course_sessions']],
                                ['icon' => 'fal fa-signal-4', 'hint' => $meta_values[$prefix . 'course_level_hint'], 'value' => $meta_values[$prefix . 'course_level']],
                                ['icon' => $meta_values[$prefix . 'sc_file_type_icon'], 'hint' => $meta_values[$prefix . 'sc_file_type_hint'], 'value' => $meta_values[$prefix . 'sc_file_type']],
                                ['icon' => 'fal fa-save', 'hint' => $meta_values[$prefix . 'sc_file_size_hint'], 'value' => $meta_values[$prefix . 'sc_file_size']],
                                ['icon' => 'fal fa-award', 'hint' => $meta_values[$prefix . 'course_certificate_hint'], 'value' => $meta_values[$prefix . 'course_certificate']],
                            ];

                            // Display course type conditionally
                            if ($meta_values[$prefix . 'sc_course_type_selector'] == 1) {
                                display_meta_unit_box('fal fa-signal', esc_html__('Course Type', 'studiare'), $meta_values[$prefix . 'sc_course_type_title_1'], esc_html__('Course Type', 'studiare'));
                            } elseif ($meta_values[$prefix . 'sc_course_type_selector'] == 2) {
                                display_meta_unit_box('fal fa-signal-slash', esc_html__('Course Type', 'studiare'), $meta_values[$prefix . 'sc_course_type_title_2'], esc_html__('Course Type', 'studiare'));
                            }

                            // Loop through meta info
                            foreach ($meta_info as $info) {
                                display_meta_unit_box($info['icon'], $info['hint'], $info['value'], $info['hint']);
                            }

                            // Custom entries
                            $custom_entries = $meta_values[$prefix . 'metaboxjff_sections'];
                            if ($custom_entries) {
                                foreach ((array)$custom_entries as $entry) {
                                    $title = isset($entry[$prefix . 'sc_studi_custom_title_1']) ? esc_html($entry[$prefix . 'sc_studi_custom_title_1']) : '';
                                    $content = isset($entry[$prefix . 'sc_studi_custom_text_1']) ? esc_html($entry[$prefix . 'sc_studi_custom_text_1']) : '';
                                    $icon = isset($entry[$prefix . 'sc_studi_custom_icon_1']) ? substr($entry[$prefix . 'sc_studi_custom_icon_1'], 0, 3) . ' ' . substr($entry[$prefix . 'sc_studi_custom_icon_1'], 3) : 'fal fa-list';
                                    display_meta_unit_box($icon, $content, $title, $content);
                                }
                            }
                            ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div id="commentstab" class="tabcontent">
                <?php include_once "sc_comments.php"; ?>
            </div>

            <div id="teacherTab" class="tabcontent">
                <!-- Teachers -->
                <?php
                $teachers = $meta_values[$prefix . 'course_teachers'];
                if (empty($teachers) || !is_array($teachers)) {
                    $teachers = array_filter([
                        $teacher_id ?? '',
                        $teacher_id_2 ?? '',
                        $teacher_id_3 ?? '',
                        $teacher_id_4 ?? ''
                    ], function($id) {
                        return !empty($id) && $id !== 'no-teacher';
                    });
                }
                if (!empty($teachers)) {
                    sc_adding_teachers_to_layout($teachers);
                }
                ?>
            </div>
        </div>
        <!-- End Tab Content Section -->

        <div class="row">
            <div class="col-xs-12">
                <!-- Tags -->
                <?php if ($product_meta_info_list_tags): ?>
                    <?php $product_tags = get_the_terms($post_id, 'product_tag'); ?>
                    <?php if ($product_tags): ?>
                        <div class="studi_boot_pad_remover col-xs-12 mb20 protags_holder">
                            <div class="studi_simple_box">
                                <span class="icon"><i class="fal fa-tags"></i></span>
                                <span class="info">
                                    <span class="label"><?php esc_html_e('Tags', 'studiare'); ?></span>
                                    <span class="value">
                                        <?php foreach ($product_tags as $tag): ?>
                                            <a href="<?php echo esc_url(get_term_link($tag)); ?>"><?php echo esc_html($tag->name); ?><span></span></a>
                                        <?php endforeach; ?>
                                    </span>
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <?php sc_related_courses(); ?>
            </div>
        </div>
    </div>
</div>

<!-- Styles -->
<style>
span.sc-numberofcomments {
    background: var(--color-neutral-300);
    padding: 3px 8px;
    margin-inline-start: 3px;
    border-radius: 5px;
    text-align: center;
}
.tab button.active .sc-numberofcomments {
    background: var(--secondary_color);
    color: #fff;
}

.row.prothree_tabholder {
    margin-left: 0;
    margin-right: 0;
}
g[aria-labelledby="id-66-title"] { display: none; }
g[aria-label="Chart created using amCharts library"] { display: none; }
#chartdiv {
    direction:ltr;
    width: 100%;
    height: 200px;
}
/* Style the tab */
.tab.studi_simple_box {
    position: sticky;
    top: 60px;
    left: 0;
    right: 0;
    z-index: 109;
    overflow-x: auto;
    padding: .75rem;
}
.admin-bar .tab.studi_simple_box {top: 92px;}
.tab {
    overflow: hidden;
    display: flex;
    justify-content: center;
    background: var(--color-neutral-200);
}
@media screen and (max-width: 428px) {
    .tab.studi_simple_box {
        display: flex;
        flex-wrap: nowrap;
        justify-content: flex-start;
        overflow-x: auto;
        overflow-y: hidden;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
    }

    .tab.studi_simple_box button {
        flex: 0 0 auto;
        white-space: nowrap;
    }
    .tab.studi_simple_box::-webkit-scrollbar {
        display: none;
    }

    .tab.studi_simple_box {
        scrollbar-width: none;
    }
    .admin-bar .tab.studi_simple_box{
            top: 68px;
    }
}

/* Style the buttons that are used to open the tab content */
.tab button {
    float: none;
    border: none;
    outline: none;
    cursor: pointer;
    transition: 0.3s;
    font-size: 14px;
    padding: 10px 15px;
    color: var(--color-neutral-400);
    background: transparent;
    margin: 0 5px;
}
.Atabcontent i {
    display: inline;
}
/* Create an active/current tablink class */
.tab button.active {
    color: var(--color-neutral-600);
    background: var(--color-neutral-100);
    border-radius: 5px;
}
/* Style the tab content */
.tabcontent {
    display: none;
    padding: 0;
    margin-top: 20px;
    margin-bottom: 20px;
    text-align: right;
    width: 100%;
}
.tabcontent ul.sc_notifs_holder li {
    border-bottom: 1px dashed gainsboro;
}
</style>

<script>
function studi_tab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
    var elementPosition = document.getElementById(tabName).offsetTop;
    window.scrollTo({
        top: elementPosition - 120,
        behavior: "smooth"
    });
}
</script>