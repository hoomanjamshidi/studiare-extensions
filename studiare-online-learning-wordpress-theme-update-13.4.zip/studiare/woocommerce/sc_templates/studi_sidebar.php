<?php
/**
 * studiare single product sidebar
 * created date 1399-06-06
 * author: Javad Pourshahabadi
 * @suncode
 **/
 ?>

    <?php wc_get_template_part('content-single-product-meta-side'); ?>
    
    <?php
        $product_meta_info_teacher_profile = codebean_option('product_meta_info_teacher_profile');
        if ($product_meta_info_teacher_profile == 1) {
            $prefix = '_studiare_';
            // Get the array of teacher IDs from the new field
            $teachers = get_post_meta(get_the_ID(), $prefix . 'course_teachers', true);
            
            // Fallback to old fields if the new field is empty
            if (empty($teachers) || !is_array($teachers)) {
                $teachers = array_filter([
                    $teacher_id,   // Assuming these variables are already defined
                    $teacher_id_2,
                    $teacher_id_3,
                    $teacher_id_4
                ], function($id) {
                    return !empty($id) && $id !== 'no-teacher';
                });
            }
        
            // Call the function once with the array of teacher IDs
            sc_adding_teachers_to_meta_sidebar($teachers);
        }
    ?>
    