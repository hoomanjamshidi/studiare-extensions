<?php
/**
 * studiare single product content
 * created date 1399-06-06
 * author: Javad Pourshahabadi
 * @suncode
 **/

// NOTE: Keep this file structure intact. We only replace the old inline Read More
// button + jQuery with the new modular system (assets + localized options).
?>

<?php
    $product_single_sc_message = codebean_option('product_single_sc_message');
    $sale_price    = $product->get_sale_price();
    $regular_price = $product->get_regular_price();
    if ( ( $product_single_sc_message == 1 && !empty( $regular_price ) ) || ( $product_single_sc_message == 1 && $sale_price === '0' ) ) {

        // since version 12.6
        $sc_sections_off = array();
        $prefix = '_studiare_';
        $sc_sections_off_raw = get_post_meta( get_the_ID(), $prefix . 'sc_sections_off', false );
        $sc_sections_off = array_merge(...$sc_sections_off_raw);

        if ( ! in_array( 'discount_message', $sc_sections_off ) ) {
?>
<div class="studiare-skeleton" data-skeleton-height="92" data-skeleton-animation="slide">
<div class="sc-single-product-message">
  <span class="sc-amazing-offer-final-price-icon"><i class="fal fa-gift"></i></span>
  <?php $product_single_sc_message_0 = codebean_option('product_single_sc_message_0'); ?>
  <?php echo do_shortcode( $product_single_sc_message_0 ); ?>
</div>
</div>
<?php
        }
    }
?>

<?php
  $product_single_sc_single_navbar = codebean_option('product_single_sc_single_navbar');
  if ( $product_single_sc_single_navbar == 1 ) {
?>
<nav class="sc_single_navbar">
  <ul>
    <li>
      <a href="javascript:void(0);" onclick="jQuery('html, body').animate({scrollTop: jQuery('#sc-product-single-content').offset().top - 150}, 100);">
        <?php _e('Description', 'studiare'); ?>
      </a>
    </li>
    <li>
      <a href="javascript:void(0);" onclick="jQuery('html, body').animate({scrollTop: jQuery('#sc-product-reviews').offset().top - 150}, 100);">
        <?php _e('User Reviews', 'studiare'); ?>
      </a>
    </li>
    <li>
      <a href="javascript:void(0);" onclick="jQuery('html, body').animate({scrollTop: jQuery('#reviews').offset().top - 50}, 100);">
        <?php _e('Comments', 'studiare'); ?>
      </a>
    </li>
  </ul>
</nav>
<?php } ?>

<div class="product-single-content " id="sc-product-single-content">
  <div class="studi_pro_content_holder">
    <?php the_content(); ?>
    
  </div>
  
  
  
    
  

</div>
<?php
  // after </div> of .studi_pro_content_holder
  do_action('studiare_after_product_content_holder');
?>