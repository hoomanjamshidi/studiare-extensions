<?php
$sc_view_page_general_att = codebean_option('sc_view_page_general_att');

if ($sc_view_page_general_att == 1) {
    $gen_page_id = codebean_option('sc_select_page_general_att');
    $gen_page_id_exclude_cats = codebean_option('sc_select_page_general_att_exclude_cats');
    $terms = get_the_terms(get_the_ID(), 'product_cat');
    $show_tag = true;

    if ($terms && is_array($terms)) {
        foreach ($terms as $term) {
            if ($term && is_array($gen_page_id_exclude_cats)) {
                if (in_array($term->term_id, $gen_page_id_exclude_cats)) {
                    $show_tag = false;
                    break;
                }
            }
        }
    }

    if (function_exists('icl_object_id') && !empty($gen_page_id)) {
        $gen_page_id = icl_object_id($gen_page_id, 'page', true);
    }

    if (!empty($gen_page_id) && $show_tag) {
        $sc_sections_off = array();
        $prefix = '_studiare_';
        $sc_sections_off_raw = get_post_meta(get_the_ID(), $prefix . 'sc_sections_off', false);
        $sc_sections_off = !empty($sc_sections_off_raw) && is_array($sc_sections_off_raw[0]) ? $sc_sections_off_raw[0] : array();

        if (!in_array('general_features', $sc_sections_off)) {
            $general_att_edit_button_html = '';

            if (
                is_user_logged_in() &&
                current_user_can('edit_post', $gen_page_id)
            ) {
                $general_att_edit_url = admin_url('post.php?post=' . absint($gen_page_id) . '&action=edit');

                if (class_exists('\Elementor\Plugin')) {
                    $document = \Elementor\Plugin::instance()->documents->get($gen_page_id);

                    if ($document) {
                        $general_att_edit_url = $document->get_edit_url();
                    }
                }

                $general_att_edit_button_html = sprintf(
                    '<a class="scGeneralAttEditPage" href="%s" target="_blank" rel="nofollow noopener">%s</a>',
                    esc_url($general_att_edit_url),
                    esc_html__('edit', 'studiare')
                );
            }
            ?>

            <div class="sc-courseCharacteristics studiare-skeleton" data-skeleton-height="150" data-skeleton-animation="slide">
                <?php echo $general_att_edit_button_html; ?>

                <?php
                $contentElementor = '';

                if (class_exists('\Elementor\Plugin')) {
                    $pluginElementor = \Elementor\Plugin::instance();

                    if (method_exists($pluginElementor->frontend, 'get_builder_content_for_display')) {
                        $contentElementor = $pluginElementor->frontend->get_builder_content_for_display($gen_page_id, true);
                    } else {
                        $contentElementor = $pluginElementor->frontend->get_builder_content($gen_page_id);
                    }
                }

                echo $contentElementor;
                ?>
            </div>

        <?php }
    }
}
?>
