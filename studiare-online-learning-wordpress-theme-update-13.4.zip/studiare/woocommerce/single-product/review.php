<?php
/**
 * Review Comments Template
 *
 * Closing li is left out on purpose!.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/review.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">

	<div id="comment-<?php comment_ID(); ?>" class="comment_container">

		<div class="comment-avatar">
			<?php echo get_avatar( $comment, apply_filters( 'woocommerce_review_gravatar_size', '75' ), '' ); ?>
		</div>

		<div class="comment-text w-full">

			<div class="comment-header flex flex-wrap items-center gap-3">
				<div class="comment-author h6"><?php comment_author(); ?><?php
					if ( get_option( 'woocommerce_review_rating_verification_label' ) === 'yes' ){
						$isbought = studi_has_bought_items($comment->user_id,$comment->comment_post_ID);
                    	if($isbought =="true"){
                    	    echo '<em class="verified">(' . esc_html__( 'verified owner', 'studiare' ) . ')</em> ';
                    	}
					}
					?></div>
				<?php

				/**
				 * The woocommerce_review_before_comment_meta hook.
				 *
				 * @hooked woocommerce_review_display_rating - 10
				 */
				do_action( 'woocommerce_review_before_comment_meta', $comment );

				?>
			</div>
			<?php


			/**
			 * The woocommerce_review_meta hook.
			 *
			 * @hooked woocommerce_review_display_meta - 10
			 * @hooked WC_Structured_Data::generate_review_data() - 20
			 */

			do_action( 'woocommerce_review_before_comment_text', $comment );

			/**
			 * The woocommerce_review_comment_text hook
			 *
			 * @hooked woocommerce_review_display_comment_text - 10
			 */
			do_action( 'woocommerce_review_comment_text', $comment );

			do_action( 'woocommerce_review_after_comment_text', $comment ); ?>
			
			<div class="reply">
				<?php
				$args = array(
					'reply_text' => esc_html__( 'Reply', 'studiare' ),
					'depth'      => 1,
					'max_depth'  => 5,
				);

				comment_reply_link( $args );
				?>
			</div>

		</div>
	</div>