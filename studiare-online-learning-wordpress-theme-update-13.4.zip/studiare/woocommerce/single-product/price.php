<?php
/**
 * Single Product Price
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/price.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;

$custom_class = $product->is_on_sale() ? '' : 'notOnSale';

$discount_percent = 0;

if ( $product->is_on_sale() ) {
	$regular_price = (float) $product->get_regular_price();
	$sale_price    = (float) $product->get_sale_price();

	if ( $regular_price > 0 && $sale_price >= 0 ) {
		$discount_percent = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
	}
}
$product_id = $product->get_id();
$is_course = function_exists('is_sc_course') && is_sc_course( $product_id );

?>

<div class="prcbox">
	<div class="prcrightside">
		<p class="price <?php echo esc_attr( $custom_class ); ?>">
			<span class="price-label">
				<?php
				if ( $is_course ) {
					esc_html_e( 'Course Price', 'studiare' );
				} else {
					esc_html_e( 'Price', 'studiare' );
				}
				?>
			</span>
		</p>
	</div>

	<div class="prcrleftside">
		<?php if ( $product->is_on_sale() ) : ?>
		<div class="scregularprice">
			<del aria-hidden="true">
				<?php echo wc_price( $product->get_regular_price() ); ?>

				
			</del>
                <?php if ( $discount_percent > 0 ) : ?>
    				<span class="discount-badge">
    						-<?php echo esc_html( $discount_percent ); ?>%
    				</span>
    			<?php endif; ?>
        </div>
        <ins aria-hidden="true" class="font-bold">
			    <?php 
    				if ( $discount_percent == 100 ) {
    					echo esc_html__( 'Free!', 'studiare' );
    				} else {
    					echo wc_price( $product->get_sale_price() );
    				}
				?>
        </ins>
		<?php else : ?>
			<span class="price font-bold">
				<?php echo wp_kses_post( $product->get_price_html() ); ?>
			</span>
		<?php endif; ?>
	</div>
</div>
