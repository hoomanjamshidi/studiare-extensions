<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Sc_Product_Category_Menu extends Widget_Base {

    public function get_name() {
        return 'sc-product-category-menu';
    }

    public function get_title() {
        return esc_html__( 'Product Category Menu', 'studiare' );
    }

    public function get_icon() {
        return 'sc eicon-menu-bar';
    }

    public function get_categories() {
        return [ 'studiare-woocommerce' ];
    }

    protected function register_controls() {

        // ── Content / General ────────────────────────────────────────
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__( 'Settings', 'studiare' ),
            ]
        );

        $this->add_control(
            'cat_number',
            [
                'label'       => esc_html__( 'Number of Categories', 'studiare' ),
                'type'        => Controls_Manager::NUMBER,
                'min'         => 0,
                'default'     => 10,
                'description' => esc_html__( 'Set 0 to show all.', 'studiare' ),
            ]
        );

        $this->add_control(
            'hide_empty',
            [
                'label'       => esc_html__( 'Hide Empty Categories', 'studiare' ),
                'type'        => Controls_Manager::SWITCHER,
                'label_on'    => esc_html__( 'Yes', 'studiare' ),
                'label_off'   => esc_html__( 'No', 'studiare' ),
                'return_value'=> 'yes',
                'default'     => '',
            ]
        );

        $this->add_control(
            'order_by',
            [
                'label'   => esc_html__( 'Order By', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'menu_order',
                'options' => [
                    'menu_order' => esc_html__( 'Menu Order (as set in WP admin)', 'studiare' ),
                    'name'       => esc_html__( 'Name', 'studiare' ),
                    'slug'       => esc_html__( 'Slug', 'studiare' ),
                    'count'      => esc_html__( 'Product Count', 'studiare' ),
                    'rand'       => esc_html__( 'Random', 'studiare' ),
                ],
            ]
        );

        $this->add_control(
            'order',
            [
                'label'     => esc_html__( 'Sort Direction', 'studiare' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'ASC',
                'options'   => [
                    'ASC'  => esc_html__( 'Ascending', 'studiare' ),
                    'DESC' => esc_html__( 'Descending', 'studiare' ),
                ],
                'condition' => [
                    'order_by!' => 'rand',
                ],
            ]
        );

        $this->add_control(
            'show_all_link',
            [
                'label'   => esc_html__( 'Show "All {Parent}" link', 'studiare' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // ── Content / Icons ───────────────────────────────────────────
        $this->start_controls_section(
            'section_icons',
            [
                'label' => esc_html__( 'Icons', 'studiare' ),
            ]
        );

        $this->add_control(
            'show_category_icons',
            [
                'label'   => esc_html__( 'Show Category Icons', 'studiare' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_responsive_control(
            'category_icon_size',
            [
                'label'     => esc_html__( 'Icon Size', 'studiare' ),
                'type'      => Controls_Manager::SLIDER,
                'size_units'=> [ 'px' ],
                'range'     => [
                    'px' => [ 'min' => 16, 'max' => 64, 'step' => 1 ],
                ],
                'default'   => [
                    'unit' => 'px',
                    'size' => 25,
                ],
                'selectors' => [
                    '{{WRAPPER}} .cat-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_category_icons' => 'yes',
                ],
            ]
        );
        
        $this->add_control(
            'toggle_icon_mode',
            [
                'label'   => esc_html__( 'Customize Toggle Icon', 'studiare' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'false',
            ]
        );

        $this->add_control(
            'toggle_icon',
            [
                'label'   => esc_html__( 'Toggle Icon (main button)', 'studiare' ),
                'type'    => Controls_Manager::ICONS,
                'default' => [
                    'value'   => 'fas fa-bars',
                    'library' => 'fa-solid',
                ],
                'skin'    => 'inline',
                'condition' => [
                    'toggle_icon_mode' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'toggle_icon_size',
            [
                'label'     => esc_html__( 'Toggle Icon Size', 'studiare' ),
                'type'      => Controls_Manager::SLIDER,
                'size_units'=> [ 'px' ],
                'range'     => [
                    'px' => [ 'min' => 14, 'max' => 48 ],
                ],
                'default'   => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .category-toggle-icon i'   => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .category-toggle-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

// ── Style / Toggle Button ───────────────────────────────────────
$this->start_controls_section(
    'section_style_toggle',
    [
        'label' => esc_html__( 'Toggle Button', 'studiare' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// Typography for text
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'toggle_typo',
        'label'    => esc_html__( 'Typography', 'studiare' ),
        'selector' => '{{WRAPPER}} .category-toggle-text',
    ]
);

// Padding (affects overall button size)
$this->add_responsive_control(
    'toggle_padding',
    [
        'label'      => esc_html__( 'Padding', 'studiare' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', 'em', '%' ],
        'selectors'  => [
            '{{WRAPPER}} .category-menu-toggle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
        'separator'  => 'before',
    ]
);

// ── Normal State ────────────────────────────────────────────────
$this->start_controls_tabs( 'toggle_style_tabs' );

$this->start_controls_tab(
    'toggle_normal',
    [ 'label' => esc_html__( 'Normal', 'studiare' ) ]
);

// Background - Normal
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'toggle_bg_normal',
        'label'    => esc_html__( 'Background', 'studiare' ),
        'types'    => [ 'classic', 'gradient' ],
        'selector' => '{{WRAPPER}} .category-menu-toggle',
    ]
);

// Text & Icon Color - Normal
$this->add_control(
    'toggle_text_color_normal',
    [
        'label'     => esc_html__( 'Text Color', 'studiare' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .category-menu-toggle' => 'color: {{VALUE}};',
        ],
    ]
);

$this->add_control(
    'toggle_icon_color_normal',
    [
        'label'     => esc_html__( 'Icon Color', 'studiare' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .category-toggle-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
        ],
    ]
);

// Border - Normal
$this->add_group_control(
    Group_Control_Border::get_type(),
    [
        'name'     => 'toggle_border_normal',
        'selector' => '{{WRAPPER}} .category-menu-toggle',
        'separator' => 'before',
    ]
);

// Border Radius - Normal
$this->add_responsive_control(
    'toggle_border_radius_normal',
    [
        'label'      => esc_html__( 'Border Radius', 'studiare' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'selectors'  => [
            '{{WRAPPER}} .category-menu-toggle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// Box Shadow - Normal
$this->add_group_control(
    Group_Control_Box_Shadow::get_type(),
    [
        'name'     => 'toggle_box_shadow_normal',
        'label'    => esc_html__( 'Box Shadow', 'studiare' ),
        'selector' => '{{WRAPPER}} .category-menu-toggle',
    ]
);

$this->end_controls_tab();

// ── Hover State ─────────────────────────────────────────────────
$this->start_controls_tab(
    'toggle_hover',
    [ 'label' => esc_html__( 'Hover', 'studiare' ) ]
);

// Background - Hover
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'toggle_bg_hover',
        'label'    => esc_html__( 'Background', 'studiare' ),
        'types'    => [ 'classic', 'gradient' ],
        'selector' => '{{WRAPPER}} .category-menu-toggle:hover',
    ]
);

// Text & Icon Color - Hover
$this->add_control(
    'toggle_text_color_hover',
    [
        'label'     => esc_html__( 'Text Color', 'studiare' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .category-menu-toggle:hover' => 'color: {{VALUE}};',
        ],
    ]
);

$this->add_control(
    'toggle_icon_color_hover',
    [
        'label'     => esc_html__( 'Icon Color', 'studiare' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .category-menu-toggle:hover .category-toggle-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
        ],
    ]
);

// Border - Hover
$this->add_group_control(
    Group_Control_Border::get_type(),
    [
        'name'     => 'toggle_border_hover',
        'selector' => '{{WRAPPER}} .category-menu-toggle:hover',
    ]
);

// Border Radius - Hover
$this->add_responsive_control(
    'toggle_border_radius_hover',
    [
        'label'      => esc_html__( 'Border Radius', 'studiare' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'selectors'  => [
            '{{WRAPPER}} .category-menu-toggle:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// Box Shadow - Hover
$this->add_group_control(
    Group_Control_Box_Shadow::get_type(),
    [
        'name'     => 'toggle_box_shadow_hover',
        'label'    => esc_html__( 'Box Shadow', 'studiare' ),
        'selector' => '{{WRAPPER}} .category-menu-toggle:hover',
    ]
);

$this->end_controls_tab();

$this->end_controls_tabs();

$this->end_controls_section();

        // ── Style / Menu Items ────────────────────────────────────────
        $this->start_controls_section(
            'section_style_menu',
            [
                'label' => esc_html__( 'Menu & Submenu', 'studiare' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // ── Level 1 (Parents)
        $this->add_control(
            'heading_level_1',
            [
                'label'     => esc_html__( 'Level 1 (Main Categories)', 'studiare' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'level1_typo',
                'selector' => '{{WRAPPER}} .header-category-dropdown > li > a .cat-name',
            ]
        );

        $this->start_controls_tabs('level1_colors');

        $this->start_controls_tab('level1_normal', [ 'label' => esc_html__( 'Normal', 'studiare' ) ]);

        $this->add_control(
            'level1_color',
            [
                'label'     => esc_html__( 'Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header-category-dropdown > li > a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'level1_bg',
            [
                'label'     => esc_html__( 'Background', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header-category-dropdown > li' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab('level1_hover', [ 'label' => esc_html__( 'Hover', 'studiare' ) ]);

        $this->add_control(
            'level1_color_hover',
            [
                'label'     => esc_html__( 'Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header-category-dropdown > li > a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'level1_bg_hover',
            [
                'label'     => esc_html__( 'Background', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header-category-dropdown > li:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        // ── Submenu (Level 2)
        $this->add_control(
            'heading_submenu',
            [
                'label'     => esc_html__( 'Submenu (Level 2)', 'studiare' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'submenu_typo',
                'selector' => '{{WRAPPER}} .sub-categories .cat-name',
            ]
        );

        $this->start_controls_tabs('submenu_colors');

        $this->start_controls_tab('submenu_normal', [ 'label' => esc_html__( 'Normal', 'studiare' ) ]);

        $this->add_control(
            'submenu_color',
            [
                'label'     => esc_html__( 'Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-categories a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'submenu_bg',
            [
                'label'     => esc_html__( 'Background', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-categories' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab('submenu_hover', [ 'label' => esc_html__( 'Hover', 'studiare' ) ]);

        $this->add_control(
            'submenu_color_hover',
            [
                'label'     => esc_html__( 'Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-categories a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'submenu_bg_hover',
            [
                'label'     => esc_html__( 'Background', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sub-categories .cat-item:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();
    }


    protected function render() {

        $settings = $this->get_settings_for_display();

        $cat_number   = (int) $settings['cat_number'];
        $hide_empty   = 'yes' === $settings['hide_empty'];
        $show_all     = 'yes' === $settings['show_all_link'];
        $show_icons   = 'yes' === $settings['show_category_icons'];
        $icon_size    = ! empty( $settings['category_icon_size']['size'] ) ? $settings['category_icon_size']['size'] : 25;

        $orderby = in_array( $settings['order_by'], [ 'name', 'slug', 'count', 'menu_order', 'rand' ] )
            ? $settings['order_by']
            : 'menu_order';

        $order = ( 'rand' !== $orderby && 'DESC' === $settings['order'] ) ? 'DESC' : 'ASC';

        $args = [
            'taxonomy'   => 'product_cat',
            'orderby'    => $orderby,
            'order'      => $order,
            'hide_empty' => $hide_empty,
            'number'     => $cat_number > 0 ? $cat_number : '',
        ];

        $parent_cats = get_categories( array_merge( $args, [ 'parent' => 0 ] ) );

        if ( empty( $parent_cats ) ) return;
        ?>

        <div class="header-category-menu header-product-category-menu">

            <a href="#" class="header-icon category-menu-toggle">
                <span class="category-toggle-icon">
                <?php
                // Decide which icon to show: custom Elementor icon OR default dots SVG
                if ( 'yes' === $settings['toggle_icon_mode'] ) {
                    // Render selected icon from Elementor Icons control (font or uploaded SVG)
                    \Elementor\Icons_Manager::render_icon(
                        $settings['toggle_icon'],
                        [
                            'aria-hidden' => 'true',
                            'class'       => 'custom-toggle-icon',
                        ]
                    );
                } else {
                    // Default dots SVG when switcher is off or no icon selected
                    ?>
                    <svg width="20" height="20" viewBox="0 0 18 18" version="1.1" xmlns="http://www.w3.org/2000/svg">
                        <g stroke="none" stroke-width="1" fill="currentColor" fill-rule="evenodd">
                            <path d="M2,14 C3.1045695,14 4,14.8954305 4,16 C4,17.1045695 3.1045695,18 2,18 C0.8954305,18 0,17.1045695 0,16 C0,14.8954305 0.8954305,14 2,14 Z M9,14 C10.1045695,14 11,14.8954305 11,16 C11,17.1045695 10.1045695,18 9,18 C7.8954305,18 7,17.1045695 7,16 C7,14.8954305 7.8954305,14 9,14 Z M16,14 C17.1045695,14 18,14.8954305 18,16 C18,17.1045695 17.1045695,18 16,18 C14.8954305,18 14,17.1045695 14,16 C14,14.8954305 14.8954305,14 16,14 Z M2,7 C3.1045695,7 4,7.8954305 4,9 C4,10.1045695 3.1045695,11 2,11 C0.8954305,11 0,10.1045695 0,9 C0,7.8954305 0.8954305,7 2,7 Z M9,7 C10.1045695,7 11,7.8954305 11,9 C11,10.1045695 10.1045695,11 9,11 C7.8954305,11 7,10.1045695 7,9 C7,7.8954305 7.8954305,7 9,7 Z M16,7 C17.1045695,7 18,7.8954305 18,9 C18,10.1045695 17.1045695,11 16,11 C14.8954305,11 14,10.1045695 14,9 C14,7.8954305 14.8954305,7 16,7 Z M2,0 C3.1045695,0 4,0.8954305 4,2 C4,3.1045695 3.1045695,4 2,4 C0.8954305,4 0,3.1045695 0,2 C0,0.8954305 0.8954305,0 2,0 Z M9,0 C10.1045695,0 11,0.8954305 11,2 C11,3.1045695 10.1045695,4 9,4 C7.8954305,4 7,3.1045695 7,2 C7,0.8954305 7.8954305,0 9,0 Z M16,0 C17.1045695,0 18,0.8954305 18,2 C18,3.1045695 17.1045695,4 16,4 C14.8954305,4 14,3.1045695 14,2 C14,0.8954305 14.8954305,0 16,0 Z"></path>
                        </g>
                    </svg>
                    <?php
                }
                ?>
            </span>
                <span class="category-toggle-text"><?php esc_html_e( 'Categories', 'studiare' ); ?></span>
            </a>

            <nav class="header-category-dropdown-wrap">
                <ul class="header-category-dropdown">
                    <?php foreach ( $parent_cats as $parent ):

                        $cat_color = get_term_meta( $parent->term_id, 'category_color', true );
                        $children  = get_categories( array_merge( $args, [ 'parent' => $parent->term_id ] ) );
                        $has_child = ! empty( $children );
                    ?>
                    <li class="cat-item <?php echo $has_child ? 'has-children' : ''; ?>"
                        <?php if ( $cat_color ) echo 'style="--cat-hover-color:' . esc_attr( $cat_color ) . ';"'; ?>>

                        <a href="<?php echo esc_url( get_term_link( $parent ) ); ?>">
                            <span class="cat-title-wrap">
                                <?php if ( $show_icons ) :
                                    $icon_id = (int) get_term_meta( $parent->term_id, 'sc_studi_cat_icon', true );
                                    if ( $icon_id > 0 ) {
                                        echo wp_get_attachment_image( $icon_id, [ $icon_size, $icon_size ], false, [
                                            'class'   => 'cat-icon',
                                            'loading' => 'lazy',
                                            'alt'     => esc_attr( sprintf( __( '%s category', 'studiare' ), $parent->name ) )
                                        ] );
                                    }
                                endif; ?>
                                <span class="cat-name"><?php echo esc_html( $parent->name ); ?></span>
                            </span>
                            <?php if ( $has_child ): ?>
                                <span class="toggle-sub-menu"></span>
                            <?php endif; ?>
                        </a>

                        <?php if ( $has_child ): ?>
                        <ul class="children sub-categories">
                            <?php if ( $show_all ): ?>
                            <li class="cat-item all-category">
                                <a href="<?php echo esc_url( get_term_link( $parent ) ); ?>">
                                    <?php printf( esc_html__( 'All %s', 'studiare' ), esc_html( $parent->name ) ); ?>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php foreach ( $children as $child ):
                                $child_icon_id = (int) get_term_meta( $child->term_id, 'sc_studi_cat_icon', true );
                            ?>
                            <li class="cat-item <?php echo $child->count > 0 ? 'has-products' : ''; ?>"
                                <?php if ( $child->count > 0 ) echo 'data-sub-id="' . esc_attr( $child->term_id ) . '"'; ?>>
                                <a href="<?php echo esc_url( get_term_link( $child ) ); ?>">
                                    <span class="cat-title-wrap">
                                        <?php if ( $show_icons && $child_icon_id > 0 ) {
                                            echo wp_get_attachment_image( $child_icon_id, [ $icon_size, $icon_size ], false, [
                                                'class'   => 'cat-icon',
                                                'loading' => 'lazy',
                                                'alt'     => esc_attr( sprintf( __( '%s category', 'studiare' ), $child->name ) )
                                            ] );
                                        } ?>
                                        <span class="cat-name"><?php echo esc_html( $child->name ); ?></span>
                                    </span>
                                </a>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        </div>

        <?php
    }
}