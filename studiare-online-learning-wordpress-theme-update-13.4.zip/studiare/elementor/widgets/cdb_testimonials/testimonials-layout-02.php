<?php
// ─── Layout 2: Enhanced Centered Swiper Style (like most modern testimonial carousels) ─────────────
$slide_width = 100/$sc_studi_cat_carouseitems_in_desktop;
?>
            <style>
               span.sctl2_icon { align-items: center; display: inline-flex; justify-content: center; width: 30px; }
               .sctl2_top_info { display: flex; align-items: center;justify-content: space-between; }
               .sctl2_author { display: flex; align-items: center; }
               .sctl2_author img { border-radius: 50px; }
               .sctl2_author_info{text-align: right;justify-content: flex-start;flex-direction: column;display: flex;margin-right: 20px; }
               article.sctl2_card { padding: 32px; border: 1px solid #e9ecef; border-radius: 16px; display: flex; flex-direction: column;  }
               .sctl2_slide_holder{min-height:230px;width:calc(<?php echo $slide_width."%"?> - 14px);}
               .sctl2_content_txt{margin-top:12px;text-align:justify;}
               span.swiper-pagination-bullet.swiper-pagination-bullet-active { width: 30px; border-radius: 12px; }
            </style>

            <div class="sc-testimonials-layout2">
                <div class="swiper swiper-testimonial" id="swiper-testi-<?php echo esc_attr( $jrand ); ?>">
                    <div class="swiper-wrapper">
                        <?php foreach ( $settings['list'] as $item ) :
                            $img_id  = $item['image']['id'] ?? 0;
                            $img_url = $img_id ? wp_get_attachment_image_url( $img_id, 'medium_large' ) : \Elementor\Utils::get_placeholder_image_src();
                            $alt     = esc_attr( $item['title'] ?? 'Testimonial author' );
                        ?>
                            <div class="swiper-slide sctl2_slide_holder">
                                <div class="sctl2_card_holder">
                                    <article class="sctl2_card">
                                        <div class="sctl2_top_info">
                                            <div class="sctl2_author">
                                                <img src="<?php echo esc_url( $img_url ); ?>" alt="<?php echo $alt; ?>">
                                                <?php if ( ! empty( $item['video']['url'] ) && ! empty( $settings['enable_video_popup'] ) && $settings['enable_video_popup'] === 'yes' ) : ?>
                                                    <a href="<?php echo esc_url( $item['video']['url'] ); ?>" class="video-play-overlay">
                                                        <svg width="60" height="60" viewBox="0 0 24 24" fill="white">
                                                            <path d="M8 5v14l11-7z"/>
                                                        </svg>
                                                    </a>
                                                <?php endif; ?>
                                                <div class="sctl2_author_info">
                                                    <?php if ( ! empty( $item['title'] ) ) : ?>
                                                        <h5><?php echo esc_html( $item['title'] ); ?></h5>
                                                    <?php endif; ?>
                                                    <?php if ( ! empty( $item['role'] ) ) : ?>
                                                        <p><?php echo esc_html( $item['role'] ); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <span class="sctl2_icon"><svg xmlns="http://www.w3.org/2000/svg" width="1em" fill="#009ca7" viewBox="0 0 29 28" style="--svg-origin-width:1000;--svg-origin-width--with-unit:1000px;" data-svg-origin-width="1000" data-svg-origin-height="" font-size="1000"><path d="M15.832 22.96v-9.175l5.462-8.745h4.726l-4.204 8.193h4.204v9.727zm-12.366 0v-9.175l5.37-8.745h4.848L9.39 13.233h4.295v9.727z"></path></svg></span>
                                        </div>
                                        <div class="sctl2_content">
                                            <div class="sctl2_content_txt">
                                                <?php echo wp_kses_post( $item['testimonial'] ); ?>
                                            </div>
                                            
                                        </div>
                                    </article>    
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>

            <script>
            jQuery(document).ready(function($) {
                new Swiper('#swiper-testi-<?php echo esc_js( $jrand ); ?>', {
                    loop: true,
                    centeredSlides: false,
                    slidesPerView: 'auto', 
                    spaceBetween: 20,
                    grabCursor: true,
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true,
                    },
                    breakpoints: {
                        0:    { slidesPerView: <?php echo $sc_studi_cat_carouseitems_in_mobile;?>, spaceBetween: 15 },
                        768:  { slidesPerView: <?php echo $sc_studi_cat_carouseitems_in_tablet;?>, spaceBetween: 15 },
                        1025: { slidesPerView: 'auto', spaceBetween: 15 }
                    },
                    autoplay: {
                        delay: 5500,
                        disableOnInteraction: false,
                    },
                });
            });
            </script>
            