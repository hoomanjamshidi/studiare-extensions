<?php
namespace Elementor;

class Cdb_Testimonials extends Widget_Base {
	
	public function get_name() {
		return 'users-testimonialls';
	}
	
	public function get_title() {
		return  __( 'Testimonials', 'studiare' );
	}
	
	public function get_icon() {
		return 'sc eicon-testimonial-carousel';
	}
	
	public function get_categories() {
		return [ 'studiare' ];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'studiare' ),
			]
		);
		
		$this->add_control(
            'layout_style',
            [
                'label'       => __( 'Layout', 'studiare' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => 'layout1',
                'options'     => [
                    'layout1' => __( 'Layout 1', 'studiare' ),
                    'layout2' => __( 'Layout 2', 'studiare' ),
                ],
                'label_block' => true,
                'separator'   => 'before',
            ]
        );
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title', [
				'label' => __( 'Title', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '',
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'role', [
				'label' => __( 'Role', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '',
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'testimonial', [
				'label' => __( 'User Testimonial', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => '',
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'image', [
				'label' => __( 'User Image', 'studiare' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
            'video', [
                'label' => __( 'User Video', 'studiare' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'media_types' => ['video'],
                'default' => [],
            ]
        );
        $repeater->add_control(
            'video_poster', [
                'label' => __( 'Video Poster', 'studiare' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'media_types' => ['image'],
                'default' => [],
                'condition' => [
                    'video[url]!' => '',
                ],
            ]
        );
        
        

		
		$this->add_control(
			'list',
			[
				'label' => __( 'Testimonials List', 'studiare' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				/*'default' => [
					[
						'list_title' => __( 'Title #1', 'studiare' ),
						'list_content' => __( 'Item content. Click the edit button to change this text.', 'studiare' ),
					],
					[
						'list_title' => __( 'Title #2', 'studiare' ),
						'list_content' => __( 'Item content. Click the edit button to change this text.', 'studiare' ),
					],
				],*/
				'title_field' => '{{{ title }}}',
			]
		);
		
		$this->add_control(
            'enable_video_popup',
            [
                'label' => __( 'Enable Video Popup', 'studiare' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'studiare' ),
                'label_off' => __( 'No', 'studiare' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $this->add_control(
            'default_video_poster', [
                'label' => __( 'Default Video Poster', 'studiare' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'media_types' => ['image'],
                'default' => [],
                'condition' => [
                    'enable_video_popup!' => 'yes',
                ],
            ]
        );
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_layout',
			[
				'label' => __( 'Layout', 'studiare' ),
			]
		);
		
		
		$this->add_control(
			'sc_studi_cat_carouseitems_in_desktop',
			[
				'label' => __( 'Columns in desktop', 'studiare' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => '',
                'default' => '4',
			]
		);
		$this->add_control(
			'sc_studi_cat_carouseitems_in_tablet',
			[
				'label' => __( 'Columns in tablet', 'studiare' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => '',
                'default' => '2',
			]
		);
		$this->add_control(
			'sc_studi_cat_carouseitems_in_mobile',
			[
				'label' => __( 'Columns in mobile', 'studiare' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
                'placeholder' => '',
                'default' => '1',
			]
		);
		$this->add_responsive_control(
            'video_max_height',
            [
                'label' => __( 'Video Max Height', 'studiare' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 500,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 220,
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-video video' => 'max-height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'enable_video_popup!' => 'yes',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'box_min_height',
            [
                'label' => __( 'Box Min Height', 'studiare' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 500,
                        'step' => 1,
                    ],
                    
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 220,
                ],
                'selectors' => [
                    '{{WRAPPER}} .sctl2_card' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'layout_style' => 'layout2',
                ],
            ]
        );

		$this->add_control(
			'sc_dots_active_color',
			[
				'label' => __( 'Dots active color', 'studiare' ),
				'label_block' => true,
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owl-dot.active span' => 'background: {{VALUE}} !important',
					'{{WRAPPER}} .swiper-pagination-bullet-active' => 'background: {{VALUE}} !important',
				],
			]
		);
		$this->add_control(
			'sc_dots_normal_color',
			[
				'label' => __( 'Dots normal color', 'studiare' ),
				'label_block' => true,
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owl-dot span' => 'background: {{VALUE}} !important',
					'{{WRAPPER}} .swiper-pagination-bullet' => 'background: {{VALUE}} !important',
				],
			]
		);
		
		
		$this->end_controls_section();
	}
	
	protected function render() {

        $settings = $this->get_settings_for_display();
        $css_class = "testimonials-wrapper";
       
        
        $layout_style = $settings['layout_style'] ;
        $sc_studi_cat_carouseitems_in_desktop = $settings['sc_studi_cat_carouseitems_in_desktop'] ;
        $sc_studi_cat_carouseitems_in_tablet  = $settings['sc_studi_cat_carouseitems_in_tablet'] ;
        $sc_studi_cat_carouseitems_in_mobile  = $settings['sc_studi_cat_carouseitems_in_mobile'] ;
        
        $jrand=rand(100,10000);     
        
        if ( $settings['list'] ) {
            
            if($layout_style == 'layout1'){
                include_once 'testimonials-layout-01.php';
            }
            if($layout_style == 'layout2'){
                include_once 'testimonials-layout-02.php';
            }
            
        }
        
        
        
	}
	
	protected function _content_template() {
	 
    }
	
	
}