(function ($) {
    "use strict";

    var StudiTabsHandler = function ($scope, $) {
        var $container = $scope.find('.studi-tabs-container');
        var $navItems  = $scope.find('.studi-tabs-nav li');
        var $content   = $scope.find('.studi-tabs-ajax-content');
        var $loader    = $scope.find('.studi-tabs-loader');
        var tabCache   = {};

        // Cache raw HTML before any carousel init
        tabCache['all'] = $content.html();

        // ── Rock‑solid carousel destruction ──
        function destroyCarousel(container) {
            var $carousel = container.find('.owl-carousel');
            if (!$carousel.length) return;

            // Try to gracefully destroy if Owl instance exists
            try {
                if ($carousel.data('owl.carousel')) {
                    // Remove all Owl events first to prevent any callbacks
                    $carousel.off();
                    $carousel.trigger('destroy.owl.carousel');
                }
            } catch (e) {
                // Ignore any errors during destroy
            }

            // Aggressive cleanup: completely strip every trace of Owl
            $carousel
                .removeClass('owl-carousel owl-loaded owl-drag owl-hidden')
                .find('.owl-stage-outer').children().unwrap()  // lift items out of stage
                .end()
                .find('.owl-nav, .owl-dots').remove()         // delete nav/dots
                .end()
                .removeData();                                // nuke jQuery data
        }

        // ── Carousel initialization ──
        function initCarousels(container) {
            container.find('.owl-carousel').each(function () {
                var $carousel = $(this),
                    optsData  = $carousel.data('slider-opts');
        
                if (!optsData || $carousel.hasClass('owl-loaded')) return;
        
                function getSlideBy(val) {
                    return (val && val > 0) ? val : 'page';
                }
        
                $carousel.owlCarousel({
                    loop:             optsData.loop || false,
                    nav:              optsData.nav || false,
                    dots:             optsData.dots || false,
                    autoplay:         optsData.autoplay || false,
                    autoplayTimeout:  optsData.autoplayTimeout || 5000,
                    navText:          ["<i class='fal fa-chevron-right'></i>", "<i class='fal fa-chevron-left'></i>"],
                    responsive: {
                        0: {
                            items:   parseInt(optsData.itemsMobile, 10) || 2,
                            slideBy: getSlideBy(optsData.slideByMobile)
                        },
                        768: {
                            items:   parseInt(optsData.itemsTablet, 10) || 3,
                            slideBy: getSlideBy(optsData.slideByTablet)
                        },
                        1000: {
                            items:   parseInt(optsData.itemsDesktop, 10) || 4,
                            slideBy: getSlideBy(optsData.slideByDesktop)
                        }
                    }
                });
            });
        }


        // Initial load carousel
        initCarousels($content);

        // ── Tab click logic ──
        $navItems.on('click', function () {
            var $this = $(this);
            var catID = $this.data('cat-id');
            var atts  = $container.data('atts');
        
            if ($this.hasClass('active') || $container.hasClass('is-loading')) return;
        
            $navItems.removeClass('active');
            $this.addClass('active');
        
            if (tabCache[catID]) {
                $content
                    .stop(true, true)
                    .css('opacity', '0.4')
                    .html(tabCache[catID]);
        
                initCarousels($content);
        
                $content.animate({ opacity: 1 }, 250);
                return;
            }
        
            $container.addClass('is-loading');
            $loader.fadeIn(100);
            $content.stop(true, true).css('opacity', '0.4');
        
            $.ajax({
                url: studiTabsParams.ajaxurl,
                type: 'post',
                data: {
                    action: 'studi_tabs_load_products',
                    cat_id: catID,
                    atts: atts
                },
                success: function (res) {
                    if (res.success) {
                        tabCache[catID] = res.data;
        
                        $content.html(res.data);
        
                        initCarousels($content);
        
                        $(document.body).trigger('updated_wc_div');
                    }
                },
                complete: function () {
                    $container.removeClass('is-loading');
                    $loader.fadeOut(100);
                    $content.stop(true, true).animate({ opacity: 1 }, 250);
                }
            });
        });

    };

    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/Studi_Products_Tabs.default', StudiTabsHandler);
    });

})(jQuery);