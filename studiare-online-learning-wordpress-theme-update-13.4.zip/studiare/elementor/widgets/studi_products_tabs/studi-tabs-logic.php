<?php
/**
 * Optimized Product fetching logic with "All" support
 */

function studi_fetch_products_callback( $atts, $cat_ids ) {
    $original_loop = isset( $GLOBALS['woocommerce_loop'] ) ? $GLOBALS['woocommerce_loop'] : null;

    $args = [
        'post_type'      => 'product',
        'posts_per_page' => $atts['limit'],
        'post_status'    => 'publish',
        'tax_query'      => [],
    ];

    // Handle "All" or Specific Category
    if ( ! empty( $cat_ids ) ) {
        $args['tax_query'][] = [
            'taxonomy' => 'product_cat',
            'field'    => 'term_id',
            'terms'    => is_array($cat_ids) ? $cat_ids : explode(',', $cat_ids),
            'operator' => 'IN',
        ];
    }

    // Product Type Filters
    switch ( $atts['product_type'] ) {
        case 'sale':
            $args['post__in'] = array_merge( [0], wc_get_product_ids_on_sale() );
            break;
        case 'best_selling':
            $args['meta_key'] = 'total_sales';
            $args['orderby']  = 'meta_value_num';
            break;
        case 'top_rated':
            $args['meta_key'] = '_wc_average_rating';
            $args['orderby']  = 'meta_value_num';
            break;
        default:
            $args['orderby'] = 'date';
            $args['order']   = 'DESC';
    }

    $query = new WP_Query($args);

    if ( $query->have_posts() ) {
        
        // Determine whether to use slider
        $use_slider = ( 'yes' === $atts['enable_slider'] ) && ( $query->found_posts > $atts['slider_items']['desktop'] );
        $show_mode = $atts['product_layout'] ?: 'grid';
        $columns = absint( $atts['columns'] ?: 4 );   // fallback, adjust as needed

          // Build container classes
        if ( $use_slider ) {
            $wrapper_classes = [ 'products products-carousel', 'owl-carousel owl-theme' ];
        } else {
            $wrapper_classes = [ 'products', ( 'grid' == $show_mode ? 'grid-view' : 'list-view' ) ];
            $wrapper_classes[] = 'courses-' . $columns . '-columns';
        }

        // Open wrapper with data attributes for carousel
        echo '<div class="' . esc_attr( implode( ' ', $wrapper_classes ) ) . '"';
        
        if ( $use_slider ) {
            echo ' style="--studi-slider-desktop:' . esc_attr( absint( $atts['slider_items']['desktop'] ) ) . ';';
            echo '--studi-slider-tablet:' . esc_attr( absint( $atts['slider_items']['tablet'] ) ) . ';';
            echo '--studi-slider-mobile:' . esc_attr( absint( $atts['slider_items']['mobile'] ) ) . ';"';
        }

        if ( $use_slider ) {
            $slider_opts = [
                'itemsDesktop'      => $atts['slider_items']['desktop'],
                'itemsTablet'       => $atts['slider_items']['tablet'],
                'itemsMobile'       => $atts['slider_items']['mobile'],
                'nav'               => 'yes' === $atts['slider_nav'],
                'dots'              => 'yes' === $atts['slider_dots'],
                'autoplay'          => 'yes' === $atts['slider_autoplay'],
                'autoplayTimeout'   => absint( $atts['slider_autoplay_timeout'] ),
                'loop'              => 'yes' === $atts['slider_loop'],
                'slideByDesktop'    => absint( $atts['slider_slideby']['desktop'] ),
                'slideByTablet'     => absint( $atts['slider_slideby']['tablet'] ),
                'slideByMobile'     => absint( $atts['slider_slideby']['mobile'] ),
            ];
            echo ' data-slider-opts="' . esc_attr( wp_json_encode( $slider_opts ) ) . '"';

        }
        echo '>';

        // Optional: add any before-loop actions if your theme relies on them
        // do_action( 'woocommerce_before_shop_loop' );   // ← only if needed (result count, ordering etc.)

        while ( $query->have_posts() ) : $query->the_post();
            // Important: setup global $product so templates work
            global $product;
            $product = wc_get_product( get_the_ID() );
            
            switch($atts['product_box']){
                case 'default':
                wc_get_template_part( 'content', 'product' );
                break;
                
                case 'pb01':
                wc_get_template_part( 'content', 'product' );
                break;
                
                case 'pb02':
                wc_get_template_part( 'suncode-content-product' );
                break;
                
                case 'pb03':
                wc_get_template_part( 'suncode-content-product-l3' );
                break;
                
                case 'pb04':
                wc_get_template_part( 'suncode-content-product-l4' );
                break;
                
                case 'pb05':
                wc_get_template_part( 'suncode-content-product-l5' );
                break;
                
                case 'pb06':
                wc_get_template_part( 'product_cards/pro_card_layout_06' );
                break;
                
                default:
                wc_get_template_part( 'content', 'product' );
                break;
                    
                    
            }
            //
            

        endwhile;

        // Optional: after loop actions
        // do_action( 'woocommerce_after_shop_loop' );   // ← pagination etc. – but probably not needed here
        echo '</div>';  // close the div
    } else {
        echo '<p class="no-products">' . __( 'No products found.', 'studiare' ) . '</p>';
    }
    wp_reset_postdata();
    // Very important: clean up after custom loop!
    // Aggressive reset
    if ( null !== $original_loop ) {
        $GLOBALS['woocommerce_loop'] = $original_loop;
    } else {
        unset( $GLOBALS['woocommerce_loop'] );
    }
    
    wc_reset_loop();

    
}

// AJAX Handler
add_action('wp_ajax_studi_tabs_load_products', 'studi_tabs_ajax_handler');
add_action('wp_ajax_nopriv_studi_tabs_load_products', 'studi_tabs_ajax_handler');

function studi_tabs_ajax_handler() {
    $atts   = $_POST['atts'];
    $cat_id = $_POST['cat_id']; // Can be 'all' or numeric ID

    ob_start();
    if ( $cat_id === 'all' ) {
        studi_fetch_products_callback($atts, $atts['all_ids']);
    } else {
        studi_fetch_products_callback($atts, $cat_id);
    }
    $html = ob_get_clean();

    wp_send_json_success($html);
}