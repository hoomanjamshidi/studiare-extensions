<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

class Studi_Products_Tabs extends Widget_Base {

    public function get_name() {
        return 'Studi_Products_Tabs';
    }

    public function get_title() {
        return __( 'Products Category Tabs', 'studiare' );
    }

    public function get_icon() {
        return 'sc fal fa-th-list';
    }

    public function get_categories() {
        return [ 'studiare' ];
    }

    public function get_style_depends() {
        return [ 'studi-products-tabs' ];
    }

    public function get_script_depends() {
        return [ 'studi-products-tabs' ];
    }

    protected function register_controls() {
        /* =====================
         * Content: General
         * ===================== */
        $this->start_controls_section(
            'section_general',
            [ 'label' => __( 'General Settings', 'studiare' ) ]
        );

        $this->add_control(
            'title',
            [
                'label'   => __( 'Section Title', 'studiare' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Featured Categories', 'studiare' ),
            ]
        );

        $this->add_control(
            'product_cats',
            [
                'label'       => __( 'Select Categories', 'studiare' ),
                'type'        => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple'    => true,
                'options'     => $this->get_woo_categories(),
            ]
        );

        $this->add_control(
            'product_type',
            [
                'label'   => __( 'Products Source', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'recent',
                'options' => [
                    'recent'       => __( 'Recent Products', 'studiare' ),
                    'sale'         => __( 'Sale Products', 'studiare' ),
                    'best_selling' => __( 'Best Selling', 'studiare' ),
                    'top_rated'    => __( 'Top Rated', 'studiare' ),
                ],
            ]
        );

        $this->add_control(
            'limit',
            [
                'label'   => __( 'Count', 'studiare' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 4,
            ]
        );
        
        $this->add_control(
            'product_box',
            [
                'label'   => __( 'Style', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default'   => __( 'default', 'studiare' ),
                    'pb01'      => __( 'Design', 'studiare' )." 1",
                    'pb02'      => __( 'Design', 'studiare' )." 2",
                    'pb03'      => __( 'Design', 'studiare' )." 3",
                    'pb04'      => __( 'Design', 'studiare' )." 4",
                    'pb05'      => __( 'Design', 'studiare' )." 5",
                    'pb06'      => __( 'Design', 'studiare' )." 6",
                ],
            ]
        );
        
        $this->add_control(
            'product_layout',
            [
                'label'   => __( 'Layout', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'grid',
                'options' => [
                    'grid'         => __( 'Grid', 'studiare' ),
                    'list'         => __( 'List', 'studiare' ),
                ],
            ]
        );

        $this->add_control(
            'columns',
            [
                'label'   => __( 'Columns', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '4',
                'options' => [
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
            ]
        );

        $this->end_controls_section();
// Slider Settings
$this->start_controls_section(
    'section_slider',
    [
        'label' => __( 'Slider Settings', 'studiare' ),
        'tab'   => Controls_Manager::TAB_CONTENT,
    ]
);

$this->add_control(
    'enable_slider',
    [
        'label'        => __( 'Enable Slider', 'studiare' ),
        'type'         => Controls_Manager::SWITCHER,
        'default'      => 'no',
        'return_value' => 'yes',
    ]
);

$this->add_control(
    'slider_items_desktop',
    [
        'label'   => __( 'Items (Desktop)', 'studiare' ),
        'type'    => Controls_Manager::NUMBER,
        'default' => 4,
        'min'     => 1,
        'max'     => 8,
        'condition' => [ 'enable_slider' => 'yes' ],
    ]
);

$this->add_control(
    'slider_items_tablet',
    [
        'label'   => __( 'Items (Tablet)', 'studiare' ),
        'type'    => Controls_Manager::NUMBER,
        'default' => 3,
        'min'     => 1,
        'max'     => 6,
        'condition' => [ 'enable_slider' => 'yes' ],
    ]
);

$this->add_control(
    'slider_items_mobile',
    [
        'label'   => __( 'Items (Mobile)', 'studiare' ),
        'type'    => Controls_Manager::NUMBER,
        'default' => 2,
        'min'     => 1,
        'max'     => 4,
        'condition' => [ 'enable_slider' => 'yes' ],
    ]
);

$this->add_control(
    'slider_nav',
    [
        'label'        => __( 'Show Navigation Arrows', 'studiare' ),
        'type'         => Controls_Manager::SWITCHER,
        'default'      => 'yes',
        'return_value' => 'yes',
        'condition' => [ 'enable_slider' => 'yes' ],
    ]
);

$this->add_control(
    'slider_dots',
    [
        'label'        => __( 'Show Dots', 'studiare' ),
        'type'         => Controls_Manager::SWITCHER,
        'default'      => 'yes',
        'return_value' => 'yes',
        'condition' => [ 'enable_slider' => 'yes' ],
    ]
);
// ── Autoplay ──
$this->add_control(
    'slider_autoplay',
    [
        'label'        => __( 'Autoplay', 'studiare' ),
        'type'         => Controls_Manager::SWITCHER,
        'default'      => 'no',
        'return_value' => 'yes',
        'condition'    => [ 'enable_slider' => 'yes' ],
    ]
);

$this->add_control(
    'slider_autoplay_timeout',
    [
        'label'       => __( 'Autoplay Speed (ms)', 'studiare' ),
        'type'        => Controls_Manager::NUMBER,
        'default'     => 5000,
        'min'         => 1000,
        'step'        => 500,
        'condition'   => [
            'enable_slider'   => 'yes',
            'slider_autoplay' => 'yes',
        ],
    ]
);

// ── Loop ──
$this->add_control(
    'slider_loop',
    [
        'label'        => __( 'Loop', 'studiare' ),
        'type'         => Controls_Manager::SWITCHER,
        'default'      => 'no',
        'return_value' => 'yes',
        'condition'    => [ 'enable_slider' => 'yes' ],
    ]
);

// ── Slide By ──
$this->add_control(
    'slider_slideby_heading',
    [
        'label'     => __( 'Slide By', 'studiare' ),
        'type'      => Controls_Manager::HEADING,
        'separator' => 'before',
        'condition' => [ 'enable_slider' => 'yes' ],
    ]
);

$this->add_control(
    'slider_slideby_desktop',
    [
        'label'       => __( 'Desktop', 'studiare' ),
        'description' => __( 'Number of items to slide. Set 0 to slide by visible columns.', 'studiare' ),
        'type'        => Controls_Manager::NUMBER,
        'default'     => 0,
        'min'         => 0,
        'condition'   => [ 'enable_slider' => 'yes' ],
    ]
);

$this->add_control(
    'slider_slideby_tablet',
    [
        'label'       => __( 'Tablet', 'studiare' ),
        'description' => __( 'Set 0 for auto (visible columns).', 'studiare' ),
        'type'        => Controls_Manager::NUMBER,
        'default'     => 0,
        'min'         => 0,
        'condition'   => [ 'enable_slider' => 'yes' ],
    ]
);

$this->add_control(
    'slider_slideby_mobile',
    [
        'label'       => __( 'Mobile', 'studiare' ),
        'description' => __( 'Set 0 for auto (visible columns).', 'studiare' ),
        'type'        => Controls_Manager::NUMBER,
        'default'     => 0,
        'min'         => 0,
        'condition'   => [ 'enable_slider' => 'yes' ],
    ]
);

$this->end_controls_section();
/* =====================
 * Style: Tabs
 * ===================== */
$this->start_controls_section(
    'section_tabs_style',
    [
        'label' => __( 'Tabs Style', 'studiare' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// ── Tab Header / Navigation Container ───────────────────────────────
$this->add_control(
    'tabs_nav_heading',
    [
        'label'     => __( 'Tabs Navigation', 'studiare' ),
        'type'      => Controls_Manager::HEADING,
        'separator' => 'before',
    ]
);

/** do not delete for version 13.5 needed
$this->add_responsive_control(
    'tabs_alignment',
    [
        'label'     => __( 'Alignment', 'studiare' ),
        'type'      => Controls_Manager::CHOOSE,
        'options'   => [
            'left'   => [
                'title' => __( 'Left', 'studiare' ),
                'icon'  => 'eicon-text-align-left',
            ],
            'center' => [
                'title' => __( 'Center', 'studiare' ),
                'icon'  => 'eicon-text-align-center',
            ],
            'right'  => [
                'title' => __( 'Right', 'studiare' ),
                'icon'  => 'eicon-text-align-right',
            ],
        ],
        'default'   => 'center',
        'selectors' => [
            '{{WRAPPER}} .studi-tabs-nav' => 'text-align: {{VALUE}}; justify-content: {{VALUE}};',
        ],
    ]
);
**/

$this->add_group_control(
    Group_Control_Border::get_type(),
    [
        'name'     => 'tabs_nav_heading_border',
        'selector' => '{{WRAPPER}} .studi-tabs-header', 
    ]
);

$this->add_responsive_control(
    'tabs_gap',
    [
        'label'      => __( 'Tabs Gap', 'studiare' ),
        'type'       => Controls_Manager::SLIDER,
        'size_units' => [ 'px', 'em' ],
        'range'      => [
            'px' => [ 'min' => 0, 'max' => 60 ],
        ],
        'default'    => [ 'unit' => 'px', 'size' => 8 ],
        'selectors'  => [
            '{{WRAPPER}} .studi-tabs-nav li' => 'margin: 0 {{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .studi-tabs-nav'    => 'margin: 0 -{{SIZE}}{{UNIT}};', // negative margin compensation
        ],
    ]
);

// ── Normal Tab Item ─────────────────────────────────────────────────
$this->add_control(
    'tab_normal_heading',
    [
        'label'     => __( 'Normal Tab', 'studiare' ),
        'type'      => Controls_Manager::HEADING,
        'separator' => 'before',
    ]
);

$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'tab_typography',
        'selector' => '{{WRAPPER}} .studi-tabs-nav li',
    ]
);

$this->add_control(
    'tab_color',
    [
        'label'     => __( 'Text Color', 'studiare' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .studi-tabs-nav li' => 'color: {{VALUE}};',
        ],
    ]
);

$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'tab_background',
        'selector' => '{{WRAPPER}} .studi-tabs-nav li',
        'exclude'  => [ 'image' ], // usually tabs don't use bg image
    ]
);

$this->add_group_control(
    Group_Control_Border::get_type(),
    [
        'name'     => 'tab_border',
        'selector' => '{{WRAPPER}} .studi-tabs-nav li',
    ]
);

$this->add_responsive_control(
    'tab_border_radius',
    [
        'label'      => __( 'Border Radius', 'studiare' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'selectors'  => [
            '{{WRAPPER}} .studi-tabs-nav li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

$this->add_responsive_control(
    'tab_padding',
    [
        'label'      => __( 'Padding', 'studiare' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', 'em', '%' ],
        'selectors'  => [
            '{{WRAPPER}} .studi-tabs-nav li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// ── Active Tab Item ─────────────────────────────────────────────────
$this->add_control(
    'tab_active_heading',
    [
        'label'     => __( 'Active Tab', 'studiare' ),
        'type'      => Controls_Manager::HEADING,
        'separator' => 'before',
    ]
);

$this->add_control(
    'tab_active_color',
    [
        'label'     => __( 'Text Color', 'studiare' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .studi-tabs-nav li.active' => 'color: {{VALUE}};',
        ],
    ]
);

$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'tab_active_background',
        'selector' => '{{WRAPPER}} .studi-tabs-nav li.active',
        'exclude'  => [ 'image' ],
    ]
);

$this->add_group_control(
    Group_Control_Border::get_type(),
    [
        'name'     => 'tab_active_border',
        'selector' => '{{WRAPPER}} .studi-tabs-nav li.active',
    ]
);

$this->add_responsive_control(
    'tab_active_border_radius',
    [
        'label'      => __( 'Border Radius', 'studiare' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', '%', 'em' ],
        'selectors'  => [
            '{{WRAPPER}} .studi-tabs-nav li.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);


//product box styles
$this->add_control(
    'box_title',
    [
        'label'     => __( 'Title', 'studiare' ),
        'type'      => Controls_Manager::HEADING,
        'separator' => 'before',
    ]
);
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'title_typography',
        'selector' => '{{WRAPPER}} .course-title',
    ]
);
$this->add_control(
    'box_price',
    [
        'label'     => __( 'Price', 'studiare' ),
        'type'      => Controls_Manager::HEADING,
        'separator' => 'before',
    ]
);
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'price_typography',
        'selector' => '{{WRAPPER}} .products .course-item .course-item-inner .course-content-holder .course-content-bottom .course-price span',
    ]
);

$this->add_control(
    'box_image',
    [
        'label'     => __( 'Image', 'studiare' ),
        'type'      => Controls_Manager::HEADING,
        'separator' => 'before',
    ]
);



$this->end_controls_section();
    }

    private function get_woo_categories() {
        $options = [];
        $terms = get_terms([ 'taxonomy' => 'product_cat', 'hide_empty' => true ]);
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $options[ $term->term_id ] = $term->name;
            }
        }
        return $options;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $cats     = $settings['product_cats'];

        if ( empty($cats) ) {
            echo __( 'Please select categories.', 'studiare' );
            return;
        }

        $atts = [
            'limit'              => $settings['limit'],
            'columns'            => $settings['columns'],
            'product_box'        => $settings['product_box'],
            'product_type'       => $settings['product_type'],
            'product_layout'     => $settings['product_layout'],
            'all_ids'            => $cats,
            // Slider settings
            'enable_slider'      => $settings['enable_slider'],
            'slider_items'       => [
                'desktop' => $settings['slider_items_desktop'],
                'tablet'  => $settings['slider_items_tablet'],
                'mobile'  => $settings['slider_items_mobile'],
            ],
            'slider_nav'         => $settings['slider_nav'],
            'slider_dots'        => $settings['slider_dots'],
            // Slider advanced settings
            'slider_autoplay'         => $settings['slider_autoplay'],
            'slider_autoplay_timeout' => $settings['slider_autoplay_timeout'],
            'slider_loop'             => $settings['slider_loop'],
            'slider_slideby'          => [
                'desktop' => $settings['slider_slideby_desktop'],
                'tablet'  => $settings['slider_slideby_tablet'],
                'mobile'  => $settings['slider_slideby_mobile'],
            ],
        ];

        ?>
        <div class="studi-tabs-container" data-atts='<?php echo json_encode($atts); ?>'>
            <div class="studi-tabs-header mb-10">
                <?php if ( ! empty($settings['title']) ) : ?>
                    <h2 class="studi-tabs-title"><?php echo esc_html($settings['title']); ?></h2>
                <?php endif; ?>

                <ul class="studi-tabs-nav">
                    <!-- Default "All" Tab -->
                    <li class="active" data-cat-id="all">
                        <?php echo __( 'All', 'studiare' ); ?>
                    </li>
                    
                    <?php foreach ( $cats as $cat_id ) : 
                        $term = get_term($cat_id);
                        if(!$term) continue;
                    ?>
                        <li data-cat-id="<?php echo $cat_id; ?>">
                            <?php echo esc_html($term->name); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="studi-tabs-content">
                <div class="studi-tabs-loader primary_color"><i class="fal fa-spinner-third fa-spin"></i></div>
                <div class="studi-tabs-ajax-content">
                    <?php 
                    // Initial load: All products from selected categories
                    studi_fetch_products_callback($atts, $cats); 
                    ?>
                </div>
            </div>
        </div>
        <?php
    }
}