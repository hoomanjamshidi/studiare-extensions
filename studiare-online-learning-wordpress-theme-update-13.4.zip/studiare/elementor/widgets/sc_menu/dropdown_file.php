<?php
$sub_rnd_id = rand(200,5000);
$sub_rnd_id = "submn_id_".$sub_rnd_id;
?>
<div id="studi_rl_with_sub<?php echo"$sub_rnd_id";?>" class="studi_rl_with_sub">
      
        <a href="#" onclick="return menuToggle(event,'<?php echo esc_attr($sub_rnd_id); ?>')" class="login-button btn-filled dropdown-toggle flex items-center justify-center gap-1">
            <?php if ( $show_avatar==1) { echo get_avatar( get_current_user_id(), 32 );} else {?><i class="fal fa-user"></i> <?php } ?><span>
                <?php if ( $show_display_name==1) { echo  esc_html( $current_user->display_name );} else echo esc_html($header_button_custom_text_1); ?></span>
        </a>
      
      <div id="<?php echo $sub_rnd_id;?>" class="studi_rl_sub">
          
       
        <?php /**
        if ( $settings['submenu_list'] ) { ?>
        
            <ul>
                <?php foreach (  $settings['submenu_list'] as $item ) {  //start lessons list
                			
                			$icon           = $item['icon']['value'];
                			$title          = $item['link_title']; 
                			$link          = $item['link']['url']; 
                			
                			echo "<li><a href='$link'><i class='$icon'></i> $title </a></li>";
                } ?>			
              
            </ul>
            
        <?php } 
        **/
        ?>   
        
        <!-- submneu start -->
        <?php
        
        $menu_location = $hb_submenu;
        if(isset($settings['menu_id']) && $settings['menu_id'] !=''){
            $menu_location = $settings['menu_id'];
        }
		//print_r();

		 $menu = wp_nav_menu( array( 

		                                'menu' 	=> $menu_location,
										'menu_class'      	=> '',
										'container_class'	=> '',
										'fallback_cb' 		=> 'sc_studiFrontendWalker::fallback',
										'walker' 			=> new \sc_studiFrontendWalker,
										'echo'            => false
								  ) );
		?>
		<div class="" role="navigation">
	                <?php echo wp_kses_post($menu); ?>
        </div>
        <!-- submneu end -->
        
      </div>
    </div>