<?php
namespace Elementor;

class Sc_ShoppingCart extends Widget_Base {
	
	public function get_name() {
		return 'studi-shopping-cart';
	}
	
	public function get_title() {
		return  __( 'Shopping Cart', 'studiare' );
	}
	
	public function get_icon() {
		return 'sc eicon-basket-light';
	}
	
	public function get_categories() {
		return [ 'studiare' ];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'studiare' ),
			]
		);
		
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_design',
			[
				'label' => __( 'Design', 'studiare' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
	    $this->add_control(
            'bg_color',
            [
                'label'     => __( 'Background Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mini-cart-opener' => 'background: {{VALUE}};',
                ],
            ]
        );
	    $this->add_control(
            'bg_color_hover',
            [
                'label'     => __( 'Hover Background Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mini-cart-opener:hover' => 'background: {{VALUE}};',
                ],
            ]
        );
	    $this->add_control(
            'icon_color',
            [
                'label'     => __( 'Icon Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mini-cart-opener' => 'color: {{VALUE}};',
                ],
            ]
        );
	    $this->add_control(
            'icon_color_hover',
            [
                'label'     => __( 'Hover Icon Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .mini-cart-opener:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
		
		
		
		$this->end_controls_section();
	}
	
	protected function render() {

        $settings = $this->get_settings_for_display();
        $cart_icon = true;
       
        if ( class_exists( 'Redux' ) ) {
        	//$cart_icon = codebean_option('topbar_cart');
        }

        if ( class_exists( 'WooCommerce' ) ) {
            if (  function_exists('WC' ) ){  //$cart_icon &&
                ?>
                
        <div class="top-bar-cart">
            <a href="<?php echo wc_get_cart_url(); ?>" class="mini-cart-opener">
                <span class="bag-icon">
                    <?php get_template_part( 'assets/images/shop-bag-two.svg' ); ?>
                </span>
                
	            <?php studiare_cart_count(); ?>
            </a>
<?php 
add_action("wp_footer", function() {
    ?>
    <div class="sc-cart-offcanvas">

        <!-- Backdrop -->
        <div class="sc-cart-backdrop"></div>

        <!-- Panel -->
        <div class="sc-cart-panel">
            
            <div class="sc-cart-header">
                <div class="h4 sc-cart-title"><?php esc_html_e('Your Cart', 'studiare'); ?></div>
                <button class="sc-cart-close" type="button"><i class="fal fa-times"></i></button>
            </div>

            <div class="sc-cart-body">
                <!-- WooCommerce mini cart -->
                <div class="widget woocommerce widget_shopping_cart">
                    <div class="widget_shopping_cart_content"></div>
                </div>
            </div>

        </div>

    </div>
    <?php
});

?>
        </div>
                <?php
                
            }
        }						  
        
	}
	
	protected function content_template() {
	 
    }
	
	
}