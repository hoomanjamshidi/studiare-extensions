<?php
namespace Elementor;

class Sc_LoginBtn extends Widget_Base {
	
	public function get_name() {
		return 'studi-login-btn';
	}
	
	public function get_title() {
		return  __( 'Login Button', 'studiare' );
	}
	
	public function get_icon() {
		return 'sc eicon-lock-user';
	}
	
	public function get_categories() {
		return [ 'studiare' ];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'studiare' ),
			]
		);
		
		/**
		//since version 12.7 adding submenu elements by user
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'link_title', [
				'label' => __( 'Title', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Title' , 'studiare' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'studiare' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-user',
					'library' => 'light',
				],
			]
		);
		$repeater->add_control(
			'link',
			[
				'label' => esc_html__( 'Link', 'studiare' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url'],//[ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					//'is_external' => true,
					//'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
		
		$this->add_control(
			'submenu_list',
			[
				'label' => __( 'Submenu', 'studiare' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				//'default' => '',
				'title_field' => '{{{ link_title }}}',
			]
		);
		**/
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_design',
			[
				'label' => __( 'Design', 'studiare' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
	
		$this->add_control(
			'btn_txt_color',
			[
				'label' => esc_html__( 'Color', 'studiare' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-button-link a.login-button span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .login-button svg' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'btn_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'studiare' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-button-link a.btn' => 'background: {{VALUE}}',
					'{{WRAPPER}} .btn-filled' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'btn_border_color',
			[
				'label' => esc_html__( 'Border Color', 'studiare' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-button-link a.btn' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		
		$this->end_controls_section();
	}
	
	protected function render() {

        $settings = $this->get_settings_for_display();
  
        $header_button_link = 'account';
        $header_button_custom_text = null;
        
        $header_button_type = 'link';
        $hb_submenu = null;
        
        $header_button_link_show_on_mobile ="show_icon_and_text";  //since ver 12.4
       if ( class_exists( 'Redux') ) {
           $header_button_link = codebean_option('header_button_link');
           $header_button_custom_text = codebean_option('header_button_custom_text');
           $header_button_custom_text_0 = codebean_option('header_button_custom_text_0')?:"شروع کنید";
	       $header_button_custom_text_1 = codebean_option('header_button_custom_text_1')?:"حساب کاربری";
	       $header_button_custom_text_2 = codebean_option('header_button_custom_text_2')?:"حساب کاربری";
	       $header_button_custom_link = codebean_option('header_button_custom_link');
	       $header_button_link_show_on_mobile = codebean_option('header_button_link_show_on_mobile'); //since ver 12.4
	       $show_avatar = codebean_option('show_avatar');
	       $show_display_name = codebean_option('show_display_name');

            //since v 12.7
	        $header_button_type = codebean_option('header_button_type');
	        $hb_submenu = codebean_option('hb_submenu');	       
	       
       }
        if ( class_exists( 'WooCommerce' ) ) {
         if(!is_account_page() ){
             ?>
                <div class="header-button-link <?php echo "sc_lgreg_btn_".$header_button_link_show_on_mobile ;?>">
                    <?php if ( $header_button_link == 'account' || $header_button_link == 'sc_digits'){
                        
                        $account_link = get_permalink( get_option('woocommerce_myaccount_page_id') );
                        $current_user = wp_get_current_user();
                        
                        if ( is_user_logged_in() ) { 
                            if($header_button_type == 'link'){
                        ?>
                           <a href="<?php echo esc_url( $account_link ); ?>" class="login-button btn-filled flex items-center gap-1"><?php if ( $show_avatar==1) { echo get_avatar( get_current_user_id(), 32 );} else {?><i class="fal fa-user"></i> <?php } ?><span><?php if ( $show_display_name==1) { echo  esc_html( $current_user->display_name );} else echo esc_html($header_button_custom_text_1); ?></span></a>
                            
                            <?php 
                            }else{
                            include 'dropdown_file.php'; 
                            }
                            ?>
                            
                        <?php }
                        elseif ( is_plugin_active( 'digits/digit.php' ) && $header_button_link == 'sc_digits' )  { ?>
                        <a href="#" class="login-button btn-filled scdigits flex items-center gap-1"><svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 28 28" width="24" height="24"><path fill="currentcolor" d="M16.944 3.25c-1.367 0-2.47 0-3.336.117-.9.12-1.658.38-2.26.981-.525.525-.79 1.17-.93 1.928-.135.737-.161 1.638-.167 2.72a.75.75 0 0 0 1.5.008c.006-1.093.034-1.868.143-2.457.104-.566.27-.895.514-1.138.277-.277.666-.457 1.4-.556.755-.101 1.756-.103 3.191-.103h1c1.436 0 2.437.002 3.192.103.734.099 1.123.28 1.4.556.276.277.456.665.555 1.4.102.754.103 1.756.103 3.191v8c0 1.435-.001 2.436-.103 3.192-.099.734-.279 1.122-.556 1.399-.276.277-.665.457-1.399.556-.755.101-1.756.103-3.192.103h-1c-1.435 0-2.436-.002-3.192-.103-.733-.099-1.122-.28-1.399-.556-.243-.244-.41-.572-.514-1.138-.109-.589-.137-1.364-.143-2.457a.75.75 0 0 0-1.5.008c.006 1.082.032 1.983.167 2.72.14.758.405 1.403.93 1.928.601.602 1.36.86 2.26.982.867.116 1.969.116 3.336.116h1.11c1.368 0 2.47 0 3.337-.116.9-.122 1.658-.38 2.26-.982s.86-1.36.982-2.26c.116-.867.116-1.97.116-3.337v-8.11c0-1.367 0-2.47-.116-3.337-.121-.9-.38-1.658-.982-2.26s-1.36-.86-2.26-.981c-.867-.117-1.97-.117-3.337-.117z"></path><path fill="currentcolor" d="M4 13.249a.75.75 0 0 0 0 1.5h11.973l-1.961 1.68a.75.75 0 1 0 .976 1.14l3.5-3a.75.75 0 0 0 0-1.14l-3.5-3a.75.75 0 1 0-.976 1.14l1.96 1.68z"></path></svg> <span><?php echo do_shortcode("[dm-modal]"); ?></span></a>
                        <?php 
                            
                        } 
                        else {
                        ?>
                            <a href="#" class="register-modal-opener login-button btn-filled flex items-center gap-1"><svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 28 28" width="24" height="24"><path fill="currentcolor" d="M16.944 3.25c-1.367 0-2.47 0-3.336.117-.9.12-1.658.38-2.26.981-.525.525-.79 1.17-.93 1.928-.135.737-.161 1.638-.167 2.72a.75.75 0 0 0 1.5.008c.006-1.093.034-1.868.143-2.457.104-.566.27-.895.514-1.138.277-.277.666-.457 1.4-.556.755-.101 1.756-.103 3.191-.103h1c1.436 0 2.437.002 3.192.103.734.099 1.123.28 1.4.556.276.277.456.665.555 1.4.102.754.103 1.756.103 3.191v8c0 1.435-.001 2.436-.103 3.192-.099.734-.279 1.122-.556 1.399-.276.277-.665.457-1.399.556-.755.101-1.756.103-3.192.103h-1c-1.435 0-2.436-.002-3.192-.103-.733-.099-1.122-.28-1.399-.556-.243-.244-.41-.572-.514-1.138-.109-.589-.137-1.364-.143-2.457a.75.75 0 0 0-1.5.008c.006 1.082.032 1.983.167 2.72.14.758.405 1.403.93 1.928.601.602 1.36.86 2.26.982.867.116 1.969.116 3.336.116h1.11c1.368 0 2.47 0 3.337-.116.9-.122 1.658-.38 2.26-.982s.86-1.36.982-2.26c.116-.867.116-1.97.116-3.337v-8.11c0-1.367 0-2.47-.116-3.337-.121-.9-.38-1.658-.982-2.26s-1.36-.86-2.26-.981c-.867-.117-1.97-.117-3.337-.117z"></path><path fill="currentcolor" d="M4 13.249a.75.75 0 0 0 0 1.5h11.973l-1.961 1.68a.75.75 0 1 0 .976 1.14l3.5-3a.75.75 0 0 0 0-1.14l-3.5-3a.75.75 0 1 0-.976 1.14l1.96 1.68z"></path></svg> <span><?php echo esc_html($header_button_custom_text_0); ?></span></a>
                        <?php } 
                        
                    }else{
                        
                        if ( is_user_logged_in() ) {
             ?>
                        <a href="<?php echo esc_url($header_button_custom_link); ?>" class="btn-filled flex items-center gap-1" rel="nofollow"><i class="fal fa-user"></i><span><?php echo esc_html($header_button_custom_text_2); ?></span></a>
             <?php
                        }else{ ?>
                        <a href="<?php echo esc_url($header_button_custom_link); ?>" class="btn-filled flex items-center gap-1" rel="nofollow"><i class="fal fa-user"></i><span><?php echo esc_html($header_button_custom_text); ?></span></a>
                        <?php }
         } 
                        ?>
                   
                </div>    
            <?php
            
        				  
         }
        }
	}
	
	protected function content_template() {
	 
    }
	
	
}