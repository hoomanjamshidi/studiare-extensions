<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_enqueue_scripts', function () {
    wp_enqueue_media();
});

add_action( 'admin_footer-post.php', 'sc_fix_coupon_featured_image_js' );
add_action( 'admin_footer-post-new.php', 'sc_fix_coupon_featured_image_js' );

function sc_fix_coupon_featured_image_js() {

    $screen = get_current_screen();
    if ( $screen->post_type !== 'shop_coupon' ) {
        return;
    }
    ?>
    <script type="text/javascript">
    jQuery(function($){

        if ( typeof wp !== 'undefined' && wp.media && wp.media.featuredImage ) {
            wp.media.featuredImage.frame().on( 'select', function() {
                var attachment = wp.media.featuredImage.frame().state().get('selection').first().toJSON();
                $('#_thumbnail_id').val( attachment.id );
            });
        }

    });
    </script>
    <?php
}


/**
 * Coupon Featured Meta Box
 */

add_action( 'add_meta_boxes', 'sc_add_coupon_meta_box' );
function sc_add_coupon_meta_box() {

    add_meta_box(
        'sc_coupon_featured',
        __( 'Coupon Options', 'studiare' ),
        'sc_render_coupon_meta_box',
        'shop_coupon',
        'side',
        'high'
    );
}

function sc_render_coupon_meta_box( $post ) {

    $value = get_post_meta( $post->ID, '_sc_featured', true );
    wp_nonce_field( 'sc_coupon_meta_nonce', 'sc_coupon_meta_nonce_field' );
    ?>
    <label style="display:block;margin-bottom:8px;">
        <input type="checkbox" name="sc_featured" value="yes" <?php checked( $value, 'yes' ); ?>>
        <?php esc_html_e( 'Mark as Popular', 'studiare' ); ?>
    </label>
    <?php
}

add_action( 'save_post_shop_coupon', 'sc_save_coupon_meta' );
function sc_save_coupon_meta( $post_id ) {

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

    if ( ! isset( $_POST['sc_coupon_meta_nonce_field'] ) ||
         ! wp_verify_nonce( $_POST['sc_coupon_meta_nonce_field'], 'sc_coupon_meta_nonce' )
    ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['sc_featured'] ) ) {
        update_post_meta( $post_id, '_sc_featured', 'yes' );
    } else {
        delete_post_meta( $post_id, '_sc_featured' );
    }
}
/**
 * Enable featured image for WooCommerce coupons (FIX)
 */
add_action( 'init', function () {

    // Enable thumbnail support
    add_post_type_support( 'shop_coupon', 'thumbnail' );

    // Ensure theme supports thumbnails for coupons
    add_theme_support( 'post-thumbnails', [ 'shop_coupon' ] );
});

/**
 * Re-add Featured Image meta box (Woo removes it)
 */
add_action( 'add_meta_boxes', function () {

    add_meta_box(
        'postimagediv',
        __( 'Coupon Image', 'studiare' ),
        'post_thumbnail_meta_box',
        'shop_coupon',
        'side',
        'low'
    );
}, 99 );
/**
 * FINAL FIX: Save featured image for WooCommerce coupons
 */
add_action( 'save_post_shop_coupon', 'sc_force_save_coupon_thumbnail', 999 );
function sc_force_save_coupon_thumbnail( $post_id ) {

    // Autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    // Permission
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    // Only in admin post save
    if ( ! is_admin() ) {
        return;
    }

    if ( isset( $_POST['_thumbnail_id'] ) ) {

        $thumbnail_id = (int) $_POST['_thumbnail_id'];

        if ( $thumbnail_id > 0 ) {
            // Force set thumbnail AFTER WooCommerce save
            update_post_meta( $post_id, '_thumbnail_id', $thumbnail_id );
        } else {
            delete_post_meta( $post_id, '_thumbnail_id' );
        }
    }
}
