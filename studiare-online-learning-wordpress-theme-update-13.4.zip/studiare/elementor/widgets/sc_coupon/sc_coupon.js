(function ($) {
    'use strict';

    // Global Toastr configuration (run once)
    if (window.toastr) {
        toastr.options = {
            closeButton: true,
            progressBar: true,
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
            escapeHtml: false // Required for inline SVG in title
        };
    }

    // Inline SVG icon for toast title
    const toastIcon = `
       <svg xmlns="http://www.w3.org/2000/svg"
     viewBox="0 0 24 24"
     width="16"
     height="16"
     fill="none"
     stroke="currentColor"
     stroke-width="1.5"
     stroke-linecap="round"
     stroke-linejoin="round">
    <path d="M9 13.4L10.7143 15L15 11"/>
    <path d="M21 16.0002C21 18.8286 21 20.2429 20.1213 21.1215C19.2426 22.0002 17.8284 22.0002 15 22.0002H9C6.17157 22.0002 4.75736 22.0002 3.87868 21.1215C3 20.2429 3 18.8286 3 16.0002V13.0002M16 4.00195C18.175 4.01406 19.3529 4.11051 20.1213 4.87889C21 5.75757 21 7.17179 21 10.0002V12.0002M8 4.00195C5.82497 4.01406 4.64706 4.11051 3.87868 4.87889C3.11032 5.64725 3.01385 6.82511 3.00174 9"/>
    <path d="M8 3.5C8 2.67157 8.67157 2 9.5 2H14.5C15.3284 2 16 2.67157 16 3.5V4.5C16 5.32843 15.3284 6 14.5 6H9.5C8.67157 6 8 5.32843 8 4.5V3.5Z"/>
</svg>
    `;

    const toastTitle = toastIcon ;

    // Filter coupons
    $(document).on('click', '.sc-coupon-filters button', function () {
        const filter = $(this).data('filter');

        $('.sc-coupon-card').each(function () {
            const status = $(this).data('status');
            const featured = $(this).data('featured') === 1;

            if (filter === 'all' || (filter === 'featured' && featured) || filter === status) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    // Copy coupon code
    $(document).on('click', '.sc-copy', function () {
        const code = $(this).data('code');

        const onSuccess = function () {
            if (window.toastr) {
                toastr.success(scCouponI18n.copy_success, toastTitle);
            }
        };

        const onFail = function () {
            if (window.toastr) {
                toastr.error(scCouponI18n.copy_failed, toastTitle);
            }
        };

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(code).then(onSuccess).catch(onFail);
        } else {
            // Fallback for older browsers
            const $temp = $('<input>');
            $('body').append($temp);
            $temp.val(code).select();

            try {
                document.execCommand('copy');
                onSuccess();
            } catch (e) {
                onFail();
            }

            $temp.remove();
        }
    });

})(jQuery);
