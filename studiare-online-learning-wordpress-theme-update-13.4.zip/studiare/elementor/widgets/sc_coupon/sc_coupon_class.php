<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

// Include coupon meta (admin only)
if ( is_admin() ) {
    require_once __DIR__ . '/coupon-meta.php';
}

class Sc_Coupon extends Widget_Base {

    /* =====================
     * Basic Info
     * ===================== */
    public function get_name() {
        return 'Sc_Coupon';
    }

    public function get_title() {
        return __( 'Coupons Festival', 'studiare' );
    }

    public function get_icon() {
        return 'sc fal fa-ticket';
    }

    public function get_categories() {
        return [ 'studiare' ];
    }

    public function get_style_depends() {
        return [ 'sc-coupon' ];
    }

    public function get_script_depends() {
        return [ 'sc-coupon' ];
    }

    /* =====================
     * Controls
     * ===================== */
    protected function register_controls() {

        $this->start_controls_section(
            'section_settings',
            [ 'label' => __( 'General Settings', 'studiare' ) ]
        );

        $this->add_control(
            'mode',
            [
                'label'   => __( 'Coupons Mode', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'auto',
                'options' => [
                    'auto'   => __( 'Automatic', 'studiare' ),
                    'manual' => __( 'Manual', 'studiare' ),
                    'hybrid' => __( 'Hybrid', 'studiare' ),
                ],
            ]
        );

        $this->add_control(
            'manual_ids',
            [
                'label'       => __( 'Manual Coupon IDs', 'studiare' ),
                'type'        => Controls_Manager::TEXT,
                'description' => __( 'Comma separated IDs', 'studiare' ),
                'condition'   => [ 'mode!' => 'auto' ],
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label'   => __( 'Coupons Count', 'studiare' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 6,
                'min'     => 1,
                'max'     => 50,
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label'   => __( 'Columns', 'studiare' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 3,
                'min'     => 1,
                'max'     => 6,
            ]
        );

        $this->add_control(
            'show_filters',
            [
                'label'   => __( 'Frontend Filters', 'studiare' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();
    }

    /* =====================
     * Query
     * ===================== */
    protected function get_query( $settings ) {

        $args = [
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'posts_per_page' => $settings['posts_per_page'],
        ];

        if ( in_array( $settings['mode'], [ 'manual', 'hybrid' ], true ) && ! empty( $settings['manual_ids'] ) ) {
            $ids = array_map( 'absint', explode( ',', $settings['manual_ids'] ) );
            $args['post__in'] = $ids;
            $args['orderby'] = 'post__in';
        }

        return new \WP_Query( $args );
    }

    /* =====================
     * Coupon State
     * ===================== */
    protected function get_state( \WC_Coupon $coupon ) {

        if ( ! $coupon->is_valid() ) {
            return 'ended';
        }

        if ( $coupon->get_usage_limit() && $coupon->get_usage_count() >= $coupon->get_usage_limit() ) {
            return 'ended';
        }

        return 'active';
    }

    /* =====================
     * Render
     * ===================== */
    protected function render() {

        if ( ! class_exists( 'WooCommerce' ) ) return;

        $settings = $this->get_settings_for_display();
        $query    = $this->get_query( $settings );

        if ( ! $query->have_posts() ) return;
        ?>

        <div class="sc-coupon-wrapper columns-<?php echo esc_attr( $settings['columns'] ); ?>">

            <?php if ( $settings['show_filters'] === 'yes' ) : ?>
                <div class="sc-coupon-filters">
                    <button data-filter="all"><?php _e( 'All', 'studiare' ); ?></button>
                    <button data-filter="active"><?php _e( 'Active', 'studiare' ); ?></button>
                    <button data-filter="ended"><?php _e( 'Expired', 'studiare' ); ?></button>
                    <button data-filter="featured"><?php _e( 'Popular', 'studiare' ); ?></button>
                </div>
            <?php endif; ?>

            <div class="sc-coupon-grid">
                <?php
                while ( $query->have_posts() ) :
                    $query->the_post();

                    $coupon   = new \WC_Coupon( get_the_ID() );
                    $state    = $this->get_state( $coupon );
                    $featured = get_post_meta( get_the_ID(), '_sc_featured', true ) === 'yes';
                    ?>

                    <?php
                    $amount = $coupon->get_amount();
                    $type   = $coupon->get_discount_type();
                    
                    if ( $type === 'percent' ) {
                        $discount_text  = intval( $amount ) . '٪';
                        $discount_label = __( 'Discount', 'studiare' );
                    } else {
                        $discount_text  = wc_price( $amount );
                        $discount_label = __( 'Discount Amount', 'studiare' );
                    }

                    ?>
                    
                    <div class="sc-coupon-card"
                         data-status="<?php echo esc_attr( $state ); ?>"
                         data-featured="<?php echo $featured ? '1' : '0'; ?>">
                    
                        <?php if ( $state === 'ended' ) : ?>
                            <span class="sc-badge ended"><?php _e( 'Expired', 'studiare' ); ?></span>
                        <?php endif; ?>
                    
                        <?php if ( $featured ) : ?>
                            <span class="sc-badge featured"><?php _e( 'Popular', 'studiare' ); ?></span>
                        <?php endif; ?>
                    
                        <!-- Gift Icon -->
                        <div class="sc-coupon-icon">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <div class="sc-coupon-thumb">
                                    <?php the_post_thumbnail( 'medium' ); ?>
                                </div>
                            <?php else : ?>
                                <div class="sc-coupon-thumb fallback">🎁</div>
                            <?php endif; ?>
                        </div>
                    
                        <!-- Discount -->
                        <div class="sc-coupon-discount">
                            <span class="label"><?php echo esc_html( $discount_label ); ?>:</span>
                            <strong><?php echo wp_kses_post( $discount_text ); ?></strong>
                        </div>

                    
                        <!-- Title -->
                        <div class="sc-coupon-title">
                            <?php
                            $description = get_the_excerpt();
                        
                            if ( ! empty( $description ) ) {
                                echo esc_html( $description );
                            } else {
                                echo esc_html( get_the_title() );
                            }
                            ?>
                        </div>

                    
                        <!-- Min Amount -->
                        <?php if ( $min_amount > 0 ) : ?>
                            <div class="sc-coupon-min">
                                <?php
                                printf(
                                    __( 'Minimum purchase: %s', 'studiare' ),
                                    wp_kses_post( wc_price( $min_amount ) )
                                );
                                ?>
                            </div>

                        <?php endif; ?>
                    
                        <!-- Code -->
                        <div class="sc-coupon-code">
                            <?php echo esc_html( $coupon->get_code() ); ?>
                        </div>
                    
                        <!-- Action -->
                        <button class="sc-copy"
                            data-code="<?php echo esc_attr( $coupon->get_code() ); ?>"
                            <?php disabled( $state === 'ended' ); ?>>
                            <?php _e( 'Copy Code', 'studiare' ); ?>
                        </button>
                    
                    </div>


                <?php endwhile; ?>
            </div>
        </div>

        <?php
        wp_reset_postdata();
    }
}
