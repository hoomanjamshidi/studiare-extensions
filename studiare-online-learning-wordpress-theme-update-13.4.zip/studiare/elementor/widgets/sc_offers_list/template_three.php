<?php
/**
 * Template for offers list - Version 3 
 * 
 * @var array $settings Widget settings
 * @var SC_Offers_List_Widget $this The widget instance
 * https://codepen.io/big-boris/pen/zodpVb
 */

// Access to widget instance via $this
// Access to settings via $settings or individual variables from extract()

                $html = "<div class='sc_special_offer_three row'>";
                $rand_id = rand(1,1000);
                $rand_id = "sc_ot_".$rand_id;
                $html .="<style>
                        .sc_special_offer_three {  border-radius: 10px; padding: 10px;}
                        .sc_special_offer_three .sc_ot_subcon { -ms-flex-wrap: wrap; display: -webkit-box; display: -ms-flexbox; display: flex ; flex-wrap: wrap; margin-left: -15px; margin-right: -15px; padding: 10px; }
                        .sc_special_offer_three .studi_special_offer_holder{ background: transparent; padding: 0px;box-shadow: none;}
                        .sc_ot_oti { position: relative;padding: 10px; margin-bottom: 10px; border-radius: 30px; cursor: pointer; background: linear-gradient(-90deg, #dfdfdf, transparent);transition:.4s; }
                        .sc_ot_oti.active { background: linear-gradient(90deg, transparent, #673AB7); color: #fff; text-indent: 15px; }
                        .sc_ot_titles { display: flex ; flex-direction: column; justify-content: center; }
                        .sc_ot_oti.active:after { content: ''; background: #ffffff47; width: 16px; height: 16px; position: absolute; right: 5px; top: 15px; border-radius: 100px; transition: .4s; }
                        .sc_ot_oti.active:before { content: ''; background: #fff; width: 10px; height: 10px; position: absolute; right: 8px; top: 18px; border-radius: 100px; transition: .4s; }
                        .sc_ot_img img {  padding: 10px; border: 1px dashed #bdbdbd; border-radius: 78px; border-width:1px 0 1px 0;}
                        .sc_special_offer_three .proTimer div { background: transparent; }
                        .sc_special_offer_three .proTimer div span { color: #6e6e6e;  }
                        .sc_special_offer_three .proTimer { background: #fff; border-radius: 20px 20px 0 0; }
                        
                        .sc_special_offer_three .sc_so_timer { position: absolute; width: calc(100% - 30px); display: flex ; justify-content: center; bottom: 0; }
                        .sc_ot_ofbox { display: flex ; flex-direction: column; justify-content: center; }
                        .sc_ot_PriceHtml { margin:15px 0; }
                        .sc_ot_ofbox_content { text-align:center; padding:0 10px;}
                        .sc_ot__regp_holder { font-size: 16px;background: #9E9E9E; border-radius: 15px; display: inline-flex ; color: #fff; padding-left: 10px; }
                        del.sc_ot__regp { background: #E91E63; border-radius: 15px; padding: 0 22px; margin-left: 10px; color: #fff; }
                        .sc_ot__salep { font-size: 30px; margin: 20px 0; color: #6e6e6e; font-weight: bold; }
                        .sc_special_offer_three .sco_excerpt { height: 5.3em; line-height: 1.7em; max-width: 400px;margin: 20px 0; }
                        .sc_special_offer_three span.sc_ot_currency { margin-right: 10px; }
                        .sc_special_offer_three a.soc_buy_btn_lthree {margin-top: 20px;  display: inline-block; padding: 10px 15px; border-radius: 30px;  min-width: 210px; text-align: center; color: #4A148C !important; background: #F3E5F5; }
                        .sc_special_offer_three a.soc_buy_btn_lthree:hover { background: #4A148C !important; color: #F3E5F5 !important; }
                        .sc_special_offer_three .owl-item:nth-child(2n+1) .sc_ot_subcon { flex-direction: row-reverse; }
                        .scot_title { border-bottom: 1px dashed gainsboro; }
                        .scot_title h3 { transform: translateY(14px); background: #fff; display: inline-block; padding: 0 9px; }
                        .scdarkcolors .scot_title h3 { background: var(--dark_primary_color); }
                        .scdarkcolors .sc_special_offer_three .proTimer { background:var(--dark_primary_color); }
                        .scdarkcolors .sc_special_offer_three .proTimer div span{ color:#fff }
                        .scdarkcolors .sc_ot_oti { background: linear-gradient(-90deg, #242424, transparent); }
                        @media screen and (min-width:968px){
                        .sc_special_offer_three a.soc_buy_btn_lthree:hover { background: #4A148C !important; color: #F3E5F5 !important; }
                        .scdarkcolors .sc_special_offer_three a.soc_buy_btn_lthree {border-color:var(--dark_primary_color);}
                        }
                        @media screen and (max-width:768px){
                            .sc_ot_ofbox_content { text-align: center; margin-top: 40px; border: 1px dashed gainsboro; border-radius: 22px; border-width: 0 1px; }
                            .sc_special_offer_three { margin-left: 0; margin-right: 0; }
                            .sc_ot_titles { width: 100%; }
                            .sc_special_offer_three .sc_so_timer { transform: translateY(32px); }
                            .sc_ot_img img { border-radius: 30px; }
                        }
                        </style>"; 

                
                
                $html .= "<div class='col-md-3 col-xs-12 sc_ot_titles'>";
                $i   = 1;
                foreach($onsale_with_date_array as $id){
                    
                    
                    
                    $title = get_the_title($id);
                    
                    $html .= "<div  class='sc_ot_oti'><span>$title</span></div>";
                    $i++;
                }
                $html .= "</div>";
                
                $html .= "<div class='col-md-9 col-xs-12 sc_ot_content studi_special_offer_holder owl-carousel'>";
                 $i   = 1;
                foreach($onsale_with_date_array as $id){
                    
                   
                    $tid = $rand_id."".$i;

                    $sales_price_to   = get_post_meta( $id, '_sale_price_dates_to', true );
                    $sales_price_to =  date('Y-m-d H:i:s',$sales_price_to);
                    
                    $regul_price   = get_post_meta( $id, '_regular_price', true );
                    $sales_price   = get_post_meta( $id, '_sale_price', true );
                    
                    $offPercent = round(100-(($sales_price/$regul_price)*100))."%";
                    
                    $regul_price   = number_format($regul_price);
                    $sales_price   = number_format($sales_price);
                    $price_sym = get_woocommerce_currency_symbol();
                    $price_html="
                                <div class='sc_ot_PriceHtml'>
                                    <div class='sc_ot__regp_holder'><del class='sc_ot__regp'>$regul_price</del><span>$offPercent</span></div>
                                    <div class='sc_ot__salep'>$sales_price<span class='sc_ot_currency'>$price_sym</span></div>
                                </div>";
               
                    $title = get_the_title($id);
                    $title = "<div class='scot_title'><h3>$title</h3></div>";
                    $link = get_permalink($id);
                    
                    $post = get_post( $id );
                    $excerpt = $post->post_excerpt;
                    
                    $image = wp_get_attachment_image_src( get_post_thumbnail_id( $id ), $image_size );
                    
                     
                        $html .= "<div id='$tid' class='sc_ot_subcon '>
                                    <div class='sl_bl_bg' style='background:url($image[0])'></div>
                                    <div class='col-md-8 col-xs-12 sc_ot_img'>
                                    <img src='$image[0]'>
                                    <div class='sc_so_timer'><div id='pro_$id' data-proid='pro_$id'  data-enddate='$sales_price_to'  class='proTimer'></div></div>
                                    </div>
                                    <div class='col-md-4 col-xs-12 sc_ot_ofbox'>
                                    <div class='sc_ot_ofbox_content'>
                                            $title    
                                            <div class='sco_excerpt'>$excerpt</div>
                                            <div class='scbtm_els'>
                                            
                                            $price_html
                                            
                                            <a class='soc_buy_btn_lthree' href='$link'><i class='$icon'></i> $btnTitle</a>
                                            </div> 
                                    </div> 

                        
                        
                         
                        
                                    </div>
                                  </div>
                                ";
                        
                    $i++;
                }
                $html .= "</div>";
                
                
                
                $html .= "</div>";