<?php
namespace Elementor;


class Sc_Lessons extends Widget_Base {
	
	public function get_name() {
		return 'studi-lesson-builder';
	}
	
	public function get_title() {
		return  __( 'Lesson Builder', 'studiare' );
	}
	
	public function get_icon() {
		return 'sc eicon-kit-details';
	}
	
	public function get_categories() {
		return [ 'studiare' ];
	}
	
	protected function register_controls() {

		
		
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'studiare' ),
			]
		);
		
		$this->add_control(
			'title',
			[
				'label' => __( 'Section Title', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Title', 'studiare' ),
				'placeholder' => '',
			]
		);
		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'section_num_title',
			[
				'label' => __( 'Chapter Title', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Section', 'studiare' ),
				'placeholder' => '',
			]
		);
		$this->add_control(
			'section_number',
			[
				'label' => __( 'Section Number', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'First', 'studiare' ),
				'placeholder' => '',
			]
		);
		$this->add_control(
			'hr2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'list_open_situ',
			[
				'label' => __( 'Section Open/Close ', 'studiare' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Open', 'studiare' ),
				'label_off' => __( 'Close', 'studiare' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);
		$this->add_control(
			'hr3',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		
		
		/* start course */
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'studiare' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fal fa-folder',
					'library' => 'light',
				],
			]
		);

		$repeater->add_control(
			'lesson_title', [
				'label' => __( 'Lesson Title', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Lesson Title' , 'studiare' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'lesson_subtitle', [
				'label' => __( 'Lesson Subtitle', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Subtitle' , 'studiare' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'badge',
			[
				'label' => __( 'Section Badge', 'studiare' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'no_badge',
				'options' => [
					'no_badge'  => __( 'Select', 'studiare' ),
					'video' => __( 'Video', 'studiare' ),
					'exam' => __( 'Exam', 'studiare' ),
					'quiz' => __( 'Quiz', 'studiare' ),
					'lecture' => __( 'Lecture', 'studiare' ),
					'free' => __( 'Free', 'studiare' ),
					'practice' => __( 'Practice', 'studiare' ),
				],
			]
		);
		$repeater->add_control(
			'hr5',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_control(
			'preview_video', [
				'label' => __( 'Preview Video', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '',
				'description' => __( 'You can use Youtube,Vimeo for preview video' , 'studiare' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'hr4',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_control(
			'lesson_video', [
				'label' => __( 'Video URL', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '',
				'description' => wp_kses(
                __('Enter the link to an <strong>m3u8</strong> file (recommended for security) or an mp4 file. Example: https://download.site.com/videos/output.m3u8 or https://site.com/video/1.mp4. This is explained in the Studiare theme PDF guide.', 'studiare'),
                array('strong' => array())
            ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'lesson_video_cover',
			[
				'label' => __( 'Video Cover Image', 'studiare' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'description' => __( 'Select or upload a cover image for the lesson video.' , 'studiare' ),
			]
		);
		$repeater->add_control(
			'lesson_audio', [
				'label' => __( 'Audio URL', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '',
				'description' => __( 'Insert Audio File full Link Address' , 'studiare' ),
				'label_block' => true,
			]
		);
		
		$repeater->add_control(
			'private_lesson',
			[
				'label' => __( 'Private Lesson', 'studiare' ),
				'description' => __( 'By activating this option, the course content will be locked and hidden and will be displayed to the user after purchasing the course.' , 'studiare' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'studiare' ),
				'label_off' => __( 'No', 'studiare' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);
		$repeater->add_control(
            'private_access_type',
            [
                'label' => __( 'Private Access Type', 'studiare' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'private_for_members' => __( 'Private for Members', 'studiare' ),
                    'private_for_buyers' => __( 'Private for Buyers', 'studiare' ),
                ],
                'default' => 'private_for_buyers',
                'condition' => [
                    'private_lesson' => 'true',
                ],
            ]
        );
        $repeater->add_control(
			'hr7',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		

		$repeater->add_control(
			'lesson_content', [
				'label' => __( 'Content', 'studiare' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'Content' , 'studiare' ),
				'show_label' => false,
			]
		);
		
		$repeater->add_control(
			'hr6',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		
		$repeater->add_control(
            'sc_file_type',
            [
                'label' => __( 'File Type', 'studiare' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'download' => __( 'Download from Downloads', 'studiare' ),
                    'external' => __( 'Custom External Link', 'studiare' ),
                ],
                'default' => 'download',
            ]
        );

		//https://developers.elementor.com/query-control-autocomplete-refactoring/
		if (class_exists("\ElementorPro\Modules\QueryControl\Module")) {
		$repeater->add_control(
        	'sc_download_file',
        	[
        		'label' => __( 'Download Link', 'studiare' ),
        		'description' => esc_html__( 'Please search the download title which you create in studiare panel->downloads', 'studiare' ),
        		'type' => \ElementorPro\Modules\QueryControl\Module::QUERY_CONTROL_ID,
        		'default'=>'',
        		'condition' => [
                    'sc_file_type' => 'download'
                ],
        		'autocomplete' => [
        			'object' => \ElementorPro\Modules\QueryControl\Module::QUERY_OBJECT_POST,
        			'display' => 'detailed',
        			//'by_field' => 'post_id',
        			'query' => ["post_type"=>"cdownload"],
        		],
        	]
        );
		}
        		$repeater->add_control(
            'sc_simple_link',
            [
                'label' => __( 'Custom Download URL', 'studiare' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'placeholder' => 'https://example.com/file.zip',
                'condition' => [
                    'sc_file_type' => 'external'
                ],
            ]
        );

		
		$repeater->add_control(
			'sc_download_access',
			[
				'label' => __( 'Download Access', 'studiare' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'protected_dl',
				'options' => [
					'free_dl_all'  => __( 'Free for all users', 'studiare' ),
					'free_dl_users' => __( 'Free just for logged-in users', 'studiare' ),
					'protected_dl' => __( 'Only buyers', 'studiare' ),
				],
			]
		);
		$repeater->add_control(
			'sc_pls',  //protect link status
			[
				'label' => __( 'Protect download link', 'studiare' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'studiare' ),
				'label_off' => __( 'No', 'studiare' ),
				'description' => esc_html__('در صورتی که این گزینه را فعال نمایید حتی پس از خرید محصول، لینک دانلود مستقیم فایل در اختیار کاربر قرار نمی گیرد و سیستم به نوعی تعریف شده است که ابتدا وضعیت ورود کاربر و خرید محصول بررسی و سپس اجازه دانلود داده می شود.', 'studiare'),
				'return_value' => 'true',
				'default' => 'false',
			]
		);
		
		$this->add_control(
			'list',
			[
				'label' => __( 'Lessons List', 'studiare' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				//'default' => '',
				'title_field' => '{{{ lesson_title }}}',
			]
		);
		
		/* end course */
		
		
		
		
		
		$this->end_controls_section();
	}
	
	protected function render() {

        $settings = $this->get_settings_for_display();
        $title   = $settings['title'];
        $list_open_situ  = $settings['list_open_situ'];
        $section_number  = $settings['section_number'];
        $section_num_title  = $settings['section_num_title'];

        $css_class = "course-section";
        $rand_id = rand();
        /* open close by default */
        if($list_open_situ=='true'){$openclass = " active_tab_by_suncode";}else{$openclass = " ";}
        ?>
        <div class="<?php echo esc_attr( $css_class ); ?>"
             data-open="<?php echo ($list_open_situ === 'true') ? $rand_id : ''; ?>">

        	<?php if(!empty($title)): ?>
              <div data-id="<?php echo $rand_id;?>" class="sc-course-lesson-toggle-wrapper">
                   <h5 class="course-section-title">
                       <?php if(!empty($section_num_title) || !empty($section_number) ) { ?>
                       <span class="chapterholder">
                       <?php if(!empty($section_num_title)): ?><span class="scchapturetitle"><?php echo $section_num_title ?></span><?php endif; ?>
                       <?php if(!empty($section_number)): ?><span class="scchapturenumber"><?php echo $section_number ?></span><?php endif; ?>
                       </span>
                       <?php } ?>
                       <?php echo esc_attr($title); ?></h5>
        			<div class="sc-course-lesson-toggle"><i class="fal fa-chevron-down"></i></div></div>
        	<?php endif; ?>
            <div class="panel-group" style="display:none;">
                
        	    <?php //start section content  
        	    
        	    
                if ( $settings['list'] ) { //start lessons holder
                            $lesson_index = 0;
                			foreach (  $settings['list'] as $item ) {  //start lessons list
                			$lesson_id = get_the_ID();
                            $lesson_index++;
                			$icon               = $item['icon'];
                			$title              = $item['lesson_title'];
                			$subtitle           = $item['lesson_subtitle'];
                			$badge              = $item['badge'];
                			$preview_video      = $item['preview_video'];
                			$private_lesson     = $item['private_lesson'];
                            $lesson_video       = $item['lesson_video'];
                            $lesson_video_cover = $item['lesson_video_cover'];
                            $lesson_audio       = $item['lesson_audio'];
                			$sc_pls             = $item['sc_pls'];
                			$content            = $item['lesson_content'];
                			
                			$atts['sc_file_type'] = isset($item['sc_file_type']) ? $item['sc_file_type'] : 'download';

                            $atts['sc_download_file'] = isset($item['sc_download_file']) ? $item['sc_download_file'] : '';
                            
                            $atts['sc_simple_link'] = isset($item['sc_simple_link']) ? $item['sc_simple_link'] : '';
                            
                            $atts['sc_download_access'] = isset($item['sc_download_access']) ? $item['sc_download_access'] : 'protected_dl';

                            $private_access = isset($item['private_access_type']) ? $item['private_access_type'] : 'private_for_buyers';


                				
                		

        	    

                
        	    /* get toast title and message */
                $login_toast_title = codebean_option('login_toast_title');
                $login_toast_message = codebean_option('login_toast_message');
                $bought_toast_title = codebean_option('bought_toast_title');
                $bought_toast_message = codebean_option('bought_toast_message');
                $private_placeholder = codebean_option('private_lesson_message');
                
                // Get current user and check if he bought current course
                $bought_course = false;
                $current_user = wp_get_current_user();
                if( !empty($current_user->user_email) and !empty($current_user->ID) ) {
                	if ( wc_customer_bought_product( $current_user->user_email, $current_user->ID, get_the_id() ) ) {
                		$bought_course = true;
                	}
                }
                
                $isbought = studi_has_bought_items($current_user->ID,get_the_id() );
        		if($isbought =="true"){
        		    $bought_course = true;
        		}
        	    
        	    ?>
        	    <div class="course-lesson">
                <div class="course-panel-heading">
                    <div class="panel-heading-left">
                	    <?php if(!empty($icon)): ?>
                            <div class="course-lesson-icon">
                                <?php \Elementor\Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] ); ?>
                            </div>
                	    <?php endif; ?>
                	    <?php if(!empty($preview_video) || !empty($title)): ?>
                	    <?php 
                            //check if video from aparat
                            if( str_contains($preview_video, ".aparat.com/v") ){
                                
                                $course_video_aparat = substr($preview_video, strrpos($preview_video, '/') + 1);
                                $preview_video = studi_get_aparat_file_link($course_video_aparat);
                            }
                        ?>
                            <div class="title">
                                <div class="title-inner">
                                <h4><?php echo esc_attr($title); ?>
                                    <?php if(!empty($badge) and $badge != 'no_badge'): ?>
                                        <span class="badge-item <?php echo esc_attr($badge); ?>"><?php  echo add_class_value_in_any_lang($badge); ?></span>
                	                <?php endif; ?>
                                </h4>
                                <?php if(!empty($preview_video)): ?>
                                    <a class="video-lesson-preview preview-button" href="<?php echo esc_url( $preview_video ); ?>"><i class="fal fa-play-circle"></i><?php esc_html_e( 'Preview', 'studiare' ); ?></a>
                                <?php endif; ?>
                                </div>
                                <?php if(!empty($subtitle)) : ?><p class="subtitle"><?php echo esc_attr($subtitle); ?></p><?php endif; ?>
                            </div>
                
                        <?php endif; ?>
                    </div>
                
                    <?php if ( !empty($private_lesson) || !empty($sc_pls)) : ?>
                    
                    
                        <div class="panel-heading-right">
                            <?php
                                if($sc_pls==="true"){$sc_protect_link_status = $sc_pls;}else{$sc_protect_link_status = "false";}
                                if($atts['sc_file_type'] === 'external' && !empty($atts['sc_simple_link'])){
                                $lesson_meta = [
                                    [
                                        'sc_file_type'  => 'external',
                                        'sc_simple_link'=> $atts['sc_simple_link']
                                    ]
                                ];
                            
                                update_post_meta($lesson_id, 'lesson_data', $lesson_meta);
                                }
        
                        	echo generate_dl_section($atts, get_the_ID(), $lesson_id,$private_lesson,$bought_course,$login_toast_title,$login_toast_message,$bought_toast_title,$bought_toast_message,$sc_protect_link_status);
                        	?>
                            
                	<?php if ($private_lesson == 'true'): ?>
                        <?php if ($private_access == 'private_for_buyers'): ?>
                            <div class="private-lesson<?php echo $bought_course ? ' privateunlock' : ''; ?>">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="titleId" class="mr-fds-12 grow-0 shrink-0 w-5 h-5 md:w-6 md:h-6 text-fds-icon-disable" aria-label="lock icon"><path d="M11.76 17.3128C11.5691 17.3128 11.3859 17.237 11.251 17.1019C11.1159 16.9669 11.04 16.7837 11.04 16.5928V14.5125C11.04 14.3215 11.1159 14.1384 11.251 14.0034C11.3859 13.8683 11.5691 13.7925 11.76 13.7925C11.951 13.7925 12.1342 13.8683 12.2691 14.0034C12.4042 14.1384 12.48 14.3215 12.48 14.5125V16.5928C12.48 16.7837 12.4042 16.9669 12.2691 17.1019C12.1342 17.237 11.951 17.3128 11.76 17.3128Z" fill="currentColor"></path><path d="M16.0299 10.7458C15.839 10.7458 15.6558 10.6699 15.5208 10.5349C15.3858 10.3999 15.3099 10.2167 15.3099 10.0258V8.00977C15.3048 7.54463 15.2073 7.08514 15.0235 6.65787C14.8395 6.23059 14.5728 5.84402 14.2386 5.52049C13.909 5.18924 13.5152 4.92894 13.0814 4.75559C12.6475 4.58224 12.1827 4.4995 11.7157 4.51248C10.7907 4.51945 9.90543 4.88881 9.24972 5.54125C8.59405 6.19368 8.22033 7.07719 8.2088 8.00209V10.0181C8.2088 10.209 8.13294 10.3922 7.99792 10.5272C7.86289 10.6622 7.67975 10.7381 7.4888 10.7381C7.29785 10.7381 7.11471 10.6622 6.97968 10.5272C6.84465 10.3922 6.7688 10.209 6.7688 10.0181V7.98673C6.7702 6.66277 7.29748 5.3936 8.23465 4.45841C9.17182 3.52321 10.4422 2.9986 11.7661 3C13.09 3.0014 14.3592 3.52868 15.2944 4.46586C16.2296 5.40304 16.7542 6.67333 16.7528 7.99729V10.0133C16.7545 10.1091 16.737 10.2043 16.7014 10.2933C16.6657 10.3823 16.6127 10.4633 16.5454 10.5315C16.4781 10.5997 16.3978 10.6538 16.3093 10.6907C16.2208 10.7274 16.1257 10.7461 16.0299 10.7458Z" fill="currentColor"></path><path d="M14.3517 21.8393H9.16779C8.08777 21.9564 6.99521 21.8352 5.96715 21.4841C5.23057 21.1289 4.63601 20.5346 4.28043 19.7983C3.93054 18.77 3.80964 17.6776 3.92618 16.5977V14.551C3.80946 13.4714 3.93037 12.3793 4.28043 11.3513C4.63577 10.6142 5.23079 10.0195 5.96811 9.66457C6.99586 9.31356 8.08809 9.19231 9.16779 9.30936H14.3517C15.4315 9.19248 16.5236 9.31372 17.5514 9.66457C18.2888 10.0197 18.8835 10.6148 19.2381 11.3522C19.5892 12.3796 19.7105 13.4715 19.5934 14.551V16.5948C19.7104 17.6748 19.5891 18.7674 19.2381 19.7954C18.8827 20.5322 18.2877 21.1267 17.5505 21.4812C16.5234 21.8331 15.4314 21.9554 14.3517 21.8393ZM9.16779 10.7494C8.30342 10.6616 7.43029 10.7339 6.5921 10.9625C6.14905 11.1752 5.79156 11.5324 5.57834 11.9753C5.35073 12.8137 5.27883 13.6867 5.36618 14.551V16.5948C5.27905 17.4598 5.35095 18.3334 5.57834 19.1724C5.79241 19.6138 6.1493 19.9701 6.59115 20.1833C7.42968 20.4118 8.30311 20.484 9.16779 20.3964H14.3517C15.2161 20.484 16.0892 20.4118 16.9275 20.1833C17.3698 19.9703 17.7268 19.6135 17.9403 19.1714C18.1688 18.3329 18.241 17.4595 18.1534 16.5948V14.5481C18.2411 13.6837 18.1689 12.8106 17.9403 11.9724C17.7275 11.5299 17.3707 11.1728 16.9285 10.9596C16.0899 10.7312 15.2165 10.659 14.3517 10.7465L9.16779 10.7494Z" fill="currentColor"></path></svg><span></span>
                            </div>
                        <?php elseif ($private_access == 'private_for_members'): ?>
                            <div class="private-lesson<?php echo is_user_logged_in() ? ' privateunlock' : ''; ?>">
                                <svg xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="md:w-4"><path d="M9.99967 10.0703C12.3009 10.0703 14.1663 8.20485 14.1663 5.90367C14.1663 3.60248 12.3009 1.737 9.99967 1.737C7.69849 1.737 5.83301 3.60248 5.83301 5.90367C5.83301 8.20485 7.69849 10.0703 9.99967 10.0703Z" stroke="currentcolor" stroke-width="1.5px" stroke-linecap="round" stroke-linejoin="round" fill="none"></path><path d="M17.1585 18.4036C17.1585 15.1786 13.9501 12.5703 10.0001 12.5703C6.05013 12.5703 2.8418 15.1786 2.8418 18.4036" stroke="currentcolor" stroke-width="1.5px" stroke-linecap="round" stroke-linejoin="round" fill="none"></path></svg><span></span>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                                			
                        </div>
                    <?php endif; ?>
                	
                </div>
                
                
    <div class="panel-content">
        <div class="panel-content-inner">
            <?php
            // بررسی نوع دسترسی به درس
            if ($private_lesson == 'true') {
                if ($private_access == 'private_for_members') {
                    // محتوای خصوصی برای کاربران واردشده
                    if (is_user_logged_in()) {
                        echo do_shortcode($content);
                        if ( ! empty( $lesson_video ) || ! empty( $lesson_audio ) ) {
                            
                                                        echo render_lesson_media( $lesson_video, $lesson_audio, $lesson_video_cover );
                                                    }
                    } else {
                        ?>
                        <div class="lessonaccessdenied">
                            <span class="icon"><i class="fas fa-user-lock"></i></span>
                            <?php
                                esc_html_e('This lesson is private. Please log in to access.', 'studiare');
                            ?>
                        </div>
                        <?php
                    }
                } else {
                    // محتوای خصوصی برای خریداران
                    if ($bought_course) {
                        echo do_shortcode($content);
                        if ( ! empty( $lesson_video ) || ! empty( $lesson_audio ) ) {
                                                        echo render_lesson_media( $lesson_video, $lesson_audio, $lesson_video_cover );
                                                    }
                    } else {
                        ?>
                        <div class="lessonaccessdenied">
                            <span class="icon"><i class="fas fa-exclamation-triangle"></i></span>
                            <?php
                            // پیام جایگزین برای خریداران
                            if (!empty($private_placeholder)) {
                                echo balancetags($private_placeholder);
                            } else {
                                esc_html_e('This lesson is private, for full access to all lessons you need to buy this course.', 'studiare');
                            }
                            ?>
                        </div>
                        <?php
                    }
                }
            } else {
                echo do_shortcode($content);
                 if ( ! empty( $lesson_video ) || ! empty( $lesson_audio ) ) {
                            
                                                        echo render_lesson_media( $lesson_video, $lesson_audio, $lesson_video_cover );
                                                    }
            }
            ?>
        </div>
    </div>
    </div>

        	    <?php 
                } //end lessons list
                } //end lessons list holder
        	    //end section content  ?>
        	    
            </div>
        </div>

        <?php
	}
	
	protected function content_template() {
	 
    }
	
	
}

