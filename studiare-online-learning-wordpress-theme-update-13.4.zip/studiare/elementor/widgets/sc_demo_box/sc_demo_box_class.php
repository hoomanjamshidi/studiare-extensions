<?php
namespace Elementor;


class Sc_Demo_Box extends Widget_Base {
	
	public function get_name() {
		return 'studi-demo-box';
	}
	
	public function get_title() {
		return  __( 'Demo Box', 'studiare' );
	}
	
	public function get_icon() {
		return 'sc eicon-image-box';
	}
	
	public function get_categories() {
		return [ 'studiare' ];
	}
	
	
	protected function register_controls() {

		
		
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'studiare' ),
			]
		);
		
	
		
		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Title', 'studiare' ),
				
			]
		);
		$this->add_control(
			'badge',
			[
				'label' => __( 'Badge', 'studiare' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'New', 'studiare' ),
				
			]
		);
		
		$this->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'studiare' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'studiare' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'studiare' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		
		$this->add_control(
			'box_height',
			[
				'label' => __( 'Height', 'studiare' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 400,
				
			]
		);
		$this->add_control(
			'badge_bg_color',
			[
				'label' => __( 'Badge Background', 'studiare' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default'=>'#E91E63',
				'selectors' => [
					'{{WRAPPER}} .studi_demo_linker .newbadge' => 'background: {{VALUE}}; box-shadow: 0 3px 13px {{VALUE}}',
				
				],
			]
		);
		
		// Layout since version 13.3
        $this->add_control(
            'layout',
            [
                'label' => __('Layout', 'studiare'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'ly_one',
                'options' => [
                    'ly_one' => __('Layout', 'studiare')." 1",
                    'ly_two' => __('Layout', 'studiare')." 2",
                ],
            ]
        );
        
        $this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'studiare' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'skin' => 'inline',
				/*'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],*/
			]
		);
		
		
		$this->end_controls_section();
	}
	
	protected function render() {

        $settings   = $this->get_settings_for_display();
        $title      = $settings['title'];
        $badge      = $settings['badge'];
        
        $layout     = $settings['layout']?:"ly_one";
        $icon       = $settings['icon'] ;
        
        $box_height = $settings['box_height'];
        $image      = $settings['image']['url'];
        $target = $settings['link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';
		
		if($layout=="ly_one"){
        ?>
        <div class="studi_demo_linker">
            <?php if(!empty($badge)){ ?>
            <span class="newbadge"><?php echo $badge;?></span>
            <?php } 
            echo '<a aria-label="'.$title.'" href="' . $settings['link']['url'] . '"' . $target . $nofollow . '>';
            ?>
        
            <div class="studi_landing_image studi_slippery" style="background-image: url(<?php echo $image;?>);padding-top:<?php echo $box_height;?>px;">
            </div>
            </a>
            <?php echo '<a aria-label="'.$title.'" class="studi_demo_link" href="' . $settings['link']['url'] . '"' . $target . $nofollow . '>'.$title.'</a>'; ?>
        </div>
        <?php
		}
		if($layout=="ly_two"){
		?>
		<div class="studi_demo_linker_ltwo">
            <?php if(!empty($badge)){ ?>
            <span class="newbadge"><?php echo $badge;?></span>
            <?php } 
            echo '<a aria-label="'.$title.'" href="' . $settings['link']['url'] . '"' . $target . $nofollow . '>';
            ?>
            <div class="sdl_head">
                <h3><?php echo $title; ?></h3>
            </div>
            <div class="studi_landing_image" style="background-image: url(<?php echo $image;?>);padding-top:<?php echo $box_height;?>px;">
            </div>
            </a>
            <?php 
            if($settings['icon']['value']){$ico=$settings['icon']['value'];}else{$ico ="fal fa-arrow-left";}
            echo '<a aria-label="'.$title.'" class="studi_dlink_ltwo" href="' . $settings['link']['url'] . '"' . $target . $nofollow . '><i class="'.$ico.'"></i></a>';  ?>
        </div>
		
		<?php
		}
        
	}
	
	protected function content_template() {
	 
    }
	
	
}

