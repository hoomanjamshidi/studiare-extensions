<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

class Studi_Product_Teachers_Widget extends Widget_Base {

    public function get_name() {
        return 'studi-product-teachers';
    }

    public function get_title() {
        return esc_html__( 'Product Teachers', 'studiare' );
    }

    public function get_icon() {
        return 'sc eicon-person';
    }

    public function get_categories() {
        return [ 'woocommerce-elements' ];
    }

    public function get_keywords() {
        return [ 'teacher', 'teachers', 'product teacher', 'course teacher', 'studiare' ];
    }

    public function show_in_panel() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return false;
        }
    
        if ( ! class_exists( '\Elementor\Plugin' ) ) {
            return false;
        }
    
        $document = \Elementor\Plugin::$instance->documents->get_current();
    
        if ( ! $document ) {
            return true;
        }
    
        // Allow Elementor Pro WooCommerce product document.
        if ( class_exists( '\ElementorPro\Modules\Woocommerce\Documents\Product' ) && $document instanceof \ElementorPro\Modules\Woocommerce\Documents\Product ) {
            return true;
        }
    
        // Check document name safely.
        if ( method_exists( $document, 'get_name' ) ) {
            $document_name = $document->get_name();
    
            if ( in_array( $document_name, [ 'product', 'single-product', 'woo-product' ], true ) ) {
                return true;
            }
        }
    
        // Check main post type safely.
        if ( method_exists( $document, 'get_main_id' ) ) {
            $main_id = $document->get_main_id();
    
            if ( $main_id && 'product' === get_post_type( $main_id ) ) {
                return true;
            }
        }
    
        // Check current global post safely.
        $current_post_id = get_the_ID();
    
        if ( $current_post_id && 'product' === get_post_type( $current_post_id ) ) {
            return true;
        }
    
        return false;
    }


    protected function register_controls() {

        /**
         * Content Section
         */
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__( 'Content', 'studiare' ),
            ]
        );

        $this->add_control(
            'link_type',
            [
                'label'   => esc_html__( 'Link Type', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'anchor',
                'options' => [
                    'anchor' => esc_html__( 'Anchor Link (#teacher-ID)', 'studiare' ),
                    'single' => esc_html__( 'Teacher Single Page', 'studiare' ),
                    'none'   => esc_html__( 'No Link', 'studiare' ),
                ],
            ]
        );
        $this->add_control(
            'profile_link_target',
            [
                'label'   => esc_html__( 'Profile Link Target', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '_self',
                'options' => [
                    '_self'  => esc_html__( 'Same Window', 'studiare' ),
                    '_blank' => esc_html__( 'New Window', 'studiare' ),
                ],
                'condition' => [
                    'link_type' => 'single',
                ],
            ]
        );

        $this->add_control(
            'show_avatar',
            [
                'label'        => esc_html__( 'Show Avatar', 'studiare' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'studiare' ),
                'label_off'    => esc_html__( 'Hide', 'studiare' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_name',
            [
                'label'        => esc_html__( 'Show Name', 'studiare' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'studiare' ),
                'label_off'    => esc_html__( 'Hide', 'studiare' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'image_size',
            [
                'label'   => esc_html__( 'Image Size', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'thumbnail',
                'options' => [
                    'thumbnail' => esc_html__( 'Thumbnail', 'studiare' ),
                    'medium'    => esc_html__( 'Medium', 'studiare' ),
                    'large'     => esc_html__( 'Large', 'studiare' ),
                    'full'      => esc_html__( 'Full', 'studiare' ),
                ],
                'condition' => [
                    'show_avatar' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'separator_style',
            [
                'label'   => esc_html__( 'Separator', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'and',
                'options' => [
                    'and'   => esc_html__( 'Comma + And', 'studiare' ),
                    'comma' => esc_html__( 'Comma Only', 'studiare' ),
                    'none'  => esc_html__( 'None', 'studiare' ),
                ],
                'condition' => [
                    'show_name' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'html_tag',
            [
                'label'   => esc_html__( 'HTML Tag', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'div',
                'options' => [
                    'div'  => 'div',
                    'span' => 'span',
                    'p'    => 'p',
                ],
            ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label'   => esc_html__( 'Alignment', 'studiare' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Start', 'studiare' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'studiare' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'End', 'studiare' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                ],
                'default'   => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .studi-product-teachers' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * Wrapper Style
         */
        $this->start_controls_section(
            'section_wrapper_style',
            [
                'label' => esc_html__( 'Wrapper', 'studiare' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'wrapper_gap',
            [
                'label'      => esc_html__( 'Gap', 'studiare' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem' ],
                'range'      => [
                    'px' => [ 'min' => 0, 'max' => 60 ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .studi-product-teachers' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_margin',
            [
                'label'      => esc_html__( 'Margin', 'studiare' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .studi-product-teachers' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label'      => esc_html__( 'Padding', 'studiare' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .studi-product-teachers' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'wrapper_bg',
            [
                'label'     => esc_html__( 'Background', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .studi-product-teachers' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'wrapper_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'studiare' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .studi-product-teachers' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * Item Style
         */
        $this->start_controls_section(
            'section_item_style',
            [
                'label' => esc_html__( 'Item', 'studiare' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'item_gap',
            [
                'label'      => esc_html__( 'Item Inner Gap', 'studiare' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem' ],
                'range'      => [
                    'px' => [ 'min' => 0, 'max' => 30 ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .studi-product-teachers__item' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'item_color',
            [
                'label'     => esc_html__( 'Text Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .studi-product-teachers__item' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .studi-product-teachers__item a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'item_hover_color',
            [
                'label'     => esc_html__( 'Hover Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .studi-product-teachers__item:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .studi-product-teachers__item:hover a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * Avatar Style
         */
        $this->start_controls_section(
            'section_avatar_style',
            [
                'label'     => esc_html__( 'Avatar', 'studiare' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_avatar' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'avatar_width',
            [
                'label'      => esc_html__( 'Width', 'studiare' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'vw' ],
                'default'    => [
                    'size' => 30,
                    'unit' => 'px',
                ],
                'range'      => [
                    'px' => [ 'min' => 10, 'max' => 200 ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .studi-product-teachers__avatar' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'avatar_height',
            [
                'label'      => esc_html__( 'Height', 'studiare' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'vw' ],
                'default'    => [
                    'size' => 30,
                    'unit' => 'px',
                ],
                'range'      => [
                    'px' => [ 'min' => 10, 'max' => 200 ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .studi-product-teachers__avatar' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'avatar_object_fit',
            [
                'label'   => esc_html__( 'Object Fit', 'studiare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'cover',
                'options' => [
                    'cover'   => esc_html__( 'Cover', 'studiare' ),
                    'contain' => esc_html__( 'Contain', 'studiare' ),
                    'fill'    => esc_html__( 'Fill', 'studiare' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .studi-product-teachers__avatar' => 'object-fit: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'avatar_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'studiare' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .studi-product-teachers__avatar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'avatar_border_color',
            [
                'label'     => esc_html__( 'Border Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .studi-product-teachers__avatar' => 'border-color: {{VALUE}}; border-style: solid;',
                ],
            ]
        );

        $this->add_control(
            'avatar_border_width',
            [
                'label'      => esc_html__( 'Border Width', 'studiare' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'selectors'  => [
                    '{{WRAPPER}} .studi-product-teachers__avatar' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; border-style: solid;',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * Name Style
         */
        $this->start_controls_section(
            'section_name_style',
            [
                'label'     => esc_html__( 'Name', 'studiare' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_name' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'name_typography',
                'selector' => '{{WRAPPER}} .studi-product-teachers__name',
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label'     => esc_html__( 'Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .studi-product-teachers__name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'name_hover_color',
            [
                'label'     => esc_html__( 'Hover Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .studi-product-teachers__item:hover .studi-product-teachers__name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /**
         * Separator Style
         */
        $this->start_controls_section(
            'section_separator_style',
            [
                'label'     => esc_html__( 'Separator', 'studiare' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_name' => 'yes',
                    'separator_style!' => 'none',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'separator_typography',
                'selector' => '{{WRAPPER}} .studi-product-teachers__separator',
            ]
        );

        $this->add_control(
            'separator_color',
            [
                'label'     => esc_html__( 'Color', 'studiare' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .studi-product-teachers__separator' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        $settings = $this->get_settings_for_display();

        $product_id = get_the_ID();

        if ( 'product' !== get_post_type( $product_id ) ) {
            global $post;
            if ( isset( $post->ID ) ) {
                $product_id = $post->ID;
            }
        }

        if ( ! $product_id || 'product' !== get_post_type( $product_id ) ) {
            if ( Plugin::$instance->editor->is_edit_mode() ) {
                echo '<div class="elementor-alert elementor-alert-warning">';
                echo esc_html__( 'This widget works only on WooCommerce single product templates.', 'studiare' );
                echo '</div>';
            }
            return;
        }

        $teachers = function_exists( 'studiare_get_course_teachers' ) ? studiare_get_course_teachers( $product_id ) : [];

        if ( empty( $teachers ) ) {
            if ( Plugin::$instance->editor->is_edit_mode() ) {
                echo '<div class="elementor-alert elementor-alert-info">';
                echo esc_html__( 'No teachers found for this product.', 'studiare' );
                echo '</div>';
            }
            return;
        }

        $tag = ! empty( $settings['html_tag'] ) ? $settings['html_tag'] : 'div';

        echo '<div class="studi-product-teachers gap-2" style="display:flex; flex-wrap:wrap; align-items:center;">';

        $teacher_count = count( $teachers );

        foreach ( $teachers as $index => $teacher_id ) {
            $teacher_id = absint( $teacher_id );
            if ( ! $teacher_id ) {
                continue;
            }

            $teacher_name = get_the_title( $teacher_id );
            if ( ! $teacher_name ) {
                continue;
            }

            $teacher_image = '';
            if ( 'yes' === $settings['show_avatar'] ) {
                $teacher_image = get_the_post_thumbnail_url( $teacher_id, $settings['image_size'] );
                if ( empty( $teacher_image ) ) {
                    $teacher_image = get_template_directory_uri() . '/assets/images/placeholder.png';
                }
            }

            $link = '';
            if ( 'single' === $settings['link_type'] ) {
                $link = get_permalink( $teacher_id );
            } elseif ( 'anchor' === $settings['link_type'] ) {
                $link = '#teacher-' . $teacher_id;
            }

            $item_inner = '';

            if ( 'yes' === $settings['show_avatar'] && $teacher_image ) {
                $item_inner .= '<img class="studi-product-teachers__avatar mask-is-squircle" src="' . esc_url( $teacher_image ) . '" alt="' . esc_attr( $teacher_name ) . '">';
            }

            if ( 'yes' === $settings['show_name'] ) {
                $item_inner .= '<span class="studi-product-teachers__name">' . esc_html( $teacher_name ) . '</span>';
            }

            if ( ! empty( $link ) ) {
                $target_attr = '';
                $rel_attr    = '';
            
                if ( 'single' === $settings['link_type'] && ! empty( $settings['profile_link_target'] ) ) {
                    $target_attr = ' target="' . esc_attr( $settings['profile_link_target'] ) . '"';
            
                    if ( '_blank' === $settings['profile_link_target'] ) {
                        $rel_attr = ' rel="noopener noreferrer"';
                    }
                }
            
                echo '<a class="studi-product-teachers__item gap-1" href="' . esc_url( $link ) . '"' . $target_attr . $rel_attr . ' style="display:inline-flex; align-items:center; text-decoration:none;">';
                echo $item_inner;
                echo '</a>';
            } else {
                echo '<' . tag_escape( $tag ) . ' class="studi-product-teachers__item gap-1" style="display:inline-flex; align-items:center;">';
                echo $item_inner;
                echo '</' . tag_escape( $tag ) . '>';
            }

            if ( $index < $teacher_count - 1 && 'yes' === $settings['show_name'] ) {
                $separator = '';

                if ( 'comma' === $settings['separator_style'] ) {
                    $separator = ', ';
                } elseif ( 'and' === $settings['separator_style'] ) {
                    $separator = ( $index === $teacher_count - 2 ) ? esc_html__( ' and ', 'studiare' ) : ', ';
                }

                if ( ! empty( $separator ) ) {
                    echo '<span class="studi-product-teachers__separator">' . esc_html( $separator ) . '</span>';
                }
            }
        }

        echo '</div>';
    }
}
