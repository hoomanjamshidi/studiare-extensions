<?php

namespace Elementor;

        // Register the Elementor widget
class Studi_Product_Informations_Widget extends Widget_Base {

            public function get_name() {
                return 'woocommerce-product-informations';
            }
            
            public function get_icon() {
        		return 'sc eicon-info';
        	}

            public function get_title() {
                return __( 'Product Informations', 'studiare' );
            }

            public function get_categories() {
                return [ 'woocommerce-elements' ];
            }
            
            protected function register_controls() {
                
               
        
        $this->start_controls_section(
			'general',
			[
				'label' => __( 'General', 'studiare' ),
			]
		);      
		
		        /*$this->add_control(
        			'title',
        			[
        				'label' => esc_html__( 'Title', 'studiare' ),
        				'type' => \Elementor\Controls_Manager::TEXT,
        				'placeholder' => esc_html__( 'Title', 'studiare' ),
        			]
        		);*/
                $this->add_control(
    			'info_type',
    			[
    				'label' => __( 'Information Type', 'studiare' ),
    				'type' => \Elementor\Controls_Manager::SELECT2,
    				'multiple' => true,
    				'options'=> [
    				    "total_sells"             => __( 'Total Sells', 'studiare' ), 
    				    "course_language"         => __( 'course language', 'studiare' ), 
    				    "course_duration"         => __( 'course duration', 'studiare' ), 
    				    "course_lesseons"         => __( 'course lesseons', 'studiare' ), 
    				    "course_level"            => __( 'course level', 'studiare' ), 
    				    "sc_file_type"            => __( 'File Type', 'studiare' ), 
    				    "sc_file_size"            => __( 'File Size', 'studiare' ), 
    				    "course_certificate"      => __( 'Course Certificate', 'studiare' ), 
    				    "course_sessions"         => __( 'Course Sessions', 'studiare' ), 
    				    "metaboxjff_sections"     => __( 'Custom Options', 'studiare' ),
    				    "sc_course_type_1"          => __( 'Course Type 1', 'studiare' ),
                        "sc_course_type_2"          => __( 'Course Type 2', 'studiare' ),
                        "published_date"            => __( 'Published Date', 'studiare' ),
                        "updated_date"              => __( 'Updated Date', 'studiare' ),
    				    ],
    				'default' => ['total_sells'],
    			]
    		);
    		
    		$this->add_control(
			'show_empties',
			[
				'label' => esc_html__( 'Show Empty Options', 'studiare' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'studiare' ),
				'label_off' => esc_html__( 'Hide', 'studiare' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
    		/*
    		$this->add_control( 'icon', [
			'label'      => esc_html__( 'Icon', 'studiare' ),
			'show_label' => false,
			'type'       => Controls_Manager::ICONS,
			 
		] ); */
    		
    		$this->add_control(
			'layout-hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
    		$this->add_control(
    			'layout',
    			[
    				'label' => __( 'Layout', 'studiare' ),
    				'type' => \Elementor\Controls_Manager::SELECT,
    				'multiple' => false,
    				'options'=> [
    				    "layout_one"         => __( 'Layout One', 'studiare' ), 
    				    "layout_two"         => __( 'Layout Two', 'studiare' ), 
    				    "layout_three" => __( 'Layout Three', 'studiare' ),
    				    ],
    				'default' => 'layout_one',
    			]
    		);
    		
    		$this->add_control(
    			'info_cols',
    			[
    				'label'               => __( 'Number Of Columns', 'studiare' ),
    				'type'                => \Elementor\Controls_Manager::SELECT2,
    				'multiple'            => false,
    				'condition' => [
            			'layout' => [ 'layout_two', 'layout_three' ],
            		],
    				'options'=> [
    				    "one"             => '1', 
    				    "two"             => '2', 
    				    "three"           => '3', 
    				    "four"            => '4', 
    				    "six"             => '6', 
    				    ],
    				'default'             => 'six',
    			]
    		);
    		
    		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .value',
			]
		);
		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
    		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Icon Color', 'studiare' ),
				'label_block' => false,
				'type' => Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .stelementori_lay_one-meta-info-unit .icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .stelementori_lay_two-meta-info-unit .icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .stelementori_lay_three-meta-info-unit .icon' => 'color: {{VALUE}}',
                ],

			]
		);
		$this->add_control(
			'icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'studiare' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
                    '{{WRAPPER}} .stelementori_lay_one-meta-info-unit .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .stelementori_lay_two-meta-info-unit .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .stelementori_lay_three-meta-info-unit .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],

			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'studiare' ),
				'label_block' => false,
				'type' => Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .sc-meta-item' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .stelementori_lay_three-meta-info-unit .meta-title' => 'color: {{VALUE}}',
                ],

			]
		);
		$this->add_control(
			'value_color',
			[
				'label' => __( 'Value Color', 'studiare' ),
				'label_block' => false,
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .value' => 'color: {{VALUE}}',
				],
			]
		);
		
		
    		
    		 $this->end_controls_section();
                
            } 
            
           public function layout_render($layout, $icon, $title, $data) {

                $settings  = $this->get_settings_for_display();
                $info_cols = !empty($settings['info_cols']) ? $settings['info_cols'] : 'six';
                $cols      = 'col-md-2';
            
                if ($info_cols === 'one') {
                    $cols = 'col-md-12';
                } elseif ($info_cols === 'two') {
                    $cols = 'col-md-6';
                } elseif ($info_cols === 'three') {
                    $cols = 'col-md-4';
                } elseif ($info_cols === 'four') {
                    $cols = 'col-md-3';
                } elseif ($info_cols === 'six') {
                    $cols = 'col-md-2';
                }
            
                $allowed_icon_html = [
                    'i' => [
                        'class' => [],
                    ],
                ];
            
                if ($layout === 'layout_one') {
                    ?>
                    <div class="stelementori_lay_one-meta-info-unit">
                        <?php if ($icon) { ?>
                            <div class="icon"><?php echo wp_kses($icon, $allowed_icon_html); ?></div>
                        <?php } ?>
                        <div class="sc-meta-holder">
                            <div class="sc-meta-item"><?php echo esc_html($title); ?></div>
                            <div class="value"><?php echo esc_html($data); ?></div>
                        </div>
                    </div>
                    <?php
                }
            
                if ($layout === 'layout_two') {
                    ?>
                    <div class="<?php echo esc_attr($cols); ?> col-xs-6">
                        <div class="stelementori_lay_two-meta-info-unit hint--top" aria-label="<?php echo esc_attr($title); ?>">
                            <?php if ($icon) { ?>
                                <div class="icon"><?php echo wp_kses($icon, $allowed_icon_html); ?></div>
                            <?php } ?>
                            <div class="value"><?php echo esc_html($data); ?></div>
                        </div>
                    </div>
                    <?php
                }
            
                if ($layout === 'layout_three') {
                    ?>
                    <div class="<?php echo esc_attr($cols); ?> col-xs-6">
                        <div class="stelementori_lay_three-meta-info-unit meta-info-unit-box">
                            <?php if ($icon) { ?>
                                <div class="icon"><?php echo wp_kses($icon, $allowed_icon_html); ?></div>
                            <?php } ?>
                            <div class="meta-content">
                                <div class="meta-title"><?php echo esc_html($title); ?></div>
                                <div class="value"><?php echo esc_html($data); ?></div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }


 
            public function render() {

                $settings = $this->get_settings_for_display();
            
                $info_type = !empty($settings['info_type']) ? (array) $settings['info_type'] : [];
                if (empty($info_type)) {
                    echo esc_html__("Nothing To Show", "studiare");
                    return;
                }
            
                $layout       = !empty($settings['layout']) ? $settings['layout'] : 'layout_one';
                $show_empties = !empty($settings['show_empties']) ? $settings['show_empties'] : '';
                $pro_id       = get_the_ID();
            
                if (!$pro_id) {
                    echo esc_html__("Nothing To Show", "studiare");
                    return;
                }
            
                $items = sc_get_product_info_items($pro_id, $info_type);
            
                if (empty($items)) {
                    echo esc_html__("Nothing To Show", "studiare");
                    return;
                }
            
                if ($layout === 'layout_three') {
                    echo '<div class="stelementori_lay_three-wrapper prolayoutfive">';
                }
            
                if ($layout === 'layout_two') {
                    echo '<div class="stelementori_lay_two-wrapper">';
                }
            
                foreach ($items as $item) {
                    $title = isset($item['title']) ? $item['title'] : '';
                    $data  = isset($item['value']) ? $item['value'] : '';
                    $icon  = isset($item['icon_html']) ? $item['icon_html'] : '';
            
                    if ($show_empties === 'yes') {
                        if ($data === '' || $data === null) {
                            $data = '-';
                        }
                        $this->layout_render($layout, $icon, $title, $data);
                    } else {
                        if (!empty($item['show'])) {
                            $this->layout_render($layout, $icon, $title, $data);
                        }
                    }
                }
            
                if ($layout === 'layout_three' || $layout === 'layout_two') {
                    echo '</div>';
                }
            }


}


