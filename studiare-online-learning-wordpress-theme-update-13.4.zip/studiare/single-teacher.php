<?php
/**
 * Default Single Teacher Post Template
 */

// Get global options
global $studiare_opt; 

$tid = get_the_ID();

// Basic CSS Injection
add_filter('studi_custom_dynamic_css', function($css){
    $css .= "
    .teacher_lessons_list { transform: translateY(30px); }
    .studi_teacher-thumbnail img { border-radius: 10px; box-shadow: 0 0 60px 0 rgba(0,0,0,.08); max-width: 150px;}
    a.studi_teacher_sbtn { font-size: 20px; color: var(--primary_color); margin: 0 5px; }
    a.studi_teacher_sbtn:hover { color: var(--secondary_color); }
    .stspadder{padding:10px 0;margin:10px 0;}
    .st_te_cou_btn { display: flex ; flex-wrap: wrap; align-items: center; }
    .st_te_cou_btn i { margin: 0 10px; }
    .teacher-stats div {min-width: 100px;}
    ";
    return $css;
});

get_header();

$tid = get_the_ID();

// Read settings via codebean_option
$show_stats_courses  = true;
$show_stats_students = true;
$show_stats_rating   = true;
$show_socials        = true;
$show_about          = true;
$show_courses_list   = true;
$courses_per_page    = 8;

if ( class_exists( 'Redux' ) ) {
    $show_stats_courses  = codebean_option( 'teacher_show_stats_courses' );
    $show_stats_students = codebean_option( 'teacher_show_stats_students' );
    $show_stats_rating   = codebean_option( 'teacher_show_stats_rating' );
    $show_socials        = codebean_option( 'teacher_show_socials' );
    $show_about          = codebean_option( 'teacher_show_about' );
    $show_courses_list   = codebean_option( 'teacher_show_courses_list' );
    $courses_per_page    = codebean_option( 'teacher_courses_per_page' ) ?: 8;
}

$container  = 'main-page-content default-margin';
$site_inner = 'site-content-inner container';
?>

<div class="<?php echo esc_attr( $container ); ?>" id="content">
    <div class="<?php echo esc_attr( $site_inner ); ?>" role="main">

        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
            <div class="studi_teacher-single">

                <?php
                if ( did_action( 'elementor/loaded' ) && \Elementor\Plugin::$instance->db->is_built_with_elementor( get_the_ID() ) ) {
                    the_content();
                } else { ?>
                    <div class="container">
                        <div class="flex flex-col items-center gap-6">

                            <div class="studi_teacher-thumbnail">
                                <?php the_post_thumbnail( 'large' ); ?>
                            </div>

                            <div class="studi_teacher-bio text-center">
                                <h2><?php the_title(); ?></h2>
                                <?php
                                $job_title = get_post_meta( $tid, '_studiare_teacher_job_title', true );
                                if ( $job_title ) echo '<p>' . esc_html( $job_title ) . '</p>';
                                ?>
                            </div>

                            <?php
                            // Stats
                            studiare_render_teacher_stats( $tid, [
                                'show_courses'  => $show_stats_courses,
                                'show_students' => $show_stats_students,
                                'show_rating'   => $show_stats_rating,
                            ] );
                            ?>

                            <?php if ( $show_socials ) : ?>
                                <div class="studi_teacher_socials stspadder">
                                    <?php studiare_render_teacher_socials( $tid ); ?>
                                </div>
                            <?php endif; ?>

                            <?php if ( $show_about && get_the_content() ) : ?>
                                <div class="st_te_about mb-30">
                                    <h3><?php esc_html_e( 'About me', 'studiare' ); ?></h3>
                                    <?php the_content(); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if ( $show_courses_list ) :
                            $q = studiare_get_teacher_courses_query( $tid, $courses_per_page );
                        
                            if ( $q->have_posts() ) :
                                $GLOBALS['studiare_is_teacher_loop'] = true; ?>
                                <div class="st_te_cou flex flex-wrap items-center justify-between gap-2 mb-10">
                                    <h3><?php esc_html_e( 'My Courses', 'studiare' ); ?></h3>
                                    <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) . '?te=' . $tid ); ?>">
                                        <?php esc_html_e( 'View All', 'studiare' ); ?>
                                        <i class="fal fa-arrow-<?php echo $direction_by_lang;?>"></i>
                                    </a>
                                </div>
                                <?php
                                wc_set_loop_prop( 'columns', 4 );
                                woocommerce_product_loop_start();
                                while ( $q->have_posts() ) : $q->the_post();
                                    wc_get_template_part( 'content', 'product' );
                                endwhile;
                                woocommerce_product_loop_end();
                        
                                wp_reset_postdata();
                                unset( $GLOBALS['studiare_is_teacher_loop'] );
                        
                            else :
                                get_template_part( 'inc/templates/not-found' );
                            endif;
                        endif; ?>

                    </div>
                <?php } ?>
            </div>
        <?php endwhile; endif; ?>
    </div>
</div>

<?php get_footer(); ?>