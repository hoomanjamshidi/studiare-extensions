<?php
/**
 * Main File for Roadmaps Archive
 */

get_header();

get_template_part( 'inc/templates/roadmap/roadmap-list' );

get_footer();

?>