document.addEventListener('DOMContentLoaded', function () {

    const skeletons = document.querySelectorAll('.studiare-skeleton');

    const observer = new IntersectionObserver((entries, obs) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {
                const wrapper = entry.target;

                const height = wrapper.dataset.skeletonHeight;
                if (height) {
                    wrapper.style.setProperty('--skeleton-height', height + 'px');
                }

                setTimeout(() => {
                    requestAnimationFrame(() => {
                        requestAnimationFrame(() => {
                            wrapper.classList.add('is-loaded');
                        });
                    });
                }, 300);

                obs.unobserve(wrapper);
            }

        });

    }, {
        threshold: 0.20
    });

    skeletons.forEach(sk => observer.observe(sk));
});
