/**
 * emoji-rating.js
 * Handles emoji-based rating selection in WooCommerce product reviews form
 * Works with the custom emoji rating HTML structure (Facebook-style reactions)
 */

jQuery(document).ready(function($) {

    var $emotes = $('.fb-emote');
    var $ratingInput = $('#rating');

    if ($emotes.length === 0) {
        return;
    }

    $emotes.on('click', function() {
        $emotes.removeClass('s--active');

        $(this).addClass('s--active');

        var ratingValue = $(this).data('rating');

        $ratingInput.val(ratingValue);
    });

    if ($ratingInput.val()) {
        $emotes.filter('[data-rating="' + $ratingInput.val() + '"]').addClass('s--active');
    }
});