jQuery(document).ready(function ($) {
    function getVoteMessage(type, fallback) {
        if (
            typeof studiareCommentVotes !== 'undefined' &&
            studiareCommentVotes.messages &&
            studiareCommentVotes.messages[type]
        ) {
            return studiareCommentVotes.messages[type];
        }

        return fallback || '';
    }

    function showVoteToast(type, messageType, fallbackMessage) {
        var message = getVoteMessage(messageType, fallbackMessage);

        if (!message) {
            return;
        }

        if (typeof toastr === 'undefined') {
            return;
        }

        if (typeof toaster_args === 'undefined') {
            window.toaster_args = {
                positionClass: 'toast-bottom-left',
                closeButton: true,
                progressBar: true,
                timeOut: 4000
            };
        }

        if (type === 'success') {
            toastr.success(message, '<i class="fal fa-check-circle"></i>', toaster_args);
            return;
        }

        if (type === 'warning') {
            toastr.warning(message, '<i class="fal fa-exclamation-triangle"></i>', toaster_args);
            return;
        }

        toastr.error(message, '<i class="fal fa-times-circle"></i>', toaster_args);
    }

    $(document).on('click', '.studiare-comment-vote-btn', function (e) {
        e.preventDefault();

        var $btn = $(this);
        var $wrap = $btn.closest('.studiare-comment-votes');
        var commentId = $wrap.data('comment-id');
        var voteType = $btn.data('vote');

        if (!commentId || $wrap.hasClass('loading')) {
            return;
        }

        $wrap.addClass('loading');

        $.ajax({
            url: studiareCommentVotes.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'studiare_comment_vote',
                nonce: studiareCommentVotes.nonce,
                comment_id: commentId,
                vote_type: voteType
            },
            success: function (response) {
                if (!response) {
                    showVoteToast('error', 'error', 'Something went wrong. Please try again.');
                    return;
                }

                if (!response.success) {
                    var errorType = response.data && response.data.type ? response.data.type : 'error';
                    var errorMessage = response.data && response.data.message ? response.data.message : getVoteMessage(errorType, '');

                    if (errorType === 'login_required') {
                        showVoteToast('error', 'login_required', errorMessage);
                        return;
                    }

                    if (errorType === 'already_voted') {
                        showVoteToast('warning', 'already_voted', errorMessage);
                        return;
                    }

                    if (errorType === 'disabled') {
                        showVoteToast('warning', 'disabled', errorMessage);
                        return;
                    }

                    if (errorType === 'dislike_disabled') {
                        showVoteToast('warning', 'dislike_disabled', errorMessage);
                        return;
                    }

                    showVoteToast('error', errorType, errorMessage);
                    return;
                }

                $wrap.find('.studiare-comment-vote-btn').removeClass('voted');

                if (response.data.user_vote === 'like') {
                    $wrap.find('.studiare-comment-vote-btn.like').addClass('voted');
                }

                if (response.data.user_vote === 'dislike') {
                    $wrap.find('.studiare-comment-vote-btn.dislike').addClass('voted');
                }

                if ($wrap.find('.studiare-comment-vote-btn.like .count').length) {
                    $wrap.find('.studiare-comment-vote-btn.like .count').text(response.data.likes);
                }

                if ($wrap.find('.studiare-comment-vote-btn.dislike .count').length) {
                    $wrap.find('.studiare-comment-vote-btn.dislike .count').text(response.data.dislikes);
                }

                showVoteToast('success', 'success', response.data.message);
            },
            error: function () {
                showVoteToast('error', 'error', 'Something went wrong. Please try again.');
            },
            complete: function () {
                $wrap.removeClass('loading');
            }
        });
    });
});
