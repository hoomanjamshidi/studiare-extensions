jQuery(function ($) {

    // highlight active tab based on current URL
    var curUrl = window.location.href;

    if (curUrl == mobileMenuData.home_url) {
        $("#schome").addClass("active").click();
    }

    if (mobileMenuData.is_woocommerce) {
        if (curUrl == mobileMenuData.account_url) {
            $("#scuser").addClass("active").click();
        }
        if (curUrl == mobileMenuData.cart_url) {
            $("#sccart").addClass("active").click();
        }
    }

    if (mobileMenuData.is_search_page) {
        $("#scsearch").addClass("active").click().click();
    }

    // search function
    window.search_inmob = function () {
        var s = $("#scmobsearchval").val();
        window.location = mobileMenuData.home_url + "/?s=" + s;
    };

    const listItem = document.querySelectorAll('.list');

    function activateLink() {
        listItem.forEach(item => item.classList.remove('active'));
        this.classList.add('active');
    }

    listItem.forEach(item => {
        item.addEventListener('click', activateLink);
        item.addEventListener('click', getPositionAtCenter);
    });

    function getPositionAtCenter() {

        var eid = this.id;
        var delay_time = 500;

        var element = document.getElementById(eid);
        var offset = element.getBoundingClientRect().left;
        var centerX = offset - 10;

        var indicator = document.getElementById("scindicator");
        indicator.style.left = centerX + "px";

        // search toggle
        if (eid == "scsearch") {
            $('.mob_btm_searchbar').toggleClass('sea_active');
        } else {
            $('.mob_btm_searchbar').removeClass('sea_active');
        }

        // homepage redirect
        if (eid == "schome" && window.location.href != mobileMenuData.home_url) {
            setTimeout(() => {
                window.location = mobileMenuData.home_url;
            }, delay_time);
        }

        // account & cart links
        if (eid == "scuser" || eid == "sccart") {
            var url = $(this).attr('data-url');
            if (window.location.href != url) {
                setTimeout(() => {
                    window.location = url;
                }, delay_time);
            }
        }

        // back to top
        if (eid == "sctotop") {
            $("#back-to-top").click();
        }

        // toggle MORE menu
        if (eid == "scmore") {

            $(".mobilemoresec").toggleClass("moreactive");

            var icon = $("#scmore i.scicon");
            var text = $("#scmore .text");

            if ($(".mobilemoresec").hasClass("moreactive")) {
                icon.removeClass("fa-ellipsis-v").addClass("fa-times");
                text.text(mobileMenuData.close_text);
            } else {
                icon.removeClass("fa-times").addClass("fa-ellipsis-v");
                text.text(mobileMenuData.more_text);
            }
        }

    }

});
