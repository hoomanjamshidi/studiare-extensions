<?php
/**
 * Course Modular Functions
 * Precision logic for product loops & Elementor widgets
 */

defined('ABSPATH') || exit;

if ( ! function_exists( 'WC' ) && ! class_exists( 'WooCommerce' ) ) {
    return;
}

/**
 * Fetch product data by name
 */
function sc_get_pro_info($args, $product = null){
    
    // Use global product if none passed
    if (!$product instanceof WC_Product) {
        global $product;
    }

    // Safety check
    if (!$product || !$product->get_id()) {
        return '';
    }
    
    $post_id = $product->get_id();
    
    if(!$args){return;}
    
    $result = array();
    if( in_array('rating',$args) ){
        $result['rating'] =  (float) $product->get_average_rating();;
    }
    if( in_array('rating_count',$args) ){
        $result['rating_count'] = $product->get_review_count();
    }
    if( in_array('has_certificate',$args) ){
        $result['has_certificate'] = get_post_meta($post_id, '_studiare_course_certificate', true);
    }
    
    if( in_array('studiare_badges',$args) ){
        
        
        $tags_html = "";
        $coming_soon = get_post_meta($post_id, '_studiare_sc_product_coming_soon_badge', 1) ;;
        if($coming_soon){$tags_html .= '<div class="cmeta_info cmeta_coming_soon">'.__("coming","studiare").' '.__("soon","studiare").'</div>';}  
        
        $day_for_new = codebean_option('days_for_new') ?: "7";
        $publish_date = get_the_date('Y-m-d H:i:s', $post_id);
        $publish_timestamp = strtotime($publish_date);
        
        // Get current date
        $current_timestamp = current_time('timestamp');
        
        // Calculate difference in seconds
        $difference_seconds = $current_timestamp - $publish_timestamp;
        
        // Convert to days
        $difference_days = ($difference_seconds / (60 * 60 * 24));
        if($difference_days < $day_for_new){$tags_html .= '<div class="cmeta_info cmeta_new">'.esc_html__( 'New', 'studiare' ).'</div>';}
        
        $terms = get_the_terms( $post_id, 'studiare_badges' );
        if ( $terms && ! is_wp_error( $terms ) ) {
            
            foreach ( $terms as $term ) {
                
                $background = get_term_meta( $term->term_id, 'studiare_badge_background', true );
                $color = get_term_meta( $term->term_id, 'studiare_badge_color', true );
                // Apply styling directly based on meta data
                $style = '';
                if ( $background ) {
                    $style .= 'background-color:' . esc_attr( $background ) . '; ';
                }
                if ( $color ) {
                    $style .= 'color:' . esc_attr( $color ) . '; ';
                }
                
                $tags_html .= '<div class="cmeta_info" style="' . $style . '">';
                //echo '<a href="' . esc_url( get_term_link( $term ) ) . '" style="' . $style . '">';
                $tags_html .= esc_html( $term->name );
                //echo '</a>'; 
                $tags_html .= '</div>';
                 
            }
            
        }
         
        $has_certificate = get_post_meta($post_id, '_studiare_course_certificate', true);
        if($has_certificate){$tags_html .= '<div class="cmeta_info">'.$has_certificate.'</div>';}
        
        if(!empty($tags_html)){ 
            
            $tags_html = "<div class='studiare_badges_holder flex flex-wrap gap-2'>$tags_html</div>";
        }
        
        $result['studiare_badges'] = $tags_html;
    }
    
    if ( in_array( 'studiare_course_levels', $args, true ) ) {

        $terms = get_the_terms( $post_id, 'studiare_course_levels' );
    
        if ( $terms && ! is_wp_error( $terms ) ) {
            $tags_html = '';
    
            foreach ( $terms as $term ) {
    
                $icon = get_term_meta( $term->term_id, 'studiare_course_level_icon', true );
    
                $tags_html .= '<div class="course_level">';
    
                if ( ! empty( $icon ) ) {
                    // Add missing space between FontAwesome style and icon class
                    $icon = preg_replace( '/^(fa|fas|far|fal|fab|fad)(fa-)/', '$1 $2', $icon );
    
                    $tags_html .= '<i class="' . esc_attr( $icon ) . '"></i> ';
                }
    
                $tags_html .= esc_html( $term->name );
                $tags_html .= '</div>';
            }
    
            $result['studiare_course_levels'] = $tags_html;
        }
    }


    
    if( in_array('discount_percent',$args) ){
        
        $sale_price     = $product->get_sale_price();
        $regular_price  = $product->get_regular_price();
        
        // Calculate discount only if on sale and prices are valid
        if ($product->is_on_sale() && $regular_price > 0) {
            $regular = (float) $regular_price;
            $sale    = (float) $sale_price;
    
            if ($sale >= 0 && $sale < $regular) {
                $discount_percent = round( (($regular - $sale) / $regular) * 100 );
                $result['discount_percent'] = $discount_percent;
            }
        }
        
        
    }
    
    if( in_array('is_new',$args) ){
        
        $publish_date = get_the_date('Y-m-d H:i:s', $post_id);
        $publish_timestamp = strtotime($publish_date);
        
        // Get current date
        $current_timestamp = current_time('timestamp');
        
        // Calculate difference in seconds
        $difference_seconds = $current_timestamp - $publish_timestamp;
        
        // Convert to days
        $difference_days = ($difference_seconds / (60 * 60 * 24));
        
        $result['is_new'] = $difference_days;
    }
    
    return $result;
}



/**
 * Fetch course meta with default values
 */
function studiare_get_course_meta($post_id) {
    $prefix = '_studiare_';
    $keys = [
        'course_teachers', 'course_duration', 'course_duration_hint', 
        'sc_course_type_selector', 'sc_course_type_title_1', 'sc_course_type_title_2', 
        'sc_loop_main_feature', 'sc_loop_main_feature_hint', 'sc_loop_main_feature_icon', 
        'course_buyers_text', 'course_buyers_text_hint', 'course_buyers_text_icon'
    ];
    $meta = [];
    foreach ($keys as $key) {
        $meta[$key] = get_post_meta($post_id, $prefix . $key, true);
    }
    return $meta;
}

/**
 * Get product excerpt with custom length
 */
function studiare_get_course_excerpt($post_id) {
    if (!codebean_option('product_descr_shop_page', false) || !has_excerpt($post_id)) {
        return '';
    }

    add_filter('excerpt_length', 'studiare_product_custom_excerpt_length', 999);
    $excerpt = get_the_excerpt($post_id);
    
    return sprintf('<div class="course-description">%s</div>', $excerpt);
}

/**
 * Get Teachers list (Only course_teachers array)
 */
function studiare_get_teachers_html($meta) {
    $view_type = codebean_option('archive_teacher_view', 'list');
    if ($view_type === 'disable' || empty($meta['course_teachers']) || !is_array($meta['course_teachers'])) {
        return '';
    }

    $teachers = $meta['course_teachers'];
    $teacher_count = count($teachers);
    $output = sprintf('<div class="sc-teacher %s">', ($view_type === 'avatar' ? 'teacher-avatar' : ''));
    
    $label = ($teacher_count > 1) ? codebean_option('teacher_plural_text', '') : codebean_option('teacher_singular_text', '');
    if ($label) $output .= '<span class="teacher-label font-smaller">' . esc_html($label) . ' </span>';

    foreach ($teachers as $index => $id) {
        $name = get_the_title($id);
        $link = get_the_permalink($id);
        if ($view_type === 'list') {
            $sep = ($index < $teacher_count - 1) ? (($index === $teacher_count - 2) ? esc_html__(' and ', 'studiare') : esc_html__(', ', 'studiare')) : '';
            $output .= sprintf('<a href="%s" class="course-loop-teacher hint--top-right">%s</a>%s', esc_url($link), esc_html($name), $sep);
        } else {
            $img = get_the_post_thumbnail_url($id, 'thumbnail');
            $output .= sprintf('<a target="_blank" href="%s" class="course-loop-teacher hint--top-right" aria-label="%s"><img class="mask-is-squircle" src="%s" alt="%s"></a>', esc_url($link), esc_attr($name), esc_url($img), esc_attr($name));
        }
    }
    return $output . '</div>';
}

/**
 * Full Pricing Logic
 */
function studiare_get_course_price_html($product) {
    $sale_price = $product->get_sale_price();
    $regular_price = $product->get_regular_price();
    $sp = ' '; // Space separator
    $toman_as_image = codebean_option('toman_as_image', false);
    $currency_symbol = get_woocommerce_currency_symbol();
    $currency_html = $toman_as_image ? '<span class="sc-toman-cur">' . $currency_symbol . '</span>' : '<span class="sc-cur-symb">'.$currency_symbol.'</span>';
    $free_or_call = codebean_option('free_or_call_for_price', false);

    // 1. Sale Price Active
    if (!empty($sale_price) && $sale_price != '0') {
        return '<span class="sc_reg_onsale_price">' . number_format($regular_price) . '</span>' . 
               '<span class="price-sale font-semibold">' . number_format($sale_price) . $sp . $currency_html . '</span>';
    } 
    
    // 2. Regular Price exists but Sale is '0'
    if (!empty($regular_price) && $sale_price === '0') {
        return '<span class="sc_reg_onsale_price">' . number_format($regular_price) . $sp . $currency_html . '</span>' . 
               '<span class="price-sale font-semibold">' . esc_html__('Free Course!', 'studiare') . '</span>';
    }

    // 3. Price not set
    if (!isset($regular_price)) {
        return '<span class="amount">' . esc_html__('Call for price', 'studiare') . '</span>';
    }

    // 4. Simple Regular Price
    if (!empty($regular_price) && $regular_price != '0') {
        return '<span class="scregprice">' . number_format($regular_price) . $sp . $currency_html . '</span>';
    }

    // 5. Grouped Products
    if ($product->is_type('grouped')) {
        $children = $product->get_children();
        $prices = [];
        foreach ($children as $child_id) {
            $child = wc_get_product($child_id);
            if ($child && $child->is_purchasable() && $child->get_price() > 0) {
                $prices[] = $child->get_price();
            }
        }
        if (!empty($prices)) {
            $min_p = min($prices);
            $max_p = max($prices);
            if ($min_p == $max_p) return '<span class="scvarprice">' . number_format($min_p) . $sp . $currency_html . '</span>';
            return '<span class="scvarprice hint--top-right" aria-label="' . esc_html__('Select Options', 'studiare') . '">' . 
                    number_format($min_p) . $sp . '-' . $sp . number_format($max_p) . $sp . $currency_html . '</span>';
        }
        return '<span class="amount">' . esc_html__('Call for price', 'studiare') . '</span>';
    }

    // 6. Variable Products
    if ($product->is_type('variable')) {
        $min_v = $product->get_variation_price('min');
        $max_v = $product->get_variation_price('max');
        if ($min_v == $max_v) return '<span class="scvarprice">' . number_format($min_v) . $sp . $currency_html . '</span>';
        return '<span class="scvarprice hint--top-right" aria-label="' . esc_html__('Select Options', 'studiare') . '">' . 
                number_format($min_v) . $sp . '-' . $sp . number_format($max_v) . $sp . $currency_html . '</span>';
    }

    // 7. Free Course
    if ($regular_price == '0') {
        return '<span class="price-free">' . esc_html__('Free Course!', 'studiare') . '</span>';
    }

    // Default Fallback
    return $free_or_call ? 
        '<span class="price-free">' . esc_html__('Free Course!', 'studiare') . '</span>' : 
        '<span class="amount">' . esc_html__('Call for price', 'studiare') . '</span>';
}


/**
 * Full Pricing Logic with correct discount percentage badge
 */
function studiare_get_course_price_plus_html($product) {
    if (!$product instanceof WC_Product) {
        return '';
    }

    $sale_price     = $product->get_sale_price();
    $regular_price  = $product->get_regular_price();
    $sp             = ' '; // Space separator
    $toman_as_image = codebean_option('toman_as_image', false);
    $currency_symbol = get_woocommerce_currency_symbol();
    $currency_html  = $toman_as_image ? '<span class="sc-toman-cur">' . $currency_symbol . '</span>' : $currency_symbol;
    $free_or_call   = codebean_option('free_or_call_for_price', false);

    $discount_percent = 0;

    // Calculate discount only if on sale and prices are valid
    if ($product->is_on_sale() && $regular_price > 0) {
        $regular = (float) $regular_price;
        $sale    = (float) $sale_price;

        if ($sale >= 0 && $sale < $regular) {
            $discount_percent = round( (($regular - $sale) / $regular) * 100 );
        }
    }

    // 1. Sale Price is Active
    if ($sale_price && $sale_price !== '0' && $product->is_on_sale()) {
        $badge = $discount_percent > 0 
            ? '<span class="discount-badge"> -' . esc_html($discount_percent) . '% </span>'
            : '';

        return '<div class="scregularprice"><del class="sc_reg_onsale_price">' . number_format($regular_price) . '</del>' . 
               $badge .
               '</div>' .
               '<div class="price-sale font-semibold">' . number_format($sale_price) . $sp . $currency_html . '</div>';
    }

    // 2. Regular Price exists but Sale is '0' → treat as free
    if ($regular_price && $sale_price === '0') {
        $badge = $discount_percent > 0 
            ? '<span class="discount-badge"> -' . esc_html($discount_percent) . '% </span>'
            : '';

        return '<div class="scregularprice"><del class="sc_reg_onsale_price">' . number_format($regular_price) . '</del>' . 
               $badge .
               '</div>' .
               '<div class="price-sale font-semibold">' . esc_html__('Free Course!', 'studiare') . '</div>';
    }

    // 3. Price not set
    if (!isset($regular_price)) {
        return '<span class="amount">' . esc_html__('Call for price', 'studiare') . '</span>';
    }

    // 4. Simple Regular Price (no sale) 
    if ($regular_price && $regular_price != '0') {
        return '<span class="price-regular font-bold">' . number_format($regular_price) . $sp . $currency_html . '</span>';
    }

    // 5. Grouped Products
    if ($product->is_type('grouped')) {
        $children = $product->get_children();
        $prices = [];
        foreach ($children as $child_id) {
            $child = wc_get_product($child_id);
            if ($child && $child->is_purchasable() && $child->get_price() > 0) {
                $prices[] = (float) $child->get_price();
            }
        }
        if (!empty($prices)) {
            $min_p = min($prices);
            $max_p = max($prices);
            if ($min_p == $max_p) {
                return '<span>' . number_format($min_p) . $sp . $currency_html . '</span>';
            }
            return '<span class="price-regular hint--top-right" aria-label="' . esc_html__('Select Options', 'studiare') . '">' .
                   number_format($min_p) . $sp . '-' . $sp . number_format($max_p) . $sp . $currency_html . '</span>';
        }
        return '<span class="amount">' . esc_html__('Call for price', 'studiare') . '</span>';
    }

    // 6. Variable Products
    if ($product->is_type('variable')) {
        $min_v = $product->get_variation_price('min', true);
        $max_v = $product->get_variation_price('max', true);
        if ($min_v == $max_v) {
            return '<span>' . number_format($min_v) . $sp . $currency_html . '</span>';
        }
        return '<span class="price-regular hint--top-right" aria-label="' . esc_html__('Select Options', 'studiare') . '">' .
               number_format($min_v) . $sp . '-' . $sp . number_format($max_v) . $sp . $currency_html . '</span>';
    }

    // 7. Free Course
    if ((float) $regular_price === 0) {
        return '<span class="price-free">' . esc_html__('Free Course!', 'studiare') . '</span>';
    }

    // Default Fallback
    return $free_or_call
        ? '<span class="price-free">' . esc_html__('Free Course!', 'studiare') . '</span>'
        : '<span class="amount">' . esc_html__('Call for price', 'studiare') . '</span>';
}

/**
 * Add to Cart Button with Toast & SVG support
 */
function studiare_get_add_to_cart_btn($product) {
    if (!codebean_option('sc_shop_page_addtocart', false)) return '';

    $restrict = codebean_option('sc_restrict_guest_purchase', false);
    $is_bought = is_user_logged_in() && wc_customer_bought_product(wp_get_current_user()->user_email, get_current_user_id(), $product->get_id());
    
    $svg_icon = '<svg class="sc-toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7.5 18C8.32843 18 9 18.6716 9 19.5C9 20.3284 8.32843 21 7.5 21C6.67157 21 6 20.3284 6 19.5C6 18.6716 6.67157 18 7.5 18Z"></path><path d="M16.5 18C17.3284 18 18 18.6716 18 19.5C18 20.3284 17.3284 21 16.5 21C15.6716 21 15 20.3284 15 19.5C15 18.6716 15.6716 18 16.5 18Z"></path><path d="M13 9V13M11 11H15"></path><path d="M2 3L2.26121 3.09184C3.5628 3.54945 4.2136 3.77826 4.58584 4.32298C4.95808 4.86771 4.95808 5.59126 4.95808 7.03836V9.76C4.95808 12.7016 5.02132 13.6723 5.88772 14.5862C6.75412 15.5 8.14857 15.5 10.9375 15.5H12M16.2404 15.5C17.8014 15.5 18.5819 15.5 19.1336 15.0504C19.6853 14.6008 19.8429 13.8364 20.158 12.3075L20.6578 9.88275C21.0049 8.14369 21.1784 7.27417 20.7345 6.69708C20.2906 6.12 18.7738 6.12 17.0888 6.12H11.0235M4.95808 6.12H7"></path></svg>';

    if ($restrict && !is_user_logged_in()) {
        return sprintf(
            '<a href="javascript:void(0)" data-toast-title="%s" data-toast-message="%s" data-toast-type="error" class="studi_add_in_shop sc-login-required"><i class="fal fa-shopping-basket"></i></a>',
            esc_attr__('Login Required', 'studiare'),
            esc_attr__('You must be logged in to buy this product.', 'studiare')
        );
    }

    if (!$is_bought && $product->is_purchasable() && $product->is_in_stock()) {
        $msg = sprintf(__('Product "%s" has been added to your cart!', 'studiare'), $product->get_name());
        return sprintf(
            '<a href="%s" data-product_id="%s" data-product_sku="%s" data-toast-title="%s" data-toast-message="%s" data-toast-type="success" class="studi_add_in_shop add_to_cart_button ajax_add_to_cart"><i class="fal fa-shopping-basket"></i></a>',
            esc_url($product->add_to_cart_url()), $product->get_id(), $product->get_sku(), esc_attr($svg_icon), esc_attr($msg)
        );
    }

    return sprintf('<a href="%s" class="studi_add_in_shop"><i class="fal fa-shopping-basket"></i></a>', get_permalink($product->get_id()));
}
function studiare_get_add_to_cart_layout4( $product ) {
    // Early return if not a valid product or feature disabled
    if ( ! $product instanceof WC_Product || ! codebean_option('sc_shop_page_addtocart', false) ) {
        return '';
    }

    $restrict_enabled = codebean_option('sc_restrict_guest_purchase', false);
    $current_user     = wp_get_current_user();
    $user_id          = $current_user->ID;
    $user_email       = $current_user->user_email ?? '';

    $already_bought = $user_id && wc_customer_bought_product($user_email, $user_id, $product->get_id());

    // SVG icon used in toast (same as default function)
    $svg_icon = '<svg class="sc-toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7.5 18C8.32843 18 9 18.6716 9 19.5C9 20.3284 8.32843 21 7.5 21C6.67157 21 6 20.3284 6 19.5C6 18.6716 6.67157 18 7.5 18Z"></path><path d="M16.5 18C17.3284 18 18 18.6716 18 19.5C18 20.3284 17.3284 21 16.5 21C15.6716 21 15 20.3284 15 19.5C15 18.6716 15.6716 18 16.5 18Z"></path><path d="M13 9V13M11 11H15"></path><path d="M2 3L2.26121 3.09184C3.5628 3.54945 4.2136 3.77826 4.58584 4.32298C4.95808 4.86771 4.95808 5.59126 4.95808 7.03836V9.76C4.95808 12.7016 5.02132 13.6723 5.88772 14.5862C6.75412 15.5 8.14857 15.5 10.9375 15.5H12M16.2404 15.5C17.8014 15.5 18.5819 15.5 19.1336 15.0504C19.6853 14.6008 19.8429 13.8364 20.158 12.3075L20.6578 9.88275C21.0049 8.14369 21.1784 7.27417 20.7345 6.69708C20.2906 6.12 18.7738 6.12 17.0888 6.12H11.0235M4.95808 6.12H7"></path></svg>';

    ob_start();
    ?>
    <div class="sc-add-to-cart-four">
        <?php if ( $product->is_purchasable() && $product->is_in_stock() && ! $already_bought ) : ?>

            <?php if ( $restrict_enabled && ! is_user_logged_in() ) : ?>
                <!-- Restricted for guests → show login toast -->
                <a href="javascript:void(0)"
                   data-toast-title="<?php esc_attr_e('Login Required', 'studiare'); ?>"
                   data-toast-message="<?php esc_attr_e('You must be logged in to buy this product.', 'studiare'); ?>"
                   data-toast-type="error"
                   class="studi_add_in_lfour sc-login-required single_add_to_cart_button button alt">
                    <?php esc_html_e('Add to Cart', 'studiare'); ?>
                </a>

            <?php else : ?>
                <!-- Normal add to cart with success toast -->
                <?php
                $success_message = sprintf(
                    __('Product "%s" has been added to your cart!', 'studiare'),
                    $product->get_name()
                );
                ?>
                <a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>"
                   data-product_id="<?php echo esc_attr( $product->get_id() ); ?>"
                   data-product_sku="<?php echo esc_attr( $product->get_sku() ); ?>"
                   data-toast-title="<?php echo esc_attr( $svg_icon ); ?>"
                   data-toast-message="<?php echo esc_attr( $success_message ); ?>"
                   data-toast-type="success"
                   class="studi_add_in_lfour single_add_to_cart_button button alt add_to_cart_button product_type_<?php echo esc_attr( $product->get_type() ); ?> ajax_add_to_cart">
                    <?php
                    echo esc_html( apply_filters(
                        'woocommerce_product_add_to_cart_text',
                        __('Add to Cart', 'studiare'),
                        $product
                    ) );
                    ?>
                </a>
            <?php endif; ?>

        <?php else : ?>
            <!-- Not purchasable / out of stock / already bought → view product -->
            <a href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>"
               class="studi_add_in_lfour single_add_to_cart_button button alt">
                <?php esc_html_e('View More', 'studiare'); ?>
            </a>
        <?php endif; ?>
    </div>
    <?php

    return ob_get_clean();
}
/**
 * Normalize icon class (fix falfa-... to fal fa-...)
 */
function studiare_normalize_icon_class($icon) {

    if (empty($icon)) {
        return '';
    }

    $icon = trim($icon);

    if (strpos($icon, 'fa-') !== false && strpos($icon, ' ') === false) {
        return substr($icon, 0, 3) . ' ' . substr($icon, 3);
    }

    return $icon;
}

/**
 * Satisfaction Rating
 */
function studiare_woocommerce_template_loop_rating_percentage($product = null) {
    // Use global product if none passed
    if (!$product instanceof WC_Product) {
        global $product;
    }

    // Safety check
    if (!$product || !$product->get_id()) {
        return '';
    }

    // Get average rating (0 to 5 scale)
    $average_rating = (float) $product->get_average_rating();

    // If no rating yet, return empty or custom text
    if ($average_rating <= 0) {
        return '<div class="sc-rating no-rating-yet">' . esc_html__('No Votes', 'studiare') . '</div>';
    }

    // Calculate percentage
    $percentage = round(($average_rating / 5) * 100);

    // Optional: add class based on rating level (for styling)
    $rating_class = '';
    if ($percentage >= 90) {
        $rating_class = 'excellent';
    } elseif ($percentage >= 75) {
        $rating_class = 'good';
    } elseif ($percentage >= 60) {
        $rating_class = 'average';
    } else {
        $rating_class = 'poor';
    }

    // You can also show the average number in tooltip
    $tooltip = sprintf(
        esc_attr__( 'Rated %s out of 5', 'studiare' ),
        number_format($average_rating, 1),
        $product->get_review_count()
    );

    // Final output
    $output = sprintf(
        '<div class="sc-rating satisfaction-percentage %s">
            <span class="percentage">%d%%</span>
            <span class="label">%s</span>
        </div>',
        esc_attr($rating_class),
        $percentage,
        esc_html__('Satisfaction', 'studiare')
    );

    return $output;
}
// add comingsoon badge to product
// Coming Soon Badge
function sc_get_coming_soon_badge( $product_id = null ) {

    if ( ! $product_id ) {
        $product_id = get_the_ID();
    }

    $prefix = '_studiare_';

    if ( get_post_meta( $product_id, $prefix . 'sc_product_coming_soon_badge', true ) ) {

        $badge  = "<span class='sc_offer_txt'>" . __( "coming", "studiare" ) . "</span>";
        $badge .= __( "soon", "studiare" );

        return "<div class='sale-perc sc_coming_soon_badge'>{$badge}</div>";
    }

    return '';
}
// add full capacity badge to product
// Full Capacity Badge
function sc_get_full_capacity_badge( $product = null ) {

    if ( ! $product ) {
        global $product;
    }

    if ( ! $product ) {
        return '';
    }

    $product_single_outstock         = codebean_option( 'product_single_outstock' );
    $product_single_outstock_message = codebean_option( 'product_single_outstock_message' );

    if ( ! $product->managing_stock() && ! $product->is_in_stock() && $product_single_outstock ) {

        $message = ! empty( $product_single_outstock_message )
            ? $product_single_outstock_message
            : "<span class='sc_offer_txt'>" . __( "full", "studiare" ) . "</span>" . __( "capacity", "studiare" );

        return "<div class='sale-perc sc_full_capacity_badge'>{$message}</div>";
    }

    return '';
}

// add discount to product
// Discount Badge
function sc_get_discount_badge( $product = null ) {

    if ( ! $product ) {
        global $product;
    }

    if ( ! $product || ! $product->is_on_sale() ) {
        return '';
    }

    $max_percentage = 0;

    if ( $product->is_type( 'simple' ) ) {

        $regular = (float) $product->get_regular_price();
        $sale    = (float) $product->get_sale_price();

        if ( $regular > 0 && $sale > 0 ) {
            $max_percentage = ( ( $regular - $sale ) / $regular ) * 100;
        }

    } elseif ( $product->is_type( 'variable' ) ) {

        foreach ( $product->get_children() as $child_id ) {

            $variation = wc_get_product( $child_id );
            $price     = (float) $variation->get_regular_price();
            $sale      = (float) $variation->get_sale_price();

            if ( $price > 0 && $sale > 0 ) {

                $percentage = ( $price - $sale ) / $price * 100;

                if ( $percentage > $max_percentage ) {
                    $max_percentage = $percentage;
                }
            }
        }
    }

    if ( $max_percentage > 0 ) {

        $badge  = "<span class='sc_offer_txt'>" . round( $max_percentage ) . "%</span>";
        $badge .= __( "Sale", "studiare" );

        return "<div class='sale-perc sc_discount_badge'>{$badge}</div>";
    }

    return '';
}
function sc_render_product_badges( $args = array() ) {

    global $product;

    if ( ! $product ) {
        return;
    }

    $defaults = array(
        'discount'      => true,
        'coming_soon'   => true,
        'full_capacity' => true,
    );

    $args = wp_parse_args( $args, $defaults );

    $output = '';

    if ( $args['discount'] ) {
        $output .= sc_get_discount_badge( $product );
    }

    if ( $args['coming_soon'] ) {
        $output .= sc_get_coming_soon_badge( $product->get_id() );
    }

    if ( $args['full_capacity'] ) {
        $output .= sc_get_full_capacity_badge( $product );
    }

    if ( ! empty( $output ) ) {
        echo "<div class='sc-badge-holder'>{$output}</div>";
    }
}

function sc_get_purchase_date( $product_id, $user_id = null ) {
    if ( ! $user_id ) {
        $user_id = get_current_user_id();
    }
    if ( ! $user_id ) {
        return false;
    }

    $cache_key = '_sc_purchase_date_' . $product_id;
    $cached = get_user_meta( $user_id, $cache_key, true );

    if ( ! empty( $cached ) ) {
        return $cached;
    }

    // Not cached → fetch from orders
    $orders = wc_get_orders([
        'customer_id' => $user_id,
        'limit' => -1,
        'status' => ['completed', 'processing'],
    ]);

    foreach ( $orders as $order ) {
        foreach ( $order->get_items() as $item ) {
            if ( (int) $item->get_product_id() === (int) $product_id ) {

                $date = $order->get_date_completed()
                    ? $order->get_date_completed()->date_i18n('Y/m/d')
                    : $order->get_date_created()->date_i18n('Y/m/d');

                // Save to cache
                update_user_meta( $user_id, $cache_key, $date );

                return $date;
            }
        }
    }

    // Save negative result to avoid repeated queries
    update_user_meta( $user_id, $cache_key, 'none' );
    return false;
}
/**
 * Get course teachers IDs from product/course
 */
function studiare_get_course_teachers($post_id = null) {
    $post_id = $post_id ? absint($post_id) : get_the_ID();
    $prefix  = '_studiare_';

    $teachers = get_post_meta($post_id, $prefix . 'course_teachers', true);

    if (empty($teachers) || !is_array($teachers)) {
        $teachers = array_filter([
            get_post_meta($post_id, $prefix . 'course_teacher', true),
            get_post_meta($post_id, $prefix . 'course_teacher_2', true),
            get_post_meta($post_id, $prefix . 'course_teacher_3', true),
            get_post_meta($post_id, $prefix . 'course_teacher_4', true),
        ], function($id) {
            return !empty($id) && $id !== 'no-teacher';
        });
    }

    $teachers = array_values(array_filter($teachers, function($id) {
        $id = absint($id);
        return $id && get_post($id);
    }));

    return $teachers;
}
/**
 * Get teacher link by mode
 */
function studiare_get_teacher_link($teacher_id, $link_type = 'anchor', $args = []) {
    $teacher_id = absint($teacher_id);

    switch ($link_type) {
        case 'single':
            return get_permalink($teacher_id);

        case 'anchor':
            return '#teacher-' . $teacher_id;

        case 'custom':
            if (!empty($args['custom_link']) && is_callable($args['custom_link'])) {
                return call_user_func($args['custom_link'], $teacher_id, $args);
            }

            if (!empty($args['custom_links']) && isset($args['custom_links'][$teacher_id])) {
                return $args['custom_links'][$teacher_id];
            }

            return '#teacher-' . $teacher_id;

        default:
            return '#teacher-' . $teacher_id;
    }
}
/**
 * Render teachers list HTML
 *
 * @param array $args
 * @return string
 */
function studiare_render_teachers($args = []) {
    $defaults = [
        'post_id'            => get_the_ID(),
        'teachers'           => [],

        'wrapper_class'      => 'course-author flex items-center gap-1 mb-10',
        'list_class'         => 'value teacher-anchor-list flex items-center gap-1',
        'item_class'         => 'teacher-anchor-item flex items-center gap-1',
        'separator_class'    => 'teacher-separator',

        'link_type'          => 'anchor', // anchor | single | custom
        'custom_link'        => null,
        'custom_links'       => [],

        'show_name'          => true,
        'show_avatar'        => true,

        'image_size'         => 'thumbnail', // thumbnail | medium | full ...
        'image_width'        => 30,
        'image_height'       => 30,
        'image_class'        => 'teacher-anchor-avatar mask-is-squircle',

        // placeholder
        'placeholder'        => get_template_directory_uri() . '/assets/images/default-avatar.svg',

        // separator
        'show_separator'     => true,
        'separator_style'    => 'and', // and | comma | none

        // خروجی
        'echo'               => false,
    ];

    $args = wp_parse_args($args, $defaults);

    $teachers = !empty($args['teachers']) && is_array($args['teachers'])
        ? $args['teachers']
        : studiare_get_course_teachers($args['post_id']);

    if (empty($teachers)) {
        return '';
    }

    $output = '<div class="' . esc_attr($args['wrapper_class']) . '">';

    $teacher_count = count($teachers);
    $label = ($teacher_count > 1)
        ? codebean_option('teacher_plural_text', '')
        : codebean_option('teacher_singular_text', '');
    
    if ($label) {
        $output .= '<span class="teacher-label">' . esc_html($label) . ' </span>';
    }
    
    $output .= '<div class="' . esc_attr($args['list_class']) . '">';



    foreach ($teachers as $index => $teacher_id) {
        $teacher_id   = absint($teacher_id);
        $teacher_name = get_the_title($teacher_id);

        if (!$teacher_id || empty($teacher_name)) {
            continue;
        }

        $teacher_link = studiare_get_teacher_link($teacher_id, $args['link_type'], $args);

        $teacher_image = get_the_post_thumbnail_url($teacher_id, $args['image_size']);
        if (empty($teacher_image)) {
            $teacher_image = $args['placeholder'];
        }

        $output .= '<a href="' . esc_url($teacher_link) . '" class="' . esc_attr($args['item_class']) . '">';

        if (!empty($args['show_avatar'])) {
            $output .= '<img 
                width="' . esc_attr($args['image_width']) . '"
                height="' . esc_attr($args['image_height']) . '"
                class="' . esc_attr($args['image_class']) . '"
                src="' . esc_url($teacher_image) . '"
                alt="' . esc_attr($teacher_name) . '">';
        }

        if (!empty($args['show_name'])) {
            $output .= '<span class="teacher-anchor-name">' . esc_html($teacher_name) . '</span>';
        }

        $output .= '</a>';

        if ($args['show_separator'] && $index < $teacher_count - 1) {
            $sep = '';
            if ($args['separator_style'] === 'comma') {
                $sep = ', ';
            } elseif ($args['separator_style'] === 'and') {
                $sep = ($index == $teacher_count - 2) ? __(' and ', 'studiare') : ', ';
            }

            if ($sep) {
                $output .= '<span class="' . esc_attr($args['separator_class']) . '">' . esc_html($sep) . '</span>';
            }
        }
    }

    $output .= '</div></div>';

    if ($args['echo']) {
        echo $output;
    }

    return $output;
}
