<?php
// dashboard shortcode
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('studiare_render_default_dashboard')) {
    function studiare_render_default_dashboard() {
        ob_start();

        global $wpdb;

        $user_id = get_current_user_id();

        // Count current user comments safely.
        $total_comments = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(comment_ID) FROM {$wpdb->comments} WHERE user_id = %d",
                $user_id
            )
        );

        // Make sure is_plugin_active exists on frontend.
        if (!function_exists('is_plugin_active')) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $events_active = is_plugin_active('wp-events-manager/wp-events-manager.php');
        $wishlist_active = is_plugin_active('woo-smart-wishlist/wpc-smart-wishlist.php');

        // Count published events.
        $total_events = 0;
        if ($events_active && post_type_exists('tp_event')) {
            $event_counts = wp_count_posts('tp_event');
            $total_events = isset($event_counts->publish) ? (int) $event_counts->publish : 0;
        }
        $total_products = count(get_posts(array('post_type' => 'product', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => '-1')));
        $total_posts = count(get_posts(array('post_type' => 'post', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => '-1')));

        do_action('suncode_before_my_account');

        $dashsidebar = 'myaccount-temp-01';
        $show_latest_notifs_tab = false;
        $show_statistics_tab = false;
        $show_custom_tab = false;
        $dash_custom_tab_title = 'تب سفارشی';
        $dash_custom_tab_content = '';
        $sc_active_dash_tab = '';

        if (class_exists('Redux')) {
            $dashsidebar = codebean_option('my_account_page_template') ?: 'myaccount-temp-01';
            $show_latest_notifs_tab = codebean_option('show_latest_notifs_tab');
            $show_statistics_tab = codebean_option('show_statistics_tab');
            $show_custom_tab = codebean_option('show_custom_tab');
            $dash_custom_tab_title = codebean_option('dash_custom_tab_title') ?: 'تب سفارشی';
            $dash_custom_tab_content = codebean_option('dash_custom_tab_content') ?: '';
            $sc_active_dash_tab = codebean_option('sc_active_dash_tab');
        }

        if ($dashsidebar === 'myaccount-temp-01') {
            if (!$events_active && !$wishlist_active) {
                $chartW = 8;
                $chartX = 0;
            } else {
                $chartW = 5;
                $chartX = 3;
            }

            $PXW_one = 2;
            $PX_one = 8;
            $PY_one = 0;

            $PXW_two = 2;
            $PX_two = 10;
            $PY_two = 0;

            $PXW_three = 2;
            $PX_three = 8;
            $PY_three = 0;

            $PXW_four = 2;
            $PX_four = 10;
            $PY_four = 2;
        } else {
            if (!$events_active && !$wishlist_active) {
                $chartW = 12;
                $chartX = 0;
            } else {
                $chartW = 9;
                $chartX = 3;
            }

            $PXW_one = 3;
            $PX_one = 0;
            $PY_one = 4;

            $PXW_two = 3;
            $PX_two = 3;
            $PY_two = 4;

            $PXW_three = 3;
            $PX_three = 6;
            $PY_three = 0;

            $PXW_four = 3;
            $PX_four = 9;
            $PY_four = 4;
        }
        ?>

        <h3 class="account-dashboard-title">
            <?php esc_html_e('Dashboard', 'studiare'); ?>
        </h3>

        <?php
        // Show support ticket stats if enabled.
        if (class_exists('SWSS_HtmlHelper')) {
            $tickets_in_dashbard_page = null;

            if (class_exists('Redux')) {
                $tickets_in_dashbard_page = codebean_option('tickets_in_dashbard_page');
            }

            if ($tickets_in_dashbard_page) {
                (new SWSS_HtmlHelper())->swss_show_ticket_stats_infront();
            }
        }
        ?>

        <div class="grid-stack">
            <?php if ($events_active) : ?>
                <div class="grid-stack-item" data-gs-x="0" data-gs-y="0" data-gs-width="3" data-gs-height="2">
                    <div class="grid-stack-item-content sc_dashboard_box flex bg-primary-gradient">
                        <a href="<?php echo esc_url(home_url('/events')); ?>" class="flex gap-5 items-center justify-between w-full flex-row-reverse">
                            <div class="sc-dahsboard-icon icon-wrapper">
                                <div class="mask-is-squircle icon-wrapper-bg bg-primary"></div>
                                <i class="fal fa-calendar-alt text-primary"></i>
                            </div>
                            <div class="sc-dahsboard-value">
                                <span class="wc-amount font-semibold text-primary">
                                    <?php
                                    echo esc_html($total_events) . '&nbsp;';
                                    esc_html_e('Event', 'studiare');
                                    ?>
                                </span>
                                <div class="wc-information"><?php esc_html_e('there is in site', 'studiare'); ?></div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($show_latest_notifs_tab || $show_statistics_tab || $show_custom_tab) : ?>
                <div class="grid-stack-item" data-gs-x="<?php echo esc_attr($chartX); ?>" data-gs-y="0" data-gs-width="<?php echo esc_attr($chartW); ?>" data-gs-height="4">
                    <div class="grid-stack-item-content sc_dashboard_box">
                        <?php
                        $chart_file = locate_template('woocommerce/myaccount/chart.php');

                        if ($chart_file) {
                            include $chart_file;
                        }
                        ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="grid-stack-item" data-gs-x="<?php echo esc_attr($PX_one); ?>" data-gs-y="<?php echo esc_attr($PY_three); ?>" data-gs-width="<?php echo esc_attr($PXW_one); ?>" data-gs-height="2">
                <div class="grid-stack-item-content sc_dashboard_box flex bg-success-gradient">
                    <a href="<?php echo esc_url(wc_get_endpoint_url('my-courses')); ?>" class="flex gap-5 items-center justify-between w-full flex-row-reverse">
                        <div class="sc-dahsboard-icon icon-wrapper">
                            <div class="mask-is-squircle icon-wrapper-bg bg-success"></div>
                            <i class="fal fa-user-graduate text-success"></i>
                        </div>
                        <div class="sc-dahsboard-value">
                            <span class="wc-amount font-semibold text-success">
                                <?php
                                $courses_count = function_exists('sc_get_user_courses_count') ? (int) sc_get_user_courses_count() : 0;
                                echo esc_html($courses_count) . '&nbsp;';
                                echo esc_html(_n('Course', 'Courses', $courses_count, 'studiare'));
                                ?>
                            </span>
                            <div class="wc-information"><?php esc_html_e('You have enrolled', 'studiare'); ?></div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="grid-stack-item" data-gs-x="<?php echo esc_attr($PX_two); ?>" data-gs-y="<?php echo esc_attr($PY_two); ?>" data-gs-width="<?php echo esc_attr($PXW_two); ?>" data-gs-height="2">
                <div class="grid-stack-item-content sc_dashboard_box flex bg-primary-gradient">
                    <a href="<?php echo esc_url(wc_get_endpoint_url('purchased-products')); ?>" class="flex gap-5 items-center justify-between w-full flex-row-reverse">
                        <div class="sc-dahsboard-icon icon-wrapper">
                            <div class="mask-is-squircle icon-wrapper-bg bg-primary"></div>
                            <i class="fal fa-shopping-bag text-primary"></i>
                        </div>
                        <div class="sc-dahsboard-value">
                            <span class="wc-amount font-semibold text-primary">
                                <?php
                                echo function_exists('sc_populate_products_page') ? esc_html(sc_populate_products_page()) : '0';
                                echo '&nbsp;';
                                esc_html_e('Product', 'studiare');
                                ?>
                            </span>
                            <div class="wc-information"><?php esc_html_e('You have registered', 'studiare'); ?></div>
                        </div>
                    </a>
                </div>
            </div>

            <?php if ($wishlist_active) : ?>
                <div class="grid-stack-item" data-gs-x="0" data-gs-y="2" data-gs-width="3" data-gs-height="2">
                    <div class="grid-stack-item-content sc_dashboard_box flex bg-warning-gradient">
                        <a href="<?php echo esc_url(wc_get_endpoint_url('wishlist')); ?>" class="flex gap-5 items-center justify-between w-full flex-row-reverse">
                            <div class="sc-dahsboard-icon icon-wrapper">
                                <div class="mask-is-squircle icon-wrapper-bg bg-warning"></div>
                                <i class="fal fa-heart text-warning"></i>
                            </div>
                            <div class="sc-dahsboard-value">
                                <span class="wc-amount font-semibold text-warning">
                                    <?php
                                    if (class_exists('WPcleverWoosw')) {
                                        echo esc_html(WPcleverWoosw::get_count()) . '&nbsp;';
                                    }

                                    esc_html_e('Product', 'studiare');
                                    ?>
                                </span>
                                <div class="wc-information"><?php esc_html_e('in Your Whishlist', 'studiare'); ?></div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>

            <div class="grid-stack-item sc_incart_box" data-gs-x="<?php echo esc_attr($PX_three); ?>" data-gs-y="<?php echo esc_attr($PY_three); ?>" data-gs-width="<?php echo esc_attr($PXW_three); ?>" data-gs-height="2">
                <div class="grid-stack-item-content sc_dashboard_box flex bg-warning-gradient">
                    <a href="<?php echo esc_url(wc_get_endpoint_url('orders') . '?status=pending,failed,on-hold'); ?>" class="flex gap-5 items-center justify-between w-full flex-row-reverse">
                        <div class="sc-dahsboard-icon icon-wrapper">
                            <div class="mask-is-squircle icon-wrapper-bg bg-warning"></div>
                            <i class="fal fa-cart-plus text-warning"></i>
                        </div>
                        <div class="sc-dahsboard-value">
                            <span class="wc-amount font-semibold text-warning">
                                <?php
                                echo function_exists('sc_get_user_orders_on_hold_total') ? esc_html(sc_get_user_orders_on_hold_total()) : '0';
                                echo '&nbsp;';
                                esc_html_e('Product', 'studiare');
                                ?>
                            </span>
                            <div class="wc-information"><?php esc_html_e('waiting for payment', 'studiare'); ?></div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="grid-stack-item" data-gs-x="<?php echo esc_attr($PX_four); ?>" data-gs-y="<?php echo esc_attr($PY_four); ?>" data-gs-width="<?php echo esc_attr($PXW_four); ?>" data-gs-height="2">
                <div class="grid-stack-item-content sc_dashboard_box flex bg-focus-gradient">
                    <a href="<?php echo esc_url(wc_get_endpoint_url('user_comments')); ?>" class="flex gap-5 items-center justify-between w-full flex-row-reverse">
                        <div class="sc-dahsboard-icon icon-wrapper">
                            <div class="mask-is-squircle icon-wrapper-bg bg-focus"></div>
                            <i class="fal fa-comments text-focus"></i>
                        </div>
                        <div class="sc-dahsboard-value">
                            <span class="wc-amount font-semibold text-focus">
                                <?php
                                echo esc_html($total_comments) . '&nbsp;';
                                esc_html_e('Comment', 'studiare');
                                ?>
                            </span>
                            <div class="wc-information"><?php esc_html_e('You have write', 'studiare'); ?></div>
                        </div>
                    </a>
                </div>
            </div>

            <?php
            if (function_exists('woo_wallet')) {
                $purch_pro_width = '9';
                $number = 3;
            } else {
                $purch_pro_width = '12';
                $number = 4;
            }

            if (class_exists('Redux')) {
                $dashsidebar = codebean_option('my_account_page_template');

                if ($dashsidebar !== 'myaccount-temp-01') {
                    if (function_exists('woo_wallet')) {
                        $purch_pro_width = '9';
                        $number = 2;
                    } else {
                        $purch_pro_width = '12';
                        $number = 3;
                    }
                }
            }
            ?>

            <div class="grid-stack-item" data-gs-x="0" data-gs-y="6" data-gs-width="<?php echo esc_attr($purch_pro_width); ?>" data-gs-height="6">
                <div class="grid-stack-item-content sc_dashboard_box">
                    <div class="sc-dahsboard-icon inline-flex items-center gap-1 justify-center w-full">
                        <i class="fal fa-shopping-basket text-success"></i>
                        <span class="wc-amount"><?php esc_html_e('Purchased Products', 'studiare'); ?></span>
                    </div>

                    <?php
                    if (function_exists('sc_get_purchased_pro')) {
                        sc_get_purchased_pro($number);
                    }
                    ?>
                </div>
            </div>

            <?php if (function_exists('woo_wallet')) : ?>
                <div class="grid-stack-item" data-gs-x="9" data-gs-y="6" data-gs-width="3" data-gs-height="2">
                    <div class="grid-stack-item-content sc_dashboard_box flex">
                        <a href="<?php echo esc_url(wc_get_account_endpoint_url(get_option('woocommerce_woo_wallet_endpoint', 'woo-wallet'))); ?>" class="flex gap-5 items-center justify-between w-full flex-row-reverse">
                            <div class="sc-dahsboard-icon icon-wrapper">
                                <div class="mask-is-squircle icon-wrapper-bg bg-success"></div>
                                <i class="fal fa-wallet text-success"></i>
                            </div>
                            <div class="sc-dahsboard-value">
                                <span class="wc-amount font-semibold text-success">
                                    <?php echo wp_kses_post(woo_wallet()->wallet->get_wallet_balance(get_current_user_id())); ?>
                                </span>
                                <div class="wc-information"><?php esc_html_e('Your wallet balance', 'studiare'); ?></div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="grid-stack-item" data-gs-x="9" data-gs-y="8" data-gs-width="3" data-gs-height="2">
                    <div class="grid-stack-item-content sc_dashboard_box flex">
                        <a href="<?php echo esc_url(wc_get_endpoint_url(get_option('woocommerce_woo_wallet_endpoint', 'woo-wallet'), 'add', wc_get_page_permalink('myaccount'))); ?>" class="flex gap-5 items-center justify-between w-full flex-row-reverse">
                            <div class="sc-dahsboard-icon icon-wrapper">
                                <div class="mask-is-squircle icon-wrapper-bg bg-primary"></div>
                                <i class="fal fa-plus text-primary"></i>
                            </div>
                            <div class="sc-dahsboard-value">
                                <span class="wc-amount font-semibold text-primary"></span>
                                <div class="wc-information"><?php esc_html_e('Increase the amount of the wallet', 'studiare'); ?></div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="grid-stack-item" data-gs-x="9" data-gs-y="10" data-gs-width="3" data-gs-height="2">
                    <div class="grid-stack-item-content sc_dashboard_box flex">
                        <a href="<?php echo esc_url(wc_get_endpoint_url(get_option('woocommerce_woo_wallet_endpoint', 'woo-wallet'), 'transfer', wc_get_page_permalink('myaccount'))); ?>" class="flex gap-5 items-center justify-between w-full flex-row-reverse">
                            <div class="sc-dahsboard-icon icon-wrapper">
                                <div class="mask-is-squircle icon-wrapper-bg bg-warning"></div>
                                <i class="fal fa-random text-warning"></i>
                            </div>
                            <div class="sc-dahsboard-value">
                                <span class="wc-amount font-semibold text-warning"></span>
                                <div class="wc-information"><?php esc_html_e('Transfer wallet balance', 'studiare'); ?></div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <script type="text/javascript">
            if (typeof GridStack !== 'undefined') {
                var grid = GridStack.init();
                grid.movable('.grid-stack-item', false);
                grid.resizable('.grid-stack-item', false);
            }
        </script>

        <?php

        return ob_get_clean();
    }
}
if (!function_exists('studiare_default_dashboard_shortcode')) {
    function studiare_default_dashboard_shortcode($atts = array()) {
        if (!function_exists('studiare_render_default_dashboard')) {
            return '';
        }

        return studiare_render_default_dashboard();
    }
}
if (!function_exists('studiare_can_render_custom_dashboard_page')) {
    function studiare_can_render_custom_dashboard_page($page_id) {
        $page_id = absint($page_id);

        if (!$page_id) {
            return false;
        }

        // Prevent rendering the current page inside itself.
        if (is_page($page_id)) {
            return false;
        }

        $myaccount_page_id = absint(get_option('woocommerce_myaccount_page_id'));

        // Prevent using the WooCommerce my account page as custom dashboard.
        if ($myaccount_page_id && $page_id === $myaccount_page_id) {
            return false;
        }

        return true;
    }
}

if (!function_exists('studiare_render_custom_dashboard_page')) {
    function studiare_render_custom_dashboard_page($page_id) {
        static $rendering_pages = array();

        $page_id = absint($page_id);

        if (!$page_id || !studiare_can_render_custom_dashboard_page($page_id)) {
            return function_exists('studiare_render_default_dashboard') ? studiare_render_default_dashboard() : '';
        }

        // Prevent recursive rendering.
        if (isset($rendering_pages[$page_id])) {
            return function_exists('studiare_render_default_dashboard') ? studiare_render_default_dashboard() : '';
        }

        $rendering_pages[$page_id] = true;

        $output = '';

        if (class_exists('\Elementor\Plugin')) {
            $content_elementor = \Elementor\Plugin::instance()->frontend->get_builder_content($page_id);

            if (!empty($content_elementor)) {
                $output = $content_elementor;
            }
        }

        if (empty($output)) {
            $page = get_post($page_id);

            if ($page && $page->post_status === 'publish') {
                $output = apply_filters('the_content', $page->post_content);
            }
        }

        unset($rendering_pages[$page_id]);

        if (empty($output)) {
            return function_exists('studiare_render_default_dashboard') ? studiare_render_default_dashboard() : '';
        }

        return $output;
    }
}
