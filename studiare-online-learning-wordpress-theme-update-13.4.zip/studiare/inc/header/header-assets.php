<?php
defined('ABSPATH') || exit;
// hi
add_action('wp_enqueue_scripts', function() {
    $theme_uri = get_template_directory_uri();

    wp_enqueue_script('studiare-header');

    wp_localize_script(
        'studiare-header',
        'studiare_ajax',
        [
            'ajaxurl' => admin_url('admin-ajax.php', 'relative'),
            'nonce'   => wp_create_nonce('studiare_header_nonce'), // Security Token
        ]
    );
      // CSS
    wp_enqueue_style('studiare-header-style');
}, 20);

add_action('wp_ajax_studiare_actions', 'studiare_ajax_handler');
add_action('wp_ajax_nopriv_studiare_actions', 'studiare_ajax_handler');

function studiare_ajax_handler() {
    check_ajax_referer('studiare_header_nonce', 'nonce');
    // 1. Basic Validation
    if (empty($_POST['type']) || $_POST['type'] !== 'get_products_by_cat') {
        wp_send_json_error(['message' => 'Invalid request']);
    }

    $cat_id = absint($_POST['cat_id']);

    if (!$cat_id) {
        wp_send_json_error(['message' => 'Invalid category ID']);
    }

    // 2. High Performance Query Arguments
    $args = [
        'post_type'           => 'product',
        'posts_per_page'      => 4,
        'post_status'         => 'publish',
        'ignore_sticky_posts' => 1,
        
        // --- PERFORMANCE OPTIMIZATIONS ---
        'no_found_rows'          => true,
        'update_post_term_cache' => false,
        
        'tax_query'           => [
            [
                'taxonomy' => 'product_cat',
                'field'    => 'term_id',
                'terms'    => $cat_id,
            ],
        ],
    ];

    $q = new WP_Query($args);

    // If no products found
    if (!$q->have_posts()) {
        wp_reset_postdata();
        wp_send_json_success(['template' => '<li class="no-products">' . esc_html__('No products found.', 'studiare') . '</li>']);
    }

    ob_start();

    while ($q->have_posts()) {
        $q->the_post();
        
        $product = wc_get_product(get_the_ID());
        
        if (!$product || !$product->is_visible()) continue;

        $thumbnail  = get_the_post_thumbnail_url(get_the_ID(), 'woocommerce_thumbnail');
        $thumbnail  = $thumbnail ? $thumbnail : wc_placeholder_img_src();
        
        $title      = get_the_title();
        $link       = get_permalink();
        $price_html = $product->get_price_html();
        ?>
        <li class="product-item">
            <a href="<?php echo esc_url($link); ?>" class="product-link">
                <div class="thumb">
                    <img src="<?php echo esc_url($thumbnail); ?>" alt="<?php echo esc_attr($title); ?>" width="60" height="60" loading="lazy">
                </div>
                <div class="content">
                    <span class="product-title"><?php echo esc_html($title); ?></span>
                    <?php if ($price_html): ?>
                        <span class="product-price"><?php echo wp_kses_post($price_html); ?></span>
                    <?php endif; ?>
                </div>
            </a>
        </li>
        <?php
    }

    wp_reset_postdata();

    wp_send_json_success([
        'template' => ob_get_clean(),
    ]);
}