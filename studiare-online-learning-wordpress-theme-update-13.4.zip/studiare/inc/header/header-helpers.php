<?php
defined('ABSPATH') || exit;

/**
 * Load header component with child-theme override support
 */
function studiare_header_component($component, $args = []) {
    $paths = [
        get_stylesheet_directory() . "/inc/header/components/{$component}.php",
        get_template_directory() . "/inc/header/components/{$component}.php",
    ];

    foreach ($paths as $path) {
        if (file_exists($path)) {
            // Apply filters to arguments before including the file
            $args = apply_filters("studiare_header_component_args_{$component}", $args);
            include $path;
            return;
        }
    }
}

/**
 * Auto-load all Header Hooks
 * This will include files like cart-offcanvas.php automatically
 */
function studiare_load_header_hooks() {
    $hooks_dir = get_template_directory() . '/inc/header/hooks/*.php';
    $files = glob($hooks_dir);
    
    if ($files) {
        foreach ($files as $file) {
            require_once $file;
        }
    }
}

// Execute the hook loader
studiare_load_header_hooks();