<?php
defined('ABSPATH') || exit;

// Use our custom header hook instead of wp_footer for better context
//add_action('studiare_after_header', function () {
add_action('wp_footer', function () {
    if (!function_exists('WC')) {
        return;
    }
    ?>
    <div class="sc-cart-offcanvas" aria-hidden="true">
        <div class="sc-cart-backdrop"></div>
        <div class="sc-cart-panel" role="dialog" aria-modal="true">
            <div class="sc-cart-header">
                <div class="h4 sc-cart-title"><?php esc_html_e('Your Cart', 'studiare'); ?></div>
                <button class="sc-cart-close" type="button"><i class="fal fa-times"></i></button>
            </div>

            <div class="sc-cart-body">
                <div class="widget woocommerce widget_shopping_cart">
                    <div class="widget_shopping_cart_content">
                        <?php 
                        // It's better to render mini-cart initially to avoid "empty" flashes
                        woocommerce_mini_cart(); 
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}, 10);