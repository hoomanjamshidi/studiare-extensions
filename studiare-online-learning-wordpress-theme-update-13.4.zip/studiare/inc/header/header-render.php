<?php
defined('ABSPATH') || exit;

/**
 * $header_data is provided by header-two.php
 */

$data = $header_data;
?>

<header class="site-header studi_header_two" itemscope itemtype="https://schema.org/WPHeader">
    <div class="container">
        <div class="site-header-inner">

            <div class="navigation-left">
                <?php
                studiare_header_component('logo', $data);
                 if (!empty($data['category_menu']['enabled'])) {
                    studiare_header_component('product-category-menu', $data);
                }
                
                ?>
            </div>

            <div class="navigation-right">

                <?php if (!empty($data['dark_mode']['enabled'])) {
                    studiare_header_component('dark-mode', $data);
                } ?>

                <?php if (!empty($data['notifications'])) {
                    studiare_header_component('notifications', $data);
                } ?>

                <?php if (!empty($data['search']['enabled'])) {
                    studiare_header_component('search', $data);
                } ?>

                <?php if (!empty($data['cart']['enabled'])) {
                    studiare_header_component('cart', $data);
                } ?>

                <?php if (!empty($data['account']['enabled'])) {
                    studiare_header_component('account', $data);
                } ?>

                <?php studiare_header_component('mobile-toggle'); ?>

            </div>
        </div>
        <?php if (!empty($data['search']['enabled'])) : ?>
            <?php studiare_header_component('search-wrapper', $data); ?>
        <?php endif; ?>
        <div class="navigation-buttom">
        
        <?php 
        studiare_header_component('navigation');
        ?>
        </div>
    </div>
    
</header>
