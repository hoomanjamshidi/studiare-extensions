<?php
/**
 * Header Account Component
 * Optimized for Studiare Clean Architecture
 */

defined('ABSPATH') || exit;

// 1. Check if we should show a dropdown or a simple link
if ( isset($args['account']['type']) && $args['account']['type'] === 'submenu' && is_user_logged_in() ) {
    studiare_header_component('account-dropdown', $args);
    return;
}

// 2. Extract Data from $args (Prepared in header-bootstrap.php)
$is_logged_in = $args['user']['is_logged_in'] ?? is_user_logged_in();
$account_url  = $args['account']['link_url']  ?? get_permalink(get_option('woocommerce_myaccount_page_id'));
$button_label = $args['account']['button_text'] ?? esc_html__('Login / Register', 'studiare');

// If logged in, maybe use display name
if ( $is_logged_in && !empty($args['user']['display_name']) && ($args['account']['show_name'] ?? false) ) {
    $button_label = $args['user']['display_name'];
}
?>

<div class="header-account-wrap">
    <a href="<?php echo esc_url($account_url); ?>" 
       class="register-modal-opener login-button sc-header-account btn btn-filled <?php echo $is_logged_in ? 'user-logged-in' : 'user-guest'; ?>"
       <?php echo !$is_logged_in ? 'data-toggle="modal" data-target="#login-modal"' : ''; // If you use login modals ?>>

        <span class="account-icon">
            <?php 
            if ( $is_logged_in && ($args['account']['show_avatar'] ?? false) && !empty($args['user']['avatar']) ) {
                echo $args['user']['avatar']; // Already contains <img> tag from bootstrap
            } else {
                echo '<i class="fal fa-user"></i>';
            }
            ?>
        </span>

        <?php if ( !empty($button_label) ) : ?>
            <span class="account-text"><?php echo esc_html($button_label); ?></span>
        <?php endif; ?>
        
    </a>
</div>