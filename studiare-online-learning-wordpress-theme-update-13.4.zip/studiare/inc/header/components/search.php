<?php
/**
 * Header Search Component
 * Supports both AJAX (FiboSearch) and Standard WordPress Search
 */

defined('ABSPATH') || exit;

// Use data passed from bootstrap
$search_data = $args['search'] ?? [];
$show_icon   = $search_data['show_icon'] ?? false;
$ajax_search = $search_data['ajax'] ?? false;
$placeholder = $search_data['placeholder'] ?? esc_html__('Search...', 'studiare');

?>

<div class="sc-search-container">
    
    <?php if ($show_icon) : ?>
        <!-- Search Toggle Icon -->
        <div class="top-bar-search top-bar-search-main-header">
            <a href="#" class="search-form-opener" aria-label="<?php esc_attr_e('Open Search', 'studiare'); ?>">
                <span class="search-icon">
                    <i class="fal fa-search"></i>
                </span>
                <span class="close-icon">
                    <i class="fal fa-times"></i>
                </span>
            </a>
        </div>
    <?php endif; ?>

</div>