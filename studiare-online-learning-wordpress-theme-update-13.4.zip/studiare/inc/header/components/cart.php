<?php
/**
 * Header Cart Component
 * Clean architecture version - compatible with hooks/cart-offcanvas.php
 */

defined('ABSPATH') || exit;

if (!function_exists('WC')) {
    return;
}
?>

<div class="top-bar-cart">
    <a href="<?php echo esc_url(wc_get_cart_url()); ?>" 
       class="mini-cart-opener sc-cart-toggle" 
       aria-label="<?php esc_attr_e('View cart', 'studiare'); ?>">
       
        <span class="bag-icon">
            <i class="fal fa-shopping-cart"></i>
        </span>

        <?php 
        // Logic for cart count bubble (usually returns <span class="count">...</span>)
        if (function_exists('studiare_cart_count')) {
            studiare_cart_count();
        } 
        ?>
    </a>
</div>