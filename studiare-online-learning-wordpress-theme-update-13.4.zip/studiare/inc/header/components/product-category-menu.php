<?php
defined('ABSPATH') || exit;

/**
 * Product Category Menu Component
 * Renders the category dropdown using data passed from header bootstrapper
 *
 * Expected $args structure (passed via studiare_header_component):
 * $args = $data  // usually the full $data array
 */

// ── Extract category menu settings from $data ───────────────────────────────
$cat_settings = !empty($args['category_menu']) ? $args['category_menu'] : [];

$enabled         = !empty($cat_settings['enabled']);
$cat_number      = isset($cat_settings['number'])     ? (int) $cat_settings['number']     : 0;
$hide_empty      = isset($cat_settings['hide_empty']) ? (bool) $cat_settings['hide_empty'] : false;
$orderby         = isset($cat_settings['orderby'])    ? $cat_settings['orderby']           : 'menu_order';
$order           = isset($cat_settings['order'])      ? $cat_settings['order']             : 'ASC';
$show_all_links  = isset($cat_settings['show_all_links']) ? (bool) $cat_settings['show_all_links'] : true;
$show_icons      = isset($cat_settings['show_icons']) ? (bool) $cat_settings['show_icons'] : true;
$icon_size       = isset($cat_settings['icon_size'])  ? (int) $cat_settings['icon_size']   : 25;

// Early exit if not enabled or no valid data
if (!$enabled) {
    return;
}

// Validate orderby to prevent injection or invalid values
$valid_orderby = ['menu_order', 'name', 'slug', 'count', 'rand'];
$orderby = in_array($orderby, $valid_orderby) ? $orderby : 'menu_order';

// Random order doesn't need ASC/DESC
if ($orderby === 'rand') {
    $order = 'ASC';
}

// ── Build WP query args ──────────────────────────────────────────────────────
$query_args = [
    'taxonomy'   => 'product_cat',
    'orderby'    => $orderby,
    'order'      => $order,
    'hide_empty' => $hide_empty,
    'number'     => ($cat_number > 0) ? $cat_number : '',
];

// Fetch top-level (parent) categories
$parent_cats = get_categories(array_merge($query_args, ['parent' => 0]));

if (empty($parent_cats)) {
    return;
}
?>

<div class="header-category-menu header-product-category-menu">
    <a href="#" class="header-icon category-menu-toggle">
        <span class="category-toggle-icon">
            <!-- Default dots SVG – you can later make this configurable via $data too -->
            <svg width="18px" height="18px" viewBox="0 0 18 18" version="1.1" xmlns="http://www.w3.org/2000/svg">
                <g stroke="none" stroke-width="1" fill="currentcolor" fill-rule="evenodd">
                    <path d="M2,14 C3.1045695,14 4,14.8954305 4,16 C4,17.1045695 3.1045695,18 2,18 C0.8954305,18 0,17.1045695 0,16 C0,14.8954305 0.8954305,14 2,14 Z M9,14 C10.1045695,14 11,14.8954305 11,16 C11,17.1045695 10.1045695,18 9,18 C7.8954305,18 7,17.1045695 7,16 C7,14.8954305 7.8954305,14 9,14 Z M16,14 C17.1045695,14 18,14.8954305 18,16 C18,17.1045695 17.1045695,18 16,18 C14.8954305,18 14,17.1045695 14,16 C14,14.8954305 14.8954305,14 16,14 Z M2,7 C3.1045695,7 4,7.8954305 4,9 C4,10.1045695 3.1045695,11 2,11 C0.8954305,11 0,10.1045695 0,9 C0,7.8954305 0.8954305,7 2,7 Z M9,7 C10.1045695,7 11,7.8954305 11,9 C11,10.1045695 10.1045695,11 9,11 C7.8954305,11 7,10.1045695 7,9 C7,7.8954305 7.8954305,7 9,7 Z M16,7 C17.1045695,7 18,7.8954305 18,9 C18,10.1045695 17.1045695,11 16,11 C14.8954305,11 14,10.1045695 14,9 C14,7.8954305 14.8954305,7 16,7 Z M2,0 C3.1045695,0 4,0.8954305 4,2 C4,3.1045695 3.1045695,4 2,4 C0.8954305,4 0,3.1045695 0,2 C0,0.8954305 0.8954305,0 2,0 Z M9,0 C10.1045695,0 11,0.8954305 11,2 C11,3.1045695 10.1045695,4 9,4 C7.8954305,4 7,3.1045695 7,2 C7,0.8954305 7.8954305,0 9,0 Z M16,0 C17.1045695,0 18,0.8954305 18,2 C18,3.1045695 17.1045695,4 16,4 C14.8954305,4 14,3.1045695 14,2 C14,0.8954305 14.8954305,0 16,0 Z"></path>
                </g>
            </svg>
        </span>
        <span class="category-toggle-text"><?php esc_html_e('Categories', 'studiare'); ?></span>
    </a>

    <nav class="header-category-dropdown-wrap">
        <ul class="header-category-dropdown">
            <?php foreach ($parent_cats as $parent):
                $cat_color = get_term_meta($parent->term_id, 'category_color', true);
                $children  = get_categories(array_merge($query_args, ['parent' => $parent->term_id]));
                $has_children = !empty($children);
            ?>
            <li class="cat-item <?php echo $has_children ? 'has-children' : ''; ?>"
                style="<?php echo $cat_color ? '--cat-hover-color:' . esc_attr($cat_color) . ';' : ''; ?>">

                <a href="<?php echo esc_url(get_term_link($parent)); ?>">
                    <span class="cat-title-wrap">
                        <?php if ($show_icons):
                            $icon_id = (int) get_term_meta($parent->term_id, 'sc_studi_cat_icon', true);
                            if ($icon_id > 0) {
                                echo wp_get_attachment_image(
                                    $icon_id,
                                    [$icon_size, $icon_size],
                                    false,
                                    [
                                        'class'   => 'cat-icon',
                                        'loading' => 'lazy',
                                        'alt'     => esc_attr(sprintf(__('%s category', 'studiare'), $parent->name))
                                    ]
                                );
                            }
                        endif; ?>
                        <span class="cat-name"><?php echo esc_html($parent->name); ?></span>
                    </span>
                    <?php if ($has_children): ?>
                        <span class="toggle-sub-menu"></span>
                    <?php endif; ?>
                </a>

                <?php if ($has_children): ?>
                <ul class="children sub-categories">
                    <?php if ($show_all_links): ?>
                    <li class="cat-item all-category">
                        <a href="<?php echo esc_url(get_term_link($parent)); ?>">
                            <?php printf(esc_html__('All %s', 'studiare'), esc_html($parent->name)); ?>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php foreach ($children as $child):
                        $has_products  = $child->count > 0;
                        $child_icon_id = (int) get_term_meta($child->term_id, 'sc_studi_cat_icon', true);
                    ?>
                    <li class="cat-item <?php echo $has_products ? 'has-products' : ''; ?>"
                        <?php if ($has_products) echo 'data-sub-id="' . esc_attr($child->term_id) . '"'; ?>>

                        <a href="<?php echo esc_url(get_term_link($child)); ?>">
                            <span class="cat-title-wrap">
                                <?php if ($show_icons && $child_icon_id > 0):
                                    echo wp_get_attachment_image(
                                        $child_icon_id,
                                        [$icon_size, $icon_size],
                                        false,
                                        [
                                            'class'   => 'cat-icon',
                                            'loading' => 'lazy',
                                            'alt'     => esc_attr(sprintf(__('%s category', 'studiare'), $child->name))
                                        ]
                                    );
                                endif; ?>
                                <span class="cat-name"><?php echo esc_html($child->name); ?></span>
                            </span>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </nav>
</div>