<?php
defined('ABSPATH') || exit;

if (!class_exists('WooCommerce') || is_account_page()) {
    return;
}
?>

<div class="sc-header-notifications">
    <?php echo do_shortcode('[studi_notifi]'); ?>
</div>
