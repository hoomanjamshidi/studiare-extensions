<?php
/**
 * Account Dropdown Component
 * Clean Markup - No Inline Styles
 */

defined('ABSPATH') || exit;

$menu_id = $args['account']['submenu'] ?? '';
$user_name = !empty($args['user']['display_name']) ? $args['user']['display_name'] : esc_html__('User', 'studiare');
?>

<div class="sc-account-dropdown-container studi_rl_with_sub" data-dropdown>
    
    <button class="sc-account-trigger login-button btn btn-filled" 
            aria-expanded="false" 
            aria-haspopup="true"
            type="button">
        
        <span class="account-avatar-wrap">
            <?php if ($args['account']['show_avatar'] && !empty($args['user']['avatar'])) : ?>
                <?php echo $args['user']['avatar']; ?>
            <?php else : ?>
                <i class="fal fa-user"></i>
            <?php endif; ?>
        </span>

        <?php if ($args['account']['show_name']) : ?>
            <span class="user-name"><?php echo esc_html($user_name); ?></span>
        <?php endif; ?>
    </button>

    <nav class="sc-account-menu-wrapper studi_rl_sub" role="menu">
        <div class="sc-menu-inner-box">
            <?php
            if ($menu_id) {
                wp_nav_menu([
                    'menu'            => $menu_id,
                    'container'       => false,
                    'echo'            => true,
                    'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                    'fallback_cb'     => false,
                    'walker'          => class_exists('sc_studiFrontendWalker') ? new sc_studiFrontendWalker() : '',
                ]);
            }
            ?>
        </div>
    </nav>
</div>