<?php
defined('ABSPATH') || exit;
?>

<div class="sc-header-darkmode">
    <button class="sc-dark-toggle" aria-label="Toggle dark mode" aria-pressed="false">
        <span class="icon-light"><i class="fal fa-sun"></i></span>
        <span class="icon-dark"><i class="fal fa-moon"></i></span>
    </button>
</div>
