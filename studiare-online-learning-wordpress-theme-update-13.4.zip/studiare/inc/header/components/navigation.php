<?php
defined('ABSPATH') || exit;

$menu = wp_nav_menu([
    'theme_location'  => 'main-menu',
    'menu_class'      	=> 'menu sc_studi-horizontal-menu main-navigation',
    'container_class'	=> 'sc_studi-main-menu visible-lg',
    'fallback_cb' 		=> 'sc_studiFrontendWalker::fallback',
    'walker' 			=> new sc_studiFrontendWalker(),
    'echo'            => false
]);
?>

<?php if ($menu) : ?>
<div class="site-navigation studiare-navigation" role="navigation">
    <?php echo wp_kses_post($menu); ?>
    </div>
<?php endif; ?>
