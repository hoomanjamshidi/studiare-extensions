<?php
defined('ABSPATH') || exit;
?>

<button class="mobile-nav-toggle"
        aria-label="<?php esc_attr_e('Open menu', 'studiare'); ?>"
        aria-controls="site-navigation"
        aria-expanded="false">
    <span class="the-icon"></span>
</button>
