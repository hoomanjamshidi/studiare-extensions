<?php
defined('ABSPATH') || exit;
?>
<div class="site-logo">
    <div class="studiare-logo-wrap" itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
        <a href="<?php echo esc_url(home_url('/')); ?>" rel="home" itemprop="url">
            <img
                src="<?php echo esc_url($args['logo']); ?>"
                alt="<?php echo esc_attr(get_bloginfo('name')); ?>"
                width="160"
                height="40"
                loading="eager"
                itemprop="logo"
            >
        </a>
    </div>
</div>