<?php
/**
 * Search Wrapper Component
 * Renders the actual search form surface
 */

defined('ABSPATH') || exit;

$search_data = $args['search'] ?? [];
if (empty($search_data['enabled']) && empty($search_data['show_icon'])) return;

$ajax_search = $search_data['ajax'] ?? false;
$placeholder = $search_data['placeholder'] ?? '';
?>

<div class="site-search-wrapper <?php echo $ajax_search ? 'sc-ajax-search' : ''; ?>">
    <div class="container">
        <?php if ($ajax_search && shortcode_exists('wcas-search-form')) : ?>
            
            <?php echo do_shortcode('[wcas-search-form]'); ?>
            
        <?php else : ?>
            
            <form method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
                <input type="search" 
                       class="search-input" 
                       placeholder="<?php echo esc_attr($placeholder); ?>" 
                       value="<?php echo esc_attr(get_search_query()); ?>" 
                       name="s">
                <button type="submit" class="submit">
                    <i class="fal fa-search"></i>
                </button>
            </form>
            
        <?php endif; ?>
    </div>
</div>