<?php
/**
 * Header Data Bootstrapper
 * Refactored for High Performance and Modular Architecture
 */

defined('ABSPATH') || exit;

// Initialize base structure
$data = [
    'logo' => get_theme_file_uri('assets/images/logo_default.svg'),
    'category_menu' => [
        'enabled' => false,
    ],
    'user' => [
        'is_logged_in' => is_user_logged_in(),
        'display_name' => '',
        'avatar'       => '',
        'id'           => get_current_user_id(),
    ],
    'account' => [
        'enabled'        => false,
        'type'           => 'link', // link or submenu
        'submenu'        => '',
        'show_avatar'    => false,
        'show_name'      => false,
        'link_url'       => '#',
        'button_text'    => '',
        'mobile_display' => 'show_icon_and_text',
    ],
    'dark_mode' => [
        'enabled' => false,
    ],
    'search' => [
        'enabled'     => false,
        'show_icon'   => false,
        'ajax'        => false,
        'placeholder' => esc_html__('Search for courses, products, teachers, posts and ...', 'studiare'),
    ],
    'cart' => [
        'enabled' => false,
    ],
    'notifications' => [
        'enabled' => false,
    ],
];

if (class_exists('Redux')) {

    // 1. Logo Handling
    $logo_uploaded = codebean_option('custom_logo_image');
    if (!empty($logo_uploaded['url'])) {
        $data['logo'] = esc_url($logo_uploaded['url']);
    }
    
    $data['category_menu'] = array(
        'enabled'         => (bool) codebean_option('show_category_menu_in_header'),
        'number'          => (int) codebean_option('header_cat_number', 0),
        'hide_empty'      => (bool) codebean_option('header_cat_hide_empty', false),
        'orderby'         => codebean_option('header_cat_orderby', 'menu_order'),
        'order'           => codebean_option('header_cat_order', 'ASC'),
        'show_all_links'  => (bool) codebean_option('header_cat_show_all_link', true),
        'show_icons'      => (bool) codebean_option('header_cat_show_icons', true),
        'icon_size'       => (int) codebean_option('header_cat_icon_size', 25),
    );
    
    // 2. Account & Header Button Logic
    $data['account']['enabled']        = (bool) codebean_option('header_button');
    $data['account']['type']           = codebean_option('header_button_type') ?: 'link';
    $data['account']['submenu']        = codebean_option('hb_submenu');
    $data['account']['show_avatar']    = (int) codebean_option('show_avatar') === 1;
    $data['account']['show_name']      = (int) codebean_option('show_display_name') === 1;
    $data['account']['mobile_display'] = codebean_option('header_button_link_show_on_mobile') ?: 'show_icon_and_text';

    // Set Dynamic Button Text & Links
    $btn_link_type = codebean_option('header_button_link');
    if ($data['user']['is_logged_in']) {
        $data['account']['button_text'] = codebean_option('header_button_custom_text_1') ?: esc_html__('Dashboard', 'studiare');
        $data['account']['link_url']    = get_permalink(get_option('woocommerce_myaccount_page_id'));
        
        if ($btn_link_type === 'custom') {
            $data['account']['link_url']    = esc_url(codebean_option('header_button_custom_link'));
            $data['account']['button_text'] = codebean_option('header_button_custom_text_2') ?: $data['account']['button_text'];
        }
    } else {
        $data['account']['button_text'] = codebean_option('header_button_custom_text_0') ?: esc_html__('Login / Register', 'studiare');
        $data['account']['link_url']    = ($btn_link_type === 'custom') ? esc_url(codebean_option('header_button_custom_link')) : '#';
    }

    // 3. Dark Mode Logic
    $data['dark_mode']['enabled'] = codebean_option('sc_darkmode_ready') && codebean_option('show_darkmode_icon_in_header');

    // 4. Search Logic
    $data['search']['enabled']     = (bool) codebean_option('topbar_search');
    $data['search']['show_icon']   = (bool) codebean_option('show_search_icon_in_header');
    $data['search']['ajax']        = (int) codebean_option('topbar_search_ajax') === 1;
    $placeholder_text              = codebean_option('search_placeholder_text');
    if (!empty($placeholder_text)) {
        $data['search']['placeholder'] = esc_attr($placeholder_text);
    }

    // 5. Notifications Logic
    $data['notifications']['enabled'] = (int) codebean_option('show_notif_icon_in_header') === 1;
}

// 6. User Data Processing
if ($data['user']['is_logged_in']) {
    $current_user = wp_get_current_user();
    $data['user']['display_name'] = $current_user->display_name;
    
    if (function_exists('sc_get_profile_img')) {
        $data['user']['avatar'] = sc_get_profile_img($data['user']['id'], 32);
    } else {
        $data['user']['avatar'] = get_avatar($data['user']['id'], 32);
    }
}

// 7. Cart Contextual Visibility (Mobile vs Desktop)
if ( function_exists( 'WC' ) ) {

    $is_mobile = wp_is_mobile(); // Use WordPress native mobile detection

    $show_on_mobile  = codebean_option( 'show_shopping_icon_in_header_mobile' );
    $show_on_desktop = codebean_option( 'show_shopping_icon_in_header' );

    $data['cart']['enabled'] = $is_mobile ? $show_on_mobile : $show_on_desktop;
}


/**
 * Filter the final data array to allow easy modifications via functions.php
 */
return apply_filters('studiare_header_data', $data);