
/**
document.addEventListener("click", function (e) {
    const dropdown = e.target.closest("[data-dropdown]");

    document.querySelectorAll("[data-dropdown]").forEach(el => {
        if (el !== dropdown) {
            const btn = el.querySelector("button");
            if (btn) btn.setAttribute("aria-expanded", "false");
            el.classList.remove("active");
        }
    });

    if (!dropdown) return;

    e.preventDefault();
    const btn = dropdown.querySelector("button");
    if (!btn) return;
    const expanded = btn.getAttribute("aria-expanded") === "true";
    btn.setAttribute("aria-expanded", !expanded);
    dropdown.classList.toggle("active");
});
**/
(function ($) {
    'use strict';

    const RENDERED = 'rendered';

    function productSkeleton() {
        let html = '';
        for (let i = 0; i < 4; i++) {
            html += `
                <li class="product-item skeleton">
                    <div class="thumb"></div>
                    <div class="content">
                        <span class="product-title"></span>
                        <span class="product-price"></span>
                    </div>
                </li>
            `;
        }
        return html;
    }

    function initHeaderCategoryMenu() {
        const $menu = $('.header-product-category-menu');

        $menu.on('mouseenter', '.sub-categories > li.has-products', function () {
            const $item = $(this);
            const subId = $item.data('sub-id');

            if ($item.hasClass(RENDERED) || !subId) return;

            $item.addClass(RENDERED);
            $item.addClass('loading');

            // Create Level 3 container dynamically
            const $productList = $('<ul/>', {
                class: 'children product-list skeleton-wrapper' // <-- new class for always visible skeleton
            });

            $productList.html(productSkeleton());
            $item.append($productList);

            $.ajax({
                url: studiare_ajax.ajaxurl,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'studiare_actions',
                    nonce: studiare_ajax.nonce,
                    type: 'get_products_by_cat',
                    cat_id: subId
                },
                success: function (res) {
                    $item.removeClass('loading');
                    if (res.success && res.data.template && res.data.template.trim() !== '') {
                        $productList.removeClass('skeleton-wrapper'); // remove always visible class
                        $productList.html(res.data.template);
                    } else {
                        $productList.remove();
                        $item.removeClass(RENDERED);
                    }
                },
                error: function () {
                    $item.removeClass('loading');
                    $productList.remove();
                    $item.removeClass(RENDERED);
                }
            });
        });
    }

    $(document).ready(initHeaderCategoryMenu);

})(jQuery);
window.menuToggle = function (event, submenuId) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }

    let dropdown = null;

    if (submenuId) {
        const submenu = document.getElementById(submenuId);

        if (!submenu) {
            return false;
        }

        dropdown = submenu.closest('.studi_rl_with_sub');
    } else if (event && event.currentTarget) {
        dropdown = event.currentTarget.closest('.studi_rl_with_sub');
    }

    if (!dropdown) {
        return false;
    }

    const isActive = dropdown.classList.contains('active');

    document.querySelectorAll('.studi_rl_with_sub.active').forEach(function (item) {
        if (item !== dropdown) {
            item.classList.remove('active');

            const trigger = item.querySelector('.sc-account-trigger, .login-button, .dropdown-toggle');
            if (trigger) {
                trigger.setAttribute('aria-expanded', 'false');
            }
        }
    });

    dropdown.classList.toggle('active', !isActive);

    const currentTrigger = event && event.currentTarget
        ? event.currentTarget
        : dropdown.querySelector('.sc-account-trigger, .login-button, .dropdown-toggle');

    if (currentTrigger) {
        currentTrigger.setAttribute('aria-expanded', isActive ? 'false' : 'true');
    }

    return false;
};

document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.studi_rl_with_sub').forEach(function (dropdown) {
        const trigger = dropdown.querySelector('.sc-account-trigger, .login-button, .dropdown-toggle');

        if (!trigger) {
            return;
        }

        if (!trigger.hasAttribute('aria-expanded')) {
            trigger.setAttribute('aria-expanded', 'false');
        }

        trigger.addEventListener('click', function (event) {
            if (trigger.hasAttribute('onclick')) {
                return;
            }

            window.menuToggle(event);
        });
    });

    document.addEventListener('click', function () {
        document.querySelectorAll('.studi_rl_with_sub.active').forEach(function (dropdown) {
            dropdown.classList.remove('active');

            const trigger = dropdown.querySelector('.sc-account-trigger, .login-button, .dropdown-toggle');
            if (trigger) {
                trigger.setAttribute('aria-expanded', 'false');
            }
        });
    });
});
