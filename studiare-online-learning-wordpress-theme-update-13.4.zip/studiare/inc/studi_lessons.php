<?php
/**
 * Studiare - Step 1: Cache all quiz results for current user
 */

if (!defined('ABSPATH')) exit;

/**
 * Get all quiz results for current user in ONE query
 * Cached per page load - super fast
 */
function studi_get_user_all_quiz_results() {
    $user_id = get_current_user_id();
    if (!$user_id) {
        return [];
    }

    // Use transient for this page request (fast & safe)
    $cache_key = "studi_user_quiz_results_{$user_id}";
    $results   = wp_cache_get($cache_key, 'studiare_quiz');

    if ($results !== false) {
        return $results; // Already loaded
    }

    global $wpdb;
    $table   = $wpdb->prefix . 'studiare_quiz_results';
    $sql     = $wpdb->prepare("SELECT quiz_id, details FROM {$table} WHERE user_id = %d", $user_id);
    $rows    = $wpdb->get_results($sql, ARRAY_A);

    $results = [];
    foreach ($rows as $row) {
        $details = maybe_unserialize($row['details']);
        $details = is_array($details) ? $details : [];
        $status  = $details['status'] ?? 'unknown';
        $results[$row['quiz_id']] = $status;
    }

    // Cache for this page load (60 seconds max)
    wp_cache_set($cache_key, $results, 'studiare_quiz', 60);

    return $results;
}

/**
 * Fast check: has user passed this quiz?
 * Replaces direct DB query
 */
function studi_has_user_passed_quiz($quiz_id) {
    static $all_results = null;
    if ($all_results === null) {
        $all_results = studi_get_user_all_quiz_results();
    }
    return ($all_results[$quiz_id] ?? 'unknown') === 'passed';
}

/**
 * Fast get: quiz status (passed/failed/pending)
 * Replaces direct DB query
 */
function studi_get_user_quiz_status($quiz_id) {
    static $all_results = null;
    if ($all_results === null) {
        $all_results = studi_get_user_all_quiz_results();
    }
    return $all_results[$quiz_id] ?? 'pending';
}
/**
 * Get user's LAST purchase timestamp for a specific product - CACHED per page load
 * This replaces the heavy repeated wc_get_orders() calls
 */
function studi_get_user_last_purchase_time_cached( $user_id, $product_id ) {

    if ( empty( $user_id ) || empty( $product_id ) ) {
        return false;
    }

    $cache_key = "studi_purchase_ts_{$user_id}_{$product_id}";
    $cached    = wp_cache_get( $cache_key, 'studiare_purchase' );

    if ( $cached !== false ) {
        return $cached;
    }

    $purchase_ts = false;

    if ( function_exists( 'wc_get_orders' ) ) {

        // Get recent completed/processing orders only
        $orders = wc_get_orders( array(
            'customer_id' => $user_id,
            'limit'       => 10, // enough for recent check
            'orderby'     => 'date_created',
            'order'       => 'DESC',
            'status'      => array( 'completed', 'processing' ),
        ) );

        foreach ( $orders as $order ) {

            foreach ( $order->get_items() as $item ) {

                $item_product_id   = $item->get_product_id();
                $item_variation_id = $item->get_variation_id();

                if ( in_array( $product_id, array( $item_product_id, $item_variation_id ), true ) ) {

                    $date = $order->get_date_created();
                    if ( $date ) {
                        $purchase_ts = $date->getTimestamp();
                        break 2; // Exit both loops
                    }
                }
            }
        }
    }

    wp_cache_set( $cache_key, $purchase_ts, 'studiare_purchase', 60 );

    return $purchase_ts;
}
// --- Helpers: truthy normalizer (handles 'on', '1', 1, true, 'yes') ---
if (!function_exists('studiare_truthy')) {
  function studiare_truthy($v) {
    return in_array($v, array('on', '1', 1, true, 'yes', 'true'), true);
  }
}

// --- Remove this if you still have the old add_filter('the_content', ...) ---
// We no longer inject lessons into content; we print via hook outside the content.
// remove_filter('the_content', 'add_shortcode_to_end_of_content'); // <- ensure removed if exists

// --- Keep the outside-content hook (prints when NOT using tabs) ---
add_action('studiare_after_product_content_holder', function () {
  // Only for single product main query
  if (!is_singular('product') || !is_main_query()) return;

  $post_id = get_the_ID();
  if (!$post_id) return;

  $prefix = '_studiare_';
  $view_lessons_end_of_content = get_post_meta($post_id, $prefix . 'view_lessons_end_of_content', true);

  // If per-product toggle is off, bail
  if (!studiare_truthy($view_lessons_end_of_content)) return;

  // If global setting says "display in tabs", DO NOT print here
  $lessons_display_in_tab = function_exists('codebean_option') ? codebean_option('sc_lessons_display_in_tab') : false;
  if (studiare_truthy($lessons_display_in_tab)) return;

  echo '<div class="studi-lessons-after-content mb-30" aria-label="' . esc_attr__('Lessons', 'studiare') . '">';
  echo do_shortcode('[sc_get_lessons_for_product]');
  echo '</div>';
}, 10);

// --- Robust WooCommerce Tabs injection ---
function studiare_add_lessons_tab_to_woocommerce_tabs($tabs) {
  // Get product ID safely (works even if global $post is not set properly)
  $product_id = 0;

  if (function_exists('wc_get_product')) {
    $product_obj = wc_get_product();
    if ($product_obj) $product_id = $product_obj->get_id();
  }

  if (!$product_id) {
    // Fallback to get_the_ID() for themes loading tabs inside the main product loop
    $product_id = get_the_ID();
  }

  if (!$product_id) {
    // If we still don't have an ID, do not modify tabs
    return $tabs;
  }

  // Per-product toggle must be ON
  $prefix = '_studiare_';
  $view_lessons_end_of_content = get_post_meta($product_id, $prefix . 'view_lessons_end_of_content', true);
  if (!studiare_truthy($view_lessons_end_of_content)) {
    return $tabs;
  }

  // Global: show lessons in a tab?
  $lessons_display_in_tab = function_exists('codebean_option') ? codebean_option('sc_lessons_display_in_tab') : false;
  if (!studiare_truthy($lessons_display_in_tab)) {
    // If not in tabs mode, leave it for the outside-content hook
    return $tabs;
  }

  // Add/override lessons tab
  $tabs['lessons_tab'] = array(
    'title'    => esc_html__('Lessons', 'studiare'),
    'priority' => 10, // adjust if you want it earlier/later than Description/Reviews
    'callback' => 'studiare_render_lessons_tab_content',
  );

  return $tabs;
}
// Priority set to 50 to run after most themes/plugins have built their tabs array
add_filter('woocommerce_product_tabs', 'studiare_add_lessons_tab_to_woocommerce_tabs', 50);

// --- Tab renderer ---
function studiare_render_lessons_tab_content() {
  echo do_shortcode('[sc_get_lessons_for_product]');
}


// Render the content of the lessons tab
function render_lessons_tab_content() {
    $shortcode = '[sc_get_lessons_for_product]';
    echo do_shortcode($shortcode);
}

// Register shortcode
add_shortcode("sc_get_lessons_for_product", "sc_get_lessons_for_product");

// Check if user has passed the required quizzes
/**
 * Check if user has passed ALL previous quizzes in the list
 * 100% backward compatible - same return values
 */
function has_passed_previous_quizzes( $user_id, $quiz_ids ) {
    if ( empty( $quiz_ids ) ) {
        return true;
    }

    if ( ! $user_id ) {
        return false;
    }

    // Load all quiz results once (cached)
    static $all_results = null;
    if ( $all_results === null ) {
        $all_results = studi_get_user_all_quiz_results();
    }

    foreach ( $quiz_ids as $quiz_id ) {
        $status = $all_results[ $quiz_id ] ?? 'pending';

        if ( $status !== 'passed' ) {
            return false;
        }
    }

    return true;
}

/**
 * Get title of the last failed (or not passed) quiz
 * Uses cached results - no extra queries
 */
function get_last_failed_quiz_title( $user_id, $quiz_ids ) {
    if ( ! $user_id || empty( $quiz_ids ) ) {
        return __( 'Previous Quiz', 'studiare' );
    }

    static $all_results = null;
    if ( $all_results === null ) {
        $all_results = studi_get_user_all_quiz_results();
    }

    foreach ( $quiz_ids as $quiz_id ) {
        $status = $all_results[ $quiz_id ] ?? 'pending';

        if ( $status !== 'passed' ) {
            $quiz_post = get_post( $quiz_id );
            return $quiz_post && ! is_wp_error( $quiz_post )
                ? $quiz_post->post_title
                : __( 'Previous Quiz', 'studiare' );
        }
    }

    return __( 'Previous Quiz', 'studiare' );
}

function render_lesson_media($lesson_video, $lesson_audio, $lesson_video_cover = '') {
    // === Add video cover support ===

    $poster_attr = '';

    // Load Redux default cover
    $enable_video_cover = false;
    $video_cover_image  = get_template_directory_uri() . '/assets/images/video-cover.webp';

    if (class_exists('Redux') && function_exists('codebean_option')) {
        $enable_video_cover = in_array(codebean_option('enable_video_cover'), ['1', 1, true], true);
        $video_cover_option = codebean_option('video_cover_image');
        if (!empty($video_cover_option['url'])) {
            $video_cover_image = esc_url($video_cover_option['url']);
        }
    }

    // If lesson has cover, use it
    if (!empty($lesson_video_cover)) {
        if (is_array($lesson_video_cover) && !empty($lesson_video_cover['url'])) {
            $poster_attr = " poster='" . esc_url($lesson_video_cover['url']) . "'";
        } elseif (is_string($lesson_video_cover)) {
            $poster_attr = " poster='" . esc_url($lesson_video_cover) . "'";
        }
    } elseif ($enable_video_cover) {
        $poster_attr = " poster='" . esc_url($video_cover_image) . "'";
    }

    $output = "<div class='sc_le_vi_au'>";
    $enable_suncode_player = false;
    if (class_exists('Redux') && function_exists('codebean_option')) {
        $enable_suncode_player = in_array(codebean_option('enable_suncode_player'), ['1', 1, true], true);
    }

    $controls_attr = '';
    if (!$enable_suncode_player) {
        $controls_attr = ' controls';
    }

    if (!empty($lesson_video)) {
        $video_type = str_ends_with($lesson_video, '.m3u8') ? 'application/x-mpegURL' : 'video/mp4';
        $unique_id = 'video_' . wp_generate_uuid4();
        $output .= "<br>";
        $output .= "<video class='studi_lesson_video scplayer scplayer--full-ui scplayer--video scplayer--html5' preload='none' style='width:100%'$poster_attr$controls_attr controlsList='nodownload' oncontextmenu='return false;' data-id='$unique_id'>";
        $output .= "<source src='" . esc_url($lesson_video) . "' type='" . esc_attr($video_type) . "'>";
        $output .= "</video>";
        $output .= "<br>";
    }

    if (!empty($lesson_audio)) {
        $unique_id = 'audio_' . wp_generate_uuid4();
        $output .= "<audio class='studi_lesson_audio scplayer scplayer--full-ui scplayer--audio scplayer--html5' preload='none' style='width:100%'$controls_attr controlsList='nodownload' oncontextmenu='return false;' data-id='$unique_id'>";
        $output .= "<source src='" . esc_url($lesson_audio) . "' type='audio/mpeg'>";
        $output .= "</audio>";
        $output .= "<br>";
    }

    $output .= "</div>";
    return $output;
}

function sc_get_lessons_for_product($post_id = null) {
    global $wpdb;
    ob_start();

    // Set post_id to current post if not provided
    if (empty($post_id)) {
        $post_id = get_the_ID();
    }

    // Validate post_id
    if (!is_numeric($post_id) || !$post_id) {
        return '<p>Error: Invalid post ID.</p>';
    }

    // Get lessons_group meta
    $lessons_group = get_post_meta($post_id, 'lessons_group', true);

    // Check if lessons_group is valid
    if (!is_array($lessons_group) || empty($lessons_group)) {
        return '<p>' . esc_html__('No lessons or quizzes found.', 'studiare') . '</p>';
    }

    // Load quiz settings
    $quiz_settings_override = get_post_meta($post_id, '_studiare_sc_quiz_settings_override', true) ?: 'default_from_theme_options';
    if ($quiz_settings_override === 'override') {
        $lock_lessons_based_on_quiz = get_post_meta($post_id, '_studiare_sc_lock_lessons_based_on_quiz', true) === 'on';
        $lock_scope = get_post_meta($post_id, '_studiare_sc_lock_lessons_scope', true) ?: 'all_items';
        $always_allow_first_item = get_post_meta($post_id, '_studiare_sc_always_allow_first_item', true) === 'on';
    } else {
        $lock_lessons_based_on_quiz = codebean_option('sc_lock_lessons_based_on_quiz') ?? false;
        $lock_scope = codebean_option('sc_lock_lessons_scope') ?? 'all_items';
        $always_allow_first_item = codebean_option('sc_always_allow_first_item') ?? true;
    }

    // Track quizzes and their positions
    $global_quiz_positions = [];
    $global_index = 0;

    
    // === Count sections, lessons, and quizzes ===
    $total_sections = count($lessons_group);
    $total_lessons = 0;
    $total_quizzes = 0;
    
    foreach ($lessons_group as $sec) {
        if (!empty($sec['lessons_list']) && is_array($sec['lessons_list'])) {
            foreach ($sec['lessons_list'] as $item_id) {
                if (!is_numeric($item_id)) continue;
                $post_type = get_post_type($item_id);
                if ($post_type === 'sc-quiz') {
                    $total_quizzes++;
                } else {
                    $total_lessons++;
                }
            }
        }
    }
    // === Display Notifications ===
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    $isbought = studi_has_bought_items($user_id, get_the_ID());
    if ($isbought) {
    do_action( 'studiare_show_notices', get_the_ID() ); 
    }
    echo '<div class="course-content-header flex items-center gap-3">';
    echo '<div class="sc_before_title_icon"><i class="fal fa-graduation-cap"></i></div>';
    echo '<h3 class="course-content-title">
    
    ' .esc_html__( 'Course Content', 'studiare' ). ' </h3>';
    // === Display summary before first section ===
   
    echo '</div><div class="course-summary">';
    echo '<div class="sc-course-curriculum-info">';
    if ($total_sections > 0) {
    echo '<li class="course-summary-item course-total-sections">' . sprintf(__('%d Section', 'studiare'), $total_sections) . '</li>';
    }
    if ($total_lessons > 0) {
    echo '<li class="course-summary-item course-total-lessons">' . sprintf(__('%d Lesson', 'studiare'), $total_lessons) . '</li>';
    }
    if ($total_quizzes > 0) {
    echo '<li class="course-summary-item course-total-quizzes">' . sprintf(__('%d Quiz', 'studiare'), $total_quizzes) . '</li>';
    }
    echo '</div><div class="sc-course-curriculum-info__right">
    <span class="sc-toggle-all-sections sc-open-all">' . esc_html__( 'Open all sections', 'studiare' ) . '</span>
    <span class="sc-toggle-all-sections sc-close-all lp-collapse sc-toggle-hidden">' . esc_html__( 'Close all sections', 'studiare' ) . '</span>
    </div></div>';
    // Collect all quiz positions
    foreach ($lessons_group as $section) {
        $lessons = isset($section['lessons_list']) ? $section['lessons_list'] : [];
        if (is_array($lessons) && !empty($lessons)) {
            foreach ($lessons as $lesson) {
                if (is_numeric($lesson) && ($post = get_post($lesson)) && get_post_type($lesson) === 'sc-quiz' && get_option('studiare_quiz_post_type_enabled', true)) {
                    $global_quiz_positions[] = $global_index;
                }
                $global_index++;
            }
        }
    }

    $global_index = 0; // Reset for rendering
    $global_previous_quiz_ids = [];

    foreach ($lessons_group as $section) {
        $title = isset($section['title']) ? $section['title'] : '';
        $list_open_situ = isset($section['list_open_situ']) ? $section['list_open_situ'] : null;
        $section_number = isset($section['section_number']) ? $section['section_number'] : '';
        $section_num_title = isset($section['section_num_title']) ? $section['section_num_title'] : '';
        $lessons = isset($section['lessons_list']) ? $section['lessons_list'] : [];

        $lesson_number = 1;
        $section_previous_quiz_ids = ($lock_scope === 'within_section') ? [] : $global_previous_quiz_ids;
        $section_index = 0;
        $section_has_quiz = false;

        $css_class = "course-section";
        
        $unique_id = !empty($section['sc_course_section_unique_id'])
            ? $section['sc_course_section_unique_id']
            : 'temp_' . wp_generate_password(8, false, false); // random but safe fallback id

        $openclass = ($list_open_situ == 'on') ? " active_tab_by_suncode" : " ";
        ?>
        <div class="<?php echo esc_attr($css_class); ?>" 
             data-open="<?php echo ($list_open_situ === 'on') ? esc_attr($unique_id) : ''; ?>">


            <?php if (!empty($title)) : ?>
                <div data-id="<?php echo esc_attr($unique_id); ?>" class="sc-course-lesson-toggle-wrapper">
                    <h5 class="course-section-title">
                        <?php if (!empty($section_num_title) || !empty($section_number)) { ?>
                            <span class="chapterholder">
                                <?php if (!empty($section_num_title)) : ?><span class="scchapturetitle"><?php echo esc_html($section_num_title); ?></span><?php endif; ?>
                                <?php if (!empty($section_number)) : ?><span class="scchapturenumber"><?php echo esc_html($section_number); ?></span><?php endif; ?>
                            </span>
                        <?php } ?>
                         <?php echo esc_html($title); ?>
                    </h5>
                    <div class="sc-course-lesson-toggle"><i class="fal fa-chevron-down"></i></div>
                </div>
            <?php endif; ?>
            <div class="panel-group" style="display:none;">
                <?php
                if (is_array($lessons) && !empty($lessons)) {
                    $current_user = wp_get_current_user();
                    $user_id = $current_user->ID;
                    $bought_course = false;

                    // Check if user has purchased the course
                    if (!empty($current_user->user_email) && !empty($user_id)) {
                        if (wc_customer_bought_product($current_user->user_email, $user_id, get_the_ID())) {
                            $bought_course = true;
                        }
                    }
                    $isbought = studi_has_bought_items($user_id, get_the_ID());
                    if ($isbought == "true") {
                        $bought_course = true;
                    }
                    
                    
                    // Check if user has an active subscription using Studiare_Subscription_Manager
                    $has_active_subscription = false;
                    if (class_exists('Studiare_Subscription_Manager') && $user_id) {
                        $subscriptions = Studiare_Subscription_Manager::get_user_subscriptions($user_id);
                        if (!empty($subscriptions)) {
                            $bought_course = true;
                            $has_active_subscription = true;
                        }
                    }

                    foreach ($lessons as $lesson) {
                        if (!is_numeric($lesson) || !($post = get_post($lesson))) {
                            $global_index++;
                            $section_index++;
                            continue;
                        }

                        $post_type = get_post_type($lesson);
                        if ($post_type === 'sc-quiz' && !get_option('studiare_quiz_post_type_enabled', true)) {
                            $global_index++;
                            $section_index++;
                            continue;
                        }

                        $is_first_quiz = false;
                        $is_current_quiz_blocking = false;
                        if ($post_type === 'sc-quiz') {
                            if (!$section_has_quiz && $lock_scope === 'within_section') {
                                $section_has_quiz = true;
                                $is_first_quiz = true;
                            }
                            $section_previous_quiz_ids[] = $lesson;
                            if ($lock_scope === 'all_items') {
                                $global_previous_quiz_ids[] = $lesson;
                            }

                            // Check if user failed this quiz
                            $is_current_quiz_blocking = $user_id && ! studi_has_user_passed_quiz( $lesson );
                        }

                        // Determine which quizzes block this item
                        $quiz_ids_to_check = [];
                        if ($lock_lessons_based_on_quiz) {
                            if ($lock_scope === 'within_section') {
                                $quiz_ids_to_check = $section_previous_quiz_ids;
                            } else {
                                foreach ($global_quiz_positions as $quiz_pos) {
                                    if ($quiz_pos < $global_index) {
                                        $quiz_ids_to_check = array_slice($global_previous_quiz_ids, 0, array_search($lesson, $global_previous_quiz_ids) ?: count($global_previous_quiz_ids));
                                    }
                                }
                            }
                        }

                        // Check if item is accessible
                        $is_access_blocked = false;
                        if ($lock_lessons_based_on_quiz) {
                            $is_access_blocked = !has_passed_previous_quizzes($user_id, $quiz_ids_to_check);
                        }

                        // Allow first item if configured
                        $is_first_item = false;
                        if ($always_allow_first_item) {
                            $is_first_item = ($lock_scope === 'within_section' ? $section_index === 0 : $global_index === 0);
                        }

                        // Allow first quiz and current blocking quiz
                        if ($is_first_quiz || $is_current_quiz_blocking) {
                            $is_access_blocked = false;
                        }

                        // Block access if needed
                        if ($lock_lessons_based_on_quiz && $is_access_blocked && !$is_first_item) {
                            $last_failed_quiz_title = get_last_failed_quiz_title($user_id, $quiz_ids_to_check);
                            ?>
                            <div class="course-lesson">
                                <div class="course-panel-heading">
                                    <div class="panel-heading-left">
                                        <div class="course-lesson-icon">
                                            <i class="fal fa-lock"></i>
                                        </div>
                                        <div class="title">
                                            <h4>
                                                <?php
                                                if ($post_type === 'sc-quiz') {
                                                    $quiz_title = !empty($post->post_title) ? $post->post_title : __('Quiz', 'studiare');
                                                    echo esc_html($quiz_title);
                                                    echo '<span class="badge-item quiz">' . __('Quiz', 'studiare') . '</span>';
                                                } else {
                                                    $item = get_post_meta($lesson, 'lesson_data', true);
                                                    $title = isset($item[0]['lesson_title']) ? $item[0]['lesson_title'] : null;
                                                    echo esc_html($title);
                                                }
                                                ?>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-content">
                                    <div class="panel-content-inner">
                                        <div class="lessonaccessdenied">
                                            <span class="icon"><i class="fas fa-exclamation-triangle"></i></span>
                                            <?php
                                            if (!$user_id) {
                                                $login_url = wp_login_url(get_permalink());
                                                printf(
                                                    esc_html__('You need to log in and pass the "%s" quiz to access this content.', 'studiare'),
                                                    esc_html($last_failed_quiz_title)
                                                );
                                            } else {
                                                printf(
                                                    esc_html__('You need to pass the "%s" quiz to access this content.', 'studiare'),
                                                    esc_html($last_failed_quiz_title)
                                                );
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                            $global_index++;
                            $section_index++;
                            continue;
                        }

                        if ($post_type === 'sc-quiz') {
                            $quiz_title = !empty($post->post_title) ? $post->post_title : __('Quiz', 'studiare');
                            $restrict_to_members = get_post_meta($lesson, '_quiz_restrict_to_members', true);
                            $restrict_to_products = get_post_meta($lesson, '_quiz_restrict_to_products', true);
                            $widget_description = get_post_meta($lesson, '_quiz_widget_description', true);
                            $current_product_id = get_the_ID();
                            $is_current_product_restricted = is_array($restrict_to_products) && in_array($current_product_id, $restrict_to_products);

                            // Get quiz status
                            $quiz_status = 'pending';
                            $quiz_status_class = 'pending';
                            $quiz_status       = studi_get_user_quiz_status( $lesson );
                            $quiz_status_class = ( $quiz_status === 'passed' ) ? 'passed' : 'failed';
                            ?>
                            <div class="course-lesson">
                                <div class="course-panel-heading scquiz">
                                    <div class="panel-heading-left">
                                        <div class="course-lesson-icon">
                                            <i class="fal fa-question-circle"></i>
                                        </div>
                                        <div class="title">
                                            <h4><?php echo esc_html($quiz_title); ?>
                                                <span class="badge-item quiz"><?php echo __('Quiz', 'studiare') ?></span>
                                                <?php if ($user_id && $quiz_status !== 'pending') : ?>
                                                    <span class="badge-item status-<?php echo esc_attr($quiz_status_class); ?>">
                                                        <?php
                                                        if ($quiz_status === 'passed') {
                                                            echo '<i class="fal fa-check-circle"></i> ' . __('Passed', 'studiare');
                                                        } else {
                                                            echo '<i class="fal fa-times-circle"></i> ' . __('Failed', 'studiare');
                                                        }
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                            </h4>
                                            <?php if (!empty($widget_description)) : ?>
                                                <p class="subtitle"><?php echo esc_html($widget_description); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="panel-heading-right">
                                        <?php if ($restrict_to_members === 'yes' && (!is_array($restrict_to_products) && empty($restrict_to_products)) ) : ?>
                                            <div class="private-lesson<?php echo is_user_logged_in() ? ' privateunlock' : ''; ?>"><svg xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="md:w-4"><path d="M9.99967 10.0703C12.3009 10.0703 14.1663 8.20485 14.1663 5.90367C14.1663 3.60248 12.3009 1.737 9.99967 1.737C7.69849 1.737 5.83301 3.60248 5.83301 5.90367C5.83301 8.20485 7.69849 10.0703 9.99967 10.0703Z" stroke="currentcolor" stroke-width="1.5px" stroke-linecap="round" stroke-linejoin="round" fill="none"></path><path d="M17.1585 18.4036C17.1585 15.1786 13.9501 12.5703 10.0001 12.5703C6.05013 12.5703 2.8418 15.1786 2.8418 18.4036" stroke="currentcolor" stroke-width="1.5px" stroke-linecap="round" stroke-linejoin="round" fill="none"></path></svg><span></span></div>
                                        <?php endif; ?>
                                        <?php if (is_array($restrict_to_products) && !empty($restrict_to_products)) : ?>
                                                <div class="private-lesson<?php echo $has_active_subscription || ($is_current_product_restricted && $bought_course) ? ' privateunlock' : '';echo $has_active_subscription ? ' hassubscriptions' : ''; ?>"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="titleId" class="mr-fds-12 grow-0 shrink-0 w-5 h-5 md:w-6 md:h-6 text-fds-icon-disable" aria-label="lock icon"><path d="M11.76 17.3128C11.5691 17.3128 11.3859 17.237 11.251 17.1019C11.1159 16.9669 11.04 16.7837 11.04 16.5928V14.5125C11.04 14.3215 11.1159 14.1384 11.251 14.0034C11.3859 13.8683 11.5691 13.7925 11.76 13.7925C11.951 13.7925 12.1342 13.8683 12.2691 14.0034C12.4042 14.1384 12.48 14.3215 12.48 14.5125V16.5928C12.48 16.7837 12.4042 16.9669 12.2691 17.1019C12.1342 17.237 11.951 17.3128 11.76 17.3128Z" fill="currentColor"></path><path d="M16.0299 10.7458C15.839 10.7458 15.6558 10.6699 15.5208 10.5349C15.3858 10.3999 15.3099 10.2167 15.3099 10.0258V8.00977C15.3048 7.54463 15.2073 7.08514 15.0235 6.65787C14.8395 6.23059 14.5728 5.84402 14.2386 5.52049C13.909 5.18924 13.5152 4.92894 13.0814 4.75559C12.6475 4.58224 12.1827 4.4995 11.7157 4.51248C10.7907 4.51945 9.90543 4.88881 9.24972 5.54125C8.59405 6.19368 8.22033 7.07719 8.2088 8.00209V10.0181C8.2088 10.209 8.13294 10.3922 7.99792 10.5272C7.86289 10.6622 7.67975 10.7381 7.4888 10.7381C7.29785 10.7381 7.11471 10.6622 6.97968 10.5272C6.84465 10.3922 6.7688 10.209 6.7688 10.0181V7.98673C6.7702 6.66277 7.29748 5.3936 8.23465 4.45841C9.17182 3.52321 10.4422 2.9986 11.7661 3C13.09 3.0014 14.3592 3.52868 15.2944 4.46586C16.2296 5.40304 16.7542 6.67333 16.7528 7.99729V10.0133C16.7545 10.1091 16.737 10.2043 16.7014 10.2933C16.6657 10.3823 16.6127 10.4633 16.5454 10.5315C16.4781 10.5997 16.3978 10.6538 16.3093 10.6907C16.2208 10.7274 16.1257 10.7461 16.0299 10.7458Z" fill="currentColor"></path><path d="M14.3517 21.8393H9.16779C8.08777 21.9564 6.99521 21.8352 5.96715 21.4841C5.23057 21.1289 4.63601 20.5346 4.28043 19.7983C3.93054 18.77 3.80964 17.6776 3.92618 16.5977V14.551C3.80946 13.4714 3.93037 12.3793 4.28043 11.3513C4.63577 10.6142 5.23079 10.0195 5.96811 9.66457C6.99586 9.31356 8.08809 9.19231 9.16779 9.30936H14.3517C15.4315 9.19248 16.5236 9.31372 17.5514 9.66457C18.2888 10.0197 18.8835 10.6148 19.2381 11.3522C19.5892 12.3796 19.7105 13.4715 19.5934 14.551V16.5948C19.7104 17.6748 19.5891 18.7674 19.2381 19.7954C18.8827 20.5322 18.2877 21.1267 17.5505 21.4812C16.5234 21.8331 15.4314 21.9554 14.3517 21.8393ZM9.16779 10.7494C8.30342 10.6616 7.43029 10.7339 6.5921 10.9625C6.14905 11.1752 5.79156 11.5324 5.57834 11.9753C5.35073 12.8137 5.27883 13.6867 5.36618 14.551V16.5948C5.27905 17.4598 5.35095 18.3334 5.57834 19.1724C5.79241 19.6138 6.1493 19.9701 6.59115 20.1833C7.42968 20.4118 8.30311 20.484 9.16779 20.3964H14.3517C15.2161 20.484 16.0892 20.4118 16.9275 20.1833C17.3698 19.9703 17.7268 19.6135 17.9403 19.1714C18.1688 18.3329 18.241 17.4595 18.1534 16.5948V14.5481C18.2411 13.6837 18.1689 12.8106 17.9403 11.9724C17.7275 11.5299 17.3707 11.1728 16.9285 10.9596C16.0899 10.7312 15.2165 10.659 14.3517 10.7465L9.16779 10.7494Z" fill="currentColor"></path></svg><span></span></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="panel-content scquiz">
                                    <div class="panel-content-inner">
                                        <?php
                                        if ($restrict_to_members === 'yes' && !is_user_logged_in()) {
                                            ?>
                                            <div class="lessonaccessdenied">
                                                <span class="icon"><i class="fas fa-user-lock"></i></span>
                                                <?php esc_html_e('This quiz is private. Please log in to access.', 'studiare'); ?>
                                            </div>
                                            <?php
                                        } elseif ($is_current_product_restricted && !$bought_course) {
                                            ?>
                                            <div class="lessonaccessdenied">
                                                <span class="icon"><i class="fas fa-exclamation-triangle"></i></span>
                                                <?php esc_html_e('This quiz is private, for full access to all lessons you need to buy this course.', 'studiare'); ?>
                                            </div>
                                            <?php
                                        } else {
                                            $quiz_shortcode_output = do_shortcode('[studiare_quiz pid="'.$current_product_id.'" id="' . esc_attr($lesson) . '"]');
                                            echo $quiz_shortcode_output ?: '<p>' . esc_html__('Quiz content not available.', 'studiare') . '</p>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        } 
                        else {
                            /* ---------------------------
                               Lesson item: availability + access
                               --------------------------- */
                            
                            // fetch lesson meta group
                            $item = get_post_meta($lesson, 'lesson_data', true);
                            if (!is_array($item) || empty($item)) {
                                $global_index++;
                                $section_index++;
                                continue;
                            }
                            // basic fields
                            $icon = isset($item[0]['icon']) ? $item[0]['icon'] : null;
                            $title = isset($item[0]['lesson_title']) ? $item[0]['lesson_title'] : null;
                            $subtitle = isset($item[0]['lesson_subtitle']) ? $item[0]['lesson_subtitle'] : null;
                            $badge = isset($item[0]['badge']) ? $item[0]['badge'] : null;
                            $preview_video = isset($item[0]['preview_video']) ? $item[0]['preview_video'] : '';
                            $private_lesson = isset($item[0]['private_lesson']) ? $item[0]['private_lesson'] : null;
                            if ($private_lesson === "on") {
                                $private_lesson = "lesson_protected";
                            }
                            $sc_pls = isset($item[0]['sc_pls']) ? $item[0]['sc_pls'] : null;
                            
                            $content_main = get_post_field('post_content', $lesson);
                            $content = wpautop($content_main);
                            
                            $atts['sc_download_file'] = isset($item[0]['sc_download_file']) ? $item[0]['sc_download_file'] : '';
                            $atts['sc_download_access'] = isset($item[0]['sc_download_access']) ? $item[0]['sc_download_access'] : '';
                            $atts['sc_file_type'] = isset($item[0]['sc_file_type']) ? $item[0]['sc_file_type'] : 'download';
                            $atts['sc_simple_link'] = isset($item[0]['sc_simple_link']) ? $item[0]['sc_simple_link'] : '';

                            
                            $lesson_video = isset($item[0]['lesson_video']) ? $item[0]['lesson_video'] : null;
                            $lesson_video_cover = isset($item[0]['lesson_video_cover']) ? $item[0]['lesson_video_cover'] : '';
                            $lesson_audio = isset($item[0]['lesson_audio']) ? $item[0]['lesson_audio'] : null;
                            
                            $lesson_number_auto = codebean_option('sc_lesson_number_auto') ?? false;
                            $login_toast_title = codebean_option('login_toast_title');
                            $login_toast_message = codebean_option('login_toast_message');
                            $bought_toast_title = codebean_option('bought_toast_title');
                            $bought_toast_message = codebean_option('bought_toast_message');
                            $private_placeholder = codebean_option('private_lesson_message');

                            /* ---------------------------
                               Availability: read settings
                               --------------------------- */
                            $available_date      = isset($item[0]['lesson_available_date']) ? trim($item[0]['lesson_available_date']) : '';
                            $available_after_days = isset($item[0]['lesson_available_after_days']) ? intval($item[0]['lesson_available_after_days']) : 0;
                            
                            // prepare vars
                            $lesson_is_locked = false;
                            $lesson_lock_message = '';
                            $now = current_time('timestamp');
                            
                            
                            /* ---------------------------
                               PRIORITY B: check privacy first
                               --------------------------- */
                            /*
                              If lesson is private and user doesn't have access (not buyer or not logged in),
                              show existing privacy messages (no time-based message).
                            */
                            
                            $show_private_message_only = false;
                            
                            // 'lesson_protected' requires buyer (or subscription)
                            if ( $private_lesson === 'lesson_protected' ) {
                                if ( empty( $bought_course ) ) {
                                    // user not buyer -> show private purchase message (existing behavior)
                                    $show_private_message_only = true;
                                }
                            }
                            
                            // 'lesson_free_users' requires login
                            if ( $private_lesson === 'lesson_free_users' ) {
                                if ( ! is_user_logged_in() ) {
                                    $show_private_message_only = true;
                                }
                            }
                            
                            /* ---------------------------
                               Build lock message or let through
                               --------------------------- */
                            
                            if ( $show_private_message_only ) {
                            
                                // We do not reveal any time-based availability if the user is blocked by privacy rules.
                                // The template below mirrors existing messages in your codebase.
                            
                                if ( $private_lesson === 'lesson_protected' ) {
                                    // purchase required message
                                    ob_start();
                                    ?>
                                    <div class="lessonaccessdenied">
                                        <span class="icon"><i class="fas fa-exclamation-triangle"></i></span>
                                        <?php
                                        if ( ! empty( $private_placeholder ) ) {
                                            echo wp_kses_post( $private_placeholder );
                                        } else {
                                            esc_html_e( 'This lesson is private, for full access to all lessons you need to buy this course.', 'studiare' );
                                        }
                                        ?>
                                    </div>
                                    <?php
                                    $lesson_lock_message = ob_get_clean();
                                } elseif ( $private_lesson === 'lesson_free_users' ) {
                                    ob_start();
                                    ?>
                                    <div class="lessonaccessdenied">
                                        <span class="icon"><i class="fas fa-user-lock"></i></span>
                                        <?php esc_html_e( 'This lesson is private. Please log in to access.', 'studiare' ); ?>
                                    </div>
                                    <?php
                                    $lesson_lock_message = ob_get_clean();
                                }
                            
                                $lesson_is_locked = true;
                            
                            } else {
                                // privacy does not block -> evaluate time-based availability
                            
                                $fixed_ts = false;
                                if ( ! empty( $available_date ) ) {
                                    $fixed_ts = strtotime( $available_date );
                                }
                            
                                $after_days_ts = false;
                                // compute purchase-based unlock time only if days configured AND user has bought the course (or has subscription)
                                if ( $available_after_days > 0 && ( ! empty( $bought_course ) || ! empty( $has_active_subscription ) ) && ! empty( $user_id ) ) {
                            
                                    $purchase_ts = studi_get_user_last_purchase_time_cached( $user_id, get_the_ID() );
                            
                                    if ( $purchase_ts !== false ) {
                                        $after_days_ts = strtotime( '+' . $available_after_days . ' days', $purchase_ts );
                                    }
                                }
                            
                                // Determine the actual unlock timestamp: maximum of the timestamps that exist
                                $unlock_ts_candidates = array();
                            
                                if ( $fixed_ts !== false ) {
                                    $unlock_ts_candidates[] = $fixed_ts;
                                }
                                if ( $after_days_ts !== false ) {
                                    $unlock_ts_candidates[] = $after_days_ts;
                                }
                            
                                if ( ! empty( $unlock_ts_candidates ) ) {
                                    $unlock_ts = max( $unlock_ts_candidates );
                            
                                    if ( $now < $unlock_ts ) {
                                        // lesson still locked by time
                                        $nice_date = date_i18n( 'j F Y - H:i', $unlock_ts );
                            
                                        // translatable single-string message
                                        $lesson_lock_message = sprintf(
                                            '<div class="lesson-locked-message" style="padding:15px; background:#fff5d1; border-radius:8px; margin-bottom:20px;">%s <strong>%s</strong> %s.</div>',
                                            esc_html__( 'This lesson from', 'studiare' ),
                                            esc_html( $nice_date ),
                                            esc_html__( 'will be available', 'studiare' )
                                        );
                            
                                        $lesson_is_locked = true;
                                    }
                                }
                            } // end privacy vs time
                            
                            /* ---------------------------
                               Render HTML (heading + panel)
                               --------------------------- */
                            ?>
                            
                            <div class="course-lesson">
                                <div class="course-panel-heading">
                                    <div class="panel-heading-left">
                                        <?php if ( $lesson_number_auto || ( ! empty( $icon ) && ! $lesson_number_auto ) ) { ?>
                                            <div class="course-lesson-icon">
                                                <?php
                                                if ( $lesson_number_auto ) {
                                                    echo '<span class="lesson-number">' . esc_html( $lesson_number ) . '</span>';
                                                } else {
                                                    $icon = substr_replace( $icon, " ", 3, -strlen( $icon ) );
                                                    echo "<i class='$icon'></i>";
                                                }
                                                ?>
                                            </div>
                                        <?php } ?>
                            
                                        <?php if ( ! empty( $preview_video ) || ! empty( $title ) || ! empty( $subtitle ) ) : ?>
                                            <div class="title">
                                                <div class="title-inner">
                                                    <h4>
                                                        <?php echo esc_html( $title ); ?>
                                                        <?php if ( ! empty( $badge ) && $badge != 'no_badge' ) : ?>
                                                            <span class="badge-item <?php echo esc_attr( $badge ); ?>"><?php echo esc_html( add_class_value_in_any_lang( $badge ) ); ?></span>
                                                        <?php endif; ?>
                                                    </h4>
                                                    <?php
                                                        if ( str_contains( $preview_video, ".aparat.com/v" ) ) {
                                                            $course_video_aparat = substr( $preview_video, strrpos( $preview_video, '/' ) + 1 );
                                                            $preview_video = studi_get_aparat_file_link( $course_video_aparat );
                                                        }
                                                    ?>
                                                    <?php if ( ! empty( $preview_video ) ) : ?>
                                                        <a class="video-lesson-preview preview-button" href="<?php echo esc_url( $preview_video ); ?>">
                                                            <i class="fal fa-play-circle"></i><?php esc_html_e( 'Preview', 'studiare' ); ?>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                                <?php if ( ! empty( $subtitle ) ) : ?>
                                                    <p class="subtitle"><?php echo esc_html( $subtitle ); ?></p>
                                                <?php endif; ?>
                                            </div>
                                            
                                        <?php endif; ?>
                                    </div>
                            
                                    <?php $lesson_number++; ?>
                            
                                    <?php if ( ! empty( $private_lesson ) || ! empty( $sc_pls ) ) : ?>
                                        
                                        <div class="panel-heading-right">
                                            
                            
                                            
                            
                                            <?php
                                            
                                            $sc_protect_link_status = ( $sc_pls === "on" ) ? 'true' : 'false';
                                            
                                            $has_download =
                                                (
                                                    !empty($atts['sc_download_file']) &&
                                                    $atts['sc_download_file'] !== 'none'
                                                )
                                                ||
                                                (
                                                    isset($atts['sc_file_type']) &&
                                                    $atts['sc_file_type'] === 'external' &&
                                                    !empty($atts['sc_simple_link'])
                                                );
                                            
                                            if ( $has_download ) {
                                            
                                                echo generate_dl_section(
                                                    $atts,
                                                    get_the_ID(),// product id
                                                    $lesson,// lesson id
                                                    $private_lesson,
                                                    $bought_course,
                                                    $login_toast_title,
                                                    $login_toast_message,
                                                    $bought_toast_title,
                                                    $bought_toast_message,
                                                    $sc_protect_link_status
                                                );
                                            
                                            }
                                            ?>
                                            
                                            <?php if ( $private_lesson == 'lesson_protected' ) : ?>
                                                <div class="private-lesson<?php echo $has_active_subscription || $bought_course ? ' privateunlock' : ''; echo $has_active_subscription ? ' hassubscriptions' : '' ?>">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="titleId" class="mr-fds-12 grow-0 shrink-0 w-5 h-5 md:w-6 md:h-6 text-fds-icon-disable" aria-label="lock icon"><path d="M11.76 17.3128C11.5691 17.3128 11.3859 17.237 11.251 17.1019C11.1159 16.9669 11.04 16.7837 11.04 16.5928V14.5125C11.04 14.3215 11.1159 14.1384 11.251 14.0034C11.3859 13.8683 11.5691 13.7925 11.76 13.7925C11.951 13.7925 12.1342 13.8683 12.2691 14.0034C12.4042 14.1384 12.48 14.3215 12.48 14.5125V16.5928C12.48 16.7837 12.4042 16.9669 12.2691 17.1019C12.1342 17.237 11.951 17.3128 11.76 17.3128Z" fill="currentColor"></path><path d="M16.0299 10.7458C15.839 10.7458 15.6558 10.6699 15.5208 10.5349C15.3858 10.3999 15.3099 10.2167 15.3099 10.0258V8.00977C15.3048 7.54463 15.2073 7.08514 15.0235 6.65787C14.8395 6.23059 14.5728 5.84402 14.2386 5.52049C13.909 5.18924 13.5152 4.92894 13.0814 4.75559C12.6475 4.58224 12.1827 4.4995 11.7157 4.51248C10.7907 4.51945 9.90543 4.88881 9.24972 5.54125C8.59405 6.19368 8.22033 7.07719 8.2088 8.00209V10.0181C8.2088 10.209 8.13294 10.3922 7.99792 10.5272C7.86289 10.6622 7.67975 10.7381 7.4888 10.7381C7.29785 10.7381 7.11471 10.6622 6.97968 10.5272C6.84465 10.3922 6.7688 10.209 6.7688 10.0181V7.98673C6.7702 6.66277 7.29748 5.3936 8.23465 4.45841C9.17182 3.52321 10.4422 2.9986 11.7661 3C13.09 3.0014 14.3592 3.52868 15.2944 4.46586C16.2296 5.40304 16.7542 6.67333 16.7528 7.99729V10.0133C16.7545 10.1091 16.737 10.2043 16.7014 10.2933C16.6657 10.3823 16.6127 10.4633 16.5454 10.5315C16.4781 10.5997 16.3978 10.6538 16.3093 10.6907C16.2208 10.7274 16.1257 10.7461 16.0299 10.7458Z" fill="currentColor"></path><path d="M14.3517 21.8393H9.16779C8.08777 21.9564 6.99521 21.8352 5.96715 21.4841C5.23057 21.1289 4.63601 20.5346 4.28043 19.7983C3.93054 18.77 3.80964 17.6776 3.92618 16.5977V14.551C3.80946 13.4714 3.93037 12.3793 4.28043 11.3513C4.63577 10.6142 5.23079 10.0195 5.96811 9.66457C6.99586 9.31356 8.08809 9.19231 9.16779 9.30936H14.3517C15.4315 9.19248 16.5236 9.31372 17.5514 9.66457C18.2888 10.0197 18.8835 10.6148 19.2381 11.3522C19.5892 12.3796 19.7105 13.4715 19.5934 14.551V16.5948C19.7104 17.6748 19.5891 18.7674 19.2381 19.7954C18.8827 20.5322 18.2877 21.1267 17.5505 21.4812C16.5234 21.8331 15.4314 21.9554 14.3517 21.8393ZM9.16779 10.7494C8.30342 10.6616 7.43029 10.7339 6.5921 10.9625C6.14905 11.1752 5.79156 11.5324 5.57834 11.9753C5.35073 12.8137 5.27883 13.6867 5.36618 14.551V16.5948C5.27905 17.4598 5.35095 18.3334 5.57834 19.1724C5.79241 19.6138 6.1493 19.9701 6.59115 20.1833C7.42968 20.4118 8.30311 20.484 9.16779 20.3964H14.3517C15.2161 20.484 16.0892 20.4118 16.9275 20.1833C17.3698 19.9703 17.7268 19.6135 17.9403 19.1714C18.1688 18.3329 18.241 17.4595 18.1534 16.5948V14.5481C18.2411 13.6837 18.1689 12.8106 17.9403 11.9724C17.7275 11.5299 17.3707 11.1728 16.9285 10.9596C16.0899 10.7312 15.2165 10.659 14.3517 10.7465L9.16779 10.7494Z" fill="currentColor"></path></svg><span></span>
                                                </div>
                                            <?php elseif ( $private_lesson == 'lesson_free_users' ) : ?>
                                                <div class="private-lesson<?php echo is_user_logged_in() ? ' privateunlock' : ''; ?>">
                                                    <svg xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="md:w-4"><path d="M9.99967 10.0703C12.3009 10.0703 14.1663 8.20485 14.1663 5.90367C14.1663 3.60248 12.3009 1.737 9.99967 1.737C7.69849 1.737 5.83301 3.60248 5.83301 5.90367C5.83301 8.20485 7.69849 10.0703 9.99967 10.0703Z" stroke="currentcolor" stroke-width="1.5px" stroke-linecap="round" stroke-linejoin="round" fill="none"></path><path d="M17.1585 18.4036C17.1585 15.1786 13.9501 12.5703 10.0001 12.5703C6.05013 12.5703 2.8418 15.1786 2.8418 18.4036" stroke="currentcolor" stroke-width="1.5px" stroke-linecap="round" stroke-linejoin="round" fill="none"></path></svg><span></span>
                                                </div>
                                            <?php endif; ?>

                                        </div>
                                    <?php endif; ?>
                            
                                </div>
                            
                                <div class="panel-content">
                                    <div class="panel-content-inner">
                            
                                        <?php
                                        // If locked (either due to privacy-only OR time), show the appropriate message
                                        if ( $lesson_is_locked ) {
                                            echo $lesson_lock_message;
                                        } else {
                            
                                            // original access rules: (unchanged)
                                            if ( $private_lesson == 'lesson_protected' ) {
                                                if ( $bought_course ) {
                                                    echo do_shortcode( $content );
                                                    if ( ! empty( $lesson_video ) || ! empty( $lesson_audio ) ) {
                                                        echo render_lesson_media( $lesson_video, $lesson_audio, $lesson_video_cover );
                                                    }
                                                } else {
                                                    ?>
                                                    <div class="lessonaccessdenied">
                                                        <span class="icon"><i class="fas fa-exclamation-triangle"></i></span>
                                                        <?php
                                                        if ( ! empty( $private_placeholder ) ) {
                                                            echo wp_kses_post( $private_placeholder );
                                                        } else {
                                                            esc_html_e( 'This lesson is private, for full access to all lessons you need to buy this course.', 'studiare' );
                                                        }
                                                        ?>
                                                    </div>
                                                    <?php
                                                }
                                            } elseif ( $private_lesson == 'lesson_free_users' && ! is_user_logged_in() ) {
                                                ?>
                                                <div class="lessonaccessdenied">
                                                    <span class="icon"><i class="fas fa-user-lock"></i></span>
                                                    <?php esc_html_e( 'This lesson is private. Please log in to access.', 'studiare' ); ?>
                                                </div>
                                                <?php
                                            } else {
                                                // fully accessible
                                                echo do_shortcode( $content );
                                                if ( ! empty( $lesson_video ) || ! empty( $lesson_audio ) ) {
                                                    echo render_lesson_media( $lesson_video, $lesson_audio, $lesson_video_cover );
                                                }
                                            }
                            
                                        } // end availability check
                                        ?>
                            
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                        $global_index++;
                        $section_index++;
                    }
                }
                ?>
            </div>
        </div>

        <?php
    }
    return ob_get_clean();
}
?>