<?php
/**
 * Teacher Helper Functions
 * Reusable functions for teacher data — used in single page, Elementor widgets, and teacher cards.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Get all course IDs assigned to a teacher.
 *
 * @param int $teacher_id
 * @return int[]
 */
function studiare_get_teacher_course_ids( $teacher_id ) {
    return get_posts( [
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'fields'         => 'ids',
        'posts_per_page' => -1,
        'meta_query'     => [ [
            'key'     => '_studiare_course_teachers',
            'value'   => $teacher_id,
            'compare' => 'LIKE',
        ] ],
    ] );
}

/**
 * Get teacher stats: total courses, students, and average rating.
 *
 * @param int $teacher_id
 * @return array { total_courses, total_students, average_rating }
 */
function studiare_get_teacher_stats( $teacher_id ) {
    $course_ids = studiare_get_teacher_course_ids( $teacher_id );

    $total_courses       = count( $course_ids );
    $total_students      = 0;
    $total_rating_sum    = 0;
    $rated_courses_count = 0;

    foreach ( $course_ids as $course_id ) {
        $product = wc_get_product( $course_id );
        if ( ! $product ) continue;

        $total_students += (int) $product->get_total_sales();
        $rating = $product->get_average_rating();
        if ( $rating > 0 ) {
            $total_rating_sum += $rating;
            $rated_courses_count++;
        }
    }

    return [
        'total_courses'   => $total_courses,
        'total_students'  => $total_students,
        'average_rating'  => $rated_courses_count > 0
            ? round( $total_rating_sum / $rated_courses_count, 1 )
            : 0,
    ];
}

/**
 * Get teacher social links as an array.
 * Returns only those that have a value.
 *
 * @param int $teacher_id
 * @return array  [ 'key' => [ 'url' => '', 'icon' => '' ], ... ]
 */
function studiare_get_teacher_socials( $teacher_id ) {
    $social_map = [
        'facebook'    => 'fab fa-facebook',
        'twitter'     => 'fab fa-twitter',
        'google-plus' => 'fab fa-google-plus',
        'linkedin'    => 'fab fa-linkedin',
        'github'      => 'fab fa-github',
        'youtube'     => 'fab fa-youtube',
        'telegram'    => 'fab fa-telegram',
        'instagram'   => 'fab fa-instagram',
        'whatsapp'    => 'fab fa-whatsapp',
        'website'     => 'fal fa-globe',
    ];

    $result = [];
    foreach ( $social_map as $key => $icon ) {
        $url = get_post_meta( $teacher_id, $key, true );
        if ( ! empty( $url ) ) {
            $result[ $key ] = [ 'url' => $url, 'icon' => $icon ];
        }
    }

    return $result;
}

/**
 * Render teacher social links HTML.
 *
 * @param int $teacher_id
 */
function studiare_render_teacher_socials( $teacher_id ) {
    $socials = studiare_get_teacher_socials( $teacher_id );
    if ( empty( $socials ) ) return;

    foreach ( $socials as $data ) {
        printf(
            '<a class="studi_teacher_sbtn" rel="noopener noreferrer nofollow" href="%s" target="_blank"><i class="%s"></i></a>',
            esc_url( $data['url'] ),
            esc_attr( $data['icon'] )
        );
    }
}

/**
 * Render teacher stats bar (courses, students, rating).
 *
 * @param int   $teacher_id
 * @param array $show  Which stats to show: show_courses, show_students, show_rating
 */
function studiare_render_teacher_stats( $teacher_id, $show = [] ) {
    $defaults = [
        'show_courses'  => true,
        'show_students' => true,
        'show_rating'   => true,
    ];
    $show  = wp_parse_args( $show, $defaults );
    $stats = studiare_get_teacher_stats( $teacher_id );
    ?>
    <div class="teacher-stats flex gap-5 items-center">
        <?php if ( $show['show_courses'] ) : ?>
        <div class="flex items-center flex-col text-center">
            <div><strong><?php echo (int) $stats['total_courses']; ?></strong></div>
            <?php esc_html_e( 'My Courses', 'studiare' ); ?>
        </div>
        <?php endif; ?>

        <?php if ( $show['show_students'] ) : ?>
        <div class="flex items-center flex-col text-center">
            <div><strong><?php echo number_format( $stats['total_students'] ); ?></strong></div>
            <?php esc_html_e( 'My Students', 'studiare' ); ?>
        </div>
        <?php endif; ?>

        <?php if ( $show['show_rating'] ) : ?>
        <div class="flex items-center flex-col text-center">
            <div class="flex gap-1.5 items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#ffab17" viewBox="0 0 12 12" width="12" height="12">
                    <g clip-path="url(#star-clip)">
                        <path d="m6.54 10.817 1.91 1.044a1.13 1.13 0 0 0 1.224-.094c.175-.133.311-.315.393-.524.081-.209.105-.438.068-.66l-.364-2.211a1.26 1.26 0 0 1 .04-.58c.058-.186.16-.355.294-.492l1.544-1.566a1.23 1.23 0 0 0 .317-.577c.052-.22.044-.45-.023-.664a1.2 1.2 0 0 0-.356-.551 1.14 1.14 0 0 0-.583-.273l-2.133-.322a1.14 1.14 0 0 1-.515-.22 1.2 1.2 0 0 1-.358-.443L7.041.674a1.2 1.2 0 0 0-.428-.492 1.13 1.13 0 0 0-1.228 0c-.185.12-.333.29-.43.493l-.953 2.013a1.2 1.2 0 0 1-.358.443 1.14 1.14 0 0 1-.515.219l-2.133.323a1.14 1.14 0 0 0-.583.272 1.2 1.2 0 0 0-.356.551 1.26 1.26 0 0 0-.023.665c.052.219.162.419.317.576l1.543 1.566c.136.137.237.306.295.493s.072.386.04.579l-.367 2.208c-.037.223-.013.452.068.661.082.21.218.391.394.524a1.13 1.13 0 0 0 1.226.092l1.91-1.043a1.13 1.13 0 0 1 1.08 0" fill="#FFAB17"/>
                    </g>
                    <defs><clipPath id="star-clip"><path fill="#fff" d="M0 0h12v12H0z"/></clipPath></defs>
                </svg>
                <strong><?php echo esc_html( $stats['average_rating'] ); ?></strong>
            </div>
            <?php esc_html_e( 'My Rating', 'studiare' ); ?>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Get WP_Query for a teacher's courses with pagination support.
 *
 * @param int $teacher_id
 * @param int $posts_per_page  -1 for all
 * @param int $paged           Current page number
 * @return WP_Query
 */
function studiare_get_teacher_courses_query( $teacher_id, $posts_per_page = -1, $paged = 1 ) {
    return new WP_Query( [
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => $posts_per_page,
        'paged'          => $paged,
        'meta_query'     => [ [
            'key'     => '_studiare_course_teachers',
            'value'   => $teacher_id,
            'compare' => 'LIKE',
        ] ],
    ] );
}
