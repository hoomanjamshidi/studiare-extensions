<?php
/**
 * Codebean WooCommerce functions, actions and filters
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if (!class_exists('WooCommerce') && !function_exists('WC')) {
    return;
}
/**
 * Display username directly on edit account form without shortcode
 */
function st_add_username_to_edit_account_form() {
    $current_user = wp_get_current_user();
    
    if (is_user_logged_in()) {
        ?>
       
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		    <label for="user_login_info"><?php echo __('User Name', 'studiare');?></label>
		    <input type="text" disabled class="woocommerce-Input woocommerce-Input--text input-text" name="user_login_info" id="user_login_info" aria-describedby="user_login_description" value="<?php echo esc_html($current_user->user_login); ?>" >
	    </p>
        <?php
    }
}
add_action('woocommerce_edit_account_form_start', 'st_add_username_to_edit_account_form');






add_action('suncode_before_my_account', 'studiare_account_dashboard_slider', 999);

function studiare_account_dashboard_slider() {

    $options = get_option('codebean_option');

    /**
     * Slider is disabled by default.
     */
    if (empty($options['dashboard_slider_enabled'])) {
        return;
    }

    if (empty($options['dashboard_slider'])) {
        return;
    }

    /**
     * Validate CSS size values.
     */
    $sanitize_css_size = function($value, $default) {
        $value = trim((string) $value);

        if ($value === '') {
            return $default;
        }

        // If only number is entered, convert to px.
        if (is_numeric($value)) {
            return absint($value) . 'px';
        }

        // Allow common CSS units.
        if (preg_match('/^\d+(\.\d+)?(px|rem|em|vh|vw|%)$/', $value)) {
            return $value;
        }

        return $default;
    };

    $desktop_height = !empty($options['dashboard_slider_height_desktop'])
        ? $sanitize_css_size($options['dashboard_slider_height_desktop'], '260px')
        : '260px';

    $mobile_height = !empty($options['dashboard_slider_height_mobile'])
        ? $sanitize_css_size($options['dashboard_slider_height_mobile'], '160px')
        : '160px';

    $raw_slides = $options['dashboard_slider'];
    $slides = array();

    if (
        isset($raw_slides['redux_repeater_data']) &&
        is_array($raw_slides['redux_repeater_data']) &&
        !empty($raw_slides['redux_repeater_data'])
    ) {

        $num_slides = count($raw_slides['redux_repeater_data']);

        for ($i = 0; $i < $num_slides; $i++) {

            if (!empty($raw_slides['image'][$i]['url'])) {

                $desktop_image = esc_url($raw_slides['image'][$i]['url']);

                $mobile_image = !empty($raw_slides['mobile_image'][$i]['url'])
                    ? esc_url($raw_slides['mobile_image'][$i]['url'])
                    : $desktop_image;

                $target = !empty($raw_slides['target'][$i]) ? $raw_slides['target'][$i] : '_self';
                $target = in_array($target, array('_self', '_blank'), true) ? $target : '_self';

                $slides[] = array(
                    'image'        => $desktop_image,
                    'mobile_image' => $mobile_image,
                    'link'         => !empty($raw_slides['link'][$i]) ? esc_url($raw_slides['link'][$i]) : '',
                    'target'       => esc_attr($target),
                );
            }
        }
    }

    if (empty($slides)) {
        return;
    }

    /**
     * Inline CSS for dynamic heights.
     */
    ?>
    <style>
        .dashboard-slider-wrap {
            --dashboard-slider-height: <?php echo esc_html($desktop_height); ?>;
            --dashboard-slider-mobile-height: <?php echo esc_html($mobile_height); ?>;
            width: 100%;
        }

        .dashboard-slider-wrap .dashboard-single-slide,
        .dashboard-slider-wrap .dashboard-owl-slider,
        .dashboard-slider-wrap .dashboard-owl-slider .item {
            width: 100%;
            height: var(--dashboard-slider-height);
            overflow: hidden;
        }

        .dashboard-slider-wrap a,
        .dashboard-slider-wrap picture,
        .dashboard-slider-wrap img {
            display: block;
            width: 100%;
            height: 100%;
        }

        .dashboard-slider-wrap img {
            object-fit: cover;
            object-position: center;
        }

        @media (max-width: 600px) {
            .dashboard-slider-wrap .dashboard-single-slide,
            .dashboard-slider-wrap .dashboard-owl-slider,
            .dashboard-slider-wrap .dashboard-owl-slider .item {
                height: var(--dashboard-slider-mobile-height);
            }
        }
    </style>
    <?php

    /**
     * Single slide.
     */
    if (count($slides) === 1) {

        $slide  = $slides[0];
        $img    = $slide['image'];
        $mImg   = $slide['mobile_image'];
        $link   = $slide['link'];
        $target = $slide['target'];

        $rel = $target === '_blank' ? ' rel="noopener noreferrer"' : '';

        echo '<div class="sc_dashboard_box mb-30 dashboard-slider-wrap">';
        echo '<div class="dashboard-single-slide">';

        if ($link) {
            echo '<a href="' . esc_url($link) . '" target="' . esc_attr($target) . '"' . $rel . '>';
        }

        echo '<picture>
                <source media="(max-width: 600px)" srcset="' . esc_url($mImg) . '">
                <img src="' . esc_url($img) . '" alt="">
              </picture>';

        if ($link) {
            echo '</a>';
        }

        echo '</div>';
        echo '</div>';

        return;
    }

    /**
     * Multiple slides.
     */
    echo '<div class="sc_dashboard_box mb-30 dashboard-slider-wrap">';
    echo '<div class="dashboard-owl-slider owl-carousel">';

    foreach ($slides as $slide) {

        $img    = $slide['image'];
        $mImg   = $slide['mobile_image'];
        $link   = $slide['link'];
        $target = $slide['target'];

        $rel = $target === '_blank' ? ' rel="noopener noreferrer"' : '';

        echo '<div class="item">';

        if ($link) {
            echo '<a href="' . esc_url($link) . '" target="' . esc_attr($target) . '"' . $rel . '>';
        }

        echo '<picture>
                <source media="(max-width: 600px)" srcset="' . esc_url($mImg) . '">
                <img src="' . esc_url($img) . '" alt="">
              </picture>';

        if ($link) {
            echo '</a>';
        }

        echo '</div>';
    }

    echo '</div>';
    echo '</div>';

    ?>
    <script>
        jQuery(function($) {
            if ($('.dashboard-owl-slider').length) {
                $('.dashboard-owl-slider').owlCarousel({
                    items: 1,
                    loop: true,
                    autoplay: true,
                    autoplayTimeout: 4000,
                    margin: 1,
                    dots: false,
                    nav: true,
                    navText: [
                        "<i class='fal fa-arrow-right'></i>",
                        "<i class='fal fa-arrow-left'></i>"
                    ],
                    navContainerClass: "owl-nav owl-nav-in nav-onhover",
                    navClass: ["owl-prev", "owl-next"]
                });
            }
        });
    </script>
    <?php
}


/**
 * bundele maker start
 * used for roadmaps bundle
 * since version 13.4
 */
// اضافه کردن شورت‌کد برای نمایش مجموع قیمت و دکمه افزودن
add_shortcode('st_bundle_add_to_cart', 'st_bundle_add_to_cart_function');

function st_bundle_add_to_cart_function( $atts ) {
    $atts = shortcode_atts( array(
        'ids' => '',        
        'link' => '',        
        'bundle_id' => 0,        
        'mode' => 'addtocart',//view
        'discount' => 0     
    ), $atts, 'st_bundle_add_to_cart' );

    if ( empty( $atts['ids'] ) ) return '';

    $ids = array_map('intval', explode(',', $atts['ids']));
    $discount = floatval($atts['discount']);
$bundle_id = $atts['bundle_id'];
    $total = 0;
    $products = [];

    foreach ( $ids as $id ) {
        $product = wc_get_product($id);
        if ( $product ) {
            $products[] = [
                'id' => $id,
                'price' => $product->get_price(),
                'name' => $product->get_name(),
            ];
            $price = floatval( $product->get_price() ?: 0 );
            $total += $price;
        }
    }

    $discounted_total = $discount > 0 ? $total * (1 - $discount / 100) : $total;

    ob_start();
    ?>
    <div class="bundle-add-wrapper" data-bundle_id="<?php echo $bundle_id;?>" data-ids="<?php echo esc_attr(implode(',', $ids)); ?>" data-discount="<?php echo esc_attr($discount); ?>">
        
        <div class="roadmap_price_box flex flex-1 max-md:flex-col items-center gap-6">
            <?php if($discount){ ?>
            <div class="course-loop-price">
                <div class="scregularprice">
                    <del class="sc_reg_onsale_price"><?php echo wc_price($total); ?></del>
                    <span class="discount-badge"><?php echo "$discount %"; ?></span>
                </div>
                <div class="price-sale"><?php echo wc_price($discounted_total); ?></div>                      
            </div>
            <?php }else{ ?>
            <div class="course-loop-price">
                
                <div class="price-sale"><?php echo wc_price($discounted_total); ?></div>                      
            </div>
            <?php } ?>
            
            <div class="roadmap_addtocart flex items-center gap-16">
                <?php if($atts['mode'] == 'addtocart'){ ?>
                    <button class="button add-bundle-to-cart single_add_to_cart_button alt"><?php echo __('Add to Cart','studiare');?></button>
                <?php }else{ ?>
                    <a href="<?php echo $atts['link'];?>" class="button"><i class="fal fa-road"></i><?php echo __('View','studiare');?></a>
                <?php } ?>
            </div>
            
            
        </div>
    </div>
    <script>
    jQuery(document).ready(function ($) {
    $('.add-bundle-to-cart').on('click', function (e) {
        e.preventDefault();

        var wrapper = $(this).closest('.bundle-add-wrapper');
        var ids = wrapper.data('ids').toString().split(',');
        var discount = wrapper.data('discount');
        var nonce = '<?php echo wp_create_nonce("add_bundle_to_cart_nonce"); ?>';
        var ajaxUrl = '<?php echo esc_url(admin_url("admin-ajax.php")); ?>';
        var cartUrl = '<?php echo wc_get_cart_url(); ?>';

        var bundle_id = wrapper.data('bundle_id');

        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            dataType: 'json', // Expect JSON response
            data: {
                action: 'st_bundle_add_to_cart', // Must match PHP handler
                nonce: nonce,                     // Nonce for security
                product_ids: ids,
                bundle_id: bundle_id,
                discount: discount,
            },
            beforeSend: function () {
                // Optional: visual feedback
                $('.add-bundle-to-cart').prop('disabled', true).text('<?php echo __('Add to Cart','studiare');?> ...');
            },
            success: function (response) {
                

                if (response.success) {
                    // Redirect to cart
                    window.location.href = cartUrl;
                } else {
                    alert(response.data && response.data.message 
                          ? response.data.message 
                          : 'خطا در افزودن محصولات به سبد خرید.');
                }

                $('.add-bundle-to-cart').prop('disabled', false).text('افزودن همه به سبد خرید');
            },
            error: function (xhr, status, error) {
                
                alert('ارتباط با سرور برقرار نشد (' + status + '). لطفا دوباره امتحان کنید.');
                $('.add-bundle-to-cart').prop('disabled', false).text('افزودن همه به سبد خرید');
            }
        });
    });
});

    </script>
    <?php
    return ob_get_clean();
}

// اکشن‌های AJAX برای کاربران لاگین و مهمان
add_action('wp_ajax_st_bundle_add_to_cart', 'st_ajax_bundle_add_to_cart');
add_action('wp_ajax_nopriv_st_bundle_add_to_cart', 'st_ajax_bundle_add_to_cart');

function st_ajax_bundle_add_to_cart() {
    check_ajax_referer('add_bundle_to_cart_nonce', 'nonce');

    if (empty($_POST['product_ids'])) {
        wp_send_json_error(['message' => 'هیچ محصولی ارسال نشد.']);
    }
    if (empty($_POST['bundle_id'])) {
        wp_send_json_error(['message' => 'این بسته وجد ندارد']);
    }

    $ids = array_map('intval', $_POST['product_ids']);
    
    $added_product_ids = [];
    $bundle_session_key = 'st_bundle_items_' . md5(json_encode($ids)); // Unique key for this bundle
    
    $bundle_id = isset($_POST['bundle_id']) ? $_POST['bundle_id'] : 0;
    //$discount = isset($_POST['discount']) ? floatval($_POST['discount']) : 0;
     $discount = get_post_meta( $bundle_id, 'st_rm_discount', true ) ?: 0;
    // Clear previous session discount if adding a new bundle
    // Consider if you want to overwrite or manage multiple bundles differently
    WC()->session->set('bundle_discount', null);
    WC()->session->set('current_bundle_key', null); // Clear current bundle key

    foreach ($ids as $id) {
        $cart_item_data = array(
            'is_bundle_item' => true,
            'bundle_session_key' => $bundle_session_key // Link item to this specific bundle session
        );
        $cart_item_key = WC()->cart->add_to_cart($id, 1, null, null, $cart_item_data);

        if ($cart_item_key) {
            $added_product_ids[] = $id;
        } else {
            error_log("Failed to add product ID: " . $id . " to cart.");
        }
    }

    // Set the discount and store the bundle items' IDs in the session
    if ($discount > 0 && !empty($added_product_ids)) {
        WC()->session->set('bundle_discount', $discount);
        WC()->session->set('current_bundle_key', $bundle_session_key); // Store the key for this bundle
        WC()->session->set($bundle_session_key, $added_product_ids); // Store the list of IDs
    } else {
         // If no discount or no products added, ensure session data is cleared
         WC()->session->set('bundle_discount', null);
         WC()->session->set('current_bundle_key', null);
         WC()->session->set($bundle_session_key, null);
    }


    if (!empty($added_product_ids)) {
        wp_send_json_success([
            'added_ids' => $added_product_ids,
            'message' => count($added_product_ids) . ' products added to your cart.'
        ]);
    } else {
        wp_send_json_error(['message' => 'None of the products could be added to the cart.']);
    }

    wp_die();
} 

add_action('woocommerce_cart_calculate_fees', 'apply_conditional_bundle_discount', 20, 1); // Use a priority to ensure it runs after other cart calculations if needed

function apply_conditional_bundle_discount() {
    $discount = WC()->session->get('bundle_discount');
    $bundle_key = WC()->session->get('current_bundle_key');
    $bundle_items_ids = WC()->session->get($bundle_key); // Get the stored IDs for this bundle

    // Check if discount is set, bundle key exists, and we have product IDs stored
    if ($discount && $bundle_key && $bundle_items_ids && is_array($bundle_items_ids)) {

        $all_bundle_items_present = true;
        $bundle_subtotal = 0;

        // Get all cart items
        $cart_items = WC()->cart->get_cart();

        // Create a temporary array of items present in the cart that belong to this bundle
        $current_bundle_in_cart = [];

        foreach ($cart_items as $cart_item_key => $cart_item) {
            // Check if the item is marked as a bundle item AND belongs to the current bundle session
            if (isset($cart_item['is_bundle_item']) && $cart_item['is_bundle_item'] &&
                isset($cart_item['bundle_session_key']) && $cart_item['bundle_session_key'] === $bundle_key) {

                $current_bundle_in_cart[$cart_item_key] = $cart_item; // Store the cart item

                // Check if this item's ID is in our expected list of bundle IDs
                if (!in_array($cart_item['product_id'], $bundle_items_ids)) {
                    // This item is marked as bundle item but not in the original list for this session key
                    // This could indicate an issue, but for now, we focus on expected items.
                }
            }
        }

        // Now, verify if all IDs from the session are present in the cart items we found
        $found_ids = [];
        foreach($current_bundle_in_cart as $item) {
            $found_ids[] = $item['product_id'];
        }

        // Sort both arrays to compare them reliably, or use array_diff
        sort($bundle_items_ids);
        sort($found_ids);

        // If the arrays don't match exactly, it means some items are missing or extra items are included
        if ($bundle_items_ids !== $found_ids) {
            $all_bundle_items_present = false;
            // Optionally: Clear the session data if the bundle is no longer valid
            WC()->session->set('bundle_discount', null);
            WC()->session->set('current_bundle_key', null);
            foreach ($bundle_items_ids as $id_to_clear) {
                 WC()->session->set('st_bundle_items_' . md5(json_encode($bundle_items_ids)), null); // Clear the specific bundle IDs
            }
        } else {
             // All items are present, calculate the subtotal for the discount
             foreach($current_bundle_in_cart as $item) {
                 $bundle_subtotal += $item['line_subtotal'];
             }
        }


        // Apply the fee only if all items are present and subtotal is positive
        if ($all_bundle_items_present && $bundle_subtotal > 0) {
            $amount = -($bundle_subtotal * ($discount / 100));
            WC()->cart->add_fee(__('Special Package Discount', 'studiare'), $amount, true, ''); // Use translation for fee name
        }
    }
}

// Also, you need to clear the session data when an item is removed from the cart
// This ensures the discount is recalculated correctly or removed if the bundle is broken
add_action('woocommerce_cart_item_removed', 'clear_bundle_session_on_item_remove', 10, 2);
function clear_bundle_session_on_item_remove($cart_item_key, $cart) {
    $cart_item = $cart->get_cart_item($cart_item_key);

    // Check if the removed item was part of a bundle
    if (isset($cart_item['is_bundle_item']) && $cart_item['is_bundle_item']) {
        $bundle_key = $cart_item['bundle_session_key'] ?? null;

        if ($bundle_key) {
            $bundle_ids_in_session = WC()->session->get($bundle_key);
            $current_cart_items = $cart->get_cart();
            $remaining_ids = [];

            // Check remaining items to see if they belong to the same bundle
            foreach ($current_cart_items as $key => $item) {
                if (isset($item['bundle_session_key']) && $item['bundle_session_key'] === $bundle_key) {
                    $remaining_ids[] = $item['product_id'];
                }
            }

            // Sort to compare
            sort($bundle_ids_in_session);
            sort($remaining_ids);

            // If the remaining items don't form the complete original bundle, clear the discount session
            if ($bundle_ids_in_session !== $remaining_ids) {
                WC()->session->set('bundle_discount', null);
                WC()->session->set('current_bundle_key', null);
                if ($bundle_key) {
                    WC()->session->set($bundle_key, null); // Clear the specific bundle IDs
                }
            }
        }
    }
     // Always recalculate cart totals after an item removal
     $cart->calculate_totals();
}
// a functions for seperate courses from products
function is_sc_course( $product_id = null ) {

    if ( ! $product_id ) {
        global $product;
        if ( ! $product ) {
            return false;
        }
        $product_id = $product->get_id();
    }

    return get_post_meta( $product_id, '_studiare_course', true ) === 'yes';
}

function get_course_release_date( $product_id ) {
    return get_post_meta( $product_id, '_studiare_sc_product_coming_soon_time', true );
}

add_filter('woocommerce_get_availability', 'custom_course_backorder_msg', 10, 2);
function custom_course_backorder_msg( $availability, $product ) {

    $product_id = $product->get_id();

    if ( ! is_sc_course( $product_id ) ) {
        return $availability;
    }

    if ( ! $product->is_on_backorder(1) ) {
        return $availability;
    }

    $release_date = get_course_release_date( $product_id );
    $release_time = date_i18n("j F Y", $release_date);
    if ( $release_date ) {

        $availability['availability'] = sprintf(
            __( 'This course is currently unavailable, but you can pre-order it. Release date: %s', 'studiare' ),
            esc_html( $release_time )
        );

    } else {

        $availability['availability'] = __(
            'This course is currently unavailable, but you can pre-order it.',
            'studiare'
        );
    }

    return $availability;
}

// hook to display release timer or message BEFORE the add to cart button
add_action('woocommerce_before_add_to_cart_form', 'display_custom_course_release_info', 10);

function display_custom_course_release_info() {
    global $product;

    if ( ! $product ) {
        return false;
    }

    $product_id = $product->get_id();

    if ( ! is_sc_course( $product_id ) ) {
        return;
    }

    $release_date_timestamp = get_course_release_date( $product_id );

    if ( $release_date_timestamp ) {
        $current_time = current_time('timestamp');

        if ( $release_date_timestamp > $current_time ) {
            $countdown_date_for_js = date('m/d/Y 23:59', $release_date_timestamp);

            echo '<div class="countdown-box-release flex gap-2 justify-center">';
            esc_html_e('to release course', 'studiare');
            echo '<div class="countdown-item-plus flex gap-1 dirLTR justify-center font-semibold" data-date="' . esc_attr($countdown_date_for_js) . '"></div>';
            echo '</div>';
        }
    }
}


 
add_filter('woocommerce_cart_item_quantity', 'disable_bundle_item_quantity_input', 10, 3);

function disable_bundle_item_quantity_input($input, $cart_item_key, $cart_item) {
    // Check if the item is a bundle item (using the metadata we added)
    if (isset($cart_item['is_bundle_item']) && $cart_item['is_bundle_item']) {
        // Return the quantity value without the input field
        // You can customize this to show a simple text or disable the input visually
        $product_name = $cart_item['data']->get_name();
        $quantity = $cart_item['quantity'];
        // Return just the quantity as text, or a disabled input if you prefer
        // return sprintf( '%s: %s', $product_name, $quantity );
        // Or, to make the input field visually disabled but still present (less ideal)
        return woocommerce_quantity_input(
            array(
                'input_name'  => "cart[{$cart_item_key}][qty]",
                'input_value' => $quantity,
                'max_value'   => $quantity, // Set max to current quantity
                'min_value'   => $quantity, // Set min to current quantity
                'product_name' => $product_name,
                'classes'     => array('input-text', 'qty', 'disabled-bundle-qty'), // Add a class for potential styling
                'readonly'    => true // Make it read-only
            ),
            $cart_item['data'],
            true
        );
    }
    // For other items, return the default input
    return $input;
}





/**
 * bundele maker end
 */


/**
 * get product list
 * since version 13.4
 */
function st_get_products_list(){
    $options = array();

    $parent_id = '';
    if (is_admin() && isset($_GET['post'])) {
        //$parent_id = intval($_GET['post']);
    }

    $product_args = array(
        'post_type'      => 'product',
        'posts_per_page' => -1,
        'post_parent'    => $parent_id,
    );

    $products = get_posts($product_args);

    if ($products) {
        foreach ($products as $product) {
            $options[$product->ID] = $product->post_title ;
        }
    }

    return $options;    
}


require_once get_parent_theme_file_path('/inc/lib/sc-courses/sc-courses-class.php');
function studi_theme_quantity_buttons() {
    if (!is_plugin_active('woocommerce/woocommerce.php')) return;
    if (!is_product() && !is_cart()) return;
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Add buttons dynamically
            $('.quantity input[type="number"]').each(function() {
                var $quantityInput = $(this);
                // Skip if buttons already added
                if ($quantityInput.data('buttons-added')) return;
                $quantityInput.data('buttons-added', true);

                // Create buttons
                var $decrementButton = $('<button type="button" class="quantity-decrement">-</button>');
                var $incrementButton = $('<button type="button" class="quantity-increment">+</button>');
                $quantityInput.before($decrementButton).after($incrementButton);

                // Function to check button status
                function checkButtonStatus() {
                    var val = parseFloat($quantityInput.val()) || 0;
                    var max = parseFloat($quantityInput.attr('max')) || Infinity;
                    var min = parseFloat($quantityInput.attr('min')) || 0;
                    $incrementButton.prop('disabled', val >= max);
                    $decrementButton.prop('disabled', val <= min);
                }

                // Event listeners
                $decrementButton.add($incrementButton).on('click', function(e) {
                    e.preventDefault();
                    var val = parseFloat($quantityInput.val()) || 0;
                    var max = parseFloat($quantityInput.attr('max')) || Infinity;
                    var min = parseFloat($quantityInput.attr('min')) || 0;
                    var step = parseFloat($quantityInput.attr('step')) || 1;

                    if ($(this).hasClass('quantity-increment')) {
                        if (val < max) {
                            $quantityInput.val(val + step);
                        }
                    } else {
                        if (val > min) {
                            $quantityInput.val(val - step);
                        }
                    }
                    $quantityInput.trigger('change');
                    checkButtonStatus();
                    $('button[name="update_cart"]').prop('disabled', false);
                });

                // Initial check
                checkButtonStatus();
            });

            // Re-run after WooCommerce AJAX updates
            $(document.body).on('updated_cart_totals updated_checkout', function() {
                $('.quantity input[type="number"]').each(function() {
                    var $quantityInput = $(this);
                    if ($quantityInput.data('buttons-added')) return;
                    $quantityInput.data('buttons-added', true);

                    var $decrementButton = $('<button type="button" class="quantity-decrement">-</button>');
                    var $incrementButton = $('<button type="button" class="quantity-increment">+</button>');
                    $quantityInput.before($decrementButton).after($incrementButton);

                    function checkButtonStatus() {
                        var val = parseFloat($quantityInput.val()) || 0;
                        var max = parseFloat($quantityInput.attr('max')) || Infinity;
                        var min = parseFloat($quantityInput.attr('min')) || 0;
                        $incrementButton.prop('disabled', val >= max);
                        $decrementButton.prop('disabled', val <= min);
                    }

                    $decrementButton.add($incrementButton).on('click', function(e) {
                        e.preventDefault();
                        var val = parseFloat($quantityInput.val()) || 0;
                        var max = parseFloat($quantityInput.attr('max')) || Infinity;
                        var min = parseFloat($quantityInput.attr('min')) || 0;
                        var step = parseFloat($quantityInput.attr('step')) || 1;

                        if ($(this).hasClass('quantity-increment')) {
                            if (val < max) {
                                $quantityInput.val(val + step);
                            }
                        } else {
                            if (val > min) {
                                $quantityInput.val(val - step);
                            }
                        }
                        $quantityInput.trigger('change');
                        checkButtonStatus();
                        $('button[name="update_cart"]').prop('disabled', false);
                    });

                    checkButtonStatus();
                });
            });
        });
    </script>
    <?php
}
add_action('wp_footer', 'studi_theme_quantity_buttons');



/**
 * Backend validation to ensure max quantity of 1
 */
function validate_grouped_product_quantities($passed, $product_id, $quantity) {
    $product = wc_get_product($product_id);
    
    if ($product->is_type('grouped') && $quantity > 1) {
        wc_add_notice(__('You can only add maximum 1 quantity of each item in grouped products.', 'your-text-domain'), 'error');
        return false;
    }
    
    return $passed;
}
add_filter('woocommerce_add_to_cart_validation', 'validate_grouped_product_quantities', 10, 3);



//add filter by teacher id since version 13.1
add_filter('query_vars', 'add_teacher_query_var');
function add_teacher_query_var($vars) {
    $vars[] = 'te';
    return $vars;
}

add_action('pre_get_posts', 'filter_products_by_teacher_url');
function filter_products_by_teacher_url($query) {
    if ( is_admin() || !$query->is_main_query() ) return;
    if ( !is_shop() && !is_product_category() && !is_product_tag() ) return;

    $teacher_id = absint( get_query_var('te') );
    if ( !$teacher_id ) return;

    $ids = studiare_get_teacher_course_ids( $teacher_id );
    $query->set( 'post__in', !empty($ids) ? $ids : [0] );
}





/* studiare lessons and course builder */
require get_parent_theme_file_path('/inc/studi_lessons.php');

/* studiare subscriptions system */
//require_once get_parent_theme_file_path('/inc/lib/wc-subscriptions/woocommerce-subscriptions.php');


/**
 * Remove general buttons from single product
 * since v12.6 add ability to enable/disable some buttons in product single page
 */
function get_generalBtnsSinglePro_situ() {
    

    if (is_plugin_active('woocommerce/woocommerce.php')) {
    	if ( is_singular('product') ) {
    	    $prefix = '_studiare_'	;
    	    $sc_sections_off = get_post_meta( get_the_ID(), $prefix . 'sc_sections_off', false );
    	    
    	    //print_r($sc_sections_off);
    	    if(!empty($sc_sections_off)){
        	    $sc_sections_off=$sc_sections_off[0];
        	    
        	    if(in_array('contact',$sc_sections_off)){
        	        remove_action("wp_footer","studi_custom_floating_btn_gen");
        	    }
        	    if(in_array('float',$sc_sections_off)){
        	        remove_action("wp_footer","sc_studi_smart_nav_builder");
        	    }
        	    if(in_array('floating_add_to_cart',$sc_sections_off)){
        	        remove_action("wp_footer","sc_studi_add_to_cart_fixed_btn");
        	    }
        	    if(in_array('fullscreen_viewer',$sc_sections_off)){
        	        remove_action('woocommerce_single_product_summary','sc_add_fullscreen_btn_to_course_area');
        	    }
        	    if(in_array('support',$sc_sections_off)){
        	        remove_action("wp_footer","swss_add_floating_button_to_frontend");
        	    }
    	    }
    	
    	} 
    }
}
add_action('woocommerce_before_single_product', 'get_generalBtnsSinglePro_situ');


/** remove show full screen mode **/
function sc_remove_full_viewer(){
    
    if ( class_exists('Redux') ) {
		$fullview = codebean_option('show_fullscreen_mode_button');
		if(!$fullview){
		     remove_action('woocommerce_single_product_summary','sc_add_fullscreen_btn_to_course_area');
		}
	}
    
}
add_action('woocommerce_before_single_product', 'sc_remove_full_viewer');

//add edit button to notifications
function sc_notifs_edit_link_to_admin_bar() {
    if (isset($_GET['item_id'])) {
        $item_id = sanitize_text_field($_GET['item_id']);
        $edit_link = admin_url('post.php?post=' . $item_id . '&action=edit');
        global $wp_admin_bar;
        $wp_admin_bar->add_menu(array(
            'id' => 'sc-notifs-edit-link',
            'icon' => 'custom-edit-link',
            'title' => esc_html__( 'Edit Notification', 'studiare' ),
            'href' => $edit_link
        ));
    }
}
add_action('admin_bar_menu', 'sc_notifs_edit_link_to_admin_bar', 999);


// Remove Woo Styles
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

// Remove result count and catalog ordering
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );

// Remove Cross-Sells from the shopping cart page
remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display');

// Change out of stock text
add_filter( 'woocommerce_get_availability', 'studiare_custom_get_availability', 1, 2);

// Our hooked in function $availablity is passed via the filter!
function studiare_custom_get_availability( $availability, $_product ) {
    $product_single_outstock_message    = codebean_option('product_single_outstock_message');
	if ( !$_product->is_in_stock() ) $availability['availability'] = $product_single_outstock_message;
	return $availability;
}

//Change the breadcrumb separator
add_filter( 'woocommerce_breadcrumb_defaults', 'jk_change_breadcrumb_delimiter' );
function jk_change_breadcrumb_delimiter( $defaults ) {
	// Change the breadcrumb delimeter from '/' to '>'
	$defaults['delimiter'] = '<i class="fal fa-angle-right"></i>';
	return $defaults;
}

// Remove breadcrumb before content add it on page title
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

// Remove tabs & upsell display
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
add_action( "woocommerce_single_product_summary_bysuncode","woocommerce_output_product_data_tabs",80);
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );

// Remove functions before single product summary
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );

// Remove thumbnails from product single
remove_action( 'woocommerce_product_thumbnails', 'woocommerce_show_product_thumbnails', 20 );


/**
 * Get Teachers List and Return it as array
 */
if (!function_exists('studiare_get_teachers_list')) {
    function studiare_get_teachers_list() {
        $teachers = array();  // Start with an empty array

        $teachers_args = array(
            'post_type'      => 'teacher',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
        );

        // Makes a query for the teacher post type
        $teachers_query = new WP_Query($teachers_args);

        // Adds every teacher to the $teachers array
        foreach ($teachers_query->posts as $teacher) {
            $teachers[$teacher->ID] = $teacher->post_title;
        }

        // Return these teachers
        return $teachers;
    }
}

/**
 * Shop products per page
 */
function studiare_shop_products_per_page() {

	$shop_per_page = '12';

	if ( class_exists('Redux') ) {
		$shop_per_page = codebean_option('shop_per_page');
	}

	$per_page = 12;
	$number = apply_filters('studiare_shop_per_page', $shop_per_page );
	if( is_numeric( $number )  &&  $number > 0) {
		$per_page = $number;
	}

	return $per_page;
}

add_filter( 'loop_shop_per_page', 'studiare_shop_products_per_page', 20 );


if( ! function_exists( 'studiare_cart_data' ) ) {
	add_filter('woocommerce_add_to_cart_fragments', 'studiare_cart_data', 30);
	function studiare_cart_data( $array ) {
		ob_start();
		studiare_cart_count();
		$count = ob_get_clean();

		ob_start();
		studiare_cart_subtotal();
		$subtotal = ob_get_clean();

		$array['span.studiare-cart-number'] = $count;
		$array['span.studiare-cart-subtotal'] = $subtotal;

		return $array;
	}
}

if( ! function_exists( 'studiare_cart_count' ) ) {
	function studiare_cart_count() {
		$count = WC()->cart->cart_contents_count;
		?>
		<span class="studiare-cart-number"><?php echo esc_html($count); ?></span>
		<?php
	}
}

if( ! function_exists( 'studiare_cart_subtotal' ) ) {
	function studiare_cart_subtotal() {
		?>
		<span class="studiare-cart-subtotal"><?php echo WC()->cart->get_cart_subtotal(); ?></span>
		<?php
	}
}

/**
 * Remove sidebar from single product
 */
function remove_sidebar_shop() {
	if ( is_singular('product') ) {
		remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar');
	}
}
add_action('template_redirect', 'remove_sidebar_shop');

/**
 * Render custom price html
 */
function studiare_custom_get_price_html( $price, $product ) {
    
	if ( $product->get_price() == 0 ) {
		if ( $product->is_on_sale() && $product->get_regular_price() ) {
			$regular_price = wc_get_price_to_display( $product, array( 'qty' => 1, 'price' => $product->get_regular_price() ) );

			//$price = wc_format_price_range( $regular_price, esc_html__( 'Free!', 'studiare' ) );
			$price = "<del><span class='woocommerce-Price-amount amount'>$regular_price" .get_woocommerce_currency_symbol()."</span></del> <ins><span class='woocommerce-Price-amount amount'>".esc_html__( 'Free!', 'studiare' )."</span></ins>";
		} 
		else {
		    $price = '<span class="amount">' . esc_html__( 'Free!', 'studiare' ) . '</span>';
		}
	}
	if('' === $product->get_price() ){
		   
            if(codebean_option('free_or_call_for_price')){
			    $price = '<span class="amount">' . esc_html__( 'Free!', 'studiare' ) . '</span>';
		    }else{
		        $price = '<span class="amount">' . esc_html__( 'Call for price', 'studiare' ) . '</span>';
		    }
                        
		}

	return $price;
	
	
    

}

add_filter( 'woocommerce_get_price_html', 'studiare_custom_get_price_html', 10, 2 );




/**
 * Cart Page markup
 */
add_action( 'woocommerce_before_cart', function() {
	echo '<div class="cart-page-inner row">';
}, 1);

add_action( 'woocommerce_after_cart', function() {
	echo '</div><!--.cart-totals-inner-->';
}, 200);

/**
 * Custom Excerpt for Products
 */
function studiare_product_custom_excerpt_length( $length ) {
	global $post;
	if ($post->post_type == 'product') {
		return 20;
	}
}

/**
 * Cart Mobile Menu Item
 */
function studiare_get_menu_item_cart() {
    $show_cart_item = true;

	if ( class_exists( 'Redux' ) ) {
		$show_cart_item = codebean_option('off_canvas_cart');
	}

	if ( ! $show_cart_item || ! function_exists( 'WC' ) ) {
		return;
	}

	$cart_items = WC()->cart->get_cart_contents_count();

	?>
    <div class="off-canvas-cart">
        <a href="<?php echo wc_get_cart_url(); ?>" class="cart-icon-link">
            <span class="bag-icon"><?php get_template_part( 'assets/images/shop-bag-two.svg' ); ?></span>
            <span class="cart-text"><?php esc_html_e( 'Cart', 'studiare' ); ?></span>
            <?php studiare_cart_count(); ?>
        </a>
    </div>
    <?php
}

/**
 * ------------------------------------------------------------------------------------------------
 * Determine is it product attribute archieve page
 * ------------------------------------------------------------------------------------------------
 */

if( ! function_exists( 'studiare_is_product_attribute_archieve' ) ) {
	function studiare_is_product_attribute_archieve() {
		$queried_object = get_queried_object();
		if( $queried_object && property_exists( $queried_object, 'taxonomy' ) ) {
			$taxonomy = $queried_object->taxonomy;
			return substr($taxonomy, 0, 3) == 'pa_';
		}
		return false;
	}
}

/**
 * ------------------------------------------------------------------------------------------------
 * Display linked checkout steps (Cart → Checkout → Completion) with Font Awesome icons
 * ------------------------------------------------------------------------------------------------
 */


// Render steps on cart page (step 1)
add_action( 'woocommerce_before_cart', 'studiare_display_checkout_steps_cart' , 0 );
function studiare_display_checkout_steps_cart() {
    studiare_render_checkout_steps( 1 );
}

// Render steps on checkout page (step 2)
add_action( 'woocommerce_before_checkout_form', 'studiare_display_checkout_steps_checkout', 0 );
function studiare_display_checkout_steps_checkout() {
    if ( is_wc_endpoint_url( 'order-received' ) ) {
        return;
    }
    studiare_render_checkout_steps( 2 );
}

// Render steps on thank-you page (step 3)
add_action( 'woocommerce_before_thankyou', 'studiare_display_checkout_steps_thankyou' );
function studiare_display_checkout_steps_thankyou( $order_id ) {
    studiare_render_checkout_steps( 3, $order_id );
}

/**
 * Core function to output the steps bar.
 *
 * @param int      $current_step 1, 2, or 3.
 * @param int|null $order_id     Order ID (only on thank-you page).
 */
function studiare_render_checkout_steps( $current_step, $order_id = null ) {
    // Check if feature is enabled in Redux
    $steps_enabled = get_option( 'codebean_option' )['course_checkout_steps_enabled'] ?? true;
    if ( ! $steps_enabled ) {
        return;
    }

    // Define steps data
    $steps = array(
        1 => array(
            'icon'  => 'fal fa-cart-plus',
            'label' => __( 'Cart', 'studiare' ),
            'url'   => wc_get_cart_url(),
        ),
        2 => array(
            'icon'  => 'fal fa-ballot-check',
            'label' => __( 'Checkout', 'studiare' ),
            'url'   => wc_get_checkout_url(),
        ),
        3 => array(
            'icon'  => '', // set dynamically
            'label' => studiare_get_step_three_label( $order_id ),
            'url'   => '#', // Step 3 does not naturally have a link; can be filtered if needed.
        ),
    );

    // Dynamic icon for step 3 based on product type
    if ( studiare_is_virtual_order( $order_id ) ) {
        $steps[3]['icon'] = 'fal fa-graduation-cap'; // Access to Training
    } else {
        $steps[3]['icon'] = 'fal fa-truck'; // Order Tracking
    }
    ?>
    <div class="studiare-checkout-steps flex text-center items-center justify-center">
        <?php foreach ( $steps as $step_number => $step ) :
            $is_completed = $step_number < $current_step;
            $is_active    = $step_number == $current_step;
    
            // Determine wrapper tag and attributes
            $tag  = 'span';
            $class_list = 'step flex flex-col items-center w-full' . ( $is_active ? ' active' : '' ) . ( $is_completed ? ' completed' : '' );
            $atts = 'class="' . $class_list . '"';
    
            // Always allow links for Step 1 and Step 2, but not for the current active page or Step 3
            if ( ! empty( $step['url'] ) && $step['url'] !== '#' && ! $is_active && $step_number < 3 ) {
                $tag  = 'a';
                $atts = 'href="' . esc_url( $step['url'] ) . '" class="' . $class_list . '"';
            }
            ?>
            
            <?php echo '<' . $tag . ' ' . $atts . '>'; ?>
                <span class="step-icon flex items-center justify-center">
                    <i class="<?php echo esc_attr( $step['icon'] ); ?>" aria-hidden="true"></i>
                </span>
                <span class="step-label"><?php echo esc_html( $step['label'] ); ?></span>
            <?php echo '</' . $tag . '>'; ?>
    
        <?php endforeach; ?>
    </div>

    <?php
}

/**
 * Get the label for step 3.
 *
 * @param int|null $order_id
 * @return string
 */
function studiare_get_step_three_label( $order_id = null ) {
    if ( $order_id ) {
        return studiare_is_virtual_order( $order_id )
            ? __( 'Access to Training', 'studiare' )
            : __( 'Order Tracking', 'studiare' );
    }

    if ( WC()->cart->is_empty() ) {
        return __( 'Complete', 'studiare' );
    }

    return studiare_cart_has_virtual_only()
        ? __( 'Access to Training', 'studiare' )
        : __( 'Order Tracking', 'studiare' );
}

/**
 * Check if an order (or cart) contains only virtual products.
 *
 * @param int|null $order_id
 * @return bool
 */
function studiare_is_virtual_order( $order_id = null ) {
    if ( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return false;
        }
        foreach ( $order->get_items() as $item ) {
            $product = $item->get_product();
            if ( $product && ! $product->is_virtual() ) {
                return false;
            }
        }
        return true;
    }
    return studiare_cart_has_virtual_only();
}

/**
 * Check if the current cart contains only virtual/downloadable products.
 *
 * @return bool
 */
function studiare_cart_has_virtual_only() {
    foreach ( WC()->cart->get_cart() as $cart_item ) {
        if ( ! $cart_item['data']->is_virtual() ) {
            return false;
        }
    }
    return true;
}
/**
 * ------------------------------------------------------------------------------------------------
 * Disable address fields for downloadable products checkout
 * ------------------------------------------------------------------------------------------------
 */
add_filter('woocommerce_checkout_fields', 'custom_checkout_fields_based_on_cart');
function custom_checkout_fields_based_on_cart($fields) {
    // Get the value of the Redux option
    $enable_address_fields = get_option('codebean_option')['course_checkout_address_fields'] ?? false;

    // If the option is disabled, do nothing
    if (!$enable_address_fields) {
        return $fields;
    }

    // Initialize product type flags
    $has_virtual_product = false;
    $has_physical_product = false;

    // Check the cart items to determine product types
    foreach (WC()->cart->get_cart() as $cart_item) {
        if ($cart_item['data']->is_virtual()) {
            $has_virtual_product = true;
        } else {
            $has_physical_product = true;
        }
    }

    // Remove address fields if only virtual products are in the cart
    if ($has_virtual_product && !$has_physical_product) {
        // Unset billing fields
        unset($fields['billing']['billing_address_1']);
        unset($fields['billing']['billing_address_2']);
        unset($fields['billing']['billing_city']);
        unset($fields['billing']['billing_postcode']);
        unset($fields['billing']['billing_state']);
        unset($fields['billing']['billing_country']);

        // Unset shipping fields
        unset($fields['shipping']['shipping_address_1']);
        unset($fields['shipping']['shipping_address_2']);
        unset($fields['shipping']['shipping_city']);
        unset($fields['shipping']['shipping_postcode']);
        unset($fields['shipping']['shipping_state']);
        unset($fields['shipping']['shipping_country']);
    }

    return $fields;
}
/**
 * ------------------------------------------------------------------------------------------------
 * Direct checkout redirect after adding a product to cart (all product types)
 * ------------------------------------------------------------------------------------------------
 */
add_filter( 'woocommerce_add_to_cart_redirect', 'studiare_direct_checkout_redirect' );
function studiare_direct_checkout_redirect( $redirect_url ) {
    // Retrieve the direct checkout option from the Redux panel
    $direct_checkout_enabled = get_option( 'codebean_option' )['course_checkout_direct_checkout'] ?? false;

    // If the option is disabled, return the default redirect URL
    if ( ! $direct_checkout_enabled ) {
        return $redirect_url;
    }

    // Redirect to the checkout page for all products
    return wc_get_checkout_url();
}
/**
 * ------------------------------------------------------------------------------------------------
 * exclude products in shop
 * ------------------------------------------------------------------------------------------------
 */
$exclude_products_shop = get_option('codebean_option')['exclude_products_shop'] ?? false;
$exclude_product_cats  = get_option('codebean_option')['exclude_product_cats'] ?? array();
$exclude_specific_products = get_option('codebean_option')['exclude_specific_products'] ?? array();
$show_excluded_in_archive  = get_option('codebean_option')['show_excluded_in_archive'] ?? false;

function custom_exclude_products_from_shop($query) {
    if (is_plugin_active('woocommerce/woocommerce.php')) {
        if (is_admin() || !$query->is_main_query() || !is_shop()) {
            return;
        }
    
        $options = get_option('codebean_option') ?: array();
        $exclude_products_shop = $options['exclude_products_shop'] ?? false;
        $exclude_product_cats = $options['exclude_product_cats'] ?? array();
        $exclude_specific_products = array_map('intval', (array) ($options['exclude_specific_products'] ?? array()));
    
        if ($exclude_products_shop) {
            $tax_query = $query->get('tax_query') ?: array();
    
            if (!empty($exclude_product_cats)) {
                $tax_query[] = array(
                    'taxonomy' => 'product_cat',
                    'field'    => 'term_id',
                    'terms'    => $exclude_product_cats,
                    'operator' => 'NOT IN',
                );
            }
    
            if (!empty($exclude_specific_products)) {
                $query->set('post__not_in', $exclude_specific_products);
            }
    
            if (!empty($tax_query)) {
                $query->set('tax_query', $tax_query);
            }
        }
    }
}
add_action('pre_get_posts', 'custom_exclude_products_from_shop');

function custom_exclude_products_from_category_archive($query) {
    if (is_admin() || !$query->is_main_query() || !is_tax('product_cat')) {
        return;
    }

    $options = get_option('codebean_option');
    $show_excluded_in_archive = $options['show_excluded_in_archive'] ?? false;
    $exclude_specific_products = $options['exclude_specific_products'] ?? array();

    if (!$show_excluded_in_archive && !empty($exclude_specific_products)) {
        $query->set('post__not_in', $exclude_specific_products);
    }
}
add_action('pre_get_posts', 'custom_exclude_products_from_category_archive');


/**
 * ------------------------------------------------------------------------------------------------
 * shop page description
 * ------------------------------------------------------------------------------------------------
 */
function add_custom_shop_description_to_end_of_loop() {
    if ( is_shop() && !is_product_category() ) {
        if ( class_exists('Redux') ) {
            $position = Redux::get_option('codebean_option', 'show_custom_shop_description');
            
            if ($position !== 'disabled') {
                $custom_shop_description_content = Redux::get_option('codebean_option', 'custom_shop_description_content');
                
                if ($position === 'top') {
                    echo '<section class="term-description">' . wpautop($custom_shop_description_content) . '</section>';
                }

                if ($position === 'bottom') {
                    add_action('woocommerce_after_shop_loop', function() use ($custom_shop_description_content) {
                        echo '<section class="term-description">' . wpautop($custom_shop_description_content) . '</section>';
                    }, 20);
                }
            }
        }
    }
}

add_action('woocommerce_before_shop_loop', 'add_custom_shop_description_to_end_of_loop', 20);

/**
 * ------------------------------------------------------------------------------------------------
 * single product stock texts
 * ------------------------------------------------------------------------------------------------
 */
function custom_stock_class_and_text( $availability, $product ) {
    $product_id = $product->get_id();

    if ( ! is_sc_course( $product_id ) ) {
        return $availability;
    }

    $default_in_stock_before = __('Remaining capacity:', 'studiare');
    $default_in_stock_after  = __('people', 'studiare');
    $default_out_stock       = __('Capacity is full!', 'studiare');

    $custom_in_stock_before = get_post_meta( $product_id, '_studiare_product_single_sc_in_stock_before_text', true );
    $custom_in_stock_after  = get_post_meta( $product_id, '_studiare_product_single_sc_in_stock_after_text', true );
    $custom_out_stock       = get_post_meta( $product_id, '_studiare_product_single_sc_out_stock_text', true );

    $stock_quantity = $product->get_stock_quantity();

    if ( $product->is_in_stock() ) {
         if ( ! empty( $stock_quantity ) ) {
            $before_text = ! empty( $custom_in_stock_before ) ? $custom_in_stock_before : $default_in_stock_before;
            $after_text  = ! empty( $custom_in_stock_after ) ? $custom_in_stock_after : $default_in_stock_after;
    
            $availability['availability'] = trim( $before_text . ' <span class="stock-quantity-number font-bold primary_color">' . $stock_quantity . '</span> ' . $after_text );
            $availability['class'] .= ' scinstock text-center font-semibold';
         }else {
            return '';
        }

    } else {
        $availability['availability'] = ! empty( $custom_out_stock ) ? $custom_out_stock : $default_out_stock;
        $availability['class'] .= ' scoutstock font-semibold';
    }

    return $availability;
}
add_filter( 'woocommerce_get_availability', 'custom_stock_class_and_text', 10, 2 );


/**
 * ------------------------------------------------------------------------------------------------
 * disable selected account page menus
 * ------------------------------------------------------------------------------------------------
 */
function disable_selected_account_page_endpoints($items) {
    if (class_exists('Redux') && function_exists('codebean_option') && !is_admin()) { 
        $disabled_menus = Redux::get_option('codebean_option', 'sc_select_account_page_menus');
        $remove_from_endpoint = Redux::get_option('codebean_option', 'sc_disable_menu_from_endpoint');

        if (!empty($disabled_menus)) {
            foreach ($items as $key => $item) {
                if (in_array($key, $disabled_menus)) {
                    unset($items[$key]);
                }
            }
        }
    }

    return $items;
}
add_filter('woocommerce_account_menu_items', 'disable_selected_account_page_endpoints', 99);

function move_logout_to_end($items) {
    if (isset($items['customer-logout'])) {
        $logout_item = $items['customer-logout'];
        unset($items['customer-logout']);
        $items['customer-logout'] = $logout_item;
    }
    return $items;
}
add_filter('woocommerce_account_menu_items', 'move_logout_to_end', 98);


function studi_disable_woocommerce_account_endpoints() {
    if (class_exists('Redux') && function_exists('codebean_option') && !is_admin()) { 
        $remove_from_endpoint = Redux::get_option('codebean_option', 'sc_disable_menu_from_endpoint');
        $disabled_menus = Redux::get_option('codebean_option', 'sc_select_account_page_menus');
        
        if ($remove_from_endpoint && !empty($disabled_menus)) {  
            // Get the current URL endpoint
            $current_endpoint = WC()->query->get_current_endpoint();
            
            // Check if the current endpoint is in the disabled list
            if (in_array($current_endpoint, $disabled_menus)) {
                wp_redirect(home_url()); // Redirect to the homepage
                exit;
            }
            
            // Handle custom endpoints

            foreach ($disabled_menus as $custom_endpoint) {
                if (strpos($_SERVER['REQUEST_URI'], $custom_endpoint) !== false) {
                    wp_redirect(home_url()); // Redirect to the homepage
                    exit;
                }
            }
        }
    }
}
add_action('template_redirect', 'studi_disable_woocommerce_account_endpoints');








/**
 * ------------------------------------------------------------------------------------------------
 * custom account menu
 * ------------------------------------------------------------------------------------------------
 */
function add_custom_account_menus($items) {
    if (class_exists('Redux') && function_exists('codebean_option')) { 
       
       
        
        $custom_account_menus = codebean_option("custom_account_menus");
        
        
        if (!empty($custom_account_menus)) {
            unset($custom_account_menus['redux_repeater_data']);
            $i=0;
            foreach ($custom_account_menus as $menu_data ) {
                if(!empty($custom_account_menus['menu_title'][$i])){

                        $menu_title = $custom_account_menus['menu_title'][$i];
                        $menu_slug  = $custom_account_menus['menu_slug'][$i];

                        if (!empty($menu_slug) && !empty($menu_title)) {
                            $items[$menu_slug] = $menu_title;
                        }
                }
                $i++;
            }
        }
        
    }
    return $items;
}
add_filter('woocommerce_account_menu_items', 'add_custom_account_menus', 10);




function register_custom_account_endpoints() {
    if (class_exists('Redux') && function_exists('codebean_option')) { 
        
        
        $custom_account_menus = codebean_option("custom_account_menus");
        //unset($custom_account_menus['redux_repeater_data']);
        
        if (!empty($custom_account_menus)) {
            $i=0;
            foreach ($custom_account_menus as $menu_data ) {
                if(!empty($custom_account_menus['menu_title'][$i])){

                        $menu_slug  = $custom_account_menus['menu_slug'][$i];

                        if (!empty($menu_slug) ) {
                             add_rewrite_endpoint($menu_slug, EP_PAGES);
                        }
                }
                $i++;
            }
        }
        
    }
}
add_action('init', 'register_custom_account_endpoints');


function display_custom_account_menu_content() {
    if (class_exists('Redux') && function_exists('codebean_option')) { 
        $custom_account_menus = codebean_option('custom_account_menus');
        
        if (!empty($custom_account_menus) && is_array($custom_account_menus)) {
            unset($custom_account_menus['redux_repeater_data']); // Remove unwanted data
            
            $i=0;
            foreach ($custom_account_menus as $menu) {
                
                if(!empty($custom_account_menus['menu_title'][$i])){
                    $menu_slug  = $custom_account_menus['menu_slug'][$i];
                    $menu_content_type = $custom_account_menus['menu_content_type'][$i] ?? '';
                    $menu_content_editor = $custom_account_menus['menu_content_editor'][$i] ?? '';
                    $menu_content_page = $custom_account_menus['menu_content_page'][$i] ?? '';
    
                    add_action('woocommerce_account_' . $menu_slug . '_endpoint', function() use ($menu_slug,$menu_content_type, $menu_content_editor, $menu_content_page) {
    
                        echo '<div class="woocommerce-MyAccount-content-inner">';
    
                        if ($menu_content_type === 'editor' && !empty($menu_content_editor)) {
                            echo wpautop(wp_kses_post($menu_content_editor));
                        } elseif ($menu_content_type === 'page' && !empty($menu_content_page)) {
    
                            echo \Elementor\Plugin::instance()->frontend->get_builder_content($menu_content_page);
                        }
                        
                        echo '</div>';
                    });
                }
            
             $i++;   
            }
        }
    }
}
add_action('init', 'display_custom_account_menu_content', 99); //woocommerce_account_dashboard


//add icons
 add_filter('studi_custom_dynamic_css', function($css){
     
     if (class_exists('Redux') && function_exists('codebean_option')) { 
       
       
        
        $custom_account_menus = codebean_option("custom_account_menus");
        
        
        if (!empty($custom_account_menus)) {
            unset($custom_account_menus['redux_repeater_data']);
            $i=0;
            foreach ($custom_account_menus as $menu_data ) {
                if(!empty($custom_account_menus['menu_title'][$i])){
                        
                        $menu_slug  = $custom_account_menus['menu_slug'][$i];
                        $menu_icon  = $custom_account_menus['menu_icon'][$i];

                        if (!empty($menu_icon) ) {
                            $menu_icon = "\\$menu_icon";
                           $css .="i.$menu_slug:before { content: '".$menu_icon."'; }";
                           $css .=".woocommerce-account .woocommerce-MyAccount-navigation ul li.woocommerce-MyAccount-navigation-link--$menu_slug a:before, .top_accoun_nav_item.woocommerce-MyAccount-navigation-link--$menu_slug a:before { content: '".$menu_icon."'; }";
                        }
                }
                $i++;
            }
        }
        return $css;
        
    }
     
     
 });

// add custom class for dashboard endpoints 
add_filter( 'woocommerce_account_content_class', function( $classes ) {

    // Detect current endpoint
    $endpoint = WC()->query->get_current_endpoint();

    // If NOT on dashboard (homepage of account)
    if ( $endpoint ) {
        $classes .= ' sc_dashboard_container';
    }

    return $classes;
});


// Add custom section after default account fields for profile picture
add_action('woocommerce_before_edit_account_form', 'add_profile_picture_section');
function add_profile_picture_section() {
    if (class_exists('Redux') && function_exists('codebean_option')) { 
        
    $enable_profile_picture = codebean_option('enable_profile_picture_upload') ?? true;
    

    if (!$enable_profile_picture) {
        return;
    }
    $user_id = get_current_user_id();
    $current_picture = get_user_meta($user_id, 'profile_picture', true);
    ?>
    <div class="profile-picture-section">
        <h3><?php esc_html_e('Profile Picture', 'studiare'); ?></h3>
        
        <div class="current-profile-picture" style="margin-bottom: 20px;">
            <?php if ($current_picture): ?>
                <img src="<?php echo esc_url($current_picture); ?>" style="width: 140px; height: 140px; object-fit: cover;" class="mask-is-squircle">
            <?php else: ?>
                <p><?php esc_html_e('No profile picture set', 'studiare'); ?></p>
            <?php endif; ?>
        </div>

        <form action="" method="post" enctype="multipart/form-data" class="profile-picture-form" style="margin-bottom: 10px;">
            <?php wp_nonce_field('update_profile_picture', 'profile_picture_nonce'); ?>
            
            <p class="form-row">
                <input type="file" 
                       class="woocommerce-Input" 
                       name="profile_picture" 
                       id="profile_picture" 
                       accept="image/*"
                       style="margin-bottom: 10px;">
                <br>
                <span><em><?php esc_html_e('Allowed formats: JPG, PNG, GIF', 'studiare'); ?></em></span>
            </p>

            <p class="form-row">
                <button type="submit" 
                        class="woocommerce-Button button" 
                        name="update_profile_picture">
                    <?php esc_html_e('Update Profile Picture', 'studiare'); ?>
                </button>
            </p>
        </form>

        <?php if ($current_picture): ?>
            <form action="" method="post">
                <?php wp_nonce_field('remove_profile_picture', 'remove_profile_picture_nonce'); ?>
                <button type="submit" name="remove_profile_picture" class="button" style="background: #dc3545; color: white;">
                    <?php esc_html_e('Remove Profile Picture', 'studiare'); ?>
                </button>
            </form>
        <?php endif; ?>
    </div>
    <?php
    }
}

// Handle the profile picture upload
add_action('template_redirect', 'handle_profile_picture_upload');
function handle_profile_picture_upload() {
    if (class_exists('Redux') && function_exists('codebean_option')) { 
$enable_profile_picture = codebean_option('enable_profile_picture_upload') ?? true;

if (!$enable_profile_picture) {
return;
}
    if (!isset($_POST['update_profile_picture']) && !isset($_POST['remove_profile_picture'])) {
        return;
    }

    // Handle profile picture removal
    if (isset($_POST['remove_profile_picture'])) {
        // Verify nonce
        if (!isset($_POST['remove_profile_picture_nonce']) || 
            !wp_verify_nonce($_POST['remove_profile_picture_nonce'], 'remove_profile_picture')) {
            wc_add_notice(__('Security check failed.', 'studiare'), 'error');
            return;
        }

        // Check if user is logged in
        if (!is_user_logged_in()) {
            wc_add_notice(__('You must be logged in to remove your profile picture.', 'studiare'), 'error');
            return;
        }

        $user_id = get_current_user_id();
        $profile_picture = get_user_meta($user_id, 'profile_picture', true);

        if ($profile_picture) {
            // Get upload directory info
            $upload_dir = wp_upload_dir();
            
            // Get the file path from URL
            $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $profile_picture);
            
            // Delete the file if it exists
            if (file_exists($file_path)) {
                wp_delete_file($file_path);
            }
            
            // Remove the meta data
            delete_user_meta($user_id, 'profile_picture');
            
            wc_add_notice(__('Profile picture removed successfully.', 'studiare'), 'success');
        }

        wp_safe_redirect(wc_get_account_endpoint_url('edit-account'));
        exit;
    }

    // Handle profile picture upload
    if (isset($_POST['update_profile_picture'])) {
        // Verify nonce
        if (!isset($_POST['profile_picture_nonce']) || 
            !wp_verify_nonce($_POST['profile_picture_nonce'], 'update_profile_picture')) {
            wc_add_notice(__('Security check failed.', 'studiare'), 'error');
            return;
        }

        // Check if user is logged in
        if (!is_user_logged_in()) {
            wc_add_notice(__('You must be logged in to update your profile picture.', 'studiare'), 'error');
            return;
        }

        $user_id = get_current_user_id();

        // Check if file was uploaded
        if (!isset($_FILES['profile_picture']) || !$_FILES['profile_picture']['size']) {
            wc_add_notice(__('Please select an image to upload.', 'studiare'), 'error');
            return;
        }

        // Load WordPress file handling functions
        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }

        // Check file type
        $file = $_FILES['profile_picture'];
        $allowed_types = array('image/jpeg', 'image/png', 'image/gif');
        
        if (!in_array($file['type'], $allowed_types)) {
            wc_add_notice(__('Only image files (JPG, PNG, GIF) are allowed.', 'studiare'), 'error');
            return;
        }

        // Additional file type verification
        $file_info = wp_check_filetype($file['name']);
        if (!$file_info['ext']) {
            wc_add_notice(__('Invalid file type.', 'studiare'), 'error');
            return;
        }

        // Set up upload parameters
        $upload_dir = wp_upload_dir();
        
        // Generate random filename
        $random_filename = 'profile_' . $user_id . '_' . wp_generate_password(32, false) . '.' . $file_info['ext'];
        
        // Prepare upload overrides
        $upload_overrides = array(
            'test_form' => false,
            'unique_filename_callback' => function($dir, $name, $ext) use ($random_filename) {
                return $random_filename;
            }
        );

        // Handle the upload
        $movefile = wp_handle_upload($file, $upload_overrides);

        if ($movefile && !isset($movefile['error'])) {
            // Process the uploaded image
            $image_path = $movefile['file'];
            
            // Load image editor
            $image_editor = wp_get_image_editor($image_path);
            
            if (!is_wp_error($image_editor)) {
                // Get current image dimensions
                $size = $image_editor->get_size();
                $orig_width = $size['width'];
                $orig_height = $size['height'];
                
                // Calculate crop dimensions
                $crop_size = min($orig_width, $orig_height);
                $crop_x = ($orig_width - $crop_size) / 2;
                $crop_y = ($orig_height - $crop_size) / 2;
                
                // Crop to square
                $image_editor->crop($crop_x, $crop_y, $crop_size, $crop_size);
                
                // Resize to 140x140
                $image_editor->resize(140, 140, true);
                
                // Set quality
                $image_editor->set_quality(90);
                
                // Generate new filename for processed image
                $processed_filename = 'profile_' . $user_id . '_' . wp_generate_password(32, false) . '_processed.' . $file_info['ext'];
                $processed_path = $upload_dir['path'] . '/' . $processed_filename;
                
                // Save the processed image
                $saved = $image_editor->save($processed_path);
                
                if (!is_wp_error($saved)) {
                    // Delete the original uploaded file
                    wp_delete_file($image_path);
                    
                    // Delete old profile picture if exists
                    $old_picture = get_user_meta($user_id, 'profile_picture', true);
                    if ($old_picture) {
                        $old_file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $old_picture);
                        if (file_exists($old_file_path)) {
                            wp_delete_file($old_file_path);
                        }
                    }
                    
                    // Save new profile picture URL
                    $new_url = $upload_dir['url'] . '/' . $processed_filename;
                    update_user_meta($user_id, 'profile_picture', $new_url);
                    wc_add_notice(__('Profile picture updated successfully.', 'studiare'), 'success');
                } else {
                    wp_delete_file($image_path);
                    wc_add_notice(__('Error processing image. Please try again.', 'studiare'), 'error');
                }
            } else {
                wp_delete_file($image_path);
                wc_add_notice(__('Error processing image. Please try again.', 'studiare'), 'error');
            }
        } else {
            wc_add_notice(__('Error uploading profile picture. Please try again.', 'studiare'), 'error');
        }

        // Redirect back to the account page
        wp_safe_redirect(wc_get_account_endpoint_url('edit-account'));
        exit;
    }
}    
}


// Filter for avatar URLs to replace with custom profile picture
add_filter('get_avatar_url', 'replace_avatar_with_custom_profile', 10, 3);
add_filter('get_avatar_data', 'replace_avatar_data_with_custom_profile', 10, 2);
add_filter('get_avatar', 'custom_avatar', 10, 6);

/**
 * Helper: Extract user ID from avatar input
 */
function get_user_id_from_avatar_input($id_or_email) {
    // Numeric user ID
    if (is_numeric($id_or_email)) {
        return (int) $id_or_email;
    }

    // WP_Comment or other object
    if (is_object($id_or_email)) {
        if (!empty($id_or_email->user_id)) {
            return (int) $id_or_email->user_id;
        }
        if (!empty($id_or_email->comment_author_email)) {
            $user = get_user_by('email', $id_or_email->comment_author_email);
            return $user ? $user->ID : 0;
        }
    }

    // Email string
    if (is_string($id_or_email) && strpos($id_or_email, '@') !== false) {
        $user = get_user_by('email', $id_or_email);
        return $user ? $user->ID : 0;
    }

    return 0;
}

/**
 * Replace avatar URL with custom profile picture or default SVG
 */
function replace_avatar_with_custom_profile($url, $id_or_email, $args) {

    // Load option dynamically on each call
    $disable_gravatar = function_exists('codebean_option')
        ? codebean_option('sc_disable_gravatar')
        : true;

    // If Gravatar is allowed → return default behavior
    if (!$disable_gravatar) {
        return $url;
    }

    $user_id = get_user_id_from_avatar_input($id_or_email);

    // Custom profile picture
    if ($user_id > 0) {
        $profile_picture = get_user_meta($user_id, 'profile_picture', true);
        if (!empty($profile_picture)) {
            return $profile_picture;
        }
    }

    // Default local avatar
    return get_template_directory_uri() . '/assets/images/default-avatar.svg';
}

/**
 * Replace avatar data for full avatar HTML compatibility
 */
function replace_avatar_data_with_custom_profile($args, $id_or_email) {

    $disable_gravatar = function_exists('codebean_option')
        ? codebean_option('sc_disable_gravatar')
        : true;

    // If Gravatar enabled → do nothing
    if (!$disable_gravatar) {
        return $args;
    }

    $user_id = get_user_id_from_avatar_input($id_or_email);

    // Custom profile picture
    if ($user_id > 0) {
        $profile_picture = get_user_meta($user_id, 'profile_picture', true);
        if (!empty($profile_picture)) {
            $args['url'] = $profile_picture;
            $args['found_avatar'] = true;
            return $args;
        }
    }

    // Default local fallback
    $args['url'] = get_template_directory_uri() . '/assets/images/default-avatar.svg';
    $args['found_avatar'] = true;
    $args['force_default'] = true;

    return $args;
}

/**
 * Replace full avatar HTML (backup filter)
 */
function custom_avatar($avatar, $id_or_email, $size, $default, $alt, $args) {

    $disable_gravatar = function_exists('codebean_option')
        ? codebean_option('sc_disable_gravatar')
        : true;

    // If Gravatar allowed → output unchanged
    if (!$disable_gravatar) {
        return $avatar;
    }

    $user_id = get_user_id_from_avatar_input($id_or_email);

    // Custom profile picture
    if ($user_id > 0) {
        $profile_picture = get_user_meta($user_id, 'profile_picture', true);
        if (!empty($profile_picture)) {
            return sprintf(
                '<img alt="%s" src="%s" class="mask-is-squircle avatar avatar-%d photo" height="%d" width="%d" %s />',
                esc_attr($alt),
                esc_url($profile_picture),
                esc_attr($size),
                esc_attr($size),
                esc_attr($size),
                !empty($args['extra_attr']) ? $args['extra_attr'] : ''
            );
        }
    }

    return $avatar; // keep original if needed
}

// Add some CSS to style the profile picture section
add_action('wp_head', 'add_profile_picture_styles');
function add_profile_picture_styles() {
    if (class_exists('Redux') && function_exists('codebean_option')) { 
    $enable_profile_picture = codebean_option('enable_profile_picture_upload') ?? true;
    
    if (!$enable_profile_picture) {
        return;
    }
    }
}
add_action( 'woocommerce_order_status_completed', 'sc_clear_purchase_cache_on_order', 10, 1 );
add_action( 'woocommerce_order_status_processing', 'sc_clear_purchase_cache_on_order', 10, 1 );

function sc_clear_purchase_cache_on_order( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( ! $order ) return;

    $user_id = $order->get_user_id();
    if ( ! $user_id ) return;

    foreach ( $order->get_items() as $item ) {
        $product_id = $item->get_product_id();
        $cache_key = '_sc_purchase_date_' . $product_id;
        delete_user_meta( $user_id, $cache_key );
    }
}


require_once get_parent_theme_file_path('/inc/lib/prerequisite/prerequisite_lessons.php');

// select product card
// Related flag
add_action( 'woocommerce_before_output_related_products', function() {
    $GLOBALS['studiare_is_related_loop'] = true;
});

add_action( 'woocommerce_after_output_related_products', function() {
    unset( $GLOBALS['studiare_is_related_loop'] );
});


// Dynamic product card loader
add_filter( 'wc_get_template_part', 'studiare_dynamic_product_template', 20, 3 );
function studiare_dynamic_product_template( $template, $slug, $name ) {

    if ( $slug !== 'content' || $name !== 'product' ) {
        return $template;
    }

    $style   = '';
    $loop_id = '';

    // Related (highest priority)
    if ( ! empty( $GLOBALS['studiare_is_related_loop'] ) ) {

        $style   = codebean_option( 'related_card_style' );
        $loop_id = codebean_option( 'related_loop_template' );

    } elseif ( is_shop() || ! empty( $GLOBALS['studiare_is_teacher_loop'] ) ) {

        $style   = codebean_option( 'shop_card_style' );
        $loop_id = codebean_option( 'shop_loop_template' );

    } elseif ( is_product_category() ) {

        $style   = codebean_option( 'category_card_style' );
        $loop_id = codebean_option( 'category_loop_template' );

    } elseif ( is_product_tag() ) {

        $style   = codebean_option( 'tag_card_style' );
        $loop_id = codebean_option( 'tag_loop_template' );
    }


    /*
     * If Elementor custom loop selected → load custom template file
     */
    if ( $style === 'custom_loop' && ! empty( $loop_id ) ) {

        // Pass loop id to template
        $GLOBALS['studiare_current_loop_id'] = $loop_id;

        return get_stylesheet_directory() . '/woocommerce/elementor-loop-product.php';
    }


    /*
     * Theme Template Fallback
     */
    $theme_path = get_stylesheet_directory() . '/woocommerce/';

    switch ( $style ) {
        case 'suncode':
            $file = 'suncode-content-product.php';
            break;

        case 'l3':
            $file = 'suncode-content-product-l3.php';
            break;

        case 'l4':
            $file = 'suncode-content-product-l4.php';
            break;
            
        case 'l5':
            $file = 'suncode-content-product-l5.php';
            break;
            
        case 'l6':
            $file = 'product_cards/pro_card_layout_06.php';
            break;

        default:
            $file = 'content-product.php';
            break;
    }

    $new_template = $theme_path . $file;

    if ( file_exists( $new_template ) ) {
        return $new_template;
    }

    return $template;
}

/**
* Add product images stack (with fallback initials) in My Account > Orders table
* Displays product thumbnails in a beautiful overlapping stack
* If product has no image → show colored circle with product initials
*/

add_filter('woocommerce_account_orders_columns', 'add_products_preview_column_to_orders_table');
function add_products_preview_column_to_orders_table($columns)
{
    // Insert new column after "Order" (order-number) column
    $new_columns = [];
    foreach ($columns as $key => $column) {
        $new_columns[$key] = $column;
        if ($key === 'order-number') {
            $new_columns['order-products'] = esc_html__('Items', 'studiare');
        }
    }
    return $new_columns;
}

add_action('woocommerce_my_account_my_orders_column_order-products', 'add_order_products_stack_to_actions_cell', 99, 1);
function add_order_products_stack_to_actions_cell($order)
{
    $items = $order->get_items();
    if (empty($items)) {
        return;
    }

    $product_data   = [];
    $visible_count  = 3;
    $colors         = ['#e91e63', '#9c27b0', '#3f51b5', '#00bcd4', '#4caf50', '#ff9800', '#f44336', '#795548'];

    foreach ($items as $item) {
        $product = $item->get_product();
        if (!$product || !$product->exists()) {
            continue;
        }

        $image_url = $product->get_image_id()
            ? wp_get_attachment_image_url($product->get_image_id(), 'thumbnail')
            : false;

        $product_data[] = [
            'image' => $image_url,
            'name'  => $product->get_name(),
            'url'   => $product->get_permalink(),
        ];
    }

    if (empty($product_data)) {
        return;
    }

    $total          = count($product_data);
    $visible_items  = array_slice($product_data, 0, $visible_count);
    $remaining      = $total - $visible_count;
    $order_view_url = $order->get_view_order_url();
    $stack_id       = 'order-stack-' . $order->get_id();

    echo '<div class="myaccount-order-products-stack" id="' . esc_attr($stack_id) . '">';
    echo '<div class="products-stack-inner">';

    

    // Visible products (reversed for overlap effect)
    foreach (array_reverse($visible_items) as $index => $item) {
        $z_index = count($visible_items) - $index;

        if ($item['image']) {
            echo '<a href="' . esc_url($item['url']) . '" target="_blank" 
                      class="stack-item has-image hint--top" 
                      aria-label="' . esc_attr($item['name']) . '" 
                      style="z-index:' . $z_index . '">
                    <img src="' . esc_url($item['image']) . '" alt="' . esc_attr($item['name']) . '">
                  </a>';
        } else {
            $initials  = strtoupper(mb_substr(wp_strip_all_tags($item['name']), 0, 1));
            $bg_color  = $colors[array_rand($colors)];

            echo '<a href="' . esc_url($item['url']) . '" target="_blank" 
            class="stack-item no-image hint--top" 
                        aria-label="' . esc_attr($item['name']) . '" 
                        style="background:' . $bg_color . '; z-index:' . $z_index . '">
                        ' . esc_html($initials) . '
                  </a>';
        }
    }
    
    // +X View All link (translatable)
    if ($remaining > 0) {
        echo '<a href="' . esc_url($order_view_url) . '" class="stack-counter hint--top" 
                aria-label="' . sprintf(esc_attr__('View all %d items', 'studiare'), $total) . '">
                <span class="plus">+' . $remaining . '</span>
              </a>';
    }

    echo '</div></div>'; // close inner + wrapper

    // Scoped & clean CSS
    echo '<style>
        #' . $stack_id . ' {margin-top:12px; text-align: center;}
        .products-stack-inner {
            display:inline-flex;
            align-items:center;
            flex-direction:row;
            gap:4px;
            position:relative;
        }
        .stack-item,
        .stack-counter {
            width:40px;
            height:40px;
            border-radius:50%;
            border:3px solid #fff;
            box-shadow:0 2px 8px rgba(0,0,0,0.15);
            display:flex;
            flex-direction:column;
            align-items:center;
            justify-content:center;
            text-decoration:none;
            transition:transform .2s ease;
            position:relative;
        }
        .stack-item.has-image img {
            width:100%;
            height:100%;
            object-fit:cover;
            border-radius:50%;
        }
        .no-image {
            color:#fff;
            font-weight:600;
            font-size:12px;
        }
        .stack-counter {
            background:#e0e0e0;
            color:#555;
            font-weight:600;
            font-size:13px;
        }
        .stack-counter .plus {font-size:14px;line-height:1;direction: ltr;}
        .stack-item:hover,
        .stack-counter:hover {
            transform:scale(1.12);
            z-index:30 !important;
        }
        .stack-counter:hover {background:#d0d0d0;}

        @media (max-width:768px) {
            .products-stack-inner { transform: scale(0.88); transform-origin: center center; flex-wrap: wrap; min-width: 90px; }
        }
    </style>';
}

// Hook for CMB2 to handle UUID generation
add_filter('cmb2_override_meta_value', 'studi_handle_group_unique_id', 10, 4);

function studi_handle_group_unique_id($override_value, $object_id, $args, $field) {
    // Only target our specific field
    if ($args['id'] !== 'unique_id' || $args['field_type'] !== 'text') {
        return $override_value;
    }

    // Get the current value from database
    $current_value = get_post_meta($object_id, $args['id'], true);
    
    // Case 1: Old section with existing UUID - return it
    if (!empty($current_value)) {
        return $current_value;
    }
    
    // Case 2 & 3: Old section empty OR New section - generate new UUID
    $new_uuid = studi_generate_uuid();
    
    // Only save to database if this is an existing post (not a new post)
    if ($object_id && $object_id != 0) {
        update_post_meta($object_id, $args['id'], $new_uuid);
    }
    
    return $new_uuid;
}


// Filter to ensure UUIDs are saved properly with repeatable groups
add_filter('cmb2_override_meta_save', 'studi_save_group_unique_id', 10, 4);
function studi_save_group_unique_id($override, $args, $field_args, $field) {
    if ($field_args['id'] !== 'unique_id') {
        return $override;
    }

    $value = $args['value'];
    
    // If value is empty, generate a new UUID
    if (empty($value)) {
        $value = studi_generate_uuid();
    }
    
    // Save the value
    if ($args['id']) {
        update_post_meta($args['id'], $args['field_id'], $value);
    }
    
    return true;
}

add_filter( 'woocommerce_my_account_my_orders_query', 'filter_my_account_orders_by_status' );

function filter_my_account_orders_by_status( $args ) {
    // Check if status parameter exists in URL
    if ( isset( $_GET['status'] ) && ! empty( $_GET['status'] ) ) {
        
        // Sanitize input
        $status = sanitize_text_field( $_GET['status'] );
        
        // Support multiple statuses separated by comma
        if ( strpos( $status, ',' ) !== false ) {
            $args['status'] = array_map( 'trim', explode( ',', $status ) );
        } else {
            $args['status'] = $status;
        }
    }

    return $args;
}

// chaneg ordering
function studiare_get_catalog_orderby_options() {
    $orderby = apply_filters(
        'woocommerce_catalog_orderby',
        array(
            'menu_order' => __( 'Default', 'studiare' ),
            'popularity' => __( 'Most Popular', 'studiare' ),
            'rating'     => __( 'Top Rated', 'studiare' ),
            'date'       => __( 'Newest', 'studiare' ),
            'price'      => __( 'Cheapest', 'studiare' ),
            'price-desc' => __( 'Most Expensive', 'studiare' ),
        )
    );

    if (!wc_review_ratings_enabled()) {
        unset($orderby['rating']);
    }

    return apply_filters('studiare_catalog_orderby_options', $orderby);
}

function studiare_get_catalog_ordering_current() {
    return isset($_GET['orderby'])
        ? wc_clean(wp_unslash($_GET['orderby']))
        : apply_filters(
            'woocommerce_default_catalog_orderby',
            get_option('woocommerce_default_catalog_orderby', 'menu_order')
        );
}

function studiare_catalog_ordering_inline() {
    $options = studiare_get_catalog_orderby_options();
    $current = studiare_get_catalog_ordering_current();

    $links = array();

    foreach ($options as $key => $label) {
        $url = add_query_arg(
            'orderby',
            $key,
            remove_query_arg(array('paged', 'product-page'))
        );

        $links[] = sprintf(
            '<a href="%1$s" class="studiare-orderby-link %2$s" data-orderby="%3$s">%4$s</a>',
            esc_url($url),
            esc_attr($current === $key ? 'active' : ''),
            esc_attr($key),
            esc_html($label)
        );
    }

    $html = '<div class="studiare-ordering-inline flex flex-wrap items center gap-1">' . implode('', $links) . '</div>';

    echo apply_filters('studiare_catalog_ordering_inline_html', $html, $options, $current);
}
