<?php
/**
 * Comment Like/Dislike for Studiare Theme
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! function_exists( 'studiare_append_comment_votes_to_text' ) ) {
	function studiare_append_comment_votes_to_text( $comment_text, $comment = null ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $comment_text;
		}

		if ( empty( $comment ) || ! is_object( $comment ) || empty( $comment->comment_ID ) ) {
			return $comment_text;
		}

		ob_start();
		studiare_render_comment_votes( $comment->comment_ID );
		$votes_html = ob_get_clean();

		if ( empty( $votes_html ) ) {
			return $comment_text;
		}

		return $comment_text . $votes_html;
	}
}
add_filter( 'comment_text', 'studiare_append_comment_votes_to_text', 99, 2 );


if ( ! function_exists( 'studiare_get_comment_vote_mode' ) ) {
	function studiare_get_comment_vote_mode() {
		if ( class_exists( 'Redux' ) && function_exists( 'codebean_option' ) ) {
			$mode = codebean_option( 'comment_like_system' );
			return ! empty( $mode ) ? $mode : 'disable';
		}

		return 'disable';
	}
}


if ( ! function_exists( 'studiare_get_comment_count_visibility' ) ) {
	function studiare_get_comment_count_visibility() {
		if ( class_exists( 'Redux' ) && function_exists( 'codebean_option' ) ) {
			$visibility = codebean_option( 'comment_like_count_visibility' );
			return ! empty( $visibility ) ? $visibility : 'all';
		}

		return 'all';
	}
}


if ( ! function_exists( 'studiare_comment_votes_members_only' ) ) {
	function studiare_comment_votes_members_only() {
		if ( class_exists( 'Redux' ) && function_exists( 'codebean_option' ) ) {
			return (bool) codebean_option( 'comment_like_members_only' );
		}

		return false;
	}
}


if ( ! function_exists( 'studiare_can_show_comment_counts' ) ) {
	function studiare_can_show_comment_counts() {
		$visibility = studiare_get_comment_count_visibility();

		if ( 'hide' === $visibility ) {
			return false;
		}

		if ( 'admin' === $visibility ) {
			return current_user_can( 'manage_options' );
		}

		return true;
	}
}

if ( ! function_exists( 'studiare_get_comment_like_count' ) ) {
	function studiare_get_comment_like_count( $comment_id ) {
		return (int) get_comment_meta( $comment_id, 'studiare_comment_likes', true );
	}
}

if ( ! function_exists( 'studiare_get_comment_dislike_count' ) ) {
	function studiare_get_comment_dislike_count( $comment_id ) {
		return (int) get_comment_meta( $comment_id, 'studiare_comment_dislikes', true );
	}
}

if ( ! function_exists( 'studiare_get_comment_vote_cookie_name' ) ) {
	function studiare_get_comment_vote_cookie_name( $comment_id ) {
		return 'studiare_comment_vote_' . absint( $comment_id );
	}
}

if ( ! function_exists( 'studiare_get_user_comment_vote' ) ) {
	function studiare_get_user_comment_vote( $comment_id ) {
		if ( is_user_logged_in() ) {
			$user_id = get_current_user_id();
			return get_user_meta( $user_id, 'studiare_comment_vote_' . absint( $comment_id ), true );
		}

		$cookie_name = studiare_get_comment_vote_cookie_name( $comment_id );
		return isset( $_COOKIE[ $cookie_name ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) ) : '';
	}
}

if ( ! function_exists( 'studiare_set_user_comment_vote' ) ) {
	function studiare_set_user_comment_vote( $comment_id, $vote_type ) {
		$comment_id = absint( $comment_id );
		$vote_type  = sanitize_text_field( $vote_type );

		if ( is_user_logged_in() ) {
			$user_id = get_current_user_id();
			update_user_meta( $user_id, 'studiare_comment_vote_' . $comment_id, $vote_type );
		} else {
			$cookie_name = studiare_get_comment_vote_cookie_name( $comment_id );

			setcookie(
				$cookie_name,
				$vote_type,
				time() + YEAR_IN_SECONDS,
				COOKIEPATH ? COOKIEPATH : '/',
				COOKIE_DOMAIN,
				is_ssl(),
				true
			);

			$_COOKIE[ $cookie_name ] = $vote_type;
		}
	}
}


if ( ! function_exists( 'studiare_render_comment_votes' ) ) {
	function studiare_render_comment_votes( $comment_id ) {
		$mode = studiare_get_comment_vote_mode();

		if ( 'disable' === $mode ) {
			return;
		}

		$user_vote   = studiare_get_user_comment_vote( $comment_id );
		$show_counts = studiare_can_show_comment_counts();
		$likes       = studiare_get_comment_like_count( $comment_id );
		$dislikes    = studiare_get_comment_dislike_count( $comment_id );

		?>
		<div class="studiare-comment-votes flex items-center gap-2" data-comment-id="<?php echo esc_attr( $comment_id ); ?>">
		    
		    <span class="title"><?php esc_html_e( 'Was this helpful?', 'studiare' ); ?></span>
			<button type="button"
			        class="studiare-comment-vote-btn like <?php echo ( 'like' === $user_vote ) ? 'voted' : ''; ?>"
			        data-vote="like">
				<i class="fal fa-thumbs-up"></i>
				<?php if ( $show_counts ) : ?>
					<span class="count"><?php echo esc_html( $likes ); ?></span>
				<?php endif; ?>
			</button>

			<?php if ( 'like_dislike' === $mode ) : ?>
				<button type="button"
				        class="studiare-comment-vote-btn dislike <?php echo ( 'dislike' === $user_vote ) ? 'voted' : ''; ?>"
				        data-vote="dislike">
					<i class="fal fa-thumbs-down"></i>
					<?php if ( $show_counts ) : ?>
						<span class="count"><?php echo esc_html( $dislikes ); ?></span>
					<?php endif; ?>
				</button>
			<?php endif; ?>
		</div>
		<?php
	}
}

add_action( 'wp_enqueue_scripts', 'studiare_comment_votes_scripts' );
function studiare_comment_votes_scripts() {
	if ( is_admin() ) {
		return;
	}
	
	if ( 'disable' === studiare_get_comment_vote_mode() ) {
		return;
	}

	if ( ! is_singular() ) {
		return;
	}

	if ( ! comments_open() && 0 === get_comments_number() ) {
		return;
	}

	wp_enqueue_script(
		'studiare-comment-votes',
		get_template_directory_uri() . '/assets/js/comment-votes.js',
		array( 'jquery' ),
		'1.0.0',
		true
	);

	wp_localize_script(
    	'studiare-comment-votes',
    	'studiareCommentVotes',
    	array(
    		'ajax_url' => admin_url( 'admin-ajax.php' ),
    		'nonce'    => wp_create_nonce( 'studiare_comment_vote_nonce' ),
    		'messages' => array(
    			'success'          => esc_html__( 'Your vote has been submitted successfully.', 'studiare' ),
    			'login_required'   => esc_html__( 'Please log in to submit your vote.', 'studiare' ),
    			'already_voted'    => esc_html__( 'You have already voted for this comment.', 'studiare' ),
    			'disabled'         => esc_html__( 'Voting is currently disabled.', 'studiare' ),
    			'dislike_disabled' => esc_html__( 'Dislike is currently disabled.', 'studiare' ),
    			'invalid'          => esc_html__( 'Invalid request.', 'studiare' ),
    			'not_found'        => esc_html__( 'Comment not found.', 'studiare' ),
    			'error'            => esc_html__( 'Something went wrong. Please try again.', 'studiare' ),
    		),
    	)
    );

}

add_action( 'wp_ajax_studiare_comment_vote', 'studiare_handle_comment_vote' );
add_action( 'wp_ajax_nopriv_studiare_comment_vote', 'studiare_handle_comment_vote' );

function studiare_handle_comment_vote() {
	check_ajax_referer( 'studiare_comment_vote_nonce', 'nonce' );

	$comment_id = isset( $_POST['comment_id'] ) ? absint( $_POST['comment_id'] ) : 0;
	$vote_type  = isset( $_POST['vote_type'] ) ? sanitize_text_field( wp_unslash( $_POST['vote_type'] ) ) : '';
	$mode       = studiare_get_comment_vote_mode();

	if ( ! $comment_id || ! in_array( $vote_type, array( 'like', 'dislike' ), true ) ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'Invalid request.', 'studiare' ),
				'type'    => 'invalid',
			)
		);
	}

	if ( 'disable' === $mode ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'Voting is disabled.', 'studiare' ),
				'type'    => 'disabled',
			)
		);
	}

	if ( studiare_comment_votes_members_only() && ! is_user_logged_in() ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'Please log in to submit your vote.', 'studiare' ),
				'type'    => 'login_required',
			)
		);
	}

	if ( 'like_only' === $mode && 'dislike' === $vote_type ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'Dislike is disabled.', 'studiare' ),
				'type'    => 'dislike_disabled',
			)
		);
	}

	$comment = get_comment( $comment_id );

	if ( ! $comment || '1' !== (string) $comment->comment_approved ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'Comment not found.', 'studiare' ),
				'type'    => 'not_found',
			)
		);
	}

	$previous_vote = studiare_get_user_comment_vote( $comment_id );

	if ( $previous_vote === $vote_type ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'You have already voted.', 'studiare' ),
				'type'    => 'already_voted',
			)
		);
	}

	$likes    = studiare_get_comment_like_count( $comment_id );
	$dislikes = studiare_get_comment_dislike_count( $comment_id );

	if ( 'like' === $vote_type ) {
		$likes++;

		if ( 'dislike' === $previous_vote && $dislikes > 0 ) {
			$dislikes--;
		}
	}

	if ( 'dislike' === $vote_type ) {
		$dislikes++;

		if ( 'like' === $previous_vote && $likes > 0 ) {
			$likes--;
		}
	}

	update_comment_meta( $comment_id, 'studiare_comment_likes', $likes );
	update_comment_meta( $comment_id, 'studiare_comment_dislikes', $dislikes );

	studiare_set_user_comment_vote( $comment_id, $vote_type );

	wp_send_json_success(
		array(
			'likes'       => (int) $likes,
			'dislikes'    => (int) $dislikes,
			'user_vote'   => $vote_type,
			'show_counts' => studiare_can_show_comment_counts(),
			'message'     => esc_html__( 'Your vote has been submitted successfully.', 'studiare' ),
			'type'        => 'success',
		)
	);
}
//admin comments page
add_filter( 'manage_edit-comments_columns', 'studiare_add_comment_votes_column' );
function studiare_add_comment_votes_column( $columns ) {
	if ( 'disable' === studiare_get_comment_vote_mode() ) {
		return $columns;
	}

	$columns['studiare_votes'] = 'Votes';
	return $columns;
}

add_action( 'manage_comments_custom_column', 'studiare_render_comment_votes_column', 10, 2 );
function studiare_render_comment_votes_column( $column, $comment_ID ) {
	if ( 'studiare_votes' !== $column ) {
		return;
	}

	if ( 'disable' === studiare_get_comment_vote_mode() ) {
		return;
	}

	$likes    = (int) get_comment_meta( $comment_ID, 'studiare_comment_likes', true );
	$dislikes = (int) get_comment_meta( $comment_ID, 'studiare_comment_dislikes', true );

	echo '<span class="studiare-admin-votes">';
	echo '<span class="studiare-admin-vote like"><i class="fal fa-thumbs-up"></i> ' . esc_html( $likes ) . '</span>';
	echo ' ';
	echo '<span class="studiare-admin-vote dislike"><i class="fal fa-thumbs-down"></i> ' . esc_html( $dislikes ) . '</span>';
	echo '</span>';
}
