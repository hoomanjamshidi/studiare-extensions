<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Studiare Course Detail Template
 * Used inside my-account/my-courses/?courseid=73
 * Fully compatible with query string method (no more my-course endpoint)
 */

$user_id = get_current_user_id();

if ( ! $user_id ) {
    wc_print_notice( __( 'You must be logged in to view this course.', 'studiare' ), 'error' );
    return;
}

// Get course ID from query var (now registered via woocommerce_get_query_vars)
$course_id = absint( get_query_var( 'courseid', 0 ) );

if ( ! $course_id ) {
    wc_print_notice( __( 'Invalid course ID.', 'studiare' ), 'error' );
    return;
}

// Check if user has purchased this course
$has_access = false;
$orders = wc_get_orders( [
    'customer_id' => $user_id,
    'status'      => [ 'wc-completed', 'wc-processing' ],
    'limit'       => -1,
    'return'      => 'ids',
] );

foreach ( $orders as $order_id ) {
    $order = wc_get_order( $order_id );
    if ( ! $order ) continue;

    foreach ( $order->get_items() as $item ) {
        if ( $item->get_product_id() == $course_id ) {
            $has_access = true;
            break 2;
        }
    }
}

if ( ! $has_access ) {
    wc_print_notice( __( 'You do not have access to this course.', 'studiare' ), 'error' );
    return;
}

// Load shortcode file (lessons, quizzes, etc.)
$shortcode_file = get_theme_file_path( '/inc/studi_lessons.php' );
if ( file_exists( $shortcode_file ) ) {
    include_once $shortcode_file;
    // Compatibility alias if needed
    if ( ! shortcode_exists( 'studiare_course_lessons' ) ) {
        add_shortcode( 'studiare_course_lessons', 'sc_get_lessons_for_product' );
    }
}

// Get the course product
$course_product = wc_get_product( $course_id );
if ( ! $course_product || get_post_meta( $course_id, '_studiare_course', true ) !== 'yes' ) {
    echo '<p>' . esc_html__( 'Course not found or invalid.', 'studiare' ) . '</p>';
    return;
}

setup_postdata( $course_product->get_id() );
?>

<div class="studiare-course-detail">

    <div class="course-title flex flex-wrap items-center justify-between gap-3">
        <h2 class="course-title-main mb-0">
            <?php echo esc_html( $course_product->get_name() ); ?>
        </h2>
        <a class="btn btn-dotted btn-gray" 
           href="<?php echo esc_url( get_permalink( $course_id ) ); ?>" 
           target="_blank" 
           rel="noopener noreferrer">
            <i class="fal fa-external-link"></i>
            <?php echo esc_html__( 'View Course Page', 'studiare' ); ?>
        </a>
    </div>

    <div class="course-content">
        <?php
        // Backup global $post
        global $post;
        $post_backup = $post;

        // Set correct post data for shortcode
        $post = get_post( $course_id );
        setup_postdata( $post );

        // Display lessons & quizzes
        echo do_shortcode( '[studiare_course_lessons]' );

        // Restore global $post
        wp_reset_postdata();
        $post = $post_backup;
        ?>
    </div>

    <div class="course-back">
        <a class="btn btn-border" href="<?php echo esc_url( wc_get_account_endpoint_url( 'my-courses' ) ); ?>">
            <i class="fal fa-chevron-double-right"></i>
            <?php esc_html_e( 'Back to My Courses', 'studiare' ); ?>
        </a>
    </div>

</div>

<?php
// Final cleanup
wp_reset_postdata();