<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class Studiare_WC_Course_Product {

    public function __construct() {
        // Add checkbox in product edit screen
        add_action( 'woocommerce_product_options_general_product_data', [ $this, 'add_studiare_type_in_wc_product' ] );

        // Save meta (classic + HPOS compatible)
        add_action( 'woocommerce_process_product_meta', [ $this, 'save_wc_product_meta' ] );
        add_action( 'woocommerce_admin_process_product_object', [ $this, 'save_wc_product_meta_object' ] );

        // Filter to detect Studiare course products
        add_filter( 'is_studiare_course_product', [ $this, 'is_studiare_course_product' ], 10, 2 );

        // Register the only endpoint we need: my-courses (will handle both list + detail)
        add_action( 'init', [ $this, 'add_my_courses_endpoint' ] );

        // VERY IMPORTANT: Preserve ?courseid= query string inside My Account endpoints
        add_filter( 'woocommerce_get_query_vars', [ $this, 'add_courseid_query_var' ], 999 );

        // Add "My Courses" tab in My Account menu
        add_filter( 'woocommerce_account_menu_items', [ $this, 'add_my_courses_menu_item' ] );

        // Content handler for my-courses endpoint
        add_action( 'woocommerce_account_my-courses_endpoint', [ $this, 'my_courses_content' ] );

        // Flush rewrite rules only on plugin/theme activation (one-time)
        if ( is_admin() ) {
            register_activation_hook( __FILE__, [ $this, 'flush_rewrites' ] );
        }
    }

    /** Add checkbox in product admin */
    public function add_studiare_type_in_wc_product() {
        wp_nonce_field( 'save_studiare_course_meta', 'studiare_course_nonce' );
        echo '<div class="options_group show_if_simple show_if_variable">';

        woocommerce_wp_checkbox( [
            'id'          => '_studiare_course',
            'label'       => __( 'Studiare course', 'studiare' ),
            'description' => __( 'This mark indicates that this product represents a Studiare course.', 'studiare' ),
            'value'       => get_post_meta( get_the_ID(), '_studiare_course', true ),
        ] );

        echo '</div>';
    }

    /** Save checkbox – classic posts */
    public function save_wc_product_meta( $post_id ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( get_post_type( $post_id ) !== 'product' ) return;

        $value = isset( $_POST['_studiare_course'] ) ? 'yes' : 'no';
        update_post_meta( $post_id, '_studiare_course', $value );
    }

    /** Save checkbox – HPOS compatible */
    public function save_wc_product_meta_object( $product ) {
        if ( ! isset( $_POST['studiare_course_nonce'] ) ||
             ! wp_verify_nonce( $_POST['studiare_course_nonce'], 'save_studiare_course_meta' ) ) {
            return;
        }

        $value = ( isset( $_POST['_studiare_course'] ) && $_POST['_studiare_course'] === 'yes' ) ? 'yes' : 'no';
        $product->update_meta_data( '_studiare_course', $value );
        $product->save();
    }

    /** Detect if product is a Studiare course */
    public function is_studiare_course_product( $default, $product_id ) {
        return get_post_meta( $product_id, '_studiare_course', true ) === 'yes';
    }

    /** Register my-courses endpoint */
    public function add_my_courses_endpoint() {
        add_rewrite_endpoint( 'my-courses', EP_ROOT | EP_PAGES );
    }

    /** Make WooCommerce preserve ?courseid= inside My Account pages */
    public function add_courseid_query_var( $query_vars ) {
        $query_vars['courseid'] = 'courseid';
        return $query_vars;
    }

    /** Flush rewrites on activation */
    public function flush_rewrites() {
        $this->add_my_courses_endpoint();
        flush_rewrite_rules();
    }

    /** Add "My Courses" menu item after Dashboard */
    public function add_my_courses_menu_item( $items ) {
        $my_courses = [ 'my-courses' => __( 'My Courses', 'studiare' ) ];
        $new_items  = [];

        foreach ( $items as $key => $label ) {
            $new_items[ $key ] = $label;
            if ( $key === 'dashboard' ) {
                $new_items = array_merge( $new_items, $my_courses );
            }
        }
        return $new_items;
    }

    /** Main content handler – decides whether to show list or single course */
    public function my_courses_content() {
        if ( ! is_user_logged_in() ) {
            wc_print_notice( __( 'You need to log in to view your courses.', 'studiare' ), 'error' );
            return;
        }

        // Get course ID from query var (WooCommerce now preserves it thanks to add_courseid_query_var)
        $course_id = absint( get_query_var( 'courseid', 0 ) );

        if ( $course_id && $this->current_user_owns_course( $course_id ) ) {
            $this->render_single_course( $course_id );
            return;
        }

        // Default: show list of purchased courses
        $this->render_courses_list();
    }

    /** Check if current user has purchased this course */
    private function current_user_owns_course( $course_id ) {
        $user_id = get_current_user_id();

        $orders = wc_get_orders( [
            'customer_id' => $user_id,
            'status'      => [ 'wc-completed', 'wc-processing' ],
            'limit'       => -1,
            'return'      => 'ids',
        ] );

        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) continue;

            foreach ( $order->get_items() as $item ) {
                if ( $item->get_product_id() == $course_id &&
                     get_post_meta( $course_id, '_studiare_course', true ) === 'yes' ) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Render single course detail page */
    private function render_single_course( $course_id ) {
        $product = wc_get_product( $course_id );

        if ( ! $product || get_post_meta( $course_id, '_studiare_course', true ) !== 'yes' ) {
            echo '<p>' . esc_html__( 'Course not found or access denied.', 'studiare' ) . '</p>';
            return;
        }

        // Optional: set page title
        $GLOBALS['current_title'] = $product->get_name();

        // Load your existing detail template (same as old my-course endpoint)
        $template = get_theme_file_path( '/inc/lib/sc-courses/class-studiare-wc-course-detail.php' );
        if ( file_exists( $template ) ) {
            $shortcode_file = get_theme_file_path( '/inc/studi_lessons.php' );
            if ( file_exists( $shortcode_file ) ) {
                include_once $shortcode_file;
            }
            include $template;
        } else {
            echo '<p>' . esc_html__( 'Course detail template not found.', 'studiare' ) . '</p>';
        }
    }

    /** Render list of purchased courses */
    private function render_courses_list() {
        $user_id = get_current_user_id();
        $orders  = wc_get_orders( [
            'customer_id' => $user_id,
            'status'      => [ 'wc-completed', 'wc-processing' ],
            'limit'       => -1,
            'return'      => 'ids',
        ] );

        if ( empty( $orders ) ) {
            $empty_orders_img = get_stylesheet_directory_uri() . '/assets/images/no-resaults.svg';
            ?>
            <div class='flex justify-center studi_empty_orders'>
                <img src='<?php echo $empty_orders_img ; ?>' class='studi_empty_orders_img' alt='Empty Orders'>
            </div>
            <?php
            $wp_button_class = wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '';
            wc_print_notice( esc_html__( 'You have not purchased any courses yet.', 'studiare' ) . ' <a class="button wc-forward' . esc_attr( $wp_button_class ) . '" href="' . esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ) . '">' . esc_html__( 'Browse products', 'studiare' ) . '</a>', 'notice' );

            return;
        }

        $courses = [];
        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) continue;

            foreach ( $order->get_items() as $item ) {
                $product_id = $item->get_product_id();
                if ( get_post_meta( $product_id, '_studiare_course', true ) !== 'yes' ) continue;

                $product = wc_get_product( $product_id );
                if ( ! $product || ! $product->is_visible() ) continue;

                $date       = $order->get_date_paid() ?: $order->get_date_created();
                $order_date = $date ? $date->date_i18n( get_option( 'date_format' ) ) : '';

                $courses[] = [
                    'id'         => $product_id,
                    'title'      => $product->get_name(),
                    // URL with query string – now preserved!
                    'link'       => add_query_arg( 'courseid', $product_id, wc_get_account_endpoint_url( 'my-courses' ) ),
                    'thumbnail'  => get_the_post_thumbnail( $product_id, 'medium' ),
                    'start_date' => $order_date,
                ];
            }
        }

        if ( empty( $courses ) ) {
            echo '<p>' . esc_html__( 'You have not purchased any courses yet.', 'studiare' ) . '</p>';
            return;
        }

        // Pagination
        $per_page     = apply_filters( 'studiare_courses_per_page', 10 );
        $current_page = max( 1, absint( $_GET['studiare_page'] ?? 1 ) );
        $total        = count( $courses );
        $total_pages  = ceil( $total / $per_page );
        $offset       = ( $current_page - 1 ) * $per_page;
        $paged_courses = array_slice( $courses, $offset, $per_page );

        echo '<div class="studiare-course-list">';
        foreach ( $paged_courses as $course ) {
            $template_path = get_parent_theme_file_path( '/inc/lib/sc-courses/templates/course-card.php' );
            if ( file_exists( $template_path ) ) {
                $course_data = [
                    'title'      => esc_html( $course['title'] ),
                    'link'       => esc_url( $course['link'] ),
                    'thumbnail'  => $course['thumbnail'],
                    'start_date' => esc_html( $course['start_date'] ),
                ];
                include $template_path;
            } else {
                echo '<div class="studiare-course-card">';
                echo '<h3><a href="' . esc_url( $course['link'] ) . '">' . esc_html( $course['title'] ) . '</a></h3>';
                if ( $course['thumbnail'] ) echo $course['thumbnail'];
                if ( $course['start_date'] ) {
                    echo '<p><strong>' . esc_html__( 'Purchase Date:', 'studiare' ) . '</strong> ' . esc_html( $course['start_date'] ) . '</p>';
                }
                echo '</div>';
            }
        }
        echo '</div>';

        // Pagination links
        if ( $total_pages > 1 ) {
            $base = add_query_arg( 'studiare_page', '%#%', wc_get_account_endpoint_url( 'my-courses' ) );
            echo '<nav class="woocommerce-pagination">';
            echo paginate_links( [
                'base'      => $base,
                'format'    => '',
                'current'   => $current_page,
                'total'     => $total_pages,
                'prev_text' => __( 'Previous', 'studiare' ),
                'next_text' => __( 'Next', 'studiare' ),
                'type'      => 'list',
            ] );
            echo '</nav>';
        }
    }
}

// Initialize
new Studiare_WC_Course_Product();