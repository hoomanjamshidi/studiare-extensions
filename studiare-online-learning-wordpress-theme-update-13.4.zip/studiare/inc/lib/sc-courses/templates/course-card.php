<?php
/**
 * Course Card Template
 * Variables: $course_data
 */

// Safety check
if ( empty( $course_data ) || ! is_array( $course_data ) ) {
    return;
}

?>

<a href="<?php echo esc_url( $course_data['link'] ); ?>" class="studiare-course-card">
    <div class="course-thumb">
        <?php echo $course_data['thumbnail']; ?>
    </div>
    <div class="course-info">
        <h6 class="course-title"><?php echo esc_html( $course_data['title'] ); ?></h6>
        <?php if ( ! empty( $course_data['start_date'] ) ) : ?>
            <div class="course-date">
                <?php echo esc_html__( 'Start Date:', 'studiare' ) . ' ' . esc_html( $course_data['start_date'] ); ?>
            </div>
        <?php endif; ?>
    </div>
    <div class="course-read-more">
        <button class="btn btn-border-primary"><i class="fal fa-book-reader"></i> <?php echo esc_html__( 'Study and learning', 'studiare' );?></button>
    </div>
</a>