<?php
/* start suncode download protector */
$phpfiledl = isset($_GET['studiare_dl']) ? $_GET['studiare_dl'] :"";



if(!function_exists('sc_studi_templateRedirect')){
	function sc_studi_templateRedirect(){
		include_once get_parent_theme_file_path( 'dl_error.php' );
        exit;
	}
}


if(!function_exists("sc_studi_get_file_size")){
	function sc_studi_get_file_size($file_url){
		$ch = curl_init($file_url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, TRUE);
		curl_setopt($ch, CURLOPT_NOBODY, TRUE);
		$data = curl_exec($ch);
		$size = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
		curl_close($ch);
		return $size;
	}
}


    if(!empty($phpfiledl)){
		
		// Get current user and check if he bought current course
		$bought_course = 'false';
		$current_user = wp_get_current_user();
		
		if( !empty($current_user->user_email) and !empty($current_user->ID) ) {
			if ( wc_customer_bought_product( $current_user->user_email, $current_user->ID, $_GET['course_id'] ) ) {
				$bought_course = 'true';
			}
		}
		$isbought = studi_has_bought_items($current_user->ID,$_GET['course_id']);
		if($isbought =="true"){
		    $bought_course = 'true';
		}
		
        // Detect if value is URL or post ID
// First check if this ID belongs to lesson (external file)
$lesson_meta = get_post_meta($phpfiledl, 'lesson_data', true);

if($lesson_meta && is_array($lesson_meta) && isset($lesson_meta[0]['sc_file_type']) && $lesson_meta[0]['sc_file_type'] === 'external'){

    $file_url = isset($lesson_meta[0]['sc_simple_link']) ? trim($lesson_meta[0]['sc_simple_link']) : '';

}else{

    // Old download system
    $file_url = get_post_meta( $phpfiledl, 'file_url', true );

}

		
		/* check if link protected */
		$link_protected = isset($_GET['pls']) ? $_GET['pls'] :"false";
		
		//check download access via cid
		$cid = isset($_GET['cid']) ? $_GET['cid'] :"";
		if($cid=="" || $cid==null){
			add_action('template_redirect', 'sc_studi_templateRedirect');
			
		}
		
		else{
			if($cid>1000 && $cid<3000){$dl_type = "free_dl_all";   }
			if($cid>4000 && $cid<6000){$dl_type = "free_dl_users"; }
			if($cid>7000 && $cid<9000){$dl_type = "protected_dl";  }
			
			if($dl_type == "free_dl_all"){
				if($link_protected=="true"){
					sc_studi_dl_file($file_url);
				}else{
					header("Location: ".$file_url);
				}
				
			}
			if($dl_type == "free_dl_users"){
				if(is_user_logged_in()) {
					if($link_protected=="true"){
					sc_studi_dl_file($file_url);
					}else{
						header("Location: ".$file_url);
					}
				}else{
					add_action('template_redirect', 'sc_studi_templateRedirect');	
				}
			}
			if($dl_type == "protected_dl"){
				if($bought_course =='false') {
					add_action('template_redirect', 'sc_studi_templateRedirect');
				}else{
					if($link_protected=="true"){
					sc_studi_dl_file($file_url);
					}else{
						header("Location: ".$file_url);
					}	
				}
			}
		}
		
		
		

    }
/* end suncode download protector */
/**
 * this shortcode is used in course sections
 * */
function generate_dl_section($atts,$course_id,$lesson_id,$private_lesson,$bought_course,$login_toast_title,$login_toast_message,$bought_toast_title,$bought_toast_message,$sc_protect_link_status){

    // Backward compatibility
    $file_type = isset($atts['sc_file_type']) ? $atts['sc_file_type'] : 'download';

    $file_id   = isset($atts['sc_download_file']) ? $atts['sc_download_file'] : '';
    $simple_link = isset($atts['sc_simple_link']) ? trim($atts['sc_simple_link']) : '';

    $download_access = $atts['sc_download_access'];

    $token = wp_nonce_url( get_site_url(), 'action' );

    // Decide what to pass to handler
    if($file_type === 'external' && !empty($simple_link)){
        $studiare_dl = $lesson_id;
    }else{
        $studiare_dl = $file_id;
    }

    if(empty($studiare_dl)){
        return '';
    }

    $dl_link = $token . "&course_id=$course_id&studiare_dl=$studiare_dl&pls=$sc_protect_link_status";
    $dl_icon = "<svg xmlns:xlink='http://www.w3.org/1999/xlink' class='me-1' fill='none' height='24' viewBox='0 0 20 20' width='24' xmlns='http://www.w3.org/2000/svg'> <path d='M2.5 12.5C2.5 14.857 2.5 16.0355 3.23223 16.7677C3.96447 17.5 5.14297 17.5 7.5 17.5H12.5C14.857 17.5 16.0355 17.5 16.7677 16.7677C17.5 16.0355 17.5 14.857 17.5 12.5' opacity='0.5' stroke='currentcolor' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5px' fill='none'> </path> <path d='M10.0003 2.5V13.3333M10.0003 13.3333L13.3337 9.6875M10.0003 13.3333L6.66699 9.6875' stroke='currentcolor' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5px' fill='none'> </path> </svg>";

    $html  = "<div class='dl_holder'>";

    if($download_access=='free_dl_all'){
        $cid = rand(1000,3000);
        $dl_link .= "&cid=".$cid;
        $html .= "<a target='_blank' href='$dl_link' class='stuadiare_dl_btn'>$dl_icon</a>";
    }

    if($download_access=='free_dl_users'){
        $cid = rand(4000,6000);
        $dl_link .= "&cid=".$cid;

        if(is_user_logged_in()) {
            $html .= "<a target='_blank' href='$dl_link' class='stuadiare_dl_btn'>$dl_icon</a>";
        }else{
            $html .= "<a href='#' class='stuadiare_dl_btn st_disable' data-toast-title=\"" . esc_attr($login_toast_title) . "\" data-toast-message=\"" . esc_attr($login_toast_message) . "\" data-toast-type=\"info\">$dl_icon</a>";
        }
    }

    if($download_access=='protected_dl'){
        $cid = rand(7000,9000);
        $dl_link .= "&cid=".$cid;

        if($bought_course) {
            $html .= "<a target='_blank' href='$dl_link' class='stuadiare_dl_btn'>$dl_icon</a>";
        }else{
            $html .= "<a href='#' class='stuadiare_dl_btn st_disable' data-toast-title=\"" . esc_attr($bought_toast_title) . "\" data-toast-message=\"" . esc_attr($bought_toast_message) . "\" data-toast-type=\"warning\">$dl_icon</a>";
        }
    }

    $html .= "</div>";

    return $html;
}

add_shortcode("generate_dl_section","generate_dl_section");