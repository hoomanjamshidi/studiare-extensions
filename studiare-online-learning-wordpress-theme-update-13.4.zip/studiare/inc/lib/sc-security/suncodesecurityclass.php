<?php
/**
 * Suncode Security – Professional protection for theme assets.
 *
 * Provides:
 * - Right-click & DevTools restriction on frontend (non-destructive overlay).
 * - Hotlink protection via .htaccess (Apache / LiteSpeed).
 * - Fully filterable, Redux‑free, i18n‑ready.
 *
 * @package Suncode\Security
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Suncode_Security {

    /**
     * Cached options array (null = not loaded yet).
     *
     * @var array|null
     */
    protected $options = null;

    /**
     * Admin notices collector.
     *
     * @var array
     */
    protected static $admin_notices = array();

    /**
     * Marker used to identify our block inside .htaccess.
     */
    const HTACCESS_MARKER = 'SUNCODE_HOTLINK_PROTECTION';

    /**
     * Constructor.
     */
    public function __construct() {
        $this->options = $this->get_raw_options();

        // Frontend restrictions
        add_action( 'wp_enqueue_scripts', array( $this, 'init_frontend_security' ) );

        // React to any settings save (Redux, customizer, etc.) that updates the option.
        add_action( 'update_option_codebean_option', array( $this, 'toggle_hotlink_protection' ), 10, 2 );

        // Shared JS translations (printed early in footer)
        add_action( 'wp_footer', array( $this, 'print_security_translations' ), 5 );

        // Collect and display admin notices
        add_action( 'admin_notices', array( $this, 'display_admin_notices' ) );
    }

    /* =========================================================================
       OPTION HELPERS (framework‑agnostic)
       ========================================================================= */

    /**
     * Get a single security option, filtered.
     *
     * @param string $key     Option key inside codebean_option.
     * @param mixed  $default Fallback value.
     * @return mixed
     */
    protected function get_security_option( $key, $default = null ) {
        // Allows overriding via filter (theme / child theme)
        $filtered = apply_filters( "suncode_security_option_{$key}", null );
        if ( null !== $filtered ) {
            return $filtered;
        }

        $options = $this->get_raw_options();
        return isset( $options[ $key ] ) ? $options[ $key ] : $default;
    }

    /**
     * Load raw options from database exactly once.
     *
     * @return array
     */
    protected function get_raw_options() {
        if ( null === $this->options ) {
            $this->options = get_option( 'codebean_option', array() );
        }
        return $this->options;
    }

    /* =========================================================================
       FRONTEND RESTRICTIONS (Right-click, DevTools)
       ========================================================================= */

    /**
     * Enqueue/print frontend protection scripts if needed.
     */
    public function init_frontend_security() {
        if ( $this->should_bypass_security() ) {
            return;
        }

        if ( ! $this->is_scope_allowed() ) {
            return;
        }

        $disable_right_click = (bool) $this->get_security_option( 'sc_disable_right_click', false );
        $disable_inspect     = (bool) $this->get_security_option( 'sc_disable_inspect', false );

        if ( $disable_right_click ) {
            add_action( 'wp_footer', array( $this, 'print_right_click_js' ), 20 );
        }

        if ( $disable_inspect ) {
            add_action( 'wp_footer', array( $this, 'print_devtools_protection_js' ), 20 );
        }
    }

    /**
     * Should security measures be skipped for the current user?
     */
    protected function should_bypass_security() {
        $ignore_admin = (bool) $this->get_security_option( 'sc_ignore_admin', true );
        if ( $ignore_admin && current_user_can( 'manage_options' ) ) {
            return true;
        }
        return false;
    }

    /**
     * Check if the current page matches the restriction scope.
     */
    protected function is_scope_allowed() {
        $scope = (array) $this->get_security_option( 'sc_restriction_scope', array() );

        // Never restrict checkout page
        if ( function_exists( 'is_checkout' ) && is_checkout() ) {
            return false;
        }

        if ( empty( $scope ) ) {
            return false;
        }

        if ( in_array( 'all', $scope, true ) ) {
            return true;
        }

        if ( in_array( 'product', $scope, true ) && function_exists( 'is_product' ) && is_product() ) {
            return true;
        }

        if ( in_array( 'account', $scope, true ) && function_exists( 'is_account_page' ) && is_account_page() ) {
            return true;
        }

        return false;
    }

    /**
     * Print JS translation object used by both protection scripts.
     */
    public function print_security_translations() {
        ?>
        <script>
            window.suncodeSecurity = window.suncodeSecurity || {};
            window.suncodeSecurity.rightClickMessage = <?php echo wp_json_encode( __( 'Right click is disabled on this page.', 'studiare' ) ); ?>;
            window.suncodeSecurity.devtoolsMessage   = <?php echo wp_json_encode( __( 'You are not allowed to use developer tools on this page.', 'studiare' ) ); ?>;
            window.suncodeSecurity.devtoolsThreshold = 200; // px difference to detect DevTools
        </script>
        <?php
    }

    /**
     * Right‑click prevention (with toastr if available).
     */
    public function print_right_click_js() {
        ?>
        <script>
            (function($){
                $(document).on('contextmenu', function(e){
                    e.preventDefault();
                    if (typeof toastr !== 'undefined') {
                        toastr.warning(window.suncodeSecurity.rightClickMessage, '<i class="fal fa-ban"></i>', {
                            positionClass: 'toast-bottom-center'
                        });
                    }
                });
            })(jQuery);
        </script>
        <?php
    }

    /**
     * DevTools protection – non‑destructive overlay.
     */
    public function print_devtools_protection_js() {
        ?>
        <script>
            (function() {
                var threshold = window.suncodeSecurity.devtoolsThreshold || 200;
                var message   = window.suncodeSecurity.devtoolsMessage;
                var overlay, shown = false;

                function createOverlay() {
                    if (overlay) return;
                    overlay = document.createElement('div');
                    overlay.setAttribute('style',
                        'position:fixed;top:0;left:0;width:100%;height:100%;' +
                        'background:#111;color:#ff4444;font-size:22px;' +
                        'display:flex;align-items:center;justify-content:center;' +
                        'z-index:9999999;text-align:center;padding:20px;'
                    );
                    overlay.textContent = message;
                    document.body.appendChild(overlay);
                }

                function removeOverlay() {
                    if (overlay && overlay.parentNode) {
                        overlay.parentNode.removeChild(overlay);
                        overlay = null;
                    }
                }

                function checkDevtools() {
                    var opened =
                        window.outerWidth - window.innerWidth > threshold ||
                        window.outerHeight - window.innerHeight > threshold;
                    if (opened && !shown) {
                        createOverlay();
                        shown = true;
                    } else if (!opened && shown) {
                        removeOverlay();
                        shown = false;
                    }
                }

                // Block only real developer shortcuts (Ctrl+S removed to not annoy legitimate users)
                document.addEventListener('keydown', function(e) {
                    if (
                        e.key === 'F12' ||
                        (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'i') ||
                        (e.ctrlKey && e.key.toLowerCase() === 'u')
                    ) {
                        e.preventDefault();
                        if (!shown) {
                            createOverlay();
                            shown = true;
                        }
                    }
                });

                checkDevtools();
                setInterval(checkDevtools, 1000);
            })();
        </script>
        <?php
    }

    /* =========================================================================
       HOTLINK PROTECTION (.htaccess – Apache only)
       ========================================================================= */

    /**
     * React to the settings option being saved.
     *
     * @param array $old_value Previous option array.
     * @param array $new_value New option array.
     */
    public function toggle_hotlink_protection( $old_value, $new_value ) {
        $old_state = isset( $old_value['sc_disable_hotlink'] ) ? (bool) $old_value['sc_disable_hotlink'] : false;
        $new_state = isset( $new_value['sc_disable_hotlink'] ) ? (bool) $new_value['sc_disable_hotlink'] : false;

        if ( $old_state === $new_state ) {
            return;
        }

        if ( $new_state ) {
            $this->add_hotlink_rule();
        } else {
            $this->remove_hotlink_rule();
        }
    }

    /**
     * Check if server is Apache or LiteSpeed (supports .htaccess).
     *
     * @return bool
     */
    protected function is_apache() {
        $server = isset( $_SERVER['SERVER_SOFTWARE'] ) ? $_SERVER['SERVER_SOFTWARE'] : '';
        return false !== stripos( $server, 'apache' ) || false !== stripos( $server, 'litespeed' );
    }

    /**
     * Does .htaccess file exist in WordPress root?
     *
     * @return bool
     */
    protected function htaccess_exists() {
        return file_exists( ABSPATH . '.htaccess' );
    }

    /**
     * Get entire .htaccess content.
     *
     * @return string|false False on failure.
     */
    protected function get_htaccess_content() {
        if ( ! $this->htaccess_exists() ) {
            return '';
        }
        $content = file_get_contents( ABSPATH . '.htaccess' );
        return false !== $content ? $content : false;
    }

    /**
     * Write content to .htaccess file with exclusive lock.
     *
     * @param string $content Full file content.
     * @return bool True on success.
     */
    protected function write_htaccess( $content ) {
        $file = ABSPATH . '.htaccess';

        if ( ! file_exists( $file ) ) {
            if ( false === @touch( $file ) ) {
                return false;
            }
        }

        if ( ! is_writable( $file ) ) {
            return false;
        }

        $result = file_put_contents( $file, $content, LOCK_EX );
        return false !== $result;
    }

    /**
     * Check if our HTACCESS_MARKER is present.
     *
     * @return bool
     */
    protected function has_hotlink_rule() {
        $content = $this->get_htaccess_content();
        if ( false === $content ) {
            return false;
        }
        return false !== strpos( $content, '# BEGIN ' . self::HTACCESS_MARKER );
    }

    /**
     * Build an array of secure RewriteCond lines for referrer checking.
     *
     * The first condition allows empty referrer (privacy tools, apps, etc.).
     *
     * @return array
     */
    protected function build_referrer_conditions() {
        $conditions = array();

        // 1) Allow requests with no referrer at all (privacy‑friendly)
        $conditions[] = 'RewriteCond %{HTTP_REFERER} !^$';

        // 2) Own domain – proper extraction using parse_url
        $domain = parse_url( home_url(), PHP_URL_HOST );
        if ( ! empty( $domain ) ) {
            $domain_regex = preg_quote( $domain, '/' );
            $conditions[] = 'RewriteCond %{HTTP_REFERER} !^https?://([^/]+[.])?' . $domain_regex . '(:[0-9]{1,5})?(/.*)?$ [NC]';
        }

        // 3) Default trusted services (search engines, social media)
        $default_domains = array(
            'google.com', 'bing.com', 'yahoo.com', 'yandex.com',
            'duckduckgo.com', 'baidu.com',
            'facebook.com', 'instagram.com', 'pinterest.com',
            'linkedin.com', 'twitter.com', 't.co',
            'reddit.com', 'tumblr.com'
        );

        foreach ( $default_domains as $host ) {
            $conditions[] = 'RewriteCond %{HTTP_REFERER} !^https?://([^/]+[.])?' . preg_quote( $host, '/' ) . '(:[0-9]{1,5})?(/.*)?$ [NC]';
        }

        // 4) User‑defined whitelist (from option or filter)
        $user_list = apply_filters(
            'suncode_security_hotlink_whitelist',
            (string) $this->get_security_option( 'sc_hotlink_whitelist_domains', '' )
        );

        if ( ! empty( $user_list ) ) {
            $lines = explode( "\n", $user_list );
            foreach ( $lines as $line ) {
                $host = trim( $line );
                if ( empty( $host ) ) {
                    continue;
                }
                // Sanitize: strip scheme, www, path, port
                $host = preg_replace( '#^https?://#i', '', $host );
                $host = preg_replace( '#^www\.#i', '', $host );
                $host = strtok( $host, '/' );
                $host = preg_replace( '/:\d+$/', '', $host );
                if ( empty( $host ) ) {
                    continue;
                }
                $host_regex = preg_quote( $host, '/' );
                $conditions[] = 'RewriteCond %{HTTP_REFERER} !^https?://([^/]+[.])?' . $host_regex . '(:[0-9]{1,5})?(/.*)?$ [NC]';
            }
        }

        return $conditions;
    }

    /**
     * Generate the complete hotlink protection block.
     *
     * @return string
     */
    protected function get_hotlink_block() {
        $extensions = 'jpg|jpeg|png|gif|webp|svg|bmp|mp4|webm|mp3|ogg|pdf|zip|rar|7z|woff|woff2|ttf|eot';
        $conditions = $this->build_referrer_conditions();
        $rewrite_conds = implode( "\n", $conditions );
        $marker = self::HTACCESS_MARKER;

        $block = <<<HTACCESS
# BEGIN {$marker}
<IfModule mod_rewrite.c>
RewriteEngine On
{$rewrite_conds}
RewriteRule \.({$extensions})$ - [F,L,NC]
</IfModule>
# END {$marker}
HTACCESS;

        return $block;
    }

    /**
     * Add hotlink protection block to .htaccess.
     */
    protected function add_hotlink_rule() {
        if ( ! $this->is_apache() ) {
            $this->queue_admin_notice( __( 'Hotlink protection requires an Apache or LiteSpeed server.', 'studiare' ), 'error' );
            return;
        }

        // Remove any existing block first to avoid duplication
        if ( $this->has_hotlink_rule() ) {
            $this->remove_hotlink_rule();
        }

        $current = $this->get_htaccess_content();
        if ( false === $current ) {
            $this->queue_admin_notice( __( 'Could not read .htaccess file.', 'studiare' ), 'error' );
            return;
        }

        $block = $this->get_hotlink_block();
        $current = rtrim( $current );

        $new_content = '' === $current ? $block . "\n" : $current . "\n\n" . $block . "\n";

        if ( ! $this->write_htaccess( $new_content ) ) {
            $this->queue_admin_notice( __( 'Unable to write to .htaccess. Please check file permissions.', 'studiare' ), 'error' );
        }
    }

    /**
     * Remove hotlink block from .htaccess.
     */
    protected function remove_hotlink_rule() {
        if ( ! $this->is_apache() || ! $this->has_hotlink_rule() ) {
            return;
        }

        $content = $this->get_htaccess_content();
        if ( false === $content ) {
            return;
        }

        $pattern = "/# BEGIN " . preg_quote( self::HTACCESS_MARKER, '/' ) . ".*?# END " . preg_quote( self::HTACCESS_MARKER, '/' ) . "\s*/s";
        $new_content = preg_replace( $pattern, '', $content );

        if ( null === $new_content ) {
            return;
        }

        if ( ! $this->write_htaccess( $new_content ) ) {
            $this->queue_admin_notice( __( 'Unable to write to .htaccess. Please check file permissions.', 'studiare' ), 'error' );
        }
    }

    /* =========================================================================
       ADMIN NOTICES SYSTEM
       ========================================================================= */

    /**
     * Queue an admin notice to be displayed.
     *
     * @param string $message Notice text.
     * @param string $type    success|error|warning|info
     */
    protected function queue_admin_notice( $message, $type = 'error' ) {
        $type = in_array( $type, array( 'error', 'warning', 'success', 'info' ), true ) ? $type : 'error';
        self::$admin_notices[] = compact( 'message', 'type' );
    }

    /**
     * Output all queued admin notices (hooked into admin_notices).
     */
    public function display_admin_notices() {
        if ( empty( self::$admin_notices ) ) {
            return;
        }
        foreach ( self::$admin_notices as $notice ) {
            ?>
            <div class="notice notice-<?php echo esc_attr( $notice['type'] ); ?> is-dismissible">
                <p><?php echo esc_html( $notice['message'] ); ?></p>
            </div>
            <?php
        }
        // Clear after rendering
        self::$admin_notices = array();
    }
}

// Instantiate the security class
new Suncode_Security();