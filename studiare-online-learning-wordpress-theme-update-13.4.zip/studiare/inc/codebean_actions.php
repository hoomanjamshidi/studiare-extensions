<?php
/**
 * Codebean Actions File
 */

# After setup theme
function studiare_after_setup_theme() {

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	// Add support Woocommerce
	add_theme_support( 'woocommerce' );
    //add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    //add_theme_support( 'wc-product-gallery-slider' );
	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	 
	add_theme_support( 'title-tag' );

	add_image_size('studiare-image-500x350-croped', 500, 350, true);
	add_image_size('studiare-image-250x400-croped', 250, 400, true);
	add_image_size('studiare-image-420x294-croped', 420, 294, true);
	add_image_size('studiare-course-thumb', 370, 270, true);
	add_image_size('studiare-teacher-single-thumb', 400, 400, true);
	add_image_size('img-120-120', 120, 120, true );
	add_image_size('teacher-single-thumb', 800, 600, true );
	add_image_size('studiare-search-thumbnail', 220, 220, true );
	add_image_size('studiare-portfolio-grid', 470, 400,true);

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus(
		array(
			'main-menu' => esc_html__( 'Main Header Menu', 'studiare' ),
			'mobile-menu' => esc_html__('Mobile Side Menu', 'studiare' ),
			'top-bar-menu' => esc_html__('Top Bar Right Menu', 'studiare' ),
		)
	);

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support(
		'html5', array(
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		)
	);

}

# Enqueue Scritps and other stuff
if ( ! function_exists( 'studiare_wp_enqueue_scripts' ) ) {

	function studiare_wp_enqueue_scripts() {

		# Styles
		wp_register_style( 'studiare-main', get_theme_file_uri( 'assets/css/studiare.css' ), null, STUDIARE_VERSION );
		wp_register_style( 'studiare-header-style', get_theme_file_uri( 'inc/header/assets/header.css' ), null, STUDIARE_VERSION );
		if ( class_exists( 'WooCommerce' ) ) {
    		wp_register_style( 'studiare-woo', get_theme_file_uri( 'assets/css/woocommerce.css' ), null, STUDIARE_VERSION );
    		// Register WC Dashboard CSS
            wp_register_style(
                'studiare-woo-dashboard',
                get_theme_file_uri('assets/css/woocommerce-dashboard.css'),
                null,
                STUDIARE_VERSION
            );
            wp_register_style(
                'studiare-grid',
                get_theme_file_uri('assets/css/gridstack.min.css'),
                null,
                STUDIARE_VERSION
            );
            wp_register_script(
                'studiare-gridstack',
                get_theme_file_uri('assets/js/gridstack.all.js'),
                null,
                STUDIARE_VERSION
            );
            
                if ( is_account_page() ) {
                    wp_enqueue_style('studiare-woo-dashboard');
                    wp_enqueue_style('studiare-grid');
                    wp_enqueue_script( 'studiare-gridstack');
                }

		}
		

		// Theme stylesheet.
        wp_enqueue_style( 'magnific-popup', get_theme_file_uri( 'assets/css/magnific-popup.css') );
        wp_enqueue_style( 'select2', get_theme_file_uri( 'assets/css/select2.min.css') );
        wp_enqueue_style( 'owl-carousel', get_theme_file_uri( 'assets/css/owl.carousel.min.css' ) );
		
       
		
		wp_enqueue_style( 'studiare-style', get_stylesheet_uri() );
		wp_enqueue_style( 'font-awesome-css', get_theme_file_uri( 'assets/css/fonawesomeall.min.css' ) );

		wp_enqueue_style( 'sc-min-hint', get_theme_file_uri( 'assets/css/sc-min-hint.css' ) );
        wp_enqueue_style( 'toastr', get_theme_file_uri( 'assets/css/toastr.css' ) );
		

		// Inlise style from settings
		wp_add_inline_style( 'studiare-style', studiare_settings_css() );
		

     

		# Styles
		wp_enqueue_style('studiare-main');
		if ( class_exists( 'WooCommerce' ) ) {
            wp_enqueue_style( 'studiare-woo' );
        }

		# Scripts
		$google_api_key = '';

		if ( class_exists( 'Redux' ) ) {
		    $google_api_key = codebean_option( 'google_api_key' );
        }

		if( !empty($google_api_key) ) {
			$google_api_map = 'https://maps.googleapis.com/maps/api/js?key='.$google_api_key.'&';
		} else {
			$google_api_map = 'https://maps.googleapis.com/maps/api/js?';
		}

		wp_register_script('gmaps', $google_api_map . '&language=' . get_bloginfo( 'language' ), array( 'jquery' ), '', true );
		wp_register_script('studiare-theme', get_theme_file_uri( 'assets/js/global.js' ), array( 'jquery' ), STUDIARE_VERSION,true );
		wp_register_script('studiare-header', get_theme_file_uri( 'inc/header/assets/header.js' ), array( 'jquery' ), STUDIARE_VERSION,true );
		

        wp_enqueue_script( 'magnific-popup', get_theme_file_uri( 'assets/js/vendor/jquery.magnific-popup.min.js'), array('jquery'), '', true );

        wp_enqueue_script( 'select2', get_theme_file_uri( 'assets/js/vendor/select2.min.js' ), array( 'jquery' ), STUDIARE_VERSION, true );
        wp_enqueue_script( 'theia-sticky-sidebar', get_theme_file_uri( 'assets/js/vendor/theia-sticky-sidebar.min.js' ), array( 'jquery' ), '', true );
        if (post_type_exists('portfolio') && is_post_type_archive('portfolio')) {
            wp_enqueue_script('mixitup', get_theme_file_uri('assets/js/vendor/mixitup.min.js'), array('jquery'), '', true);
        }
        wp_enqueue_script( 'appear', get_theme_file_uri( 'assets/js/vendor/jquery.appear.js'), array( 'jquery' ), '', true );
        wp_enqueue_script( 'owl-carousel', get_theme_file_uri( 'assets/js/vendor/owl.carousel.min.js' ), array( 'jquery' ), '2.3.4', true );
		wp_enqueue_script( 'imagesLoaded', get_theme_file_uri( 'assets/js/vendor/imagesloaded.pkgd.min.js' ), array('jquery'), '', true );
        wp_enqueue_script( 'packery', get_theme_file_uri( 'assets/js/vendor/packery.pkgd.min.js' ), array('jquery'), '4.2.1', true );
		wp_enqueue_script( 'countTo', get_theme_file_uri( 'assets/js/vendor/jquery.countTo.js'), array( 'jquery' ), '', true );
		wp_enqueue_script( 'countdown', get_theme_file_uri( 'assets/js/vendor/countdown.js'), array( 'jquery' ), '', true );
		
        wp_enqueue_script( 'studiare-theme');
        wp_localize_script( 'studiare-theme', 'loginAjax', array(
            'ajax_url'  => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce('load_login_popup_nonce'),
        ));

		wp_enqueue_script( 'toastr', get_theme_file_uri( 'assets/js/vendor/toastr.js' ), array( 'jquery' ), '',true );

		$translations = array(
			'countdown_days' => esc_html__('days', 'studiare'),
			'countdown_hours' => esc_html__('hours', 'studiare'),
			'countdown_mins' => esc_html__('minutes', 'studiare'),
			'countdown_sec' => esc_html__('seconds', 'studiare'),
		);

		wp_localize_script( 'studiare-theme', 'studiare_options', $translations );
		wp_localize_script('studiare-theme', 'SC_Notif', [
            'ajaxurl'   => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('sc_notif_nonce'),
            'logged_in' => is_user_logged_in() ? 1 : 0,
            
            'i18n'      => [
                'login_required' => esc_html__('Please login to show notifications', 'studiare'),
            ]
        ]);

		if ( is_single() ) {
			if ( comments_open() ) {
				wp_enqueue_script( 'comment-reply' );
			}
        }

		# Dequeue Script & CSS OWL carousel of WP Events Manager plugin.
		if ( ! is_singular( 'tp_event' ) ) {
			wp_dequeue_script( 'wpems-countdown-js' );
			wp_dequeue_script( 'wpems-countdown-plugin-js' );
		}
		wp_dequeue_script( 'wpems-owl-carousel-js' );
		wp_dequeue_style( 'wpems-owl-carousel-css' );
		wp_dequeue_style( 'wpems-magnific-popup-css' );
		wp_dequeue_script( 'wpems-magnific-popup-js' );

		if ( is_singular( 'tp_event' ) ) {
			wp_dequeue_script( 'countdown' );
		}
	}
}

# Register widget area.
function studiare_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Blog Sidebar', 'studiare' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here to appear in your sidebar on blog archive pages.', 'studiare' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'   => '</h5>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Blog Single Sidebar', 'studiare' ),
			'id'            => 'sidebar-2',
			'description'   => esc_html__( 'Add widgets here to appear in your sidebar on single blog posts.', 'studiare' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'   => '</h5>',
		)
	);

	for ($footer = 1; $footer < 5; $footer++) {
		register_sidebar(array(
			'id'            => 'studiare-footer-' . $footer,
			'name'          => esc_html__('Footer ', 'studiare') . $footer,
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'   => '</h5>',
		));
	}

	if ( class_exists( 'WooCommerce' ) ) {
		register_sidebar( array(
			'id'            => 'sidebar_shop',
			'name'          => esc_html__('Shop Sidebar', 'studiare'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'   => '</h5>',
		) );
	}
	if ( class_exists( 'WooCommerce' ) ) {
		register_sidebar( array(
			'id'            => 'singleshop',
			'name'          => esc_html__('Single Shop Sidebar', 'studiare'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h5 class="widget-title">',
			'after_title'   => '</h5>',
		) );
	}

	if ( class_exists( 'WPEMS') ) {
	    register_sidebar( array(
            'id'            => 'sidebar_events',
            'name'          => esc_html__( 'Events Sidebar', 'studiare' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h5 class="widget-title">',
            'after_title'   => '</h5>',
        ) );
    }

}

add_action( 'widgets_init', 'studiare_widgets_init' );

# Post Navigation
function studiare_post_nav() {
	$prev = get_previous_post();
	$next = get_next_post();

	?>
	<div class="post-nav">
		<div class="post-nav-btn prev-btn">
			<?php if ($prev) { ?>
				<a href="<?php echo esc_url( get_permalink($prev->ID) ); ?>" class="post-nav-link prev">
					<?php get_template_part( 'assets/images/arrow-prev.svg' ); ?>
					<span><?php esc_html_e('Newer', 'studiare'); ?></span>
					<strong><?php echo esc_html($prev->post_title); ?></strong>
				</a>
			<?php } ?>
		</div>

		<div class="post-nav-btn next-btn">
			<?php if ($next) { ?>
				<a href="<?php echo esc_url( get_permalink($next->ID) ); ?>" class="post-nav-link next">
					<?php get_template_part( 'assets/images/arrow-next.svg' ); ?>
					<span><?php esc_html_e('Older', 'studiare'); ?></span>
					<strong><?php echo esc_attr($next->post_title); ?></strong>
				</a>
			<?php } ?>
		</div>
	</div>
	<?php

}

add_action( 'studiare_post_nav', 'studiare_post_nav', 3, 3 );

# Pre-loader
if ( ! function_exists( 'studiare_preloader' ) ) {
    function studiare_preloader() {
        if ( is_admin() || isset($_GET['elementor-preview']) || is_customize_preview() ) {
            return;
        }

        $preloader = false;

        if ( class_exists('Redux' ) ) {
            $preloader = codebean_option('studiare_preloader');
        }

        if ($preloader) {
            echo '<div class="studiare-preloader">';
            studiare_preloader_icon();

            if (class_exists('Redux')) {
                $preloader_text = codebean_option('preloader_text');
                if (!empty($preloader_text)) {
                    echo '<div class="studiare-preloader-text">' . esc_html($preloader_text) . '</div>';
                }
            }

            echo '</div>';
        }
    }

    add_action( 'studiare_before_body', 'studiare_preloader', 10 );
}

# Pre-loader icon
if ( ! function_exists( 'studiare_preloader_icon' ) ) {
    function studiare_preloader_icon() {
        $loading_icon = '';

        if ( class_exists('Redux' ) ) {
            $loading_icon = codebean_option('preloader_icon');

        }

	    echo '<div class="studiare-preloader-icon">';

	    switch ( $loading_icon ) {
		    case 'custom-image':
		        $loading_image = '';

		        if ( class_exists('Redux' ) ) {
			        $loading_image = codebean_option('custom_preloader_image');
			        ?>

                        <div style="text-align:center">
                            
                            <div class="sc-img-glow">
                            <?php if(!empty(codebean_option('custom_preloader_image')['thumbnail'])){ 
                              $img_login_src = codebean_option('custom_preloader_image')['url'];
                              }
                              else{
                                $img_login_src = get_template_directory_uri()."/assets/images/logo_default.svg";
                              }
                            ?>
                         <img <?php list($width, $height) = getimagesize($img_login_src);?> width ="<?php echo $width;?>" height ="<?php echo $height;?>" src="<?php echo $img_login_src;?>"></div>
                             
                        </div>
                        <?php
                }

			    
			    break;
		    default:
			    include locate_template( 'inc/templates/preloader/' . $loading_icon . '.php' );
			    break;
	    }

	    echo '</div>';

    }
}

# Mobile Navigation
if ( ! function_exists( 'studiare_mobile_nav' ) ) {
    function studiare_mobile_nav() {
        get_template_part( 'inc/templates/mobile-nav' );
    }

    add_action( 'studiare_before_body', 'studiare_mobile_nav', 20 );
}

/**
 * ------------------------------------------------------------------------------------------------
 * Enqueue google fonts
 * ------------------------------------------------------------------------------------------------
 */
if( ! function_exists( 'codebean_enqueue_google_fonts' ) ) {
	add_action( 'wp_enqueue_scripts', 'codebean_enqueue_google_fonts', 10000 );

	function codebean_enqueue_google_fonts() {
		$default_google_fonts = 'Nunito:200,300,400,500,600,700';

		if( ! class_exists('Redux') )
			wp_enqueue_style( 'codebean-google-fonts', codebean_get_fonts_url( $default_google_fonts ), array(), '1.0.0' );
	}
}

/**
 * ------------------------------------------------------------------------------------------------
 * Get google fonts URL
 * ------------------------------------------------------------------------------------------------
 */
if( ! function_exists( 'codebean_get_fonts_url') ) {
	function codebean_get_fonts_url( $fonts ) {
		$font_url = '';

		$font_url = add_query_arg( 'family', urlencode( $fonts ), "//fonts.googleapis.com/css" );

		return $font_url;
	}
}

/**
 * Studiare Favicon
 */
function studiare_favicon() {

	if ( function_exists( 'has_site_icon' ) && has_site_icon() ) return '';

	// Get the favicon.
	$favicon = get_parent_theme_file_uri('assets/images/icons/favicon.png' );

	// Get the custom touch icon.
	$touch_icon = get_parent_theme_file_uri('assets/images/icons/apple-touch-icon.png' );

	if ( class_exists('Redux') ) {

		$fav_uploaded = codebean_option('favicon');
		if(isset($fav_uploaded['url']) && $fav_uploaded['url'] != '') {
			$favicon = $fav_uploaded['url'];
		}

		$fav_uploaded_retina = codebean_option( 'favicon_retina' );
		if(isset($fav_uploaded_retina['url']) && $fav_uploaded_retina['url'] != '') {
			$touch_icon = $fav_uploaded_retina['url'];
		}

	}

	?>
    <link rel="shortcut icon" href="<?php echo esc_url($favicon); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="<?php echo esc_url($touch_icon); ?>">
	<?php

}

add_action( 'wp_head', 'studiare_favicon', 10 );
add_action( 'admin_head', 'studiare_favicon', 10 );

/**
 * After Content Import
 */
if ( ! function_exists( 'studiare_after_content_import' ) ) {
	function studiare_after_content_import( $demo_active_import , $demo_directory_path ) {

		reset( $demo_active_import );
		$current_key = key( $demo_active_import );

		$locations = get_theme_mod('nav_menu_locations');
		$menus  = wp_get_nav_menus();

		if(!empty($menus)) {
			foreach($menus as $menu)
			{
				if(is_object($menu) && $menu->name == 'Main Header Menu')
				{
					$locations['main-menu'] = $menu->term_id;
				}
				if(is_object($menu) && $menu->name == 'Mobile Side Menu')
				{
					$locations['mobile-menu'] = $menu->term_id;
				}
				
			}
		}

		set_theme_mod('nav_menu_locations', $locations);

		update_option( 'show_on_front', 'page' );

		$front_page = get_page_by_title( 'Home' );
		if ( isset( $front_page->ID ) ) {
			update_option( 'page_on_front', $front_page->ID );
		}

		$blog_page = get_page_by_title( 'Blog' );
		if ( isset( $blog_page->ID ) ) {
			update_option( 'page_for_posts', $blog_page->ID );
		}

		if ( class_exists( 'RevSlider' ) ) {

			$wbc_sliders_array = array(
				'demo' => 'studiare-slider.zip',
			);
			if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_sliders_array ) ) {
				$wbc_slider_import = $wbc_sliders_array[$demo_active_import[$current_key]['directory']];
				if ( file_exists( $demo_directory_path.$wbc_slider_import ) ) {
					$slider = new RevSlider();
					$slider->importSliderFromPost( true, true, $demo_directory_path.$wbc_slider_import );
				}
			}
		}

	}

	add_action( 'wbc_importer_after_content_import', 'studiare_after_content_import', 10, 2 );
}