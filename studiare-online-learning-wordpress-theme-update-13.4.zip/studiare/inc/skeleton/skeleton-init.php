<?php
/**
 * Studiare Skeleton System
 * Core init file
 */

if ( ! defined('ABSPATH') ) {
    exit;
}

/**
 * Check skeleton activation safely
 */
function studiare_skeleton_is_active() {

    if ( ! function_exists('codebean_option') ) {
        return false;
    }

    if ( ! class_exists('Redux') ) {
        return false;
    }

    return codebean_option('studiare_enable_skeleton') == 1;
}

/**
 * Enqueue Skeleton Assets
 */
add_action( 'wp_enqueue_scripts', function() {

    if ( ! studiare_skeleton_is_active() ) {
        return;
    }

    $theme   = wp_get_theme();
    $version = $theme->get('Version');

    wp_enqueue_style(
        'studiare-skeleton',
        get_theme_file_uri( 'assets/css/studiare-skeleton.css' ),
        array(),
        $version
    );

    wp_enqueue_script(
        'studiare-skeleton',
        get_theme_file_uri( 'assets/js/studiare-skeleton.js' ),
        array(),
        $version,
        true
    );

}, 20 );

