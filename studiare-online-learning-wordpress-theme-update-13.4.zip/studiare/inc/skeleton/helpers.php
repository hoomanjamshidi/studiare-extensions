<?php
// Get animation type from Redux
function studiare_skeleton_get_animation() {
    if ( class_exists('Redux') ) {
        return codebean_option('studiare_skeleton_animation');
    }
    return 'slide';
}

// Get skeleton height (product > redux > fallback)
function studiare_skeleton_get_height( $post_id = null ) {
    $post_id = $post_id ? $post_id : get_the_ID();

    $meta_height = get_post_meta( $post_id, '_studiare_skeleton_height', true );
    if ( is_numeric($meta_height) && $meta_height > 0 ) {
        return (int) $meta_height;
    }

    if ( class_exists('Redux') ) {
        return (int) codebean_option('studiare_skeleton_default_height');
    }

    return 260;
}
