<?php

$roadmap_filters = 'left';
$roadmap_col = 'three';
$roadmap_orderby = 'date';
$roadmap_order = 'DESC';
$roadmap_pagination = true;
$posts_per_page = 9;



$roadmap_holder_class = array('roadmap-holder roadmap-masonry');
$roadmap_holder_class[] = 'roadmap-' . $roadmap_col . '-col';

$paged = get_query_var( 'paged', 1 );

$args = array(
	'post_type' => 'studi_roadmap',
	'orderby' => $roadmap_orderby,
	'order' => $roadmap_order,
	'posts_per_page' => $posts_per_page,
	'paged' => $paged
);

//$i = 0;

$roadmap_query = new WP_Query( $args );

?>
<div class="main-page-content default-margin" id="content">
    <div class="site-content-inner container" role="main">

        <?php if ( $roadmap_query->have_posts() ) : ?>

            <div class="roadmap-archive ">

                <!-- roadmap Loop -->
                <div class="roadmap-items-holder">
                    <div class="<?php echo implode( ' ', apply_filters( 'studiare_roadmap_holder_class', $roadmap_holder_class ) ); ?>">

		                <?php while ( $roadmap_query->have_posts() ) : $roadmap_query->the_post(); ?>

			                <?php get_template_part( 'inc/templates/roadmap/roadmap-item' ); ?>

		                <?php  endwhile; ?>

                    </div>

	                <?php if ( $roadmap_pagination ) {
		                echo paginate_links( array(
			                'type'      => 'list',
			                'total'     => $roadmap_query->max_num_pages,
			                'prev_text' => '<i class="fal fa-angle-left"></i>',
			                'next_text' => '<i class="fal fa-angle-right"></i>',
		                ) );
	                } ?>
                </div>

	            

            </div>

        <?php else : ?>

            <?php get_template_part( 'inc/templates/not-found' ); ?>

        <?php endif; ?>

    </div>
</div>
