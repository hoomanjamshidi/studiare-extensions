<?php

$classes = array();
$classes[] = 'roadmap-entry mix';

$post_id      = get_the_ID();
$roadmap_data = get_post_meta( $post_id, 'roads_group', true );

if ( ! is_array( $roadmap_data ) ) {
    $roadmap_data = array();
}

$discount        = get_post_meta( $post_id, 'st_rm_discount', true ) ?: 0;
$duration        = get_post_meta( $post_id, 'st_rm_duration', true ) ?: 0;
$number_of_steps = count( $roadmap_data );
$link            = esc_url( get_permalink() );

?>
<style>
    .roadmap-entry-inner {  padding: 10px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 66px #adbcc838 ; } 
    .rm_item span {  padding: 0 5px; margin: 0 5px; border-radius: 3px;  background: color-mix(in srgb, var(--primary_color) 10%, transparent) ; color: var(--primary_color); }
    .rm-thumb-inner img { width: 100%; border-radius: 10px;aspect-ratio: 16 / 9; }
    .roadmap-entry-thumb { width: 25%; }
    .roadmap-infos { width: 75%; justify-content: space-between;}
    .roadmap-steps { border-bottom: 1px dashed gainsboro; padding-bottom: 10px; margin-bottom: 10px; }
    .rm-data-icons { padding: 10px; text-align: center;min-width:100px; }
    .roadmap-bottom-info { align-items: center; }
    .rm-data-icons p { color: #3d3d3d; font-size: 14px; }
    @media screen and (max-width: 426px){
        .roadmap-entry-inner { flex-direction: column; gap: 15px; }
        .roadmap-steps { flex-direction: column; }
        .roadmap-bottom-info { flex-direction: column; align-items: flex-start; }
        .roadmap-entry-thumb { width: 100%; }
        .roadmap-infos { width: 100%; }
    }
    
    .st_standard_icon{align-items: center; display: inline-flex; justify-content: center;}
    
</style>
<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
    <div class="roadmap-entry-inner flex gap-4">

	    <?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
            <div class="roadmap-entry-thumb">
                
                <figure class="rm-thumb-inner">
                    <a href="<?php echo esc_url( get_permalink() ); ?>" class="roadmap-thumb-link" aria-label="<?php the_title(); ?>">
			            <?php the_post_thumbnail('large' ); ?>
                    </a>
                </figure>
                
            </div>
        <?php endif; ?>
        
        <div class="roadmap-infos flex flex-col">
            <h2 class="roadmap-entry-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h2>
            <div class="roadmap-steps flex gap-3">
                    <?php 
                    $i = 1;
                    
                    if ( ! empty( $roadmap_data ) && is_array( $roadmap_data ) ) {
                        foreach ( $roadmap_data as $road ) {
                            if ( $i <= 3 && ! empty( $road['course'] ) ) {
                                $course  = absint( $road['course'] );
                                $product = wc_get_product( $course );
                    
                                if ( $product ) {
                                    $pname = $product->get_name();
                    
                                    echo '<div class="rm_item"><span>' . esc_html( $i ) . '</span>' . esc_html( $pname ) . '</div>';
                    
                                    $i++;
                                }
                            }
                        }
                    }
                    ?>

                    
            </div>
            <div class="roadmap-bottom-info flex justify-between">
                
                <div class="flex">
                    <div class="rm-data-icons">
                        <span class="st_standard_icon" style="width:24px;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="1em" fill="#3d3d3d" viewBox="0 0 24 24" fill-opacity=".6" style="--svg-origin-width:1000;--svg-origin-width--with-unit:1000px;" data-svg-origin-width="1000" data-svg-origin-height="" font-size="1000"><path fill-rule="evenodd" d="M1.75 3.5a.75.75 0 0 1 .75-.75H8a4.75 4.75 0 0 1 4.75 4.75V21a.75.75 0 0 1-1.5 0A2.25 2.25 0 0 0 9 18.75H2.5a.75.75 0 0 1-.75-.75zm9.5 14.5V7.5A3.25 3.25 0 0 0 8 4.25H3.25v13H9c.844 0 1.623.279 2.25.75" clip-rule="evenodd"></path><path fill-rule="evenodd" d="M11.25 7.5A4.75 4.75 0 0 1 16 2.75h5.5a.75.75 0 0 1 .75.75V18a.75.75 0 0 1-.75.75H15A2.25 2.25 0 0 0 12.75 21a.75.75 0 0 1-1.5 0zm1.5 10.5a3.73 3.73 0 0 1 2.25-.75h5.75v-13H16a3.25 3.25 0 0 0-3.25 3.25z" clip-rule="evenodd"></path></svg>
                        </span>
                        <?php echo "<p>".sprintf(__('%s Courses','studiare'),$number_of_steps)."</p>"; ?>
                    </div>
                    <div class="rm-data-icons">
                        <span class="st_standard_icon" style="width:24px;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="1em" fill="#3d3d3d" viewBox="0 0 24 24" fill-opacity=".6" style="--svg-origin-width:1000;--svg-origin-width--with-unit:1000px;" data-svg-origin-width="1000" data-svg-origin-height="" font-size="1000"><path fill-rule="evenodd" d="M1.25 12C1.25 6.063 6.063 1.25 12 1.25S22.75 6.063 22.75 12 17.937 22.75 12 22.75 1.25 17.937 1.25 12M12 2.75a9.25 9.25 0 1 0 0 18.5 9.25 9.25 0 0 0 0-18.5" clip-rule="evenodd"></path><path fill-rule="evenodd" d="M12.004 5.25a.75.75 0 0 1 .75.75v5.694l4.02 4.02a.75.75 0 1 1-1.061 1.06l-4.24-4.24a.75.75 0 0 1-.22-.53L11.254 6a.75.75 0 0 1 .75-.75" clip-rule="evenodd"></path></svg>
                        </span>
                        <?php echo "<p>".sprintf(__('%s Hours','studiare'),$duration)."</p>"; ?>
                    </div>
                </div>
            
                <?php
                if ( ! empty( $roadmap_data ) && is_array( $roadmap_data ) ) {
                    $ids = array();
                
                    foreach ( $roadmap_data as $item ) {
                        if ( ! empty( $item['course'] ) ) {
                            $ids[] = absint( $item['course'] );
                        }
                    }
                
                    if ( ! empty( $ids ) ) {
                        $ids = implode( ',', $ids );
                
                        echo do_shortcode(
                            '[st_bundle_add_to_cart ids="' . esc_attr( $ids ) . '" discount="' . esc_attr( $discount ) . '" mode="view" link="' . esc_url( $link ) . '"]'
                        );
                    }
                }
                ?>

            </div>    
        </div>

    </div>
</article>
