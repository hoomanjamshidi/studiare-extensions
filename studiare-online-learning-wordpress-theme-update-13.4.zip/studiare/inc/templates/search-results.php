<?php
/**
 * Page template for search results
 */
?>
<style>
        .sas_form input[type="submit"] { margin-right: 10px; }
        .sas_ptypes { display: flex ;  margin-top: 25px; }
        .sas_ptypes label { display: flex ; align-items: center; }
        .sas_ptypes label input { margin: 0 10px !important; }
        .sas_form { display: flex ; justify-content: space-between; }
        ul.sas_rholder { margin: 0; }
        ul.sas_rholder li { margin: 10px ; padding: 10px; border-radius: 5px; border: 1px solid var(--primary_color); position: relative; overflow: hidden;display: inline-flex ; justify-content: space-between; width: calc(33% - 20px);}
        img.sas_img { max-width: 80px; border-radius: 5px; box-shadow: -4px 4px #3f3d4112; }
        ul.sas_rholder li a { display: flex ; align-items: center; z-index: 1; position: relative;width: 100%;}
        .sas_pagination { text-align: center; }
        .sas_pagination .page-numbers { border: 1px solid gainsboro; padding: 3px; margin: 0 2px; min-width: 36px; display: inline-block; border-radius: 3px; }
        .sas_pagination .page-numbers.current, .sas_pagination .page-numbers:hover { background: var(--primary_color); color: #fff; border-color: var(--primary_color); }
        ul.sas_rholder li:hover .sas_image-container { transform: skewX(-10deg); }
        .sasr_title{transition:.4s;}
        i.sas_read { position: absolute; bottom: 20px; left: 45px; transition: .4s; background: var(--primary_color); padding: 10px 14px; border-radius: 138px; color: #fff; transform: skewX(10deg); }
        ul.sas_rholder li:hover i.sas_read { left: -100%;  }
        ul.sas_rholder li:hover .sasr_title{transform: translate(8px, -10px);}
        .sasr_bg { position: absolute; left: 0; top: 0; bottom: 0; right: 0; background-repeat: no-repeat !important; background-size: cover !important; filter: blur(15px); opacity: .05;z-index:0; background-position: center !important;}
        @media screen and (max-width:1000px){ul.sas_rholder li { width: 100%; }}
        .sas_image-container { position: relative; display: inline-block;    padding: 10px;transition:.4s; }
        .sas_border-image { display: block; max-width: 100px; position: relative; z-index: 1; border-radius: 5px; }
        .sas_border-overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-size: cover; background-blur: 5px; filter: blur(10px); pointer-events: none; z-index: 0; opacity: 0.3; }
        
        .stas_filters {    margin-top: 10px;}
        .sas_filterby.sasf_active { background: var(--primary_color); color: #fff; }
        .sas_filterby { border: 2px solid var(--color-neutral-100); border-radius: 5px; min-width: 50px; margin-top: 10px; margin-inline-end: 10px; text-align: center; padding: 3px 15px; display: inline-block; line-height: 2.75; }
        .search ul.page-numbers { margin: 20px 0; }
        .sas_badge { background: var(--color-neutral-200); padding: 0px 5px; border-radius: 4px; margin-inline-start: 5px; color: var(--color-neutral-400); }
        .sas_filterby.sasf_active .sas_badge { background: var(--secondary_color); color: #fff; }
        .sas_filterby.sas_disabled { pointer-events: none; opacity: 0.75; cursor: default; }
    </style>
<div class="main-page-content default-margin" id="content">
<div class="site-content-inner container" role="main">
<div class="studiare-search-results-wrapper">

<div class="search-results-main">
<?php
// Read options
$show_filters       = (bool) codebean_option('sp_show_filters', true);
$show_empty_filters = (bool) codebean_option('sp_show_empty_filters', true);
$show_counts        = (bool) codebean_option('sp_show_filter_counts', true);
get_template_part('searchform'); 
/* =======================================
   LOAD SEARCH QUERY
   ======================================= */
$search_query = get_search_query();

// --- Default post types ---
$post_types = [
    'post'     => __("Post","studiare"),
    'product'  => __("Product","studiare"),
    'page'     => __("Page","studiare"),
    'tp_event' => __("Event","studiare"),
];


// Override with Redux sorter
if (class_exists('Redux')) {
    $pt_arr = codebean_option("sp_post_types");
    if (!empty($pt_arr['enabled'])) {
        $post_types = $pt_arr['enabled'];
        unset($post_types['placebo']);
    }
}

// Merge custom post types from textarea
$custom_raw = codebean_option('sp_custom_post_types', '');
if (!empty($custom_raw)) {
    foreach (explode("\n", $custom_raw) as $line) {
        $line = trim($line);
        if (!$line) continue;
        $parts = explode('|', $line, 2);
        $slug  = sanitize_key($parts[0]);
        $label = isset($parts[1]) ? sanitize_text_field($parts[1]) : $slug;
        if ($slug && !isset($post_types[$slug])) {
            $post_types[$slug] = $label;
        }
    }
}

$allowed_types = array_keys($post_types);

/* =======================================
   Detect current selected post_type
   ======================================= */
$current_type = isset($_GET['post_type']) ? sanitize_text_field($_GET['post_type']) : 'all';
if ($current_type !== 'all' && !in_array($current_type, $allowed_types, true)) {
    $current_type = 'all';
}

/* =======================================
   ONE SINGLE QUERY FOR ALL COUNTS
   ======================================= */
$count_query = new WP_Query([
    'post_type'      => $allowed_types,
    's'              => $search_query,
    'posts_per_page' => -1,
    'fields'         => 'ids',
    'no_found_rows'  => true,  // speed boost
]);

$type_counts = array_fill_keys($allowed_types, 0);
$total_count = 0;

/* Count results per post type */
if (!empty($count_query->posts)) {
    foreach ($count_query->posts as $post_id) {

        $pt = get_post_type($post_id);
        if (isset($type_counts[$pt])) {
            $type_counts[$pt]++;
            $total_count++;
        }
    }
}

wp_reset_postdata();

/* =======================================
   SORT POST TYPES
   - Highest count first
   - Zero results last
   ======================================= */
uksort($post_types, function ($a, $b) use ($type_counts) {

    $countA = $type_counts[$a] ?? 0;
    $countB = $type_counts[$b] ?? 0;

    if ($countA === 0 && $countB !== 0) return 1;
    if ($countB === 0 && $countA !== 0) return -1;

    return $countB <=> $countA;
});
?>

<?php if (have_posts()) : ?>

<div class="studiare_advanced_search">

    <!-- Filters -->
    <?php if ($show_filters) : ?>
        <div class="stas_filters mb-10">
        
            <?php
            // "All" link
            $all_active = ($current_type === 'all') ? 'sasf_active' : '';
            $all_badge  = $show_counts ? "<span class='sas_badge'>{$total_count}</span>" : '';
            echo "<a class='sas_filterby $all_active' href='?s=".urlencode($search_query)."&post_type=all'>
                    ".__('All','studiare')." $all_badge
                  </a>";
        
            foreach ($post_types as $pt => $label) {
                $badge  = $type_counts[$pt] ?? 0;
                $active = ($current_type === $pt) ? 'sasf_active' : '';
        
                // Skip zero-result filters if option is off
                if ($badge === 0 && !$show_empty_filters) continue;
        
                $badge_html = $show_counts ? "<span class='sas_badge'>{$badge}</span>" : '';
        
                if ($badge === 0) {
                    echo "<span class='sas_filterby sas_disabled $active'>".esc_html($label)." $badge_html</span>";
                } else {
                    echo "<a class='sas_filterby $active' href='?s=".urlencode($search_query)."&post_type={$pt}'>
                            ".esc_html($label)." $badge_html
                          </a>";
                }
            }
            ?>
        
        </div>
    <?php endif; ?>


    <!-- Results List -->
    <ul class="sas_rholder">

    <?php while (have_posts()) : the_post();

        $image = has_post_thumbnail()
            ? get_the_post_thumbnail_url(get_the_ID(), 'thumbnail')
            : get_template_directory_uri()."/assets/images/no-image.jpg";
    ?>

        <li class="sas_result" data-sasptype="<?php echo esc_attr(get_post_type()); ?>">
            <div class="sasr_bg" style="background:url('<?php echo esc_url($image); ?>')"></div>

            <a href="<?php the_permalink(); ?>">

                <div class="sas_image-container">
                    <i class="sas_read fal fa-chevron-left"></i>
                    <img src="<?php echo esc_url($image); ?>" class="sas_border-image">
                    <div class="sas_border-overlay"
                         style="background-image:url('<?php echo esc_url($image); ?>')"></div>
                </div>

                <span class="sasr_title"><?php the_title(); ?></span>
            </a>
        </li>

    <?php endwhile; ?>

    </ul>

    <!-- Pagination -->
    <div class="studiare-pagination-holder">
        <?php
        $pagination_base = home_url( '/' ) . '?s=' . urlencode( $search_query ) . '&post_type=' . urlencode( $current_type ) . '%_%';
        
        echo paginate_links( [
            'base'      => $pagination_base,
            'format'    => '&paged=%#%',
            'total'     => $wp_query->max_num_pages,
            'current'   => max( 1, get_query_var( 'paged' ) ),
            'type'      => 'list',
            'prev_text' => '<i class="fal fa-angle-left"></i>',
            'next_text' => '<i class="fal fa-angle-right"></i>',
        ] );
        ?>
    </div>

</div>

<?php else: ?>

    <?php get_template_part('/inc/templates/not-found'); ?>

<?php endif; ?>


</div>
</div>
</div>
</div>
