<?php
			if ( class_exists('Redux') ) {
				$blog_pro_image_size = codebean_option('blog_pro_image_size')?:"studiare-image-420x294-croped";
			}


			?>
			<div class="studi_blog_list_card_holder" id="post-<?php the_ID(); ?>">
    			<div class="studi_blog_list_card">
                  <div class="studi_blog_list_card_img_block">
                    <?php the_post_thumbnail($blog_pro_image_size, array('class'=>'img-fluid')); ?>
                    <?php if($args['sc_show_date'] == 'true'){?> <p class="studi_pdate"><?php echo get_the_date(); ?></p> <?php } ?>
                  </div>
                  <div class="studi_blog_list_card_text_block ">
                   
                <div class="st_tobbox_con_rp">
                    <h5 ><a class="studi_blog_list_title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                    <p class="studi_bt_ex"><?php if($args['sc_show_description'] == 'true'){ the_excerpt();} ?></p>
                    <div class="sc_tbtm_info flex items-center justify-between gap-2">
                      <div class="sc_pauthor flex items-center gap-1">
                        <?php if($args['sc_show_author'] == 'true'){?>    
                         <?php
        					$author_bio_avatar_size = apply_filters('goseowp_author_bio_avatar_size', 60);
        
                            $author_id = get_the_author_meta('ID');
                            
                            $author_picture = get_user_meta($author_id, 'profile_picture', true);
                            
                            if (!empty($author_picture)) {
                                echo '<img src="' . esc_url($author_picture) . '" alt="Author Avatar" class="mask-is-squircle avatar" width="' . $author_bio_avatar_size . '" height="' . $author_bio_avatar_size . '" />';
                            } else {
                                echo get_avatar(get_the_author_meta('user_email'), $author_bio_avatar_size, '', '', array('class' => 'avatar'));
                            }
        				?>
                        <h6 class="mb-0"><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author"><?php echo get_the_author(); ?></a></h6>
                     <?php } ?> 
                      </div>
                      
                      <?php 
                      $sc_readmore_label = !empty($args['sc_readmore_txt'])?$args['sc_readmore_txt']:__('Read More','studiare');
                      if($args['sc_show_readmore'] == 'true'){?> <a class="flex items-center gap-1.5" href="<?php the_permalink(); ?>"><span><?php echo $sc_readmore_label ; ?></span> <i class="fal fa-chevron-left"></i></a> <?php } ?>
                    </div>
                </div>
                  </div>
                </div>
            </div>
<?php
			/* end suncode postgrid */

?>
