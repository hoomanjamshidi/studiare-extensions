<?php

$blog_grid_columns = 'two';
$blog_show_date = true;
$blog_show_author = true;
$blog_show_excerpt = true;
$blog_show_categories = true;
$blog_show_comments = true;
$blog_comments_linked = true;
$blog_pro_image_size = 'studiare-image-420x294-croped';

if ( class_exists( 'Redux' ) ) {
	$blog_grid_columns     = codebean_option( 'blog_grid_columns' );
	$blog_show_date        = codebean_option( 'blog_show_date' );
	$blog_show_author      = codebean_option( 'blog_show_author' );
	$blog_show_excerpt     = codebean_option( 'blog_show_excerpt' );
	$blog_show_categories  = codebean_option( 'blog_show_categories' );
	$blog_show_comments    = codebean_option( 'blog_show_comments' );
	$blog_comments_linked  = codebean_option( 'blog_comments_linked' );
	$blog_pro_image_size   = codebean_option( 'blog_pro_image_size' ) ? : 'studiare-image-420x294-croped';
}

$categories = get_the_category();
$comments_count = get_comments_number();
?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="post-inner">

		<?php if ( has_post_thumbnail() ) : ?>
			<div class="post-thumbnail">
				<a href="<?php the_permalink(); ?>">
					<?php the_post_thumbnail( $blog_pro_image_size, array( 'class' => 'img-fluid' ) ); ?>
				</a>
			</div>
		<?php endif; ?>

		<div class="post-content">
			<?php if ( $blog_show_categories ) : ?>
				<div class="post-meta post-category">
					<?php
					if ( ! empty( $categories ) ) {
						foreach ( $categories as $category ) {
							echo '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a> ';
						}
					}
					?>
				</div>
			<?php endif; ?>

			<h4 class="entry-title">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</h4>

			<?php if ( $blog_show_excerpt ) : ?>
				<div class="the-excerpt">
					<?php the_excerpt(); ?>
				</div>
			<?php endif; ?>
			
			<div class="sc-post-footer mb-30">
			    <div class="flex flex-wrap items-center gap-3 font-smaller">
        			<?php if ( $blog_show_date ) : ?>
        				<div class="post-meta date">
        					<i class="fal fa-calendar-alt"></i>
        					<?php echo esc_html( get_the_date() ); ?>
        				</div>
        			<?php endif; ?>
        
        			<?php if ( $blog_show_author ) : ?>
        				<div class="post-meta author">
        					<i class="fal fa-user"></i>
        					<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author">
        						<?php echo esc_html( get_the_author() ); ?>
        					</a>
        				</div>
        			<?php endif; ?>
        
        			<?php if ( $blog_show_comments ) : ?>
        				<div class="post-meta comments">
        					<i class="fal fa-comments"></i>
        
        					<?php if ( $blog_comments_linked ) : ?>
        						<a href="<?php echo esc_url( get_comments_link() ); ?>">
        							<?php echo esc_html( $comments_count ); ?>
        						</a>
        					<?php else : ?>
        						<span><?php echo esc_html( $comments_count ); ?></span>
        					<?php endif; ?>
        				</div>
        			<?php endif; ?>
        		</div>
			</div>
		</div>
	</div>
</div>
