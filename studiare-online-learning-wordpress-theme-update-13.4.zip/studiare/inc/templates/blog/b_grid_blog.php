<?php
$blog_show_comments = true;
$blog_comments_linked = true;
$blog_show_author = true;
if ( class_exists( 'Redux' ) ) {
	$blog_show_comments    = codebean_option( 'blog_show_comments' );
	$blog_comments_linked  = codebean_option( 'blog_comments_linked' );
	$blog_show_author      = codebean_option( 'blog_show_author' );
}

$comments_count = get_comments_number();
$comments_text  = sprintf(
	/* translators: %s: comments count */
	_n( '%s Comment', '%s Comments', $comments_count, 'studiare' ),
	number_format_i18n( $comments_count )
);
$is_carousel = $args['is_carousel']?:"no";
$colnum = $args['colnum']?:"1";
switch($colnum){
    case 1 :
    $colname = "mainpost";
    break;
    case 2 :
    $colname = "secondpost";
    break;
    case 3 :
    $colname = "thirdpost";
    break;
    case 4 :
    $colname = "fourthpost";
    break;
    case 5 :
    $colname = "fifthpost";
    break;
    default:
    $colname = "mainpost";
}
?>

<div id="post-<?php the_ID(); ?>" <?php if($is_carousel!="no"){ post_class('post'); }else{?> class=" studigriditem <?php echo $colname;?>" <?php } ?>  >
  <div class="post-inner">
    <?php if ( has_post_thumbnail() ) : ?>
						<div class="post-thumbnail">
							<a href="<?php the_permalink(); ?>">
								<?php 
								if($colname == "mainpost"){
								    the_post_thumbnail('full'); 
								}else{
								    the_post_thumbnail('medium'); 
								}
								
								?>
							</a>
							
							<div class="post-meta post-category">
							<?php if ( ! empty( $categories ) ) {
								foreach ( $categories as $category ) {
                echo '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a> ';
            }
							} ?>
						</div>
						
						</div>
                	<?php endif; ?>
                	<div class="scpost_data <?php  if($args['sc_show_readmore'] == 'true'){echo "has_readmore";}?>">
					<div class="post-content">
						
						<h4 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
						<?php if($colname == "mainpost"){
						    $excerpt = get_the_excerpt();
						    
						    if($is_carousel!="yes"){echo $excerpt;}
						} ?>
						<div class="flex flex-wrap items-center gap-3 font-smaller">
    						<div class="post-meta date">
    							<i class="fal fa-calendar-alt"></i>
    							<?php echo get_the_date(); ?>
    						</div>
    						<?php if ( $blog_show_author ) : ?>
                				<div class="post-meta author">
                					<i class="fal fa-user"></i>
                					<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author">
                						<?php echo esc_html( get_the_author() ); ?>
                					</a>
                				</div>
                			<?php endif; ?>
    						<?php if ( $blog_show_comments ) : ?>
                				<div class="post-meta comments">
                					<i class="fal fa-comments"></i>
                
                					<?php if ( $blog_comments_linked ) : ?>
                						<a href="<?php echo esc_url( get_comments_link() ); ?>">
                							<?php echo esc_html( $comments_text ); ?>
                						</a>
                					<?php else : ?>
                						<span><?php echo esc_html( $comments_text ); ?></span>
                					<?php endif; ?>
                				</div>
                			<?php endif; ?>
            			</div>
						
					</div>
					
				</div>
				
  </div>
</div>
 
