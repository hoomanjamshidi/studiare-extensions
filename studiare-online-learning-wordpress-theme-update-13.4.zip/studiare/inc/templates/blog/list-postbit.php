<?php


$blog_show_comments = true;
$blog_comments_linked = true;
$vars = $wp_query->query_vars;

$categories = get_the_category();
if ( class_exists('Redux') ) {
    $blog_show_date = codebean_option('blog_show_date');
    $blog_show_author = codebean_option('blog_show_author');
    $blog_show_excerpt = codebean_option('blog_show_excerpt');
    $blog_show_categories = codebean_option('blog_show_categories');
    $blog_list_image_size = codebean_option('blog_list_image_size')?:"full";
	$blog_show_comments    = codebean_option( 'blog_show_comments' );
	$blog_comments_linked  = codebean_option( 'blog_comments_linked' );
}
$comments_count = get_comments_number();
$comments_text  = sprintf(
	/* translators: %s: comments count */
	_n( '%s Comment', '%s Comments', $comments_count, 'studiare' ),
	number_format_i18n( $comments_count )
);
?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="post-inner">

        <?php if ( has_post_thumbnail() ) : ?>
            <div class="post-thumbnail">
                <a href="<?php the_permalink(); ?>">
                    <?php // echo get_the_post_thumbnail( get_the_ID(), '$blog_list_image_size', array('class' => 'img-fluid') ); ?>
                    <?php
					the_post_thumbnail($blog_list_image_size, array('class'=>'img-fluid'));
					?>
                </a>
            </div>
        <?php endif; ?>

        <div class="post-content">
            
                <?php if ( $blog_show_categories ) : ?>
                <div class="post-meta post-category">
    	            <?php if ( ! empty( $categories ) ) {
    		            foreach ( $categories as $category ) {
                    echo '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a> ';
                }
    	            } ?>
                </div>
                <?php endif; ?>
                <h4 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                <?php if ( $blog_show_excerpt ) : ?>
    	        <div class="the-excerpt">
    		        <?php the_excerpt(); ?>
                </div>
                <?php endif; ?>
                <div class="flex flex-wrap items-center gap-5">
                <?php if ( $blog_show_date ) : ?>
                <div class="post-meta date">
                    <span>
                        <i class="fal fa-calendar-alt"></i>
                        <?php echo get_the_date(); ?>
                    </span>
                </div>
                <?php endif; ?>
                <?php if ( $blog_show_author ) : ?>
                <div class="post-meta author">
                      <i class="fal fa-user"></i>
    	            <?php esc_html_e('Posted by', 'studiare'); ?>
                    <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author"><?php echo get_the_author(); ?></a>
                </div>
                <?php endif; ?>
                <?php if ( $blog_show_comments ) : ?>
        				<div class="post-meta comments">
        					<i class="fal fa-comments"></i>
        
        					<?php if ( $blog_comments_linked ) : ?>
        						<a href="<?php echo esc_url( get_comments_link() ); ?>">
        							<?php echo esc_html( $comments_text ); ?>
        						</a>
        					<?php else : ?>
        						<span><?php echo esc_html( $comments_text ); ?></span>
        					<?php endif; ?>
        				</div>
        			<?php endif; ?>
        	   </div>
        </div>
    </div>
</div>
