<?php

?>
<div id="studi_rl_with_sub" class="studi_rl_with_sub">
      
        <a href="#" class="login-button btn-filled dropdown-toggle flex items-center justify-center gap-1" data-toggle="dropdown" onclick="return menuToggle(event)">
            <?php if ( $show_avatar == 1 ) { 
                $us_id = get_current_user_id();
                if ( $us_id ) { echo sc_get_profile_img( $us_id, "32" ); }
            ?> 
             
            <?php } else { ?>
                <i class="fal fa-user"></i> 
            <?php } ?>
            <span>
                <?php 
                global $current_user;
                wp_get_current_user();
                if ( is_user_logged_in() && !empty( $current_user->display_name ) && isset( $show_display_name ) && $show_display_name == 1 ) {
                    echo esc_html( $current_user->display_name );
                } else {
                    echo esc_html( !empty( $header_button_custom_text_1 ) ? $header_button_custom_text_1 : 'حساب کاربری' );
                }
                ?>
            </span>
        </a>
      
      <div class="studi_rl_sub">
          
       
        <?php /**
        if ( $settings['submenu_list'] ) { ?>
        
            <ul>
                <?php foreach (  $settings['submenu_list'] as $item ) {  //start lessons list
                			
                			$icon           = $item['icon']['value'];
                			$title          = $item['link_title']; 
                			$link          = $item['link']['url']; 
                			
                			echo "<li><a href='$link'><i class='$icon'></i> $title </a></li>";
                } ?>			
              
            </ul>
            
        <?php } 
        **/
        ?>   
        
        <!-- submneu start -->
        <?php
        $menu_location = $hb_submenu;
        /**
        if($settings['menu_id'] !=''){
            $menu_location = $settings['menu_id'];
        }
        **/
		//print_r();

		 $menu = wp_nav_menu( array( 

		                                'menu' 	=> $menu_location,
										'menu_class'      	=> '',
										'container_class'	=> '',
										'fallback_cb' 		=> 'sc_studiFrontendWalker::fallback',
										'walker' 			=> new \sc_studiFrontendWalker,
										'echo'            => false
								  ) );
		?>
		<div class="" role="navigation">
	                <?php echo wp_kses_post($menu); ?>
        </div>
        <!-- submneu end -->
        
      </div>
    </div>
