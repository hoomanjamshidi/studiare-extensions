<?php
/**
 * Header Template: Style Two
 * Highly optimized with standard WordPress action hooks.
 */

defined('ABSPATH') || exit;

// 1. Logic: Check if header is globally or locally disabled
if (get_post_meta(get_the_ID(), '_studiare_header_off', true)) {
    return;
}

// 2. Load dependencies
require_once get_template_directory() . '/inc/header/header-helpers.php';

// 3. Prepare Data (Bootstrap)
$header_data = require get_template_directory() . '/inc/header/header-bootstrap.php';

/**
 * Hook: studiare_before_header
 * Fires before the header rendering starts.
 */
do_action('studiare_before_header');

// 4. Render the Main Header
require get_template_directory() . '/inc/header/header-render.php';

/**
 * Hook: studiare_after_header
 * Use this to hook off-canvas elements, modals, and overlays.
 * This is where your cart-offcanvas.php and other hooks will attach.
 */
do_action('studiare_after_header');