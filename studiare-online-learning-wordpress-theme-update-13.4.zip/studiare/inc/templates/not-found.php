<?php
defined( 'ABSPATH' ) || exit;
$empty_resault_img = get_stylesheet_directory_uri() . '/assets/images/not-found.svg';
?>
    <div class="container flex justify-center items-center flex-col lg:flex-row gap-3 no-resaults-found">
        <div class='studi_empty_resault'>
            <img src='<?php echo $empty_resault_img ; ?>' class='studi_empty_resault_img' alt='not found' width='186' height='136'>
        </div>
        <div class="not-found-content">
            <p><?php esc_html_e( 'Sorry, no posts found for your query.', 'studiare' ); ?></p>
        </div>
    </div>
    