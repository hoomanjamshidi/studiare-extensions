jQuery(document).ready(function ($) {
    'use strict';

    /**
     * Normalize FontAwesome class without touching DB
     * falfa-address-card -> fal fa-address-card
     */
    function normalizeFa(value) {
        if (!value) return '';

        // If already correct
        if (value.indexOf(' ') !== -1) {
            return value;
        }

        // Match falfa-xxx, fasfa-xxx, farfa-xxx, fabfa-xxx
        var m = value.match(/^(fa[lsrb]?)fa-(.+)$/);

        if (m) {
            return m[1] + ' fa-' + m[2];
        }

        return value;
    }

    function initIconPicker($input) {

        // Init picker
        $input.iconpicker({
            hideOnSelect: true
        });

        // Add preview if missing
        if (!$input.next('.studi-fa-preview').length) {
            $input.after(
                '<span class="studi-fa-preview" style="margin-left:10px;margin-right: 10px;font-size:24px;vertical-align:middle;position: absolute;margin-top: -35px;color: var(--sc-admin-primary-button);">' +
                '<i></i>' +
                '</span>'
            );
        }

        // Fix value ONLY for UI usage
        var fixed = normalizeFa($input.val());
        updatePreview($input, fixed);

        // Also update picker internal state (important)
        if (fixed !== $input.val()) {
            $input.val(fixed);
        }

        // On picker select
        $input.on('iconpickerSelected', function (e) {
            var icon = normalizeFa(e.iconpickerValue);
            updatePreview($input, icon);
            $input.val(icon); // UI only, not DB until save
        });

        // Manual edit fallback
        $input.on('change keyup', function () {
            updatePreview($input, normalizeFa($(this).val()));
        });
    }

    function updatePreview($input, iconClass) {
        $input.next('.studi-fa-preview').find('i').attr('class', iconClass);
    }

    // Init all
    $('.fontawesome-icon-select').each(function () {
        initIconPicker($(this));
    });

});
