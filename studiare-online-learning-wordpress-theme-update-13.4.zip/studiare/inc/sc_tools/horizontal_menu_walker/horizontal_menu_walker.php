<?php
/**
 * SC (Separate Rows) Menu – Two‑row horizontal menu with full‑width submenu row.
 *
 * 1. Custom Walker (SC_Horizontal_Menu_Walker) that outputs:
 *    - <div class="sc-hr-main-menu"> for top‑level items
 *    - <div class="sc-hr-submenu-row"> containing separate <div> for each parent’s children
 * 2. Elementor widget (optional) to use the menu inside Elementor.
 * 3. Enqueues CSS and JavaScript.
 *
 * Place this code in your theme's functions.php or a custom plugin.
 */ 

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* -------------------------------------------------------------------------- */
/* 1. Custom Menu Walker                                                      */
/* -------------------------------------------------------------------------- */

/**
 * SC_Horizontal_Menu_Walker class.
 */
class SC_Horizontal_Menu_Walker extends Walker_Nav_Menu {

    /**
     * Database fields.
     *
     * @var array
     */
    public $db_fields = array(
        'parent' => 'menu_item_parent',
        'id'     => 'db_id',
    );

    /**
     * Override the walk method to generate two separate rows.
     *
     * @param array $elements  Menu items.
     * @param int   $max_depth Maximum depth.
     * @param mixed ...$args   Additional arguments (menu args from wp_nav_menu).
     * @return string HTML output.
     */
    public function walk( $elements, $max_depth, ...$args ) {
        // Get the menu arguments (first element of $args)
        $args_array = ! empty( $args ) ? $args[0] : array();
        // Ensure it's an array
        if ( ! is_array( $args_array ) ) {
            $args_array = array();
        }
        $this->args_array = $args_array;
        $this->args = (object) $args_array;

        // Safely access properties with defaults
        $before      = $this->args->before ?? '';
        $link_before = $this->args->link_before ?? '';
        $link_after  = $this->args->link_after ?? '';
        $after       = $this->args->after ?? '';

        // Build a tree of items
        $children_of = array();
        $top_level = array();

        foreach ( $elements as $item ) {
            if ( ! isset( $children_of[ $item->menu_item_parent ] ) ) {
                $children_of[ $item->menu_item_parent ] = array();
            }
            $children_of[ $item->menu_item_parent ][] = $item;

            if ( 0 == $item->menu_item_parent ) {
                $top_level[] = $item;
            }
        }

        // --- Row 1: top-level menu items ---
        $output = '<div class="sc-hr-main-menu">' . "\n";

        foreach ( $top_level as $item ) {
            $classes = empty( $item->classes ) ? array() : (array) $item->classes;
            $classes[] = 'sc-hr-menu-item';
            if ( ! empty( $children_of[ $item->ID ] ) ) {
                $classes[] = 'sc-hr-menu-item-has-children';
            }

            $class_names = implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $this->args_array, 0 ) );
            $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

            //$item_id = apply_filters( 'nav_menu_item_id', 'sc-hr-menu-item-' . $item->ID, $item, $this->args_array, 0 );
            $item_id = 'sc-hr-menu-item-' . $item->ID;
            $item_id = $item_id ? ' id="' . esc_attr( $item_id ) . '"' : '';

            $output .= '<div' . $item_id . $class_names . '>';

            // Link attributes
            $atts = array(
                'title'  => $item->attr_title,
                'target' => $item->target,
                'rel'    => $item->xfn,
                'href'   => $item->url,
                'class'  => 'sc-hr-toplvl sc-hr-menu-link',
            );
            $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $this->args_array, 0 );

            $attributes = '';
            foreach ( $atts as $attr => $value ) {
                if ( ! empty( $value ) ) {
                    $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                    $attributes .= ' ' . $attr . '="' . $value . '"';
                }
            }

            $title = apply_filters( 'the_title', $item->title, $item->ID );

            $item_output = $before;
            $item_output .= '<a' . $attributes . '>';
            $item_output .= $link_before . $title . $link_after;
            $item_output .= '</a>';
            $item_output .= $after;

            $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, 0, $this->args_array );

            $output .= '</div>' . "\n";
        }

        $output .= '</div>' . "\n";

        // --- Row 2: submenus container ---
        $output .= '<div class="sc-hr-submenu-row">' . "\n";

        foreach ( $top_level as $item ) {
            if ( empty( $children_of[ $item->ID ] ) ) {
                continue;
            }

            $submenu_id = 'sc-hr-submenu-' . $item->ID;
            $output .= '<div id="' . $submenu_id . '" class="sc-hr-sub-menu">' . "\n";

            foreach ( $children_of[ $item->ID ] as $child ) {
                $classes = empty( $child->classes ) ? array() : (array) $child->classes;
                $classes[] = 'sc-hr-menu-item';

                $class_names = implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $child, $this->args_array, 1 ) );
                $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

                $child_id = apply_filters( 'nav_menu_item_id', 'sc-hr-menu-item-' . $child->ID, $child, $this->args_array, 1 );
                $child_id = $child_id ? ' id="' . esc_attr( $child_id ) . '"' : '';

                $output .= '<div' . $child_id . $class_names . '>';

                // Link attributes
                $atts = array(
                    'title'  => $child->attr_title,
                    'target' => $child->target,
                    'rel'    => $child->xfn,
                    'href'   => $child->url,
                    'class'  => 'sc-hr-menu-link',
                );
                $atts = apply_filters( 'nav_menu_link_attributes', $atts, $child, $this->args_array, 1 );

                $attributes = '';
                foreach ( $atts as $attr => $value ) {
                    if ( ! empty( $value ) ) {
                        $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                        $attributes .= ' ' . $attr . '="' . $value . '"';
                    }
                }

                $title = apply_filters( 'the_title', $child->title, $child->ID );

                $item_output = $before;
                $item_output .= '<a' . $attributes . '>';
                $item_output .= $link_before . $title . $link_after;
                $item_output .= '</a>';
                $item_output .= $after;

                $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $child, 1, $this->args_array );

                $output .= '</div>' . "\n";
            }

            $output .= '</div>' . "\n";
        }

        $output .= '</div>' . "\n";

        return $output;
    }

    // Empty overrides with correct signatures to prevent default output
    public function start_lvl( &$output, $depth = 0, $args = null ) {}
    public function end_lvl( &$output, $depth = 0, $args = null ) {}
    public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ) {}
    public function end_el( &$output, $data_object, $depth = 0, $args = null ) {}
}

/* -------------------------------------------------------------------------- */
/* 2. Optional Shortcode (for use outside Elementor)                          */
/* -------------------------------------------------------------------------- */

/**
 * Shortcode to display a menu with the SC_Horizontal_Menu_Walker.
 * Usage: [sc_menu menu="your-menu-slug"]
 */
function sc_hmenu_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'menu'            => '',
        'container'       => 'div',
        'container_class' => 'sc-hr-menu',
        'menu_class'      => '', // Not used directly; we set our own in the walker.
        'echo'            => false,
        'fallback_cb'     => false,
        'walker'          => new SC_Horizontal_Menu_Walker(),
    ), $atts );

    if ( empty( $atts['menu'] ) ) {
        return '';
    }
    
    // Optional: enqueue assets when shortcode is used
    wp_enqueue_style( 'sc-hr-menu-style' );
    wp_enqueue_script( 'sc-hr-menu-script' );

    return wp_nav_menu( $atts );
}
add_shortcode( 'sc_hmenu', 'sc_hmenu_shortcode' );

/* -------------------------------------------------------------------------- */
/* 3. Enqueue CSS and JavaScript                                              */
/* -------------------------------------------------------------------------- */

add_action( 'wp_enqueue_scripts', 'sc_hmenu_enqueue_scripts',1 );

/**
 * Enqueue the required CSS and JavaScript for the menu.
 */
function sc_hmenu_enqueue_scripts() {
    // Register and enqueue CSS
    wp_register_style( 'sc-hr-menu-style', false ); // Use false to add inline CSS, or provide a real file.
    wp_enqueue_style( 'sc-hr-menu-style' );

    $css = '
        .sc-hr-main-menu-holder { padding: 0; margin: 0; }
        /* Main menu row */
        .sc-hr-main-menu {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            gap: 1rem;
            width: 100%;
            justify-content: center;
        }

        .sc-hr-menu-item {
            position: relative;
        }

        .sc-hr-menu-link {
            text-decoration: none;
            color: #333;
            padding: 1rem;
            display: block;
        }

        /* Submenu row – full width below main menu */
        .sc-hr-submenu-row { width: 100%; background: #2c2c2e; padding: 0; display: none; position: absolute; top: 100%; }
        .sc-hr-submenu-row .menu-item a { color: #fff; }
        .sc-hr-submenu-row.show-submenu {
            display: block;
        }

        /* Each submenu ul is a horizontal flex row */
        .sc-hr-sub-menu {
            display: none; /* Hidden by default, shown when targeted */
            list-style: none;
            margin: 0;
            padding: 0;
            flex-direction: row;
            gap: 1rem;
            white-space: nowrap;
            justify-content: center;
        }

        .sc-hr-sub-menu.sc-hr-active {
            display: flex;
        }

        /* Style submenu items as inline blocks */
        .sc-hr-sub-menu .sc-hr-menu-item {
            display: inline-block;
        }

        /* Optional: highlight active parent */
        a.sc-hr-toplvl.sc-hr-menu-link:{ color: #212529; }
        a.sc-hr-toplvl.sc-hr-menu-link:hover { color: #212529;background: #f8f9fa; }
        a.sc-hr-menu-link { padding: 2px 10px; border-radius: 8px; margin: 5px 2px; }
        .sc-hr-submenu-row .menu-item:hover a { background-color: #d9d9d91f; }
        .sc-hr-submenu-row .menu-item a { color: #fff; padding: 0px 10px; line-height: 24px; margin: 10px 0px; }
        .sc-hr-trigger { border-left: 9px solid transparent; border-radius: 4px; border-right: 9px solid transparent; border-top: 9px solid #2f2f2f; font-size: 0; height: 0; line-height: 0; pointer-events: none; position: absolute; top: 44px; transform: scale(0) rotate(180deg); transform-origin: top; transition: all .2s ease; width: 0; z-index: 10; }
        .sc-hr-trigger.sc-hr-trigger-active{transform: scale(1) rotate(180deg);}
    ';

    wp_add_inline_style( 'sc-hr-menu-style', $css );

    // Register and enqueue JavaScript
    wp_register_script( 'sc-hr-menu-script', '', array(), false, true ); // Empty URL for inline script
    wp_enqueue_script( 'sc-hr-menu-script' );

    $js = '
        document.addEventListener("DOMContentLoaded", function() {
            const mainItems = document.querySelectorAll(".sc-hr-main-menu > .sc-hr-menu-item");
            const submenuRow = document.querySelector(".sc-hr-submenu-row");
            const submenus = document.querySelectorAll(".sc-hr-sub-menu");
            
            const men_arrow = document.querySelector(".sc-hr-trigger");

            if (!mainItems.length || !submenuRow || !submenus.length) return;

            // Hide all submenus initially
            submenus.forEach(menu => menu.classList.remove("sc-hr-active"));
            submenuRow.classList.remove("show-submenu");
            

            mainItems.forEach(item => {
                item.addEventListener("mouseenter", function() {
                    // Remove hover class from all parents
                    mainItems.forEach(i => i.classList.remove("sc-hr-hover"));
                    this.classList.add("sc-hr-hover");
                    
                    men_arrow.classList.add("sc-hr-trigger-active");
                    var rect = item.getBoundingClientRect();
                    var docEl = document.documentElement;
                    var distance_from_left = rect.left + ((rect.width)/2) + (window.pageXOffset || docEl.scrollLeft || 0);
                    //console.log(distance_from_left);
                    men_arrow.style.left = distance_from_left+"px";

                    // Find the corresponding submenu ID from the item ID
                    const itemId = this.id.replace("sc-hr-menu-item-", "");
                    const targetSubmenu = document.getElementById("sc-hr-submenu-" + itemId);

                    // Hide all submenus
                    submenus.forEach(menu => menu.classList.remove("sc-hr-active"));

                    if (targetSubmenu) {
                        targetSubmenu.classList.add("sc-hr-active");
                        submenuRow.classList.add("show-submenu");
                    } else {
                        // No submenu for this item, hide the row
                        submenuRow.classList.remove("show-submenu");
                    }
                });
                
            });

            // Optional: hide submenu row when mouse leaves the entire menu area
            const menuWrapper = document.querySelector(".sc-hr-menu"); // Adjust if your container class differs
            if (menuWrapper) {
                menuWrapper.addEventListener("mouseleave", function() {
                 men_arrow.classList.remove("sc-hr-trigger-active");
                    submenus.forEach(menu => menu.classList.remove("sc-hr-active"));
                    submenuRow.classList.remove("show-submenu");
                    mainItems.forEach(i => i.classList.remove("sc-hr-hover"));
                });
            }
        });
    ';

    wp_add_inline_script( 'sc-hr-menu-script', $js );
}

/* -------------------------------------------------------------------------- */
/* 4. Elementor Widget Integration (only if Elementor is active)              */
/* -------------------------------------------------------------------------- */

if ( defined( 'ELEMENTOR_VERSION' ) ) {
    add_action( 'elementor/widgets/register', 'register_sc_menu_widget' );
} else {
    // Optional admin notice if Elementor is not active
    add_action( 'admin_notices', 'sc_hmenu_elementor_missing_notice' );
}

/**
 * Admin notice when Elementor is not active.
 */
function sc_hmenu_elementor_missing_notice() {
    ?>
    <div class="notice notice-warning is-dismissible">
        <p><?php esc_html_e( 'Studiare Horizontal Menu: Elementor is not active. The Elementor widget will not be available, but you can still use the [sc_hmenu] shortcode.', 'studiare' ); ?></p>
    </div>
    <?php
}

/**
 * Register the Elementor widget.
 *
 * @param \Elementor\Widgets_Manager $widgets_manager
 */
 

function register_sc_menu_widget( $widgets_manager ) {
    
    class SC_Menu_Widget extends \Elementor\Widget_Base {

        public function get_name() {
            return 'sc_menu';
        }

        public function get_title() {
            return esc_html__( 'Horizontal Menu', 'studiare' );
        }

        public function get_icon() {
            return 'eicon-nav-menu';
        }

        public function get_categories() {
            return array( 'studiare' );
        }
        
        public function get_style_depends() {
            return [ 'sc-hr-menu-style' ];
        }

        public function get_script_depends() {
            return [ 'sc-hr-menu-script' ];
        }

        protected function register_controls() {
            $this->start_controls_section(
                'content_section',
                array(
                    'label' => esc_html__( 'Menu', 'studiare' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                )
            );

            $menus = wp_get_nav_menus();
            $options = array();
            foreach ( $menus as $menu ) {
                $options[ $menu->slug ] = $menu->name;
            }

            $this->add_control(
                'menu_id',
                array(
                    'label'   => esc_html__( 'Select Menu', 'studiare' ),
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'options' => $options,
                )
            );

            $this->end_controls_section();
            
            $this->start_controls_section(
                'style_section',
                array(
                    'label' => esc_html__( 'Menu', 'studiare' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                )
            );
            
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name'     => 'menu_typography',
                    'selector' => '{{WRAPPER}} a.sc-hr-toplvl.sc-hr-menu-link',
                ]
            );
            $this->add_control(
            'menu_background',
            [
                'label' => __('Menu Background Color', 'studiare'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .sc-hr-main-menu' => 'background: {{VALUE}};',
                ]
            ]
            );
            
            $this->add_group_control(
                 \Elementor\Group_Control_Border::get_type(),
                [
                    'name'     => 'menu_border',
                    'selector' => '{{WRAPPER}} .sc-hr-main-menu', 
                ]
            );
            
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'label' => __('Submenu Typography', 'studiare'),
                    'name'     => 'submenu_typography',
                    'selector' => '{{WRAPPER}} .sc-hr-submenu-row .menu-item a',
                ]
            );
            $this->add_control(
            'submenu_background',
            [
                'label' => __('Submenu Background Color', 'studiare'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2c2c2e',
                'selectors' => [
                    '{{WRAPPER}} .sc-hr-submenu-row' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .sc-hr-trigger'    => 'border-top-color: {{VALUE}};',
                ]
            ]
            );
            
            // ── Normal State ────────────────────────────────────────────────
            $this->start_controls_tabs( 'toggle_style_tabs' );
            
                $this->start_controls_tab(
                    'toggle_normal',
                    [ 'label' => esc_html__( 'Normal', 'studiare' ) ]
                );
                
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'label' => __('Menu Item Background', 'studiare'),
                        'name'     => 'menu_background',
                        'selector' => '{{WRAPPER}} .sc-hr-toplvl.sc-hr-menu-link', 
                        'exclude'  => [ 'image' ], // usually tabs don't use bg image
                    ]
                );
                
                $this->add_group_control(
                    \Elementor\Group_Control_Background::get_type(),
                    [
                        'label' => __('Submenu Item Background', 'studiare'),
                        'name'     => 'submenu_background',
                        'selector' => '{{WRAPPER}} .sc-hr-submenu-row .menu-item a', 
                        'exclude'  => [ 'image' ], // usually tabs don't use bg image
                    ]
                );
                
                $this->add_control(
                'menu_item_color',
                [
                    'label' => __('Menu Item Color', 'studiare'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .sc-hr-toplvl.sc-hr-menu-link' => 'color: {{VALUE}};',
                    ]
                ]
                );
                $this->add_control(
                'submenu_item_color',
                [
                    'label' => __('Submenu Item Color', 'studiare'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .sc-hr-submenu-row .menu-item a' => 'color: {{VALUE}};',
                    ]
                ]
                );
            
            $this->end_controls_tab();
            
            // ── Hover State ─────────────────────────────────────────────────
            $this->start_controls_tab(
                'toggle_hover',
                [ 'label' => esc_html__( 'Hover', 'studiare' ) ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'menu_background_hover',
                    'selector' => '{{WRAPPER}} .sc-hr-toplvl.sc-hr-menu-link:hover', 
                    'exclude'  => [ 'image' ], // usually tabs don't use bg image
                ]
            ); 
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name'     => 'submenu_background_hover',
                    'selector' => '{{WRAPPER}} .sc-hr-submenu-row .menu-item a:hover', 
                    'exclude'  => [ 'image' ], // usually tabs don't use bg image
                ]
            );
            
                $this->add_control(
                'menu_item_color_hover',
                [
                    'label' => __('Menu Item Color', 'studiare'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .sc-hr-toplvl.sc-hr-menu-link:hover' => 'color: {{VALUE}};',
                    ]
                ] 
                ); 
                $this->add_control(
                'submenu_item_color_hover',
                [
                    'label' => __('Submenu Item Color', 'studiare'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .sc-hr-submenu-row .menu-item a:hover' => 'color: {{VALUE}};',
                    ]
                ] 
                ); 
            
            $this->end_controls_tab();
            
            $this->end_controls_section();
            
             $this->start_controls_section(
                'advanced_section',
                array(
                    'label' => esc_html__( 'Studiare extra settings', 'studiare' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
                )
            );
            
            //si means studi item 
            $this->add_control(
            'onscroll',
            [
                'label'   => __( 'On Scroll', 'studiare' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'si_show',
                'options' => [
                    'si_show'            => __( 'Show', 'studiare' ),
                    'si_hide'            => __( 'Hide', 'studiare' ),
                    'si_hide_on_scroll'  => esc_html__( 'Smart Sticky Mode', 'studiare' ),
                ],
            ]
            );
            
            $this->end_controls_section();
        }

        protected function render() {
            $settings  = $this->get_settings_for_display();
            $menu_slug = $settings['menu_id'];
            $onscroll  = $settings['onscroll'];

            if ( empty( $menu_slug ) ) {
                echo esc_html__( 'No menu selected.', 'studiare' );
                return;
            }

            wp_nav_menu( array(
                'menu'            => $menu_slug,
                'container'       => 'div',
                'container_class' => 'sc-hr-menu '.$onscroll,
                'items_wrap'      => '<div id="%1$s" class="%2$s"><div class="sc-hr-trigger"></div>%3$s</div>',
                'menu_class'      => 'sc-hr-main-menu-holder', // This will be used on the top-level ul
                'walker'          => new SC_Horizontal_Menu_Walker(),
                'fallback_cb'     => false,
            ) );
        }
    }

    $widgets_manager->register( new SC_Menu_Widget() );
}

