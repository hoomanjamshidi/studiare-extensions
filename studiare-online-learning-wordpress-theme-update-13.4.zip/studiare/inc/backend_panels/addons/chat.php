<?php
# Chat Settings
Redux::setSection( $opt_name, array(
    'title'  => esc_html__( 'Chat System', 'studiare' ),
    'id'     => 'chat_settings',
    'icon'   => 'fal fa-comment',
    'subsection' => true,
    'fields' => array(
        array(
            'id'      => 'chat_status',
            'type'    => 'switch',
            'title'   => esc_html__( 'Chat System', 'studiare' ),
            'default' => false,
        ),
        
        array(
            'id'      => 'chat_emojies',
            'type'    => 'switch',
            'title'   => esc_html__( 'Chat Emojis', 'studiare' ),
            'default' => false,
            'required' => array('chat_status', '=', '1'),
        ),
        array(
            'id'      => 'chat_gif',
            'type'    => 'switch',
            'title'   => esc_html__( 'Chat GIF', 'studiare' ),
            'default' => false,
            'required' => array('chat_status', '=', '1'),
        ),
        array(
            'id'      => 'chat_file',
            'type'    => 'switch',
            'title'   => esc_html__( 'Chat Upload', 'studiare' ),
            'default' => false,
            'required' => array('chat_status', '=', '1'),
        ),
       
    )
) );
