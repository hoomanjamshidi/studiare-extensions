<?php
/**
 * Register fields added optionally to combined form
 * since version 13.4
 * 1405-03-03
 * */


Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'OTP', 'studiare' ),
    'id'         => 'sc_otp_settings',
    'subsection' => true,
    'icon'       => 'fal fa-mobile',
    'fields'     => array(
        array(
            'id'       => 'otp',
            'type'     => 'switch',
            'title'    => esc_html__('Activate OTP', 'studiare'),
            'default'  => false,
        ),
        array(
            'id'       => 'email_login_enabled',
            'type'     => 'switch',
            'title'    => esc_html__('Email Login/Register', 'studiare'),
            'default'  => true,
        ),
        array(
            'id'       => 'compulsion_mobile_num',
            'type'     => 'switch',
            'title'    => esc_html__('Compulsion to register mobile number', 'studiare'),
            'description'  => esc_html__('With this option enabled, if your users have previously registered with an email and their phone number is not registered in the system, after logging in to their account with an email, a form for registering a mobile number will be displayed to these users, and if the mobile number is not registered, they will not be able to access the site.', 'studiare'),
            'default'  => false,
            'required' => array('otp', '=', 'true'),
        ),
        array(
            'id'       => 'login_priority',
            'type'     => 'button_set',
            'title'    => esc_html__('Login priority', 'studiare'),
            'desc' => esc_html__('If SMS login is disabled, set this option to Email.', 'studiare'),
            'options'  => array(
                'email'  => esc_html__('With Email', 'studiare'),
                'mobile' => esc_html__('With Mobile', 'studiare'),
            ),
            'default'  => 'email',
        ),
        array(
            'id'          => 'otp_provider',
            'type'        => 'select',
            'title'       => esc_html__( 'OTP Provider', 'studiare' ),
            'subtitle'    => esc_html__( 'Select your otp provider', 'studiare' ),
            'options'     => array(
                'mellipayamak' => esc_html__( 'Melli Payamak', 'studiare' ),
                'ippanel'      => esc_html__( 'IPPanel', 'studiare' ),
                'msgway'       => esc_html__( 'Message Way', 'studiare' ),
                'farazsms'     => esc_html__( 'Faraz SMS', 'studiare' ),
                'smsir'        => esc_html__( 'SMS.ir', 'studiare' ),
                'kavenegar'    => esc_html__( 'Kavenegar', 'studiare' ),
                'suncode'      => esc_html__( 'Suncode', 'studiare' ),
            ),
            'default'     => 'mellipayamak',
            'description' => '',
            'select2'     => array('allowClear' => false),
            'required'    => array('otp', '=', 'true'),
        ),
        array(
            'id'       => 'otp_help_box',
            'type'     => 'raw',
            'required' => array('otp', '=', 'true'),
            'content'  => '
                <div style="
                    background: #f0f6ff;
                    border: 1px solid #d0e2ff;
                    border-radius: 8px;
                    padding: 15px 20px;
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    margin: 10px 0 20px 0;
                    font-size: 16px;
                ">
                    <span style="
                        background: #0073aa;
                        color: #fff;
                        border-radius: 50%;
                        width: 32px;
                        height: 32px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 16px;
                    ">
                        <i class="dashicons dashicons-info"></i>
                    </span>
                    <div style="flex:1;">
                        <strong style="display:block; margin-bottom:4px;">'.esc_html__('Need help?', 'studiare').'</strong>
                        '.sprintf(
                            wp_kses_post(__('For setup instructions, please visit <a href="%s" target="_blank">this documentation link</a>.', 'studiare')),
                            esc_url('https://docs.studiaretheme.ir/tuts/theme-options/login-and-account/')
                        ).'
                    </div>
                </div>
            ',
        ),
        array(
            'id'   =>'divider_1',
            'description' => sprintf(__('You can register sms plan from <a target="_blank" href="%s">%s</a>','studiare'), 'https://melipayamak.com/?aff=AB7RE',esc_html__( 'Melli Payamak', 'studiare' )),
            'required' => array('otp_provider', '=', 'mellipayamak'),
            'type' => 'raw'
        ),
        array(
            'id'       => 'mellipayamak_api_address',
            'type'     => 'text',
            'title'    => esc_html__('Mellipayamak Api Address', 'studiare'),
            'description'  => esc_html__('Please copy the full API link from the Mellipayamak Console and paste it into this field.', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'mellipayamak'),
        ),
        
        //kavenegar 
        array(
            'id'   =>'divider_6',
            'description' => sprintf(__('You can register sms plan from <a target="_blank" href="%s">%s</a>','studiare'), 'https://iff.gg/sAH2Fg',esc_html__( 'Kavenegar', 'studiare' )),
            'required' => array('otp_provider', '=', 'kavenegar'),
            'type' => 'raw'
        ),
        array(
            'id'       => 'kavenegar_api_address',
            'type'     => 'text',
            'title'    => esc_html__('Kavenegar Api', 'studiare'),
            'description'  => esc_html__('Please copy API code from  Kavenegar Console and paste it into this field.', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'kavenegar'),
        ),
        array(
            'id'       => 'kavenegar_pattern_code',
            'type'     => 'text',
            'title'    => esc_html__('Pattern Code', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'kavenegar'),
        ),
        
        // ippanel start
                
        array(
            'id'   =>'divider_2',
            'description' => sprintf(__('You can register sms plan from <a target="_blank" href="%s">%s</a>','studiare'), 'https://ippanel.co/?ref=42',esc_html__( 'IPPanel', 'studiare' )),
            'required' => array('otp_provider', '=', 'ippanel'),
            'type' => 'raw'
        ),
        array(
            'id'       => 'ippanel_api_address',
            'type'     => 'text',
            'title'    => esc_html__('Api Address', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'ippanel'),
        ),
        array(
            'id'       => 'ippanel_pattern_code',
            'type'     => 'text',
            'title'    => esc_html__('Pattern Code', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'ippanel'),
        ),
        array(
            'id'       => 'ippanel_pattern_variable',
            'type'     => 'text',
            'title'    => esc_html__('Pattern Variable', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'ippanel'),
        ),
        
         // msgway start
                
        array(
            'id'   =>'divider_5',
            'description' => sprintf(__('You can register sms plan from <a target="_blank" href="%s">%s</a>','studiare'), 'https://www.msgway.com/r/mkb',esc_html__( 'Message Way', 'studiare' )),
            'required' => array('otp_provider', '=', 'msgway'),
            'type' => 'raw'
        ),
        array(
            'id'       => 'msgway_api_address',
            'type'     => 'text',
            'title'    => esc_html__('Api Key', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'msgway'),
        ),
        array(
            'id'       => 'msgway_pattern_code',
            'type'     => 'text',
            'title'    => esc_html__('Pattern Code', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'msgway'),
        ),
        
        
        // farazsms start
                
        array(
            'id'   =>'divider_3',
            'description' => sprintf(__('You can register sms plan from <a target="_blank" href="%s">%s</a>','studiare'), 'https://farazsms.com/?ref=3054',esc_html__( 'Faraz SMS', 'studiare' )),
            'required' => array('otp_provider', '=', 'farazsms'),
            'type' => 'raw'
        ),
        array(
            'id'       => 'farazsms_api_address',
            'type'     => 'text',
            'title'    => esc_html__('Api Address', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'farazsms'),
        ),
        array(
            'id'       => 'farazsms_pattern_code',
            'type'     => 'text',
            'title'    => esc_html__('Pattern Code', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'farazsms'),
        ),
        array(
            'id'       => 'farazsms_pattern_variable',
            'type'     => 'text',
            'title'    => esc_html__('Pattern Variable', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'farazsms'),
        ),
        
        // sms.ir start
                
        array(
            'id'   =>'divider_4',
            'description' => sprintf(__('You can register sms plan from <a target="_blank" href="%s">%s</a>','studiare'), 'https://app.sms.ir/auth/sign-up?ref=Z9E33',esc_html__( 'SMS.ir', 'studiare' )),
            'required' => array('otp_provider', '=', 'smsir'),
            'type' => 'raw'
        ),
        array(
            'id'       => 'smsir_api_address',
            'type'     => 'text',
            'title'    => esc_html__('Api Address', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'smsir'),
        ),
        array(
            'id'       => 'smsir_pattern_code',
            'type'     => 'text',
            'title'    => esc_html__('Pattern Code', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'smsir'),
        ),
        array(
            'id'       => 'smsir_pattern_variable',
            'type'     => 'text',
            'title'    => esc_html__('Pattern Variable', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'smsir'),
        ),
        
        array(
            'id'       => 'suncode_api_address',
            'type'     => 'text',
            'title'    => esc_html__('Suncode Api Address', 'studiare'),
            'default'  => '',
            'required' => array('otp_provider', '=', 'suncode'),
        ),
        
        // Register fields settings
        array(
            'id'       => 'otp_register_fields_section',
            'type'     => 'section',
            'title'    => esc_html__( 'Register Fields', 'studiare' ),
            'indent'   => true,
            'required' => array('otp', '=', 'true'),
        ),
        
        array(
            'id'       => 'otp_register_first_name',
            'type'     => 'button_set',
            'title'    => esc_html__( 'First Name', 'studiare' ),
            'options'  => array(
                'disabled' => esc_html__( 'Disabled', 'studiare' ),
                'optional' => esc_html__( 'Optional', 'studiare' ),
                'required' => esc_html__( 'Required', 'studiare' ),
            ),
            'default'  => 'disabled',
            'required' => array('otp', '=', 'true'),
        ),
        
        array(
            'id'       => 'otp_register_last_name',
            'type'     => 'button_set',
            'title'    => esc_html__( 'Last Name', 'studiare' ),
            'options'  => array(
                'disabled' => esc_html__( 'Disabled', 'studiare' ),
                'optional' => esc_html__( 'Optional', 'studiare' ),
                'required' => esc_html__( 'Required', 'studiare' ),
            ),
            'default'  => 'disabled',
            'required' => array('otp', '=', 'true'),
        ),
        
        array(
            'id'       => 'otp_register_email',
            'type'     => 'button_set',
            'title'    => esc_html__( 'Email', 'studiare' ),
            'options'  => array(
                'disabled' => esc_html__( 'Disabled', 'studiare' ),
                'optional' => esc_html__( 'Optional', 'studiare' ),
                'required' => esc_html__( 'Required', 'studiare' ),
            ),
            'default'  => 'disabled',
            'required' => array('otp', '=', 'true'),
        ),
        
        array(
            'id'       => 'otp_register_username',
            'type'     => 'button_set',
            'title'    => esc_html__( 'Username', 'studiare' ),
            'options'  => array(
                'disabled' => esc_html__( 'Disabled', 'studiare' ),
                //'optional' => esc_html__( 'Optional', 'studiare' ),
                'required' => esc_html__( 'Required', 'studiare' ),
            ),
            'default'  => 'disabled',
            'required' => array('otp', '=', 'true'),
        ),
        
        array(
            'id'       => 'otp_register_password',
            'type'     => 'button_set',
            'title'    => esc_html__( 'Password', 'studiare' ),
            'options'  => array(
                'disabled' => esc_html__( 'Disabled', 'studiare' ),
                'optional' => esc_html__( 'Optional', 'studiare' ),
                'required' => esc_html__( 'Required', 'studiare' ),
            ),
            'default'  => 'disabled',
            'required' => array('otp', '=', 'true'),
        ),
        
        // Username generation settings
        array(
            'id'       => 'otp_username_generate_method',
            'type'     => 'button_set',
            'title'    => esc_html__( 'Username Generation Method', 'studiare' ),
            'subtitle' => esc_html__( 'Choose how username should be generated when username field is disabled.', 'studiare' ),
            'options'  => array(
                //'auto'   => esc_html__( 'Auto', 'studiare' ),
                'email'  => esc_html__( 'From Email', 'studiare' ),
                'mobile' => esc_html__( 'From Mobile', 'studiare' ),
                'random' => esc_html__( 'Random String', 'studiare' ),
            ),
            'default'  => 'mobile',
            'required' => array(
                array('otp', '=', 'true'),
                array('otp_register_username', '=', 'disabled'),
            ),
        ),
        
        array(
            'id'       => 'otp_register_fields_section_end',
            'type'     => 'section',
            'indent'   => false,
            'required' => array('otp', '=', 'true'),
        ),




        //end register fields
        array(
            'id'       => 'new_user_display_name_type',
            'type'     => 'select',
            'title'    => __('New User Display Name', 'studiare'),
            'subtitle' => __('Choose how the display name for new users should be set.', 'studiare'),
            'options'  => array(
                'mobile'    => __('Mobile Number', 'studiare'),
                'full_name' => __('Full Name', 'studiare'),
                'first_name'=> __('First Name', 'studiare'),
                'username'  => __('Username', 'studiare'),
                'email'     => __('Email', 'studiare'),
                'custom'    => __('Custom Text', 'studiare'),
            ),
            'default'  => 'mobile',
            'required' => array('otp', '=', 'true'),
        ), 
        array(
            'id'       => 'new_user_custom_display_name',
            'type'     => 'text',
            'title'    => __('Custom Display Name', 'studiare'),
            'subtitle' => __('Enter the custom display name for new users.', 'studiare'),
            'default'  => __('New User', 'studiare'),
            'required' => array('new_user_display_name_type', '=', 'custom'),
        ),
        
        
        // ====================== OTP ANTI-SPAM / RATE LIMITING ====================== since version 13.4
        array(
            'id'       => 'otp_antispam_section',
            'type'     => 'section',
            'title'    => esc_html__( 'OTP Anti-Spam Protection', 'studiare' ),
            'subtitle' => esc_html__( 'Prevent OTP spam and abuse', 'studiare' ),
            'indent'   => true,
            'required' => array('otp', '=', 'true'),
        ),

        // Global Enable
        array(
            'id'       => 'otp_antispam_enabled',
            'type'     => 'switch',
            'title'    => esc_html__('Enable Anti-Spam Protection', 'studiare'),
            'subtitle' => esc_html__('Highly recommended to prevent OTP bombing attacks', 'studiare'),
            'default'  => true,
            'required' => array('otp', '=', 'true'),
        ),

        // Cooldown
        array(
            'id'       => 'otp_cooldown_enabled',
            'type'     => 'switch',
            'title'    => esc_html__('Enable Cooldown', 'studiare'),
            'subtitle' => esc_html__('Time between two OTP requests for same number', 'studiare'),
            'default'  => true,
            'required' => array('otp_antispam_enabled', '=', '1'),
        ),
        array(
            'id'       => 'otp_cooldown_seconds',
            'type'     => 'slider',
            'title'    => esc_html__('Cooldown Duration', 'studiare'),
            'subtitle' => esc_html__('Seconds to wait before next OTP request', 'studiare'),
            'default'  => 60,
            'min'      => 30,
            'max'      => 300,
            'step'     => 15,
            'display_value' => 'text',
            'required' => array(
                array('otp_antispam_enabled', '=', '1'),
                array('otp_cooldown_enabled', '=', '1')
            ),
        ),

        // Per Phone Hourly Limit
        array(
            'id'       => 'otp_per_phone_enabled',
            'type'     => 'switch',
            'title'    => esc_html__('Limit OTP per Phone Number', 'studiare'),
            'subtitle' => esc_html__('Maximum OTPs per hour for one mobile number', 'studiare'),
            'default'  => true,
            'required' => array('otp_antispam_enabled', '=', '1'),
        ),
        array(
            'id'       => 'otp_per_phone_limit',
            'type'     => 'slider',
            'title'    => esc_html__('Max OTPs per Phone (Hourly)', 'studiare'),
            'default'  => 4,
            'min'      => 2,
            'max'      => 10,
            'step'     => 1,
            'display_value' => 'text',
            'required' => array(
                array('otp_antispam_enabled', '=', '1'),
                array('otp_per_phone_enabled', '=', '1')
            ),
        ),

        // Per IP Hourly Limit
        array(
            'id'       => 'otp_per_ip_enabled',
            'type'     => 'switch',
            'title'    => esc_html__('Limit OTP per IP Address', 'studiare'),
            'subtitle' => esc_html__('Global protection against bots using multiple numbers', 'studiare'),
            'default'  => true,
            'required' => array('otp_antispam_enabled', '=', '1'),
        ),
        array(
            'id'       => 'otp_per_ip_limit',
            'type'     => 'slider',
            'title'    => esc_html__('Max OTPs per IP (Hourly)', 'studiare'),
            'default'  => 10,
            'min'      => 5,
            'max'      => 30,
            'step'     => 1,
            'display_value' => 'text',
            'required' => array(
                array('otp_antispam_enabled', '=', '1'),
                array('otp_per_ip_enabled', '=', '1')
            ),
        ),

        // Daily Limit per Phone
        array(
            'id'       => 'otp_daily_enabled',
            'type'     => 'switch',
            'title'    => esc_html__('Daily Limit per Phone', 'studiare'),
            'subtitle' => esc_html__('Maximum OTP requests per day for one number', 'studiare'),
            'default'  => true,
            'required' => array('otp_antispam_enabled', '=', '1'),
        ),
        array(
            'id'       => 'otp_daily_limit',
            'type'     => 'slider',
            'title'    => esc_html__('Max OTPs per Phone (Daily)', 'studiare'),
            'default'  => 15,
            'min'      => 5,
            'max'      => 50,
            'step'     => 1,
            'display_value' => 'text',
            'required' => array(
                array('otp_antispam_enabled', '=', '1'),
                array('otp_daily_enabled', '=', '1')
            ),
        ),

        array(
            'id'       => 'otp_antispam_section_end',
            'type'     => 'section',
            'indent'   => false,
            'required' => array('otp', '=', 'true'),
        ),
        
    )
));

