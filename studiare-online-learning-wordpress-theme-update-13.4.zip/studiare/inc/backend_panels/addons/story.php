<?php
Redux::setSection( $opt_name, array(
    'title'  => esc_html__( 'Story', 'studiare' ),
    'id'     => 'story_settings',
    'icon'   => 'fal fa-image',
    'subsection' => true,
    'fields' => array(
        array(
            'id'      => 'story_status',
            'type'    => 'switch',
            'title'   => esc_html__( 'Stories', 'studiare' ),
            'default' => true,
        ),
        
    )
) );