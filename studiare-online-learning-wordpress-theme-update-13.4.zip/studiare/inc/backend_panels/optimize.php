<?php
#theme_optimization
Redux::setSection( $opt_name, array(
	'title'             => esc_html__( 'Advanced', 'studiare' ),
	'id'                => 'sc_theme_optimization',
	'icon'              => 'fal fa-globe',
	'fields'            => array(
	    /*array(
			'id'       => 'sc_defer_scripts',
			'title'    => esc_html__( 'تعویق بارگذاری فایل های جاوا اسکریپت', 'studiare' ),
			'type'     => 'switch',
			'default'  => false,
			'on'       => esc_html__( 'Enable', 'studiare' ),
			'off'      => esc_html__( 'Disable', 'studiare' )
		),
		array(
			'id'       => 'sc_defer_scripts_exclude',
			'type'     => 'textarea',
			'mode'      => 'css',
			'title'    => esc_html__('نادیده گرفتن تعویق برای فایل های جاوا اسکریپت', 'studiare'),
			'subtitle' => esc_html__('نام فایل را بدون پسوند بنویسید و برای نوشتن نام چند فایل بین آنها کاما قرار دهید', 'studiare'),
			'placeholder' => 'myscript,yourscript'
		),*/
		
		array(
			'id'       => 'sc_remove_ver_css_js',
			'title'    => esc_html__( 'Delete version of CSS and JavaScript files', 'studiare' ),
			'type'     => 'switch',
			'default'  => true,
			'on'       => esc_html__( 'Enable', 'studiare' ),
			'off'      => esc_html__( 'Disable', 'studiare' )
		),
		array(
			'id'       => 'sc_disable_gutenberg_widgets',
			'title'    => esc_html__( 'Disable gutenberg for widgets page', 'studiare' ),
			'type'     => 'switch',
			'default'  => true,
			'on'       => esc_html__( 'Enable', 'studiare' ),
			'off'      => esc_html__( 'Disable', 'studiare' )
		),
		array(
			'id'       => 'sc_disable_gutenberg_in_posts',
			'title'    => esc_html__( 'Disable gutenberg for post page', 'studiare' ),
			'type'     => 'switch',
			'default'  => false,
			'on'       => esc_html__( 'Enable', 'studiare' ),
			'off'      => esc_html__( 'Disable', 'studiare' )
		),
		array(
			'id'       => 'sc_dequee_elementor_fontawesome',
			'title'    => esc_html__( 'Disable Elementor Fontawesome', 'studiare' ),
			'subtitle' => esc_html__( 'for increasing load page speed you can disable these fonticons', 'studiare' ),
			'type'     => 'switch',
			'default'  => true,
			'on'       => esc_html__( 'Enable', 'studiare' ),
			'off'      => esc_html__( 'Disable', 'studiare' )
		),
		array(
            'id'       => 'sc_disable_gravatar',
            'title'    => esc_html__( 'Disable Gravatar Globally', 'studiare' ),
            'subtitle' => esc_html__( 'Disable Gravatar and external avatar requests across the entire site.', 'studiare' ),
            'type'     => 'switch',
            'default'  => true,
            'on'       => esc_html__( 'Enable', 'studiare' ),
            'off'      => esc_html__( 'Disable', 'studiare' )
        ),
        array(
            'id'       => 'sc_disable_emojis',
            'title'    => esc_html__( 'Disable WordPress Emojis', 'studiare' ),
            'subtitle' => esc_html__( 'Control loading of default WordPress emoji scripts.', 'studiare' ),
            'type'     => 'select',
            'default'  => 'both',
            'options'  => array(
                'none'  => esc_html__( 'Disabled', 'studiare' ),
                'front' => esc_html__( 'Disable on Site', 'studiare' ),
                'admin' => esc_html__( 'Disable on Admin', 'studiare' ),
                'both'  => esc_html__( 'Disable on Site and Admin', 'studiare' ),
            ),
        ),


	)
) );