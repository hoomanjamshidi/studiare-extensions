<?php

#Search Page
$search_post_types = array(
	'enabled' => array (
		'post'=>__("Post","studiare"), 
		'product'=>__("Product","studiare"), 
		'portfolio'=>__("Portfolio","studiare"), 
		'page'=>__("Page","studiare"), 
		'tp_event'=>__("Event","studiare")

	),'disabled' => array (
		'teacher'=>__("Teacher","studiare"),
	),
);
Redux::setSection( $opt_name, array(
	'title'             => esc_html__( 'Search Page', 'studiare' ),
	'id'                => 'search_page_settings',
	'icon'              => 'fal fa-search',
	'fields'            => array(
		array(
			'id'        => 'sp_post_types',
			'type'      => 'sorter',
			'title'     => esc_html__( 'Post Types', 'studiare' ),
			'subtitle'  => esc_html__( 'Select which post type to show in search box and search results.', 'studiare' ),
			'options'   => $search_post_types,
		),
		array(
			'id'        => 'sp_result_perpage',
			'type'      => 'text',
			'title'     => esc_html__( 'Number of results per page', 'studiare' ),
			'default'   => '9',
		),
		array(
            'id'      => 'sp_show_filters',
            'type'    => 'switch',
            'title'   => esc_html__( 'Show Filter Bar', 'studiare' ),
            'default' => true,
        ),
		array(
            'id'       => 'sp_show_empty_filters',
            'type'     => 'switch',
            'title'    => esc_html__( 'Show Filters with Zero Results', 'studiare' ),
            'subtitle' => esc_html__( 'Only applies when Filter Bar is enabled.', 'studiare' ),
            'default'  => true,'required' => array( 'sp_show_filters', '=', true ),
        ),

        array(
            'id'       => 'sp_show_filter_counts',
            'type'     => 'switch',
            'title'    => esc_html__( 'Show Result Count on Filters', 'studiare' ),
            'subtitle' => esc_html__( 'Only applies when Filter Bar is enabled.', 'studiare' ),
            'default'  => true,
            'required' => array( 'sp_show_filters', '=', true ),
        ),

        // --- Custom post types ---
        array(
            'id'       => 'sp_custom_post_types',
            'type'     => 'textarea',
            'title'    => esc_html__( 'Custom Post Types', 'studiare' ),
            'subtitle' => esc_html__( 'Add custom post type slugs, one per line, in format: slug|Label  (e.g. book|Books)', 'studiare' ),
            'desc'     => wp_kses_post(
                __( 'To find a post type slug: go to <strong>Tools → Debug Bar</strong> or check the URL in its admin list (e.g. <code>post_type=book</code>). The slug is case-sensitive and must exactly match the registered post type name.', 'studiare' )
            ),
            'default'  => '',
        ),
	)
) );

#custom codes
Redux::setSection( $opt_name, array(
	'title'             => esc_html__( 'Custom Codes', 'studiare' ),
	'id'                => 'sc_custom_code_settings',
	'icon'              => 'fal fa-code',
	'fields'            => array(
		array(
			'id'       => 'sc_custom_css_codes',
			'type'     => 'ace_editor',
			'mode'      => 'css',
			'title'    => esc_html__('Custom Css', 'studiare'),
		),
	)
) );
