<?php
# Security Settings
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Security', 'studiare' ),
    'id'         => 'sc_security_settings',
    'icon'       => 'fal fa-shield-alt',
    'fields'     => array(

        array(
            'id'       => 'sc_disable_right_click',
            'title'    => esc_html__( 'Disable Right Click', 'studiare' ),
            'subtitle' => esc_html__( 'Prevents users from opening the context menu (right click).', 'studiare' ),
            'type'     => 'switch',
            'default'  => false,
            'on'       => esc_html__( 'Enable', 'studiare' ),
            'off'      => esc_html__( 'Disable', 'studiare' ),
        ),

        array(
            'id'       => 'sc_disable_inspect',
            'title'    => esc_html__( 'Disable Inspect Element', 'studiare' ),
            'subtitle' => esc_html__( 'Blocks keyboard shortcuts and detects open developer tools.', 'studiare' ),
            'type'     => 'switch',
            'default'  => false,
            'on'       => esc_html__( 'Enable', 'studiare' ),
            'off'      => esc_html__( 'Disable', 'studiare' ),
        ),

        array(
            'id'       => 'sc_disable_hotlink',
            'title'    => esc_html__( 'Disable Hotlink Protection', 'studiare' ),
            'subtitle' => esc_html__( 'Prevents other websites from embedding your media files directly.', 'studiare' ),
            'type'     => 'switch',
            'default'  => false,
            'on'       => esc_html__( 'Enable', 'studiare' ),
            'off'      => esc_html__( 'Disable', 'studiare' ),
        ),
        
        array(
            'id'       => 'sc_hotlink_whitelist_domains',
            'type'     => 'textarea',
            'required'  => array('sc_disable_hotlink', '=', '1'),
            'title'    => esc_html__( 'Additional Whitelisted Domains', 'studiare' ),
            'subtitle' => esc_html__( 'Enter one domain per line. These domains will be allowed to load your files.', 'studiare' ),
            'desc'     => esc_html__( 'Example:
        zarinpal.com
        zibal.ir
        example.com', 'studiare' ),
            'default'  => '',
        ),


        array(
            'id'       => 'sc_ignore_admin',
            'type'     => 'switch',
            'title'    => esc_html__( 'Ignore Restrictions for Admins', 'studiare' ),
            'subtitle' => esc_html__( 'Allow administrators to bypass all active security restrictions.', 'studiare' ),
            'default'  => true,
            'on'       => esc_html__( 'Yes', 'studiare' ),
            'off'      => esc_html__( 'No', 'studiare' ),
        ),

        array(
            'id'       => 'sc_restriction_scope',
            'title'    => esc_html__( 'Apply Restrictions On', 'studiare' ),
            'subtitle' => esc_html__( 'Choose where these security measures should be applied.', 'studiare' ),
            'type'     => 'select',
            'multi'    => true,
            'options'  => array(
                'all'      => esc_html__( 'Entire Site', 'studiare' ),
                'product'  => esc_html__( 'Single Product Pages', 'studiare' ),
                'account'  => esc_html__( 'User Account Pages', 'studiare' ),
            ),
            'default'  => array(),
        ),

        array(
            'id'       => 'sc_security_notice',
            'type'     => 'info',
            'style'    => 'info',
            'icon'     => 'el el-info-circle',
            'title'    => esc_html__( 'Notice', 'studiare' ),
            'desc'     => esc_html__( 'Some browsers may still allow users to open Developer Tools manually via menu options. The detection script monitors such activity periodically but cannot guarantee 100% prevention.', 'studiare' ),
        ),
    ),
) );
