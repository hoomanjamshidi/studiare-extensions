<?php
Redux::setSection( $opt_name , array(
        'title'  => esc_html__( 'Subscription Settings', 'studiare' ),
        'id'     => 'subscription-settings',
        'desc'   => esc_html__( 'Manage subscription-related settings for the Studiare theme.', 'studiare' ),
        'icon'   => 'fal fa-user-crown',
        'fields' => array(
            array(
                'id'       => 'enable_premium_subscription_opt',
                'type'     => 'switch',
                'title'    => esc_html__( 'Enable Premium Subscription', 'studiare' ),
                'subtitle' => esc_html__( 'Enable or disable the premium subscription feature for the Studiare theme.', 'studiare' ),
                'default'  => false,
            ),
        )
    ) );
?>