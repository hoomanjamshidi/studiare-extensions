<?php
# Teachers Settings Subsection
Redux::setSection( $opt_name, array(
	'title' => esc_html__( 'Teachers', 'studiare' ),
	'id'         => 'teachers_settings_section',
	'icon'       => 'fal fa-users-cog',
	'fields' => array(
	    )));
Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Teachers', 'studiare' ),
	'id'         => 'teachers_settings',
	'subsection' => true,
	'icon'       => 'fal fa-users-cog',
	'fields'     => array(
		// Field for number of teachers per page
		array(
			'id'       => 'teachers_per_page',
			'type'     => 'text',
			'title'    => esc_html__( 'Teachers Per Page', 'studiare' ),
			'subtitle' => esc_html__( 'Set the number of teachers to display per page.', 'studiare' ),
			'default'  => '6',
			'validate' => 'numeric', // Ensures only numbers are entered
		),
		
		// Field for selecting custom archive page
		array(
			'id'       => 'teachers_archive_page',
			'type'     => 'select',
			'data'     => 'posts',
			'args'     => array( 
				'post_type'   => array( 'page' ), 
				'numberposts' => -1,
				'post_status' => array( 'publish', 'private' )
			),
			'title'    => esc_html__( 'Teachers Archive Page', 'studiare' ),
			'desc'     => esc_html__( 'If this field is left empty, the default archive page will be displayed.', 'studiare' ),
			'default'  => '',
			'select2'  => array( 'allowClear' => true ), // Allows clearing the selection
		),
		
		// Switch for dynamic title and slug
		array(
			'id'       => 'enable_dynamic_teacher_name_slug',
			'type'     => 'switch',
			'title'    => esc_html__( 'Enable Dynamic Title and Slug', 'studiare' ),
			'subtitle' => esc_html__( 'If enabled, customize the archive title and slug dynamically.', 'studiare' ),
			'default'  => false,
		),
		
		// Field for custom archive title (shown if switch is enabled and no page is selected)
		array(
			'id'       => 'teachers_custom_title',
			'type'     => 'text',
			'title'    => esc_html__( 'Custom Archive Title', 'studiare' ),
			'subtitle' => esc_html__( 'Set a custom title for the teachers archive.', 'studiare' ),
			'default'  => 'Teachers',
			'required' => array( 
				array( 'enable_dynamic_teacher_name_slug', '=', true ),
				array( 'teachers_archive_page', '=', '' )
			), // Show only if switch is on and no archive page is selected
		),
		
		// Field for custom archive slug (shown if switch is enabled and no page is selected)
		array(
			'id'       => 'teachers_custom_slug',
			'type'     => 'text',
			'title'    => esc_html__( 'Custom Archive Slug', 'studiare' ),
			'subtitle' => esc_html__( 'Set a custom slug for the teachers archive.', 'studiare' ),
			'default'  => 'teacher',
			'required' => array( 
				array( 'enable_dynamic_teacher_name_slug', '=', true ),
				array( 'teachers_archive_page', '=', '' )
			), // Show only if switch is on and no archive page is selected
		),
	)
) );
# Single Teacher Settings Subsection
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Single Teacher Page', 'studiare' ),
    'id'         => 'single_teacher_settings',
    'subsection' => true,
	'icon'       => 'fal fa-chalkboard-teacher',
    'fields'     => array(
        array(
            'id'       => 'teacher_show_stats_courses',
            'type'     => 'switch',
            'title'    => esc_html__( 'Show Total Courses', 'studiare' ),
            'default'  => true,
        ),
        array(
            'id'       => 'teacher_show_stats_students',
            'type'     => 'switch',
            'title'    => esc_html__( 'Show Total Students', 'studiare' ),
            'default'  => true,
        ),
        array(
            'id'       => 'teacher_show_stats_rating',
            'type'     => 'switch',
            'title'    => esc_html__( 'Show Average Rating', 'studiare' ),
            'default'  => true,
        ),
        array(
            'id'       => 'teacher_show_socials',
            'type'     => 'switch',
            'title'    => esc_html__( 'Show Social Networks', 'studiare' ),
            'default'  => true,
        ),
        array(
            'id'       => 'teacher_show_about',
            'type'     => 'switch',
            'title'    => esc_html__( 'Show About Me Section', 'studiare' ),
            'default'  => true,
        ),
        array(
            'id'       => 'teacher_show_courses_list',
            'type'     => 'switch',
            'title'    => esc_html__( 'Show Courses List', 'studiare' ),
            'default'  => true,
        ),
        array(
			'id'       => 'teacher_courses_per_page',
			'type'     => 'spinner',
			'title'    => esc_html__( 'Courses To Show', 'studiare' ),
			'subtitle' => esc_html__( 'Set the number of courses to show on the single teacher page.', 'studiare' ),
			'default'  => 8,
			'min'      => 1,
			'max'      => 100,
			'step'     => 1,
			'required' => array( 'teacher_show_courses_list', '=', true ),
		),
    )
) );
