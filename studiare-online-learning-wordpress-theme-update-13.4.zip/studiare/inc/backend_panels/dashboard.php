<?php
# Dashboard
Redux::setSection( $opt_name, array(
    'title'            => esc_html__( 'Dashboard and Login', 'studiare' ),
    'id'               => 'sc_notification_settings',
    'subsection'       => false,
    'icon'             => 'fal fa-user-cog',
    'fields'           => array()
));

Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Login Form', 'studiare' ),
    'id'         => 'sc_login_form',
    'subsection' => true,
    'icon'       => 'fal fa-user-lock',
    'fields'     => array(
        array(
            'id'       => 'show_logo_in_login',
            'type'     => 'switch',
            'title'    => esc_html__('Show Logo in Login and Register Page', 'studiare'),
            'default'  => true,
        ),
        array(
            'id'        => 'login_page_template',
            'type'      => 'select',
            'title'     => esc_html__( 'Login And Register Layout', 'studiare' ),
            'subtitle'  => esc_html__( 'This Layout will Apply on Woocommerce My Account Page', 'studiare' ),
            'options'   => array(
                'temp-01' => esc_html__( 'Layout 1', 'studiare' ),
                'temp-02' => esc_html__( 'Layout 2', 'studiare' ),
                'temp-03' => esc_html__( 'Layout 3', 'studiare' ),
                'temp-04' => esc_html__( 'Layout 4', 'studiare' ),
                'default' => esc_html__( 'Woocommerce Default', 'studiare' ),
            ),
            'default'   => 'temp-01',
            'select2'   => array('allowClear' => false)
        ),
        array(
            'id'    => 'login_image',
            'type'  => 'media',
            'desc'  => esc_html__('Upload Image: png, jpg or gif file', 'studiare'),
            'title' => esc_html__('Login/Register Form Image', 'studiare'),
        ),
        array(
            'id'          => 'login-page-main-color',
            'type'        => 'color',
            'title'       => esc_html__( 'Main Color', 'studiare' ),
            'validate'    => 'color',
            'transparent' => false,
            'description' => esc_html__( 'Layout 1 Default Color is  #26a69a - Layout 2 Default Color is  #8224e3', 'studiare' ),
            'output'      => '',
            'default'     => '#8224e3'
        ),
        // New field for redirect after login
        array(
            'id'       => 'login_redirect_type',
            'type'     => 'select',
            'title'    => esc_html__( 'Redirect After Login', 'studiare' ),
            'subtitle' => esc_html__( 'Choose where to redirect users after successful login', 'studiare' ),
            'options'  => array(
                'account'     => esc_html__( 'My Account Page (Default)', 'studiare' ),
                'current'     => esc_html__( 'Current Page', 'studiare' ),
                'custom'      => esc_html__( 'Custom URL', 'studiare' ),
            ),
            'default'  => 'account',
            'select2'  => array('allowClear' => false)
        ),
        // Conditional field for custom redirect URL
        array(
            'id'       => 'login_custom_redirect_url',
            'type'     => 'text',
            'title'    => esc_html__( 'Custom Redirect URL', 'studiare' ),
            'subtitle' => esc_html__( 'Enter a valid URL to redirect users after login', 'studiare' ),
            'default'  => '',
            'required' => array('login_redirect_type', '=', 'custom'),
            'validate' => 'url'
        ),
        array(
            'id'          => 'sc_custom_logout_url',
            'type'        => 'text',
            'title'       => esc_html__( 'Logout URL', 'studiare' ),
            'description' => esc_html__( 'Redirect user after logout from my account page', 'studiare' ),
        ),
    )
));

/***
 * OTP Login Register
 **/

include_once 'addons/combied_otp.php';

# Floating Contact Button
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Account Page', 'studiare' ),
    'id'         => 'sc_account_page',
    'subsection' => true,
    'icon'       => 'fal fa-id-card',
    'fields'     => array(
        array(
            'id'        => 'my_account_page_template',
            'type'      => 'select',
            'title'     => esc_html__( 'Dashboard Page Layout', 'studiare' ),
            'subtitle'  => esc_html__( 'My Account Page Layout and How to Show Menus', 'studiare' ),
            'options'   => array(
                'myaccount-temp-01' => esc_html__( 'Show Menu at Top', 'studiare' ),
                'myaccount-temp-02' => esc_html__( 'Show Menu at Left', 'studiare' ),
                'myaccount-temp-03' => esc_html__( 'Show Menu at Top and Left', 'studiare' ),
            ),
            'default'   => 'myaccount-temp-01',
            'select2'   => array('allowClear' => false)
        ),
        array(
        'id'      => 'dashboard-header-blocks',
        'type'    => 'sorter',
        'title'   => esc_html__( 'Dashboard Header Items', 'studiare' ),
        'subtitle'    => esc_html__( 'Organize how you want the layout to appear on Dashboard Header Items', 'studiare' ),
        'desc'    => esc_html__( 'Drag and Drop Items', 'studiare' ),
        'options' => 
            array(
                'enabled'  => array(
                    'logo'              => esc_html__( 'Logo Image', 'studiare' ),
                    'hamburger-menu'    => esc_html__( 'Hamburger Menu', 'studiare' ),
                    'date'              => esc_html__( 'Date', 'studiare' ),
                    'notifications'     => esc_html__( 'Notifications', 'studiare' ),
                    'cart'              => esc_html__( 'Cart', 'studiare' ),
                    'avatar'            => esc_html__( 'Avatar', 'studiare' ),
                ),
                'disabled' => array(
                )
            ),
	    ),
	    array(
            'id'       => 'dashboard_slider_enabled',
            'type'     => 'switch',
            'title'    => esc_html__('Enable Dashboard Slider', 'studiare'),
            'subtitle' => esc_html__('Enable or disable dashboard slider globally.', 'studiare'),
            'default'  => false,
            'on'       => esc_html__('Enabled', 'studiare'),
            'off'      => esc_html__('Disabled', 'studiare'),
        ),
        array(
            'id'       => 'dashboard_slider_height_desktop',
            'type'     => 'text',
            'title'    => esc_html__('Dashboard Slider Desktop Height', 'studiare'),
            'subtitle' => esc_html__('Example: 220px, 35vh, 18rem', 'studiare'),
            'default'  => '220px',
            'required' => array('dashboard_slider_enabled', '=', true),
        ),
        
        array(
            'id'       => 'dashboard_slider_height_mobile',
            'type'     => 'text',
            'title'    => esc_html__('Dashboard Slider Mobile Height', 'studiare'),
            'subtitle' => esc_html__('Example: 160px, 25vh, 12rem', 'studiare'),
            'default'  => '160px',
            'required' => array('dashboard_slider_enabled', '=', true),
        ),
	    array(
            'id'          => 'dashboard_slider',
            'type'        => 'repeater',
            'group_values'=> true,
            'title'       => esc_html__('Dashboard Slider', 'studiare'),
            'subtitle'    => esc_html__('Add Slider to WooCommerce account page.', 'studiare'),
            'fields'      => array(
        
                array(
                    'id'      => 'image',
                    'type'    => 'media',
                    'title'   => esc_html__('Slide Image', 'studiare'),
                    'subtitle'=> esc_html__('Select the main desktop image.', 'studiare'),
                ),
        
                array(
                    'id'      => 'mobile_image',
                    'type'    => 'media',
                    'title'   => esc_html__('Mobile Slide Image', 'studiare'),
                    'subtitle'=> esc_html__('Select an image for mobile display.', 'studiare'),
                ),
        
                array(
                    'id'      => 'link',
                    'type'    => 'text',
                    'title'   => esc_html__('Slide Link', 'studiare'),
                ),
        
                array(
                    'id'      => 'target',
                    'type'    => 'select',
                    'title'   => esc_html__('Link Target', 'studiare'),
                    'options' => array(
                        '_self'  => esc_html__('Open in same tab', 'studiare'),
                        '_blank' => esc_html__('Open in new tab', 'studiare'),
                    ),
                    'default' => '_self',
                ),
        
            ),
        ),


        array(
            'id'       => 'sc_comments_per_page',
            'title'    => esc_html__( 'Comments Per Page', 'studiare' ),
            'type'     => 'text',
            'default'  => '5',
        ),
        array(
            'id'       => 'enable_profile_picture_upload',
            'type'     => 'switch',
            'title'    => esc_html__('Enable Profile Picture Upload', 'studiare'),
            'subtitle' => esc_html__('Enable or disable the profile picture upload feature in the account page.', 'studiare'),
            'default'  => true,
        ),
        array(
            'id'       => 'sc_custom_dashboard_page',
            'type'     => 'select',
            'multi'    => false,
            'data'     => 'posts',
            'args'     => array(
                'post_type'   => array( 'page' ),
                'numberposts' => -1,
                'post_status' => array( 'publish', 'private' )
            ),
            'title'    => esc_html__( 'Custom Dashboard Page', 'studiare' ),
            'desc'     => esc_html__( 'Select a page to display its content in the dashboard instead of the default content.', 'studiare' ),
            'default'  => '',
        ),
        array(
            'id'     => 'account_page-tabs-section',
            'type'   => 'section',
            'title'  => esc_html__('Account Tab Options', 'studiare'),
            'indent' => true
        ),
        array(
            'id'        => 'sc_active_dash_tab',
            'type'      => 'select',
            'title'     => esc_html__( 'Default Tab', 'studiare' ),
            'options'   => array(
                'notifs'      => esc_html__( 'Latest Notifications', 'studiare' ),
                'statics'     => esc_html__( 'Website Statistics', 'studiare' ),
                'scCustomTab' => esc_html__( 'Custom Tab', 'studiare' ),
            ),
            'default'   => 'notifs',
            'select2'   => array('allowClear' => false)
        ),
        array(
            'id'       => 'show_latest_notifs_tab',
            'type'     => 'switch',
            'title'    => esc_html__('Show Latest Notifications Tab', 'studiare'),
            'default'  => true,
        ),
        array(
            'id'       => 'sc_notif_to_show',
            'title'    => esc_html__( 'Number of Notifications in Dropdown Menu', 'studiare' ),
            'type'     => 'text',
            'default'  => '5',
        ),
        array(
            'id'       => 'show_statistics_tab',
            'type'     => 'switch',
            'title'    => esc_html__('Show Website Statistics Tab', 'studiare'),
            'default'  => true,
        ),
        array(
            'id'       => 'show_custom_tab',
            'type'     => 'switch',
            'title'    => esc_html__('Show Custom Tab', 'studiare'),
            'default'  => false,
        ),
        array(
            'id'       => 'dash_custom_tab_title',
            'title'    => esc_html__( 'Custom Tab Title', 'studiare' ),
            'type'     => 'text',
            'required' => array('show_custom_tab', '=', '1'),
            'default'  => esc_html__( 'Custom Tab', 'studiare' ),
        ),
        array(
            'id'       => 'dash_custom_tab_content',
            'title'    => esc_html__( 'Custom Tab Content', 'studiare' ),
            'type'     => 'editor',
            'required' => array('show_custom_tab', '=', '1'),
            'default'  => '',
        ),
        
        array(
            'id'     => 'account_page_menus-section',
            'type'   => 'section',
            'title'  => esc_html__('Account Menu Options', 'studiare'),
            'indent' => true
        ),
        array(
            'id'       => 'sc_select_account_page_menus',
            'type'     => 'select',
            'multi'    => true,
            'data'     => 'custom',
            'args'     => array(),
            'title'    => esc_html__('Disable Account Page Menus', 'studiare'),
            'subtitle' => esc_html__('Select the menus to disable in the account page.', 'studiare'),
            'options'  => get_account_page_menus(),
        ),
        array(
            'id'       => 'sc_disable_menu_from_endpoint',
            'type'     => 'switch',
            'title'    => esc_html__('Remove Menu from Endpoint', 'studiare'),
            'default'  => false,
            'required' => array('sc_select_account_page_menus', '!=', ''),
            'subtitle' => esc_html__('Choose whether to remove the menu from the endpoint as well as the list.', 'studiare'),
        ),
        array(
            'id'          => 'custom_account_menus',
            'type'        => 'repeater',
            'group_values'=> true,
            'title'       => esc_html__('Custom Account Menus', 'studiare'),
            'subtitle'    => esc_html__('Add custom menus to WooCommerce account page.', 'studiare'),
            'fields'      => array(
                array(
                    'id'    => 'menu_title',
                    'type'  => 'text',
                    'title' => esc_html__('Menu Title', 'studiare'),
                ),
                array(
                    'id'    => 'menu_slug',
                    'type'  => 'text',
                    'title' => esc_html__('Menu Slug (Unique)', 'studiare'),
                ),
                array(
                    'id'    => 'menu_icon',
                    'type'  => 'text',
                    'title' => esc_html__('Menu Icon (FontAwesome)', 'studiare'),
                ),
                array(
                    'id'      => 'menu_content_type',
                    'type'    => 'select',
                    'title'   => esc_html__('Content Type', 'studiare'),
                    'options' => array(
                        'editor' => esc_html__('Text Editor', 'studiare'),
                        'page'   => esc_html__('Select Page', 'studiare'),
                    ),
                    'default' => 'editor',
                ),
                array(
                    'id'    => 'menu_content_editor',
                    'type'  => 'editor',
                    'title' => esc_html__('Menu Content (if Editor selected)', 'studiare'),
                ),
                array(
                    'id'    => 'menu_content_page',
                    'type'  => 'select',
                    'data'  => 'pages',
                    'title' => esc_html__('Select Page (if Page selected)', 'studiare'),
                ),
            ),
        ),
    )
));

function get_account_page_menus() {
    $menu_list = array();

    if (class_exists('WooCommerce')) {
        $menu_items = wc_get_account_menu_items();
        foreach ($menu_items as $key => $menu_item) {
            $menu_list[$key] = $menu_item;
        }
    } else {
        $menu_list = array('none' => esc_html__('WooCommerce is not active', 'studiare'));
    }

    return $menu_list;
}
