<?php
# Studiare Addons
Redux::setSection( $opt_name, array(
    'title'  => esc_html__( 'Addons', 'studiare' ),
    'id'     => 'addons_section',
    'icon'   => 'fal fa-puzzle-piece',
) );


require_once "addons/story.php";
require_once "addons/ticket.php";
require_once "addons/chat.php";
