<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Studiare_Auto_Updator' ) ) {

    class Studiare_Auto_Updator {

        const API_URL       = 'https://studiaretheme.ir/api/versions.json';
        const TRANSIENT_KEY = 'studiare_remote_versions_data';

        public static function init() {
            add_action( 'admin_init', array( __CLASS__, 'handle_clear_cache_request' ) );
            add_action( 'admin_init', array( __CLASS__, 'maybe_redirect_for_studiare_core_update' ) );
            add_action( 'admin_notices', array( __CLASS__, 'admin_update_notices' ) );
        }

        public static function get_remote_versions_data() {
            $cached = get_transient( self::TRANSIENT_KEY );

            if ( false !== $cached && is_array( $cached ) ) {
                return $cached;
            }

            $response = wp_remote_get(
                self::API_URL,
                array(
                    'timeout' => 10,
                    'headers' => array(
                        'Accept' => 'application/json',
                    ),
                )
            );

            if ( is_wp_error( $response ) ) {
                return false;
            }

            $body = wp_remote_retrieve_body( $response );

            if ( empty( $body ) ) {
                return false;
            }

            $data = json_decode( $body, true );

            if ( ! is_array( $data ) ) {
                return false;
            }

            set_transient( self::TRANSIENT_KEY, $data, 12 * HOUR_IN_SECONDS );

            return $data;
        }

        public static function get_plugin_version( $slug ) {
            $data = self::get_remote_versions_data();

            if (
                empty( $slug ) ||
                empty( $data['plugins'] ) ||
                empty( $data['plugins'][ $slug ] ) ||
                empty( $data['plugins'][ $slug ]['version'] )
            ) {
                return false;
            }

            return sanitize_text_field( $data['plugins'][ $slug ]['version'] );
        }
        
        public static function get_required_plugin_version( $slug ) {
            $plugins = self::get_managed_plugins();
        
            if ( empty( $plugins[ $slug ] ) ) {
                return false;
            }
        
            $remote_version   = self::get_plugin_version( $slug );
            $fallback_version = ! empty( $plugins[ $slug ]['fallback'] ) ? $plugins[ $slug ]['fallback'] : '';
        
            if ( empty( $remote_version ) ) {
                return ! empty( $fallback_version ) ? $fallback_version : false;
            }
        
            if ( empty( $fallback_version ) ) {
                return $remote_version;
            }
        
            return version_compare( $fallback_version, $remote_version, '>' ) ? $fallback_version : $remote_version;
        }


        public static function get_tgmpa_plugin_version( $slug ) {
            $required_version = self::get_required_plugin_version( $slug );
        
            return ! empty( $required_version ) ? $required_version : '';
        }
        
        
        public static function get_theme_version() {
            $data = self::get_remote_versions_data();
        
            if (
                empty( $data['theme'] ) ||
                empty( $data['theme']['studiare'] ) ||
                empty( $data['theme']['studiare']['version'] )
            ) {
                return false;
            }
        
            return sanitize_text_field( $data['theme']['studiare']['version'] );
        }



        public static function get_managed_plugins() {
            return array(
                'studiare-core' => array(
                    'name'        => __( 'Studiare Core', 'studiare' ),
                    'plugin_file' => 'studiare-core/studiare-core.php',
                    'fallback'    => '13.4',
                    'redirect'    => true,
                ),
                'elementor-pro' => array(
                    'name'        => __( 'Elementor Pro', 'studiare' ),
                    'plugin_file' => 'elementor-pro/elementor-pro.php',
                    'fallback'    => '4.0.4',
                    'redirect'    => false,
                ),
                'revslider' => array(
                    'name'        => __( 'Slider Revolution', 'studiare' ),
                    'plugin_file' => 'revslider/revslider.php',
                    'fallback'    => '6.7.54',
                    'redirect'    => false,
                ),
                'govahiar' => array(
                    'name'        => __( 'Govahiar', 'studiare' ),
                    'plugin_file' => 'govahiar/govahiar.php',
                    'fallback'    => '1.1.0',
                    'redirect'    => false,
                ),
            );
        }

        public static function get_installed_plugin_version( $plugin_file ) {
            if ( ! function_exists( 'get_plugin_data' ) ) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }

            $plugin_path = WP_PLUGIN_DIR . '/' . $plugin_file;

            if ( ! file_exists( $plugin_path ) ) {
                return false;
            }

            $plugin_data = get_plugin_data( $plugin_path );

            if ( empty( $plugin_data['Version'] ) ) {
                return false;
            }

            return sanitize_text_field( $plugin_data['Version'] );
        }

        public static function get_plugins_needing_update() {
            $plugins = self::get_managed_plugins();
            $updates = array();

            foreach ( $plugins as $slug => $plugin ) {
                $required_version = self::get_required_plugin_version( $slug );
                $current_version  = self::get_installed_plugin_version( $plugin['plugin_file'] );
                
                if ( empty( $required_version ) || empty( $current_version ) ) {
                    continue;
                }
                
                if ( version_compare( $current_version, $required_version, '<' ) ) {
                    $updates[ $slug ] = array(
                        'slug'             => $slug,
                        'name'             => $plugin['name'],
                        'current_version'  => $current_version,
                        'required_version' => $required_version,
                        'redirect'         => ! empty( $plugin['redirect'] ),
                    );
                }

            }

            return $updates;
        }

        public static function maybe_redirect_for_studiare_core_update() {
            if ( ! is_admin() ) {
                return;
            }

            $updates = self::get_plugins_needing_update();

            if ( empty( $updates['studiare-core'] ) ) {
                return;
            }

            global $pagenow;

            $allowed_pages = array(
                'index.php',  
                'plugins.php',
                'update.php',
                'admin.php',
                'plugin-install.php',
                'update-core.php',
            );

            if ( in_array( $pagenow, $allowed_pages, true ) ) {
                return;
            }

            wp_safe_redirect( admin_url( 'admin.php?page=tgmpa-install-plugins&plugin_status=update' ) );
            exit;
        }

        public static function admin_update_notices() {
            if ( ! is_admin() ) {
                return;
            }

            $updates = self::get_plugins_needing_update();

            if ( empty( $updates ) ) {
                return;
            }

            if ( ! empty( $updates['studiare-core'] ) ) {
                self::render_studiare_core_notice( $updates['studiare-core'] );
                unset( $updates['studiare-core'] );
            }

            if ( ! empty( $updates ) ) {
                self::render_plugins_notice( $updates );
            }
        }

        public static function render_debug_clear_cache_button() {
            if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG || ! current_user_can( 'manage_options' ) ) {
                return;
            }

            $url = wp_nonce_url(
                add_query_arg(
                    array(
                        'studiare_clear_versions_cache' => '1',
                    ),
                    admin_url()
                ),
                'studiare_clear_versions_cache',
                'studiare_versions_nonce'
            );
            ?>
            <a href="<?php echo esc_url( $url ); ?>" class="button" style="margin-inline-start: 8px;">
                <?php esc_html_e( 'Clear version cache', 'studiare' ); ?>
            </a>
            <?php
        }

        public static function handle_clear_cache_request() {
            if (
                empty( $_GET['studiare_clear_versions_cache'] ) ||
                empty( $_GET['studiare_versions_nonce'] )
            ) {
                return;
            }

            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['studiare_versions_nonce'] ) ), 'studiare_clear_versions_cache' ) ) {
                return;
            }

            delete_transient( self::TRANSIENT_KEY );

            wp_safe_redirect(
                remove_query_arg(
                    array(
                        'studiare_clear_versions_cache',
                        'studiare_versions_nonce',
                    )
                )
            );
            exit;
        }

        public static function render_studiare_core_notice( $plugin ) {
            $current_version  = $plugin['current_version'];
            $required_version = $plugin['required_version'];
            ?>
            <div dir="auto" style="--error-bg: linear-gradient(to bottom, #FFF5F5 0%, rgba(255,245,245,0.8) 100%); --error-text: #7F1D1D; --error-border: #DC2626; --error-accent: #B91C1C; --error-gradient: linear-gradient(to bottom, rgba(220,38,38,0.2) 0%, rgba(220,38,38,0) 100%); background: var(--error-gradient), var(--error-bg); padding: 1.5rem; border-radius: 0.75rem; color: var(--error-text); border-inline-start: 0.25rem solid var(--error-border); display: flex; gap: 1rem; align-items: flex-start; margin: 20px auto; max-width: 100%; position: relative; overflow: hidden; ">
                <div style=" position: absolute; inset-inline-end: 1rem; top: 50%; transform: translateY(-50%); opacity: 0.1; z-index: 0; ">
                    <svg width="120" height="120" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 8V12M12 16H12.01M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="var(--error-border)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>

                <div style="position: relative; z-index: 1; flex: 1;">
                    <p style="font-size: 1rem; line-height: 1.5; margin: 0 0 0.75rem 0; font-weight: 500;">
                        <?php
                        printf(
                            esc_html__( 'Please update the Studiare Core plugin to version %s. Your current version is %s. Access to the dashboard is restricted until updated.', 'studiare' ),
                            '<span style="font-weight: 600; color: var(--error-accent);">' . esc_html( $required_version ) . '</span>',
                            '<span style="font-weight: 600; color: var(--error-accent);">' . esc_html( $current_version ) . '</span>'
                        );
                        ?>
                    </p>

                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=tgmpa-install-plugins&plugin_status=update' ) ); ?>" style="
                        display: inline-flex;
                        align-items: center;
                        padding: 0.5rem 1rem;
                        background: var(--error-border);
                        color: white;
                        text-decoration: none;
                        border-radius: 0.375rem;
                        font-weight: 500;
                        font-size: 0.875rem;
                        transition: all 0.2s ease;
                        position: relative;
                        overflow: hidden;
                        z-index: 1;
                    ">
                        <?php esc_html_e( 'Go to plugin updates', 'studiare' ); ?>
                        <svg style="margin-inline-start: 0.5rem; transform: rotate(<?php echo is_rtl() ? '180deg' : '0deg'; ?>);" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>

                    <?php self::render_debug_clear_cache_button(); ?>
                </div>
            </div>
            <?php
        }

        public static function render_plugins_notice( $updates ) {
            ?>
            <div class="notice notice-warning">
                <p>
                    <strong><?php esc_html_e( 'Some Studiare plugins have updates available:', 'studiare' ); ?></strong>
                </p>

                <ul style="list-style: disc; margin-inline-start: 20px;">
                    <?php foreach ( $updates as $plugin ) : ?>
                        <li>
                            <?php
                            printf(
                                esc_html__( '%1$s: current version %2$s, latest version %3$s', 'studiare' ),
                                esc_html( $plugin['name'] ),
                                esc_html( $plugin['current_version'] ),
                                esc_html( $plugin['required_version'] )
                            );
                            ?>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <p>
                    <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=tgmpa-install-plugins&plugin_status=update' ) ); ?>">
                        <?php esc_html_e( 'Go to plugin updates', 'studiare' ); ?>
                    </a>

                    <?php self::render_debug_clear_cache_button(); ?>
                </p>
            </div>
            <?php
        }
    }

    Studiare_Auto_Updator::init();
}
