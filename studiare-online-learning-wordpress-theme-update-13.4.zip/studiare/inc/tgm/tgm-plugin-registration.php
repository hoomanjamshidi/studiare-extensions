<?php
/**
 * This file represents an example of the code that themes would use to register
 * the required plugins.
 *
 * It is expected that theme authors would copy and paste this code into their
 * functions.php file, and amend to suit.
 *
 * @see http://tgmpluginactivation.com/configuration/ for detailed documentation.
 *
 * @package    TGM-Plugin-Activation
 * @subpackage Example
 * @version    2.6.1 for parent theme Studiare
 * @author     Thomas Griffin, Gary Jones, Juliette Reinders Folmer
 * @copyright  Copyright (c) 2011, Thomas Griffin
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       https://github.com/TGMPA/TGM-Plugin-Activation
 */

/**
 * Include the TGM_Plugin_Activation class.
 *
 * Depending on your implementation, you may want to change the include call:
 *
 * Parent Theme:
 * require_once get_template_directory() . '/path/to/class-tgm-plugin-activation.php';
 *
 * Child Theme:
 * require_once get_stylesheet_directory() . '/path/to/class-tgm-plugin-activation.php';
 *
 * Plugin:
 * require_once dirname( __FILE__ ) . '/path/to/class-tgm-plugin-activation.php';
 */
require_once get_template_directory() . '/inc/tgm/class-tgm-plugin-activation.php';
require_once get_template_directory() . '/inc/tgm/auto-updator.php';

//add_action( 'tgmpa_register', 'studiare_register_required_plugins' );

/**
 * Register the required plugins for this theme.
 *
 * In this example, we register five plugins:
 * - one included with the TGMPA library
 * - two from an external source, one from an arbitrary source, one from a GitHub repository
 * - two from the .org repo, where one demonstrates the use of the `is_callable` argument
 *
 * The variables passed to the `tgmpa()` function should be:
 * - an array of plugin arrays;
 * - optionally a configuration array.
 * If you are not changing anything in the configuration array, you can remove the array and remove the
 * variable from the function call: `tgmpa( $plugins );`.
 * In that case, the TGMPA default settings will be used.
 *
 * This function is hooked into `tgmpa_register`, which is fired on the WP `init` action on priority 10.
 */
add_action('tgmpa_register', 'studiare_register_plugins');
function studiare_register_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$api = 'https://studiaretheme.ir/api/';
	$plugins = array(
	    array(
			'name'      => esc_html__( 'Redux Framework', 'studiare' ),
			'slug'      => 'redux-framework',
			'required'  => true,
		),
	    array(
			'name'      => esc_html__( 'Studiare Core', 'studiare' ),
			'slug'      => 'studiare-core',
			'source'    => $api . 'studiare-core.zip',
			'required'  => true,
			'version'          => Studiare_Auto_Updator::get_tgmpa_plugin_version( 'studiare-core' ),
			'force_activation'   => true,
		),
		array(
			'name'      => esc_html__( 'Elementor', 'studiare' ),
			'slug'      => 'elementor',
			'required'  => true,
		),
		array(
			'name'      => esc_html__( 'Elementor Pro', 'studiare' ),
			'slug'      => 'elementor-pro',
			'required'  => true,
			'version'      => Studiare_Auto_Updator::get_tgmpa_plugin_version( 'elementor-pro' ),
			'external_url' => $api . 'elementor-pro.zip',
			'source'    => $api . 'elementor-pro.zip',
		),
		array(
			'name'               => esc_html__( 'WooCommerce', 'studiare' ),
			'slug'               => 'woocommerce',
			'required'           => true,
		),
		array(
			'name'               => esc_html__( 'Persian Woocommerce', 'studiare' ),
			'slug'               => 'persian-woocommerce',
			'required'           => false,
		),
        array(
			'name'      => esc_html__( 'govahiar', 'studiare' ),
			'slug'      => 'govahiar',
			'source'    => $api . 'govahiar.zip',
			'external_url' => $api . 'govahiar.zip',
			'required'  => false,
			'version'      => Studiare_Auto_Updator::get_tgmpa_plugin_version( 'govahiar' ),
		),
		array(
			'name'      => esc_html__( 'Slider Revolution', 'studiare' ),
			'slug'      => 'revslider',
			'source'    => $api . 'revslider.zip',
			'external_url' => $api . 'revslider.zip',
			'required'  => false,
			'version'      => Studiare_Auto_Updator::get_tgmpa_plugin_version( 'revslider' ),
		),
		
		array(
			'name'      => esc_html__( 'Events Manager', 'studiare' ),
			'slug'      => 'wp-events-manager',
			'required'  => false,
		),
		
	    array(
			'name'      => esc_html__( 'MailChimp for WordPress', 'studiare' ),
			'slug'      => 'mailchimp-for-wp',
		    'required'  => false,
		),

		
		array(
			'name'        => esc_html__( 'FiboSearch', 'studiare' ),
			'slug'        => 'ajax-search-for-woocommerce',
			'required'    => false,
		),
		
		array(
			'name'        => esc_html__( 'Smart Wishlist', 'studiare' ),
			'slug'        => 'woo-smart-wishlist',
			'required'    => false,
		),
		

	);

	$config = array(
		'default_path'    => '',
		'menu'            => 'tgmpa-install-plugins',
		'has_notices'     => true,
		'dismissable'     => true,
		'dismiss_msg'     => '',
		'is_automatic'    => true,
		'message'         => '',
	);

	tgmpa( $plugins, $config );
}


add_action( 'admin_notices', 'add_studiare_plugins_notice' );

function add_studiare_plugins_notice() {
    global $pagenow;

    if (
        $pagenow === 'admin.php' &&
        isset( $_GET['page'] ) &&
        $_GET['page'] === 'tgmpa-install-plugins'
    ) {
        $manual_check_url = wp_nonce_url(
            add_query_arg(
                array(
                    'page'                          => 'tgmpa-install-plugins',
                    'studiare_clear_versions_cache' => '1',
                ),
                admin_url( 'admin.php' )
            ),
            'studiare_clear_versions_cache',
            'studiare_versions_nonce'
        );
        ?>
        <div class="wrap o-notice gray">
            <div class="holder">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 0 0 8 0a8 8 0 0 0 0 16z"></path>
                    <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"></path>
                </svg>
                <?php esc_html_e( 'List of Useful Plugins for Studiare Theme', 'studiare' ); ?>
            </div>

            <div class="actions">
                <a href="<?php echo esc_url( $manual_check_url ); ?>" class="btn btn-flat" aria-label="بررسی بروزرسانی ها">
                    <i class="fal fa-sync"></i>
                </a>

                <a href="https://docs.studiaretheme.ir/tuts/setting-up/required-plugins/" target="_blank" class="btn">
                    <i class="fal fa-external-link" style="margin-inline-end: 6px;"></i>
                    <?php esc_html_e( 'More Information', 'studiare' ); ?>
                </a>
            </div>

            <style>
                .o-notice { margin-top: 20px; -webkit-box-shadow: none; box-shadow: none; border: none; -webkit-box-sizing: border-box; box-sizing: border-box; padding: 14px 1rem; display: -webkit-box; display: -webkit-flex; display: -ms-flexbox; display: flex; -webkit-box-align: center; -webkit-align-items: center; -ms-flex-align: center; align-items: center; -webkit-box-pack: justify; -webkit-justify-content: space-between; -ms-flex-pack: justify; justify-content: space-between; color: #3D84FC; border-left: 5px solid #3D84FC; background-color: #d9e7fe; min-height: 50px; font-size: 15px; line-height: 1.5; border-radius: 0.35rem; }
                .o-notice .holder { display: inline-flex; align-items: center; gap: 8px; }
                .o-notice .actions { display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap; }
                .o-notice.gray a.btn { padding: 0px 0.55rem; font-size: 14px; background-color: #3D84FC; border: 1px solid #3D84FC; color: #fff; min-height: 30px; line-height: 1; display: -webkit-inline-box; display: -webkit-inline-flex; display: -ms-inline-flexbox; display: inline-flex; -webkit-transition-duration: .2s; -o-transition-duration: .2s; transition-duration: .2s; -webkit-box-shadow: none; box-shadow: none; cursor: pointer; text-decoration: none; font-weight: 500; -webkit-box-sizing: border-box; box-sizing: border-box; -webkit-box-align: center; -ms-flex-align: center; -webkit-align-items: center; align-items: center; border-radius: 0.25rem; -webkit-transition: all cubic-bezier(0.645, 0.045, 0.355, 1) 0.35s; -o-transition: all cubic-bezier(0.645, 0.045, 0.355, 1) 0.35s; transition: all cubic-bezier(0.645, 0.045, 0.355, 1) 0.35s; }
                .o-notice.gray .btn.btn-flat { background-color: rgba(150, 144, 162, 0.15); border-color: transparent; }
            </style>
        </div>
        <?php
    }
}
