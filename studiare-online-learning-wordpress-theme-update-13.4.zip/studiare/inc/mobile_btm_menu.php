<?php
/**
 * addig bottom menu to mobile
 *
 * date: 1402-05-29
 * author: javad pourshahabadi
 * */

add_action("wp_footer","sc_adding_btm_menu_for_mobile"); 

function sc_adding_btm_menu_for_mobile(){
    
    $show_on_mob = 1;
    $mobmore_page_id=null;
    
    $btm_account_link='';
    //sorter since version 12.9    
    $sort_items['enabled'] = array(
        "backtotop" =>  __('Back to top','studiare'),
        "home"      =>  __('Home','studiare'),
        "search"    =>  __('Search','studiare'),
        "account"   =>  __('Account','studiare'),
        "cart"      =>  __('Cart','studiare'),
        "more"      =>  __('More','studiare'),
        );
        
     if(class_exists('Redux')){
        $show_on_mob =codebean_option('show_mobile_bottom_navbar');
        $mobmore_page_id = codebean_option('mobile_more_menu');
        
        //sorter since version 12.9    
       $sort_items       =codebean_option('mobile-button-nav-blocks');
       $btm_account_link =codebean_option('btm_account_link');

    }
    if ( ! wp_is_mobile() ) {
        return;
    }


     
    ?>
    
    
    <div class="navigation sc-mobile-bottom-nav">
        <div class='mobilemoresec'>
            <?php
if (!empty($mobmore_page_id)) {
    if (function_exists('icl_object_id')) {
        $mobmore_page_id = icl_object_id($mobmore_page_id, 'page', true);
    }
    
    $contentElementor = "";
    if (class_exists("\\Elementor\\Plugin")) {
        $pluginElementor = \Elementor\Plugin::instance();
        $contentElementor = $pluginElementor->frontend->get_builder_content($mobmore_page_id);
    }
    
    if (!empty($contentElementor)) {
        echo "<div class='morecontenthol'>$contentElementor</div>";
    }
}
?>
        </div>
        <div class='mob_btm_searchbar' style='display:nonem;'>
            <input id='scmobsearchval' type='text' placeholder='<?php echo __('Search','studiare'); ?>...'><a onclick="search_inmob()" href="javascript:void(0);"><?php echo __('Search','studiare'); ?></a>
        </div>
	<ul class="listWrap">
	    <?php
	    foreach($sort_items['enabled'] as $key=>$value){
	        switch($key) {
	            case 'backtotop':
	        ?>
		<li id='sctotop' class="list ">
			<a href="javascript:void(0);">
				<i class="scicon fal fa-arrow-up"></i>
				<span class="text"><?php echo __('Back to top','studiare'); ?></span>
			</a>
		</li>
		<?php 
		        break; 
			    case 'home':
		?>
		
		<li id='schome' class="list">
			<a href="javascript:void(0);">
				<i class="scicon fal fa-home"></i>
				<span class="text"><?php echo __('Home','studiare'); ?></span>
			</a>
		</li>
		<?php 
		        break; 
	            case 'search':

		?>
		<li id='scsearch' class="list">
			<a href="javascript:void(0);">
				<i class="scicon fal fa-search"></i>
				<span class="text"><?php echo __('Search','studiare'); ?></span>
			</a>
		</li>
		<?php 
		        break; 
                case 'account':
		?>
		<?php 
		//check if woocommerce is active
		if ( class_exists( 'woocommerce' ) ) { 
		    
		    if(!empty($btm_account_link)){$acLink = $btm_account_link;}else{$acLink =get_permalink( wc_get_page_id( 'myaccount' ) );}
		?>
		
    		<li id='scuser' class="list" data-url='<?php echo $acLink; ?>'>
    			<a href="javascript:void(0);">
    				<i class="scicon fal fa-user"></i>
    				<span class="text"><?php echo __('Account','studiare'); ?></span>
    			</a>
    		</li>
    		
    		<?php 
		        break; 
		}    
	            case 'cart':
	                if ( class_exists( 'woocommerce' ) ) { 
		?>
    		<li id='sccart' class="list" data-url='<?php echo get_permalink(wc_get_page_id( 'cart' )); ?>'>
    			<a href="javascript:void(0);">
    				<i class="scicon fal fa-shopping-basket"></i>
    				<span class="text"><?php echo __('Cart','studiare'); ?></span>
    			</a>
    		</li>
    	<?php } ?>	
    	<?php 
		        break; 
	            case 'more':
	             if(!empty($mobmore_page_id)){
		?>
		<li id='scmore' class="list">
			<a href="javascript:void(0);">
				<i class="scicon fal fa-ellipsis-v">
					<ion-scicon name="settings-outline"></ion-scicon>
				</i>
				<span class="text"><?php echo __('More','studiare'); ?></span>
			</a>
		</li>
		<?php } ?>
	<?php 
	            break;
	        }
	} 
	
	?>	
		<li id='scindicator' class="indicator"></li>
	</ul>
</div>
<div id="mobile-bottom-nav-spacer" style="height:70px;"></div>    
    
    <?php
}