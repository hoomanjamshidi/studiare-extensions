<h2 class="studiare-headline"><?php _e( 'What’s New', 'studiare' ); ?></h2>
<style>
    .studiare-group-details { color: #635d6f; font-size: 0.95em; border-bottom: 1px solid rgba(142, 135, 155, 0.15); }
    .studiare-group pre { font-family: 'iransansxv', iransansx, tahoma; font-size: 0.82rem; margin: 0; font-variation-settings: "wght" 200;   line-height: 1.8em; }
    .studiare-group table { width: 100%; }
    .studiare-group .table-col-2 td, .studiare-group .table-col-3 td { padding: 3px 28px; }
    .studiare-group .table-col-2.table-col-equal td:nth-child(1), .studiare-group .table-col-2.table-col-equal td:nth-child(2), .studiare-group .table-col-2.table-col-equal td:nth-child(3), .studiare-group .table-col-3.table-col-equal td:nth-child(1), .studiare-group .table-col-3.table-col-equal td:nth-child(2), .studiare-group .table-col-3.table-col-equal td:nth-child(3) { width: -webkit-calc(100% / 3); width: calc(100% / 3); }
    .studiare-group pre { margin: 0; background-color: #FFFFCC; padding: 1.2%; padding-left: 1%; clear: both; font-size: 1em; white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap; white-space: -o-pre-wrap; word-wrap: break-word; }
    .studiare-group pre.studiare-changelog { margin: 0; background-color: #FFFFCC; padding: 1.2%; padding-left: 1%; clear: both; font-family: 'iransansxv', iransansx, tahoma; font-size: 1em; font-variation-settings: "wght" 200; line-height: 1.8em; white-space: normal; word-wrap: break-word; } .studiare-group pre.studiare-changelog ul { margin: 0; padding-right: 22px; padding-left: 0; } .studiare-group pre.studiare-changelog li { margin-bottom: 6px; list-style: number; }

</style>
<!-- Group 2cl -->
<div class="studiare-group">
	<div class="studiare-group-headline">
		<h3><?php _e( 'Release Notes', 'studiare' ); ?></h3>
		<a target="_blank" href="https://docs.studiaretheme.ir/docs-category/changelog/" class="btn btn-flat"><?php _e( 'All Changelog', 'studiare' ); ?></a>
	</div>
	<div class="studiare-group-content">
<?php
$changelog_file = trailingslashit( get_template_directory() ) . 'changelog.txt';

$changelog_content = '';
if ( file_exists( $changelog_file ) ) {
    $changelog_content = file_get_contents( $changelog_file );
} else {
    $changelog_content = __( 'Changelog file not found.', 'studiare' );
}
?>
<pre class="studiare-changelog"><ul>
<?php
$changelog_lines = preg_split( '/\R/u', $changelog_content );

foreach ( $changelog_lines as $changelog_line ) :
	$changelog_line = trim( $changelog_line );

	if ( '' === $changelog_line ) {
		continue;
	}
	?>
	<li><?php echo esc_html( $changelog_line ); ?></li>
<?php endforeach; ?>
</ul></pre>


	</div>
</div>

<!-- Group 2cl -->
<div class="studiare-group">
	<div class="studiare-group-headline">
		<h3><?php _e( 'Previous Versions', 'studiare' ); ?></h3>
		<a target="_blank" href="https://docs.studiaretheme.ir/docs-category/changelog/" class="btn btn-flat"><?php _e( 'All Changelog', 'studiare' ); ?></a>
	</div>
	<table class="studiare-group-content studiare-group-table table-col-3 table-col-equal">
		<tbody>
			<tr>
				<td><label>نسخه 13.3</label></td>
				<td>23 آذر 1404</td>
				<td class="text-right"><a target="_blank" href="https://docs.studiaretheme.ir/tuts/changelog/ver-13-3/"><?php _e( 'View Changelog', 'studiare' ); ?></a></td>
			</tr>
			<tr>
				<td><label>نسخه 13.2</label></td>
				<td>16 شهریور 1404</td>
				<td class="text-right"><a target="_blank" href="https://docs.studiaretheme.ir/tuts/changelog/ver-13-2/"><?php _e( 'View Changelog', 'studiare' ); ?></a></td>
			</tr>
			<tr>
				<td><label>نسخه 13.1</label></td>
				<td>14 اردیبهشت 1404</td>
				<td class="text-right"><a target="_blank" href="https://docs.studiaretheme.ir/tuts/changelog/ver-13-1/"><?php _e( 'View Changelog', 'studiare' ); ?></a></td>
			</tr>
			<tr>
				<td><label>نسخه 13.0.1</label></td>
				<td>5 دی 1403</td>
				<td class="text-right"><a target="_blank" href="https://docs.studiaretheme.ir/tuts/changelog/ver-13-0-1/"><?php _e( 'View Changelog', 'studiare' ); ?></a></td>
			</tr>
			<tr>
				<td><label>نسخه 13.0</label></td>
				<td>3 دی 1403</td>
				<td class="text-right"><a target="_blank" href="https://docs.studiaretheme.ir/tuts/changelog/ver-13-0/"><?php _e( 'View Changelog', 'studiare' ); ?></a></td>
			</tr>
			<tr>
				<td><label>نسخه 12.9</label></td>
				<td>15 آبان 1403</td>
				<td class="text-right"><a target="_blank" href="https://docs.studiaretheme.ir/tuts/changelog/ver12-9/"><?php _e( 'View Changelog', 'studiare' ); ?></a></td>
			</tr>
			<tr>
				<td><label>نسخه 12.8</label></td>
				<td>19 خرداد 1403</td>
				<td class="text-right"><a target="_blank" href="https://docs.studiaretheme.ir/tuts/changelog/ver12-8/"><?php _e( 'View Changelog', 'studiare' ); ?></a></td>
			</tr>
			<tr>
				<td><label>نسخه 12.7</label></td>
				<td>20 اسفند 1402</td>
				<td class="text-right"><a target="_blank" href="https://docs.studiaretheme.ir/tuts/changelog/ver12-7/"><?php _e( 'View Changelog', 'studiare' ); ?></a></td>
			</tr>
			<tr>
				<td><label>نسخه 12.6</label></td>
				<td>6 مهر 1402</td>
				<td class="text-right"><a target="_blank" href="https://docs.studiaretheme.ir/tuts/changelog/ver12-6/"><?php _e( 'View Changelog', 'studiare' ); ?></a></td>
			</tr>
		</tbody>
	</table>
</div>
