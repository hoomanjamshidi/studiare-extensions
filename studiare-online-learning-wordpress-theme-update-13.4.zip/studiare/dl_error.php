<?php
/**
 * The template for displaying 404 pages (not found)
 */
defined( 'ABSPATH' ) || exit;
$empty_dl_img = get_stylesheet_directory_uri() . '/assets/images/locked-files.svg';
get_header(); ?>

<div class="main-page-content default-margin flex items-center" id="content">

	<div class="site-content-inner container" role="main">
	    
	    
	    <div class="container flex justify-center items-center flex-col lg:flex-row gap-3 no-resaults-found">
        <div class='studi_empty_resault'>
            <img src='<?php echo $empty_dl_img ; ?>' class='studi_empty_resault_img' alt='not found' width='186' height='209'>
        </div>
        <div class="not-found-content">
            <div class="h1 mb-10"><?php esc_html_e( 'You do not have permission to access and download this file', 'studiare' ); ?></div>
            <p class="mb-30"><?php esc_html_e( 'If you have purchased this course and encountered this error, contact the site administrator.', 'studiare' ); ?></p>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-border"><?php esc_html_e('Back to home', 'studiare'); ?></a>
        </div>
    </div>

	</div>

</div>

<?php get_footer();

