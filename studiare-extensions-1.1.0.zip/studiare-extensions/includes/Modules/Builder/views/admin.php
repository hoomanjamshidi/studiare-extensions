<?php
/**
 * Settings panel for the page templates module.
 *
 * Static structure lives here; builder-admin.js renders the template pickers,
 * category rules, library and preview dialog from `stxAdmin.moduleData`.
 *
 * @var \StudiareExt\Modules\Builder\Module $module
 *
 * @package StudiareExt
 */

use StudiareExt\Admin\Fields;
use StudiareExt\Core\Icon_Library;
use StudiareExt\Core\Theme_Bridge;
use StudiareExt\Modules\Builder\Context;
use StudiareExt\Modules\Builder\Library;
use StudiareExt\Modules\Builder\Schema;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- included from a class method, so variables are local.

$ui_icon = static function ( string $key ): string {
	return Icon_Library::svg( 'phosphor-duotone', $key, false, 'stx-ico' );
};

$elementor = Library::elementor_status();
$has_woo   = Context::has_woo();

$panel_tabs = array(
	'course'  => array( 'graduation', __( 'Course pages', 'studiare-extensions' ) ),
	'product' => array( 'bag', __( 'Product pages', 'studiare-extensions' ) ),
	'header'  => array( 'arrow-up', __( 'Header', 'studiare-extensions' ) ),
	'footer'  => array( 'chevron-down', __( 'Footer', 'studiare-extensions' ) ),
	'library' => array( 'grid', __( 'Templates', 'studiare-extensions' ) ),
	'brand'   => array( 'palette', __( 'Colours & options', 'studiare-extensions' ) ),
);

$sample_select = static function ( string $type ) use ( $module ): void {
	$choices = array( '0' => __( 'Newest item (automatic)', 'studiare-extensions' ) );
	foreach ( $module->sample_choices( $type ) as $sample ) {
		$choices[ (string) $sample['id'] ] = $sample['title'];
	}

	Fields::select(
		$type . '.preview_id',
		'course' === $type ? __( 'Sample course for previews and the Elementor editor', 'studiare-extensions' ) : __( 'Sample product for previews and the Elementor editor', 'studiare-extensions' ),
		$choices,
		array( 'help' => __( 'Product widgets show this item\'s real data while you design.', 'studiare-extensions' ) )
	);
};

$brand_labels = array(
	'accent'        => __( 'Accent (buttons, highlights)', 'studiare-extensions' ),
	'accent_strong' => __( 'Accent — hover & links', 'studiare-extensions' ),
	'accent_soft'   => __( 'Accent — light background', 'studiare-extensions' ),
	'on_accent'     => __( 'Text on accent', 'studiare-extensions' ),
	'ink'           => __( 'Headings', 'studiare-extensions' ),
	'text'          => __( 'Body text', 'studiare-extensions' ),
	'muted'         => __( 'Muted text', 'studiare-extensions' ),
	'bg'            => __( 'Page background', 'studiare-extensions' ),
	'card'          => __( 'Cards', 'studiare-extensions' ),
	'line'          => __( 'Borders', 'studiare-extensions' ),
	'dark'          => __( 'Dark areas', 'studiare-extensions' ),
	'success'       => __( 'Success / in stock', 'studiare-extensions' ),
	'danger'        => __( 'Warning / out of stock', 'studiare-extensions' ),
);
?>
<div class="stx-module stx-builder" data-stx-module="builder">

	<section class="stx-module-head">
		<span class="stx-module-head__icon" aria-hidden="true"><?php echo $ui_icon( 'palette' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- bundled SVG. ?></span>
		<div class="stx-module-head__text">
			<h1><?php echo esc_html( $module->title() ); ?></h1>
			<p><?php echo esc_html( $module->description() ); ?></p>
		</div>
		<label class="stx-module-head__switch">
			<span data-stx-show-if="enabled"><?php esc_html_e( 'Active', 'studiare-extensions' ); ?></span>
			<span data-stx-show-if="!enabled"><?php esc_html_e( 'Inactive', 'studiare-extensions' ); ?></span>
			<span class="stx-switch stx-switch--lg">
				<input type="checkbox" data-stx-bind="enabled" aria-label="<?php esc_attr_e( 'Enable page templates', 'studiare-extensions' ); ?>">
				<span class="stx-switch__track" aria-hidden="true"></span>
			</span>
		</label>
	</section>

	<?php if ( ! $elementor['active'] ) : ?>
		<div class="stx-notice">
			<?php echo $ui_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<p>
				<?php esc_html_e( 'Elementor is not active. The designs are Elementor templates, so install and activate the free Elementor plugin first.', 'studiare-extensions' ); ?>
				<a href="<?php echo esc_url( $elementor['installUrl'] ); ?>"><?php esc_html_e( 'Install Elementor', 'studiare-extensions' ); ?></a>
			</p>
		</div>
	<?php elseif ( ! $elementor['container'] ) : ?>
		<div class="stx-notice" data-stx-container-notice>
			<?php echo $ui_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<p><?php esc_html_e( 'The designs use Elementor\'s Flexbox Containers, which are switched off on this site. Turn them on to display and edit the templates.', 'studiare-extensions' ); ?></p>
			<button type="button" class="stx-btn stx-btn--primary" data-stx-activate-container><?php esc_html_e( 'Turn on containers', 'studiare-extensions' ); ?></button>
		</div>
	<?php endif; ?>

	<?php if ( ! $has_woo ) : ?>
		<div class="stx-notice">
			<?php echo $ui_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<p><?php esc_html_e( 'WooCommerce is not active, so course and product pages are unavailable. Headers and footers still work.', 'studiare-extensions' ); ?></p>
		</div>
	<?php endif; ?>

	<div class="stx-module-body stx-module-body--wide">
		<div class="stx-settings">

			<div class="stx-tabs" role="tablist" data-stx-tabs="builder">
				<?php foreach ( $panel_tabs as $tab_id => $panel_tab ) : ?>
					<button type="button" class="stx-tab" role="tab" id="stx-tab-<?php echo esc_attr( $tab_id ); ?>" aria-controls="stx-panel-<?php echo esc_attr( $tab_id ); ?>" aria-selected="false" data-stx-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $ui_icon( $panel_tab[0] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php echo esc_html( $panel_tab[1] ); ?></span>
					</button>
				<?php endforeach; ?>
			</div>

			<?php foreach ( Schema::SINGLE_TYPES as $type ) : ?>
				<?php $is_course = 'course' === $type; ?>
				<section class="stx-panel" role="tabpanel" id="stx-panel-<?php echo esc_attr( $type ); ?>" aria-labelledby="stx-tab-<?php echo esc_attr( $type ); ?>">
					<div class="stx-card">
						<header class="stx-card__head">
							<h2><?php echo esc_html( $is_course ? __( 'Layout for course pages', 'studiare-extensions' ) : __( 'Layout for product pages', 'studiare-extensions' ) ); ?></h2>
							<p>
								<?php
								echo esc_html(
									$is_course
										? __( 'Used by every course unless a category rule below or the course itself says otherwise. Courses are products marked as a course in Studiare.', 'studiare-extensions' )
										: __( 'Used by every product that is not a course, unless a category rule below or the product itself says otherwise.', 'studiare-extensions' )
								);
								?>
							</p>
						</header>
						<div class="stx-tpl-grid" data-stx-picker="<?php echo esc_attr( $type ); ?>" data-path="<?php echo esc_attr( $type ); ?>.default" data-keywords="theme"></div>
					</div>

					<div class="stx-card">
						<header class="stx-card__head stx-card__head--split">
							<div>
								<h2><?php esc_html_e( 'Rules by category', 'studiare-extensions' ); ?></h2>
								<p><?php esc_html_e( 'Give some categories a different layout. Rules are checked from top to bottom and the first match wins. A layout chosen on the product edit screen always comes first.', 'studiare-extensions' ); ?></p>
							</div>
							<button type="button" class="stx-btn stx-btn--soft" data-stx-add-rule="<?php echo esc_attr( $type ); ?>">
								<?php echo $ui_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php esc_html_e( 'Add rule', 'studiare-extensions' ); ?></span>
							</button>
						</header>
						<div class="stx-rules" data-stx-rules="<?php echo esc_attr( $type ); ?>"></div>
					</div>

					<div class="stx-card">
						<div class="stx-fields">
							<?php $sample_select( $type ); ?>
						</div>
					</div>
				</section>
			<?php endforeach; ?>

			<?php foreach ( array( 'header', 'footer' ) as $area ) : ?>
				<?php $is_header = 'header' === $area; ?>
				<section class="stx-panel" role="tabpanel" id="stx-panel-<?php echo esc_attr( $area ); ?>" aria-labelledby="stx-tab-<?php echo esc_attr( $area ); ?>">
					<div class="stx-card">
						<header class="stx-card__head">
							<h2 class="stx-device-title"><?php echo $ui_icon( 'grid' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php echo esc_html( $is_header ? __( 'Header on desktop', 'studiare-extensions' ) : __( 'Footer on desktop', 'studiare-extensions' ) ); ?></h2>
							<p><?php esc_html_e( 'Shown on screens wider than the breakpoint (Colours & options tab).', 'studiare-extensions' ); ?></p>
						</header>
						<div class="stx-tpl-grid" data-stx-picker="<?php echo esc_attr( $area ); ?>" data-path="<?php echo esc_attr( $area ); ?>.desktop" data-keywords="theme,none"></div>
					</div>

					<div class="stx-card">
						<header class="stx-card__head">
							<h2 class="stx-device-title"><?php echo $ui_icon( 'mobile' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php echo esc_html( $is_header ? __( 'Header on phones & tablets', 'studiare-extensions' ) : __( 'Footer on phones & tablets', 'studiare-extensions' ) ); ?></h2>
							<p><?php esc_html_e( 'Each device gets only its own version: pick the same design, a different one, the theme\'s, or nothing.', 'studiare-extensions' ); ?></p>
						</header>
						<div class="stx-tpl-grid" data-stx-picker="<?php echo esc_attr( $area ); ?>" data-path="<?php echo esc_attr( $area ); ?>.mobile" data-keywords="same,theme,none"></div>
					</div>

					<?php if ( $is_header ) : ?>
						<div class="stx-card">
							<header class="stx-card__head">
								<h2><?php esc_html_e( 'Behaviour while scrolling', 'studiare-extensions' ); ?></h2>
								<p><?php esc_html_e( 'Applies to Studiare+ headers (the theme header keeps its own settings).', 'studiare-extensions' ); ?></p>
							</header>
							<div class="stx-fields stx-fields--2">
								<?php
								$sticky_options = array(
									'none'      => __( 'Scrolls away', 'studiare-extensions' ),
									'always'    => __( 'Always visible', 'studiare-extensions' ),
									'scroll_up' => __( 'Shows when scrolling up', 'studiare-extensions' ),
								);
								Fields::segmented( 'header.sticky_desktop', __( 'Desktop', 'studiare-extensions' ), $sticky_options );
								Fields::segmented( 'header.sticky_mobile', __( 'Phones & tablets', 'studiare-extensions' ), $sticky_options );
								?>
							</div>
						</div>
					<?php endif; ?>
				</section>
			<?php endforeach; ?>

			<section class="stx-panel" role="tabpanel" id="stx-panel-library" aria-labelledby="stx-tab-library">
				<div class="stx-card">
					<header class="stx-card__head stx-card__head--split">
						<div>
							<h2><?php esc_html_e( 'Template library', 'studiare-extensions' ); ?></h2>
							<p><?php esc_html_e( 'Every design is a normal Elementor template: edit it, duplicate it to try variations, or restore a ready-made design to its original state.', 'studiare-extensions' ); ?></p>
						</div>
						<div class="stx-inline-actions">
							<button type="button" class="stx-btn stx-btn--ghost" data-stx-install-presets>
								<?php echo $ui_icon( 'download' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php esc_html_e( 'Reinstall missing designs', 'studiare-extensions' ); ?></span>
							</button>
							<button type="button" class="stx-btn stx-btn--primary" data-stx-new-template>
								<?php echo $ui_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php esc_html_e( 'New template', 'studiare-extensions' ); ?></span>
							</button>
						</div>
					</header>
					<div class="stx-library" data-stx-library></div>
				</div>
			</section>

			<section class="stx-panel" role="tabpanel" id="stx-panel-brand" aria-labelledby="stx-tab-brand">
				<div class="stx-card">
					<header class="stx-card__head stx-card__head--split">
						<div>
							<h2><?php esc_html_e( 'Brand colours', 'studiare-extensions' ); ?></h2>
							<p><?php esc_html_e( 'Every design uses these colours, including Studiare\'s dark mode. Anything you set on a widget in Elementor overrides them.', 'studiare-extensions' ); ?></p>
						</div>
						<div class="stx-inline-actions">
							<?php if ( Theme_Bridge::is_active() ) : ?>
								<button type="button" class="stx-btn stx-btn--ghost" data-stx-theme-colors><?php esc_html_e( 'Use Studiare\'s colours', 'studiare-extensions' ); ?></button>
							<?php endif; ?>
							<?php if ( $elementor['active'] ) : ?>
								<button type="button" class="stx-btn stx-btn--soft" data-stx-sync-colors><?php esc_html_e( 'Add to Elementor global colours', 'studiare-extensions' ); ?></button>
							<?php endif; ?>
						</div>
					</header>
					<div class="stx-color-grid">
						<?php foreach ( Schema::BRAND_DEFAULTS as $key => $fallback ) : ?>
							<?php Fields::color( 'brand.' . $key, $brand_labels[ $key ], $fallback ); ?>
						<?php endforeach; ?>
					</div>
					<div class="stx-fields" style="margin-top:22px">
						<?php Fields::range( 'brand.radius', __( 'Corner roundness', 'studiare-extensions' ), 0, 40, 1, 'px' ); ?>
					</div>
				</div>

				<div class="stx-card">
					<header class="stx-card__head">
						<h2><?php esc_html_e( 'Options', 'studiare-extensions' ); ?></h2>
					</header>
					<div class="stx-fields">
						<?php
						Fields::range(
							'breakpoint',
							__( 'Phone & tablet breakpoint', 'studiare-extensions' ),
							480,
							1600,
							1,
							'px',
							array( 'help' => __( 'At this width and below, the phone header and footer are shown. 1024 matches Elementor\'s tablet breakpoint.', 'studiare-extensions' ) )
						);

						$packs = array();
						foreach ( Icon_Library::catalog()['packs'] as $pack_id => $pack ) {
							if ( Icon_Library::FONT_AWESOME !== $pack_id ) {
								$packs[ $pack_id ] = $pack['label'];
							}
						}
						Fields::select( 'options.icon_pack', __( 'Icon style in the designs', 'studiare-extensions' ), $packs );

						Fields::toggle(
							'options.persian_digits',
							__( 'Persian digits', 'studiare-extensions' ),
							array( 'help' => __( 'Show prices, counts and years as ۱۲۳ with Persian separators on Persian sites.', 'studiare-extensions' ) )
						);
						Fields::toggle(
							'options.hide_theme_title',
							__( 'Hide Studiare\'s title bar on template pages', 'studiare-extensions' ),
							array( 'help' => __( 'Course and product templates have their own title and breadcrumb.', 'studiare-extensions' ) )
						);
						?>
					</div>
				</div>
			</section>

		</div>
	</div>
</div>
