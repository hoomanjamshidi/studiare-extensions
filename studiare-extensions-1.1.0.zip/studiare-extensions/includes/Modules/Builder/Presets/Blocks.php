<?php
/**
 * Building blocks shared by several presets.
 *
 * @package StudiareExt
 */

namespace StudiareExt\Modules\Builder\Presets;

defined( 'ABSPATH' ) || exit;

final class Blocks {

	/**
	 * Heading widget.
	 *
	 * @param string $title Title.
	 * @param string $size  xl|lg|md|sm|xs.
	 * @param array  $more  Extra settings (eyebrow, subtitle, align, tag…).
	 */
	public static function heading( string $title, string $size = 'md', array $more = array() ): array {
		return El::w(
			'stx-heading',
			array_merge(
				array(
					'title' => $title,
					'size'  => $size,
					'tag'   => in_array( $size, array( 'sm', 'xs' ), true ) ? 'h3' : 'h2',
				),
				$more
			)
		);
	}

	/**
	 * Text widget.
	 *
	 * @param string $html Paragraph HTML.
	 * @param string $tone body|lead|muted.
	 * @param array  $more Extra settings.
	 */
	public static function text( string $html, string $tone = 'body', array $more = array() ): array {
		return El::w(
			'stx-text',
			array_merge(
				array(
					'content' => $html,
					'tone'    => $tone,
				),
				$more
			)
		);
	}

	/**
	 * Button widget.
	 *
	 * @param string $text    Text.
	 * @param string $url     Link.
	 * @param string $variant Variant.
	 * @param array  $more    Extra settings.
	 */
	public static function button( string $text, string $url, string $variant = 'accent', array $more = array() ): array {
		return El::w(
			'stx-button',
			array_merge(
				array(
					'text'    => $text,
					'link'    => array(
						'url'         => $url,
						'is_external' => '',
						'nofollow'    => '',
					),
					'variant' => $variant,
				),
				$more
			)
		);
	}

	/**
	 * Buy card: price, add to cart and key facts.
	 *
	 * @param array $facts Info items (source keys) for the list under the button.
	 * @param array $o     `note` (text under the button), `pad`, `hide` (devices).
	 */
	public static function buy_card( array $facts, array $o = array() ): array {
		$items = array();
		foreach ( $facts as $source ) {
			$items[] = array(
				'_id'    => El::id(),
				'source' => $source,
				'icon'   => 'auto',
			);
		}

		return El::box(
			array(
				'surface' => 'card',
				'pad'     => $o['pad'] ?? 26,
				'pad_mobile' => 20,
				'gap'     => 18,
				'hide'    => $o['hide'] ?? array(),
				'set'     => array( 'css_classes' => 'stx-buycard' ),
			),
			array(
				El::w( 'stx-product-price', array( 'size' => 'lg' ) ),
				El::w(
					'stx-add-to-cart',
					array(
						'note'      => $o['note'] ?? '',
						'note_icon' => 'wallet',
					)
				),
				$items ? El::w(
					'stx-product-info',
					array(
						'items'  => $items,
						'layout' => 'list',
					)
				) : null,
			)
		);
	}

	/**
	 * "Related" section: heading row with a "see all" link, then a grid.
	 *
	 * @param string $title    Section title.
	 * @param array  $settings Related widget settings.
	 * @param int    $boxed    Content width.
	 */
	public static function related( string $title, array $settings = array(), int $boxed = 1280 ): array {
		$shop = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );

		return El::box(
			array(
				'boxed'      => $boxed,
				'pad'        => array( 56, 20, 72 ),
				'pad_mobile' => array( 40, 16, 56 ),
				'gap'        => 20,
				'tag'        => 'section',
			),
			array(
				El::box(
					array(
						'dir'     => 'row',
						'justify' => 'space-between',
						'align'   => 'flex-end',
						'wrap'    => 'wrap',
						'gap'     => 12,
					),
					array(
						self::heading( $title, 'lg', array( 'tag' => 'h2' ) ),
						self::button( __( 'See all', 'studiare-extensions' ) . ' ←', $shop, 'link', array( 'size' => 'sm' ) ),
					)
				),
				El::w( 'stx-related-products', array_merge( array( 'source' => 'same_kind' ), $settings ) ),
			)
		);
	}

	/**
	 * Small benefit tile: icon, title and one line of text.
	 *
	 * @param string $icon  Bundled icon key.
	 * @param string $title Title.
	 * @param string $text  Text.
	 */
	public static function perk( string $icon, string $title, string $text ): array {
		return El::box(
			array(
				'surface' => 'card',
				'pad'     => array( 14, 16 ),
				'gap'     => 4,
				'grow'    => true,
				'width'   => 30,
				'width_mobile' => 100,
			),
			array(
				El::w(
					'stx-icon-list',
					array(
						'items'      => array(
							array(
								'_id'  => El::id(),
								'text' => $title,
								'icon' => $icon,
							),
						),
						'icon_style' => 'plain',
						'text_typography_typography'  => 'custom',
						'text_typography_font_weight' => '800',
					)
				),
				self::text( '<p>' . esc_html( $text ) . '</p>', 'muted' ),
			)
		);
	}

	/**
	 * Info items for the product-info widget.
	 *
	 * @param array $specs List of [source, suffix?, label?].
	 */
	public static function facts( array $specs ): array {
		$items = array();
		foreach ( $specs as $spec ) {
			$spec    = (array) $spec;
			$items[] = array(
				'_id'    => El::id(),
				'source' => $spec[0],
				'suffix' => $spec[1] ?? '',
				'label'  => $spec[2] ?? '',
				'icon'   => 'auto',
			);
		}

		return $items;
	}
}
