<?php
/**
 * Header designs. Each one is responsive by itself (the menu turns into a
 * drawer on small screens), and any of them can be picked separately for
 * desktop and for phones.
 *
 * @package StudiareExt
 */

namespace StudiareExt\Modules\Builder\Presets;

defined( 'ABSPATH' ) || exit;

final class Header {

	/** Logo, menu, search, cart and login in one row (from the supplied design). */
	public static function classic(): array {
		return array(
			El::box(
				array(
					'surface' => 'page',
					'tag'     => 'header',
					'set'     => array( 'css_classes' => 'stx-bar stx-bar--line' ),
				),
				array(
					El::box(
						array(
							'boxed'      => 1280,
							'dir'        => 'row',
							'align'      => 'center',
							'gap'        => 24,
							'gap_mobile' => 10,
							'pad'        => array( 14, 20 ),
							'pad_mobile' => array( 10, 14 ),
						),
						array(
							El::w( 'stx-site-logo', array( 'width' => El::px( 150 ), 'width_mobile' => El::px( 110 ) ) ),
							El::w(
								'stx-nav-menu',
								array(
									'pointer' => 'underline',
									'toggle'  => 'tablet',
								),
								array( 'grow' => true )
							),
							El::box(
								array(
									'dir'   => 'row',
									'align' => 'center',
									'gap'   => 10,
									'gap_mobile' => 6,
									'width' => 'auto',
									'set'   => array( '_flex_size' => 'none' ),
								),
								array(
									El::w( 'stx-search', array( 'layout' => 'icon' ) ),
									El::w( 'stx-cart', array( 'variant' => 'outline' ) ),
									El::w( 'stx-account', array( 'variant' => 'dark' ) ),
								)
							),
						)
					),
				)
			),
		);
	}

	/** Logo in the middle, search and account around it, menu row below. */
	public static function centered(): array {
		$third = array(
			'width'        => 33,
			'width_tablet' => 33,
			'width_mobile' => 33,
			'dir'          => 'row',
			'align'        => 'center',
			'gap'          => 10,
		);

		return array(
			El::box(
				array(
					'surface' => 'card',
					'tag'     => 'header',
					'set'     => array( 'css_classes' => 'stx-bar stx-bar--line' ),
				),
				array(
					El::box(
						array(
							'boxed'      => 1280,
							'dir'         => 'row',
							'align'       => 'center',
							'gap'         => 16,
							'gap_mobile'  => 6,
							// Elementor wraps rows on phones by default; the three thirds must share one line.
							'wrap_mobile' => 'nowrap',
							'pad'         => array( 16, 20 ),
							'pad_mobile'  => array( 10, 14 ),
						),
						array(
							El::box(
								$third,
								array(
									El::w(
										'stx-nav-menu',
										array(
											'toggle'       => 'always',
											'drawer_side'  => 'start',
										),
										array( 'hide' => array( 'desktop' ) )
									),
									El::w(
										'stx-search',
										array(
											'layout'      => 'field',
											'field_width' => El::size( 100 ),
										),
										array( 'hide' => array( 'tablet', 'mobile' ), 'grow' => true )
									),
								)
							),
							El::box(
								array_merge( $third, array( 'justify' => 'center', 'width' => 34, 'width_tablet' => 34, 'width_mobile' => 34 ) ),
								array(
									El::w(
										'stx-site-logo',
										array(
											'align'        => 'center',
											'width'        => El::px( 160 ),
											'width_mobile' => El::px( 110 ),
										)
									),
								)
							),
							El::box(
								array_merge( $third, array( 'justify' => 'flex-end' ) ),
								array(
									El::w( 'stx-search', array( 'layout' => 'icon' ), array( 'hide' => array( 'desktop' ) ) ),
									El::w( 'stx-account', array( 'variant' => 'outline' ), array( 'hide' => array( 'mobile' ) ) ),
									El::w( 'stx-cart', array( 'variant' => 'icon' ) ),
								)
							),
						)
					),
					El::box(
						array(
							'boxed' => 1280,
							'pad'   => array( 4, 20, 10 ),
							'hide'  => array( 'tablet', 'mobile' ),
						),
						array(
							El::w(
								'stx-nav-menu',
								array(
									'pointer' => 'pill',
									'toggle'  => 'never',
									'align'   => 'center',
								)
							),
						)
					),
				)
			),
		);
	}

	/** Contact strip on top, then logo, menu and a call-to-action. */
	public static function topbar(): array {
		return array(
			El::box(
				array(
					'tag' => 'header',
					'set' => array( 'css_classes' => 'stx-bar' ),
				),
				array(
					El::box(
						array(
							'surface' => 'dark',
							'hide'    => array( 'mobile' ),
							'set'     => array( 'css_classes' => 'stx-band' ),
						),
						array(
							El::box(
								array(
									'boxed'   => 1280,
									'dir'     => 'row',
									'align'   => 'center',
									'justify' => 'space-between',
									'gap'     => 16,
									'pad'     => array( 8, 20 ),
								),
								array(
									El::w(
										'stx-icon-list',
										array(
											'layout'           => 'horizontal',
											'items'            => array(
												array(
													'_id'  => El::id(),
													'text' => '021-00000000',
													'icon' => 'phone',
													'ltr'  => 'yes',
													'link' => array( 'url' => 'tel:02100000000' ),
												),
												array(
													'_id'  => El::id(),
													'text' => 'info@example.com',
													'icon' => 'mail',
													'ltr'  => 'yes',
													'link' => array( 'url' => 'mailto:info@example.com' ),
												),
											),
											'text_typography_typography' => 'custom',
											'text_typography_font_size'  => El::px( 13 ),
										)
									),
									Footer::social( 'dark', 13 ),
								)
							),
						)
					),
					El::box(
						array(
							'surface' => 'card',
							'set'     => array( 'css_classes' => 'stx-band stx-bar--line' ),
						),
						array(
							El::box(
								array(
									'boxed'      => 1280,
									'dir'        => 'row',
									'align'      => 'center',
									'gap'        => 24,
									'gap_mobile' => 8,
									'pad'        => array( 14, 20 ),
									'pad_mobile' => array( 10, 14 ),
								),
								array(
									El::w( 'stx-site-logo', array( 'width' => El::px( 150 ), 'width_mobile' => El::px( 110 ) ) ),
									El::w(
										'stx-nav-menu',
										array(
											'pointer' => 'pill',
											'toggle'  => 'tablet',
										),
										array( 'grow' => true )
									),
									Blocks::button(
										__( 'Free consultation', 'studiare-extensions' ),
										'#',
										'accent',
										array(
											'size'        => 'sm',
											'hide_mobile' => 'hidden-mobile',
										)
									),
									El::w( 'stx-cart', array( 'variant' => 'icon' ) ),
									El::w( 'stx-account', array( 'variant' => 'icon' ) ),
								)
							),
						)
					),
				)
			),
		);
	}

	/** Wide search and a category bar, for large catalogues. */
	public static function market(): array {
		return array(
			El::box(
				array(
					'surface' => 'card',
					'tag'     => 'header',
					'set'     => array( 'css_classes' => 'stx-bar stx-bar--line' ),
				),
				array(
					El::box(
						array(
							'boxed'      => 1280,
							'dir'        => 'row',
							'wrap'       => 'wrap',
							'align'      => 'center',
							'justify_mobile' => 'space-between',
							'gap'        => 20,
							'gap_mobile' => array( 10, 8 ),
							'pad'        => array( 14, 20 ),
							'pad_mobile' => array( 10, 14 ),
						),
						array(
							El::w(
								'stx-nav-menu',
								array(
									'source'       => 'product_cat',
									'toggle'       => 'always',
									'drawer_title' => __( 'Categories', 'studiare-extensions' ),
								),
								array( 'hide' => array( 'desktop' ) )
							),
							El::w( 'stx-site-logo', array( 'width' => El::px( 140 ), 'width_mobile' => El::px( 104 ) ) ),
							El::w(
								'stx-search',
								array(
									'layout'              => 'field',
									'field_width'         => El::size( 100 ),
									'_flex_order_mobile'  => 'end',
									'_element_width_mobile' => 'inherit',
									'placeholder'         => __( 'Search among all products…', 'studiare-extensions' ),
								),
								array( 'grow' => true )
							),
							El::box(
								array(
									'dir'   => 'row',
									'align' => 'center',
									'gap'   => 10,
									'width' => 'auto',
									'set'   => array( '_flex_size' => 'none' ),
								),
								array(
									El::w( 'stx-account', array( 'variant' => 'outline' ) ),
									El::w(
										'stx-cart',
										array(
											'variant'    => 'solid',
											'show_total' => 'yes',
										)
									),
								)
							),
						)
					),
					El::box(
						array(
							'hide' => array( 'tablet', 'mobile' ),
							'set'  => array( 'css_classes' => 'stx-bar--line-top' ),
						),
						array(
							El::box(
								array(
									'boxed'   => 1280,
									'dir'     => 'row',
									'align'   => 'center',
									'justify' => 'space-between',
									'gap'     => 20,
									'pad'     => array( 4, 20 ),
								),
								array(
									El::w(
										'stx-nav-menu',
										array(
											'source'  => 'product_cat',
											'pointer' => 'pill',
											'toggle'  => 'never',
										)
									),
									El::w(
										'stx-nav-menu',
										array(
											'pointer' => 'none',
											'toggle'  => 'never',
											'depth'   => '1',
										)
									),
								)
							),
						)
					),
				)
			),
		);
	}

	/** Rounded floating bar with a dark mode switch. */
	public static function floating(): array {
		return array(
			El::box(
				array(
					'tag'        => 'header',
					'pad'        => array( 12, 16 ),
					'pad_mobile' => array( 8, 10 ),
					'set'        => array( 'css_classes' => 'stx-bar stx-bar--float' ),
				),
				array(
					El::box(
						array(
							'boxed'      => 1240,
							'surface'    => 'card',
							'dir'        => 'row',
							'align'      => 'center',
							'justify'    => 'space-between',
							'gap'        => 16,
							'gap_mobile' => 6,
							'pad'        => array( 10, 14, 10, 20 ),
							'pad_mobile' => array( 8, 10, 8, 14 ),
							'set'        => array( 'css_classes' => 'stx-pill-bar' ),
						),
						array(
							El::w( 'stx-site-logo', array( 'width' => El::px( 120 ), 'width_mobile' => El::px( 100 ) ) ),
							El::w(
								'stx-nav-menu',
								array(
									'pointer'     => 'pill',
									'toggle'      => 'tablet',
									'align'       => 'center',
									'align_tablet' => 'flex-end',
									'drawer_side' => 'end',
								),
								array( 'grow' => true )
							),
							El::box(
								array(
									'dir'   => 'row',
									'align' => 'center',
									'gap'   => 8,
									'gap_mobile' => 4,
									'width' => 'auto',
									'set'   => array( '_flex_size' => 'none' ),
								),
								array(
									El::w( 'stx-dark-toggle' ),
									El::w( 'stx-search', array( 'layout' => 'icon' ) ),
									El::w( 'stx-account', array( 'variant' => 'accent' ) ),
								)
							),
						)
					),
				)
			),
		);
	}
}
