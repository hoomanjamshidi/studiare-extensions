<?php
/**
 * Registry of the ready-made designs.
 *
 * @package StudiareExt
 */

namespace StudiareExt\Modules\Builder\Presets;

defined( 'ABSPATH' ) || exit;

final class Catalog {

	/**
	 * @return array<string, array{type:string, label:string, description:string, build:callable}>
	 */
	public static function all(): array {
		return array(
			'course-classic'   => array(
				'type'        => 'course',
				'label'       => __( 'Course · Classic', 'studiare-extensions' ),
				'description' => __( 'Cover, tabs (overview, curriculum, teacher, reviews) and a sticky buy box.', 'studiare-extensions' ),
				'build'       => array( Course::class, 'classic' ),
			),
			'course-spotlight' => array(
				'type'        => 'course',
				'label'       => __( 'Course · Spotlight', 'studiare-extensions' ),
				'description' => __( 'Dark hero with the teacher, a buy card with the intro video, sections stacked below.', 'studiare-extensions' ),
				'build'       => array( Course::class, 'spotlight' ),
			),
			'course-landing'   => array(
				'type'        => 'course',
				'label'       => __( 'Course · Landing', 'studiare-extensions' ),
				'description' => __( 'Centred sales page: big title, video, fact tiles, curriculum and a closing call to action.', 'studiare-extensions' ),
				'build'       => array( Course::class, 'landing' ),
			),
			'product-shop'     => array(
				'type'        => 'product',
				'label'       => __( 'Product · Shop', 'studiare-extensions' ),
				'description' => __( 'Gallery and buy area in one card, variation buttons, perks, tabs and similar products.', 'studiare-extensions' ),
				'build'       => array( Product::class, 'shop' ),
			),
			'product-showcase' => array(
				'type'        => 'product',
				'label'       => __( 'Product · Showcase', 'studiare-extensions' ),
				'description' => __( 'Large gallery with a sticky summary and a section jump bar below.', 'studiare-extensions' ),
				'build'       => array( Product::class, 'showcase' ),
			),
			'product-editorial' => array(
				'type'        => 'product',
				'label'       => __( 'Product · Editorial', 'studiare-extensions' ),
				'description' => __( 'Soft hero band, benefit tiles and details in an accordion.', 'studiare-extensions' ),
				'build'       => array( Product::class, 'editorial' ),
			),
			'header-classic'   => array(
				'type'        => 'header',
				'label'       => __( 'Header · Classic', 'studiare-extensions' ),
				'description' => __( 'Logo, menu, search, cart and login in one row.', 'studiare-extensions' ),
				'build'       => array( Header::class, 'classic' ),
			),
			'header-centered'  => array(
				'type'        => 'header',
				'label'       => __( 'Header · Centred logo', 'studiare-extensions' ),
				'description' => __( 'Logo in the middle, search and account around it, menu below.', 'studiare-extensions' ),
				'build'       => array( Header::class, 'centered' ),
			),
			'header-topbar'    => array(
				'type'        => 'header',
				'label'       => __( 'Header · Top bar', 'studiare-extensions' ),
				'description' => __( 'Contact strip on top, then logo, menu and a call-to-action button.', 'studiare-extensions' ),
				'build'       => array( Header::class, 'topbar' ),
			),
			'header-market'    => array(
				'type'        => 'header',
				'label'       => __( 'Header · Marketplace', 'studiare-extensions' ),
				'description' => __( 'Wide search field and a category bar — for large catalogues.', 'studiare-extensions' ),
				'build'       => array( Header::class, 'market' ),
			),
			'header-floating'  => array(
				'type'        => 'header',
				'label'       => __( 'Header · Floating', 'studiare-extensions' ),
				'description' => __( 'Rounded floating bar with dark mode switch. Also great as a phone header.', 'studiare-extensions' ),
				'build'       => array( Header::class, 'floating' ),
			),
			'footer-columns'   => array(
				'type'        => 'footer',
				'label'       => __( 'Footer · Columns', 'studiare-extensions' ),
				'description' => __( 'About, two link columns, contact details and trust badges.', 'studiare-extensions' ),
				'build'       => array( Footer::class, 'columns' ),
			),
			'footer-dark'      => array(
				'type'        => 'footer',
				'label'       => __( 'Footer · Dark', 'studiare-extensions' ),
				'description' => __( 'Call-to-action band over a dark footer.', 'studiare-extensions' ),
				'build'       => array( Footer::class, 'dark' ),
			),
			'footer-minimal'   => array(
				'type'        => 'footer',
				'label'       => __( 'Footer · Minimal', 'studiare-extensions' ),
				'description' => __( 'One slim row: logo, links and copyright.', 'studiare-extensions' ),
				'build'       => array( Footer::class, 'minimal' ),
			),
			'footer-centered'  => array(
				'type'        => 'footer',
				'label'       => __( 'Footer · Centred', 'studiare-extensions' ),
				'description' => __( 'Logo, short text, social icons and links, all centred.', 'studiare-extensions' ),
				'build'       => array( Footer::class, 'centered' ),
			),
			'footer-trust'     => array(
				'type'        => 'footer',
				'label'       => __( 'Footer · Trust', 'studiare-extensions' ),
				'description' => __( 'Contact card, links and large e-Namad / Samandehi area.', 'studiare-extensions' ),
				'build'       => array( Footer::class, 'trust' ),
			),
		);
	}

	/** @return string[] */
	public static function keys(): array {
		return array_keys( self::all() );
	}

	/**
	 * @param string $key Preset key.
	 */
	public static function get( string $key ): ?array {
		return self::all()[ $key ] ?? null;
	}

	/**
	 * Elementor data for a preset.
	 *
	 * @param string $key Preset key.
	 */
	public static function build( string $key ): array {
		$preset = self::get( $key );

		return $preset ? El::finalize( call_user_func( $preset['build'] ) ) : array();
	}
}
