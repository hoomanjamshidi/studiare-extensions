<?php
/**
 * Footer designs.
 *
 * @package StudiareExt
 */

namespace StudiareExt\Modules\Builder\Presets;

use StudiareExt\Modules\Builder\Schema;

defined( 'ABSPATH' ) || exit;

final class Footer {

	/**
	 * Elementor's native Social Icons widget with brand colours.
	 *
	 * @param string $tone `light` or `dark` background.
	 * @param int    $size Icon size.
	 */
	public static function social( string $tone = 'light', int $size = 16 ): array {
		$list = array();
		foreach ( array( 'fab fa-instagram', 'fab fa-telegram', 'fab fa-whatsapp', 'fab fa-youtube' ) as $icon ) {
			$list[] = array(
				'_id'         => El::id(),
				'social_icon' => array(
					'value'   => $icon,
					'library' => 'fa-brands',
				),
				'link'        => array(
					'url'         => '#',
					'is_external' => 'true',
					'nofollow'    => '',
				),
			);
		}

		$dark = 'dark' === $tone;

		return El::w(
			'social-icons',
			array(
				'social_icon_list'      => $list,
				'shape'                 => 'rounded',
				'align'                 => El::start(),
				'icon_color'            => 'custom',
				'icon_primary_color'    => $dark ? 'rgba(255,255,255,0.08)' : '#EEF1F3',
				'icon_secondary_color'  => $dark ? '#EAEDEF' : Schema::BRAND_DEFAULTS['text'],
				'hover_primary_color'   => Schema::BRAND_DEFAULTS['accent'],
				'hover_secondary_color' => '#FFFFFF',
				'icon_size'             => El::px( $size ),
				'icon_padding'          => array(
					'unit'  => 'em',
					'size'  => 0.62,
					'sizes' => array(),
				),
				'icon_spacing'          => El::px( 8 ),
				'border_radius'         => El::dims( 10 ),
			)
		);
	}

	/**
	 * Column heading.
	 *
	 * @param string $title Title.
	 */
	private static function col_title( string $title ): array {
		return Blocks::heading( $title, 'xs', array( 'tag' => 'h3' ) );
	}

	/** Contact list with placeholder details. */
	private static function contact_list(): array {
		return El::w(
			'stx-icon-list',
			array(
				'items' => array(
					array(
						'_id'  => El::id(),
						'text' => '021-00000000',
						'icon' => 'phone',
						'ltr'  => 'yes',
						'link' => array( 'url' => 'tel:02100000000' ),
					),
					array(
						'_id'  => El::id(),
						'text' => 'info@example.com',
						'icon' => 'mail',
						'ltr'  => 'yes',
						'link' => array( 'url' => 'mailto:info@example.com' ),
					),
					array(
						'_id'  => El::id(),
						'text' => __( 'Your address goes here', 'studiare-extensions' ),
						'icon' => 'map-pin',
					),
				),
			)
		);
	}

	/**
	 * Vertical link list from a menu (or the product categories).
	 *
	 * @param string $source `menu` or `product_cat`.
	 */
	private static function links( string $source = 'menu' ): array {
		return El::w(
			'stx-nav-menu',
			array(
				'source' => $source,
				'layout' => 'vertical',
				'toggle' => 'never',
				'depth'  => '1',
			)
		);
	}

	/**
	 * @param string $align Alignment (start|center).
	 */
	private static function copyright( string $align = '' ): array {
		return El::w( 'stx-copyright', '' !== $align ? array( 'align' => $align ) : array() );
	}

	/** About, two link columns, contact details, bottom bar with trust badges. */
	public static function columns(): array {
		$col = static function ( int $width, array $children ): array {
			return El::box(
				array(
					'width'        => $width,
					'width_tablet' => 46,
					'width_mobile' => 100,
					'gap'          => 14,
				),
				$children
			);
		};

		return array(
			El::box(
				array(
					'surface' => 'card',
					'tag'     => 'footer',
					'set'     => array( 'css_classes' => 'stx-foot stx-foot--accent' ),
				),
				array(
					El::box(
						array(
							'boxed'      => 1280,
							'dir'        => 'row',
							'wrap'       => 'wrap',
							'gap'        => array( 32, 40 ),
							'pad'        => array( 48, 20, 32 ),
							'pad_mobile' => array( 36, 16, 24 ),
						),
						array(
							$col(
								30,
								array(
									El::w( 'stx-site-logo', array( 'width' => El::px( 140 ) ) ),
									Blocks::text( '<p>' . esc_html__( 'A short line about your school: what you teach, who it is for and why students trust you.', 'studiare-extensions' ) . '</p>', 'muted' ),
									self::social(),
								)
							),
							$col( 18, array( self::col_title( __( 'Quick links', 'studiare-extensions' ) ), self::links() ) ),
							$col( 18, array( self::col_title( __( 'Courses & products', 'studiare-extensions' ) ), self::links( 'product_cat' ) ) ),
							$col( 22, array( self::col_title( __( 'Contact us', 'studiare-extensions' ) ), self::contact_list() ) ),
						)
					),
					El::box(
						array(
							'boxed' => 1280,
							'set'   => array( 'css_classes' => 'stx-bar--line-top' ),
						),
						array(
							El::box(
								array(
									'dir'        => 'row',
									'dir_mobile' => 'column',
									'justify'    => 'space-between',
									'align'      => 'center',
									'gap'        => 14,
									'pad'        => array( 16, 20 ),
								),
								array(
									self::copyright(),
									El::w( 'stx-trust-badges', array( 'size' => El::px( 72 ) ) ),
								)
							),
						)
					),
				)
			),
		);
	}

	/** Call-to-action band over a dark footer. */
	public static function dark(): array {
		return array(
			El::box(
				array(
					'tag' => 'footer',
					'set' => array( 'css_classes' => 'stx-foot' ),
				),
				array(
					El::box(
						array(
							'boxed'      => 1180,
							'pad'        => array( 0, 20 ),
							'pad_mobile' => array( 0, 16 ),
							'margin'     => array( 24, 0, -56, 0 ),
							'set'        => array( 'z_index' => 2 ),
						),
						array(
							El::box(
								array(
									'surface'    => 'accent',
									'dir'        => 'row',
									'dir_tablet' => 'column',
									'justify'    => 'space-between',
									'align'      => 'center',
									'gap'        => 20,
									'pad'        => array( 28, 32 ),
									'pad_mobile' => array( 22, 20 ),
								),
								array(
									El::box(
										array(
											'gap'  => 6,
											'grow' => true,
										),
										array(
											Blocks::heading( __( 'Start learning today', 'studiare-extensions' ), 'md' ),
											Blocks::text( '<p>' . esc_html__( 'Join thousands of students and learn at your own pace.', 'studiare-extensions' ) . '</p>' ),
										)
									),
									Blocks::button( __( 'Browse courses', 'studiare-extensions' ), function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : '#', 'dark', array( 'size' => 'lg' ) ),
								)
							),
						)
					),
					El::box(
						array(
							'surface' => 'dark',
							'set'     => array( 'css_classes' => 'stx-band' ),
						),
						array(
							El::box(
								array(
									'boxed'      => 1280,
									'dir'        => 'row',
									'wrap'       => 'wrap',
									'gap'        => array( 28, 40 ),
									'pad'        => array( 96, 20, 32 ),
									'pad_mobile' => array( 84, 16, 24 ),
								),
								array(
									El::box(
										array(
											'width'        => 36,
											'width_tablet' => 100,
											'gap'          => 14,
										),
										array(
											El::w( 'stx-site-logo', array( 'source' => 'text' ) ),
											Blocks::text( '<p>' . esc_html__( 'A short line about your school: what you teach, who it is for and why students trust you.', 'studiare-extensions' ) . '</p>', 'muted' ),
											self::social( 'dark' ),
										)
									),
									El::box(
										array(
											'width'        => 24,
											'width_tablet' => 46,
											'width_mobile' => 100,
											'gap'          => 14,
										),
										array( self::col_title( __( 'Quick links', 'studiare-extensions' ) ), self::links() )
									),
									El::box(
										array(
											'width'        => 28,
											'width_tablet' => 46,
											'width_mobile' => 100,
											'gap'          => 14,
										),
										array( self::col_title( __( 'Contact us', 'studiare-extensions' ) ), self::contact_list() )
									),
								)
							),
							El::box(
								array(
									'boxed' => 1280,
									'pad'   => array( 16, 20 ),
									'set'   => array( 'css_classes' => 'stx-bar--line-top' ),
								),
								array( self::copyright() )
							),
						)
					),
				)
			),
		);
	}

	/** One slim row: logo, links and copyright. */
	public static function minimal(): array {
		return array(
			El::box(
				array(
					'surface' => 'card',
					'tag'     => 'footer',
					'set'     => array( 'css_classes' => 'stx-foot stx-bar--line-top' ),
				),
				array(
					El::box(
						array(
							'boxed'      => 1280,
							'dir'        => 'row',
							'dir_mobile' => 'column',
							'justify'    => 'space-between',
							'align'      => 'center',
							'gap'        => 16,
							'pad'        => array( 22, 20 ),
						),
						array(
							El::w( 'stx-site-logo', array( 'width' => El::px( 110 ) ) ),
							El::w(
								'stx-nav-menu',
								array(
									'pointer' => 'none',
									'toggle'  => 'never',
									'depth'   => '1',
									'align'   => 'center',
								)
							),
							self::copyright(),
						)
					),
				)
			),
		);
	}

	/** Everything centred. */
	public static function centered(): array {
		return array(
			El::box(
				array(
					'surface' => 'page',
					'tag'     => 'footer',
					'set'     => array( 'css_classes' => 'stx-foot stx-bar--line-top' ),
				),
				array(
					El::box(
						array(
							'boxed'      => 900,
							'align'      => 'center',
							'gap'        => 18,
							'pad'        => array( 48, 20, 28 ),
							'pad_mobile' => array( 36, 16, 24 ),
						),
						array(
							El::w(
								'stx-site-logo',
								array(
									'align' => 'center',
									'width' => El::px( 140 ),
								)
							),
							Blocks::text(
								'<p>' . esc_html__( 'A short line about your school: what you teach, who it is for and why students trust you.', 'studiare-extensions' ) . '</p>',
								'muted',
								array( 'align' => 'center' )
							),
							array_replace_recursive( self::social(), array( 'settings' => array( 'align' => 'center' ) ) ),
							El::w(
								'stx-nav-menu',
								array(
									'pointer' => 'none',
									'toggle'  => 'never',
									'depth'   => '1',
									'align'   => 'center',
								)
							),
							self::copyright( 'center' ),
						)
					),
				)
			),
		);
	}

	/** Support card, links and a large trust-badge area. */
	public static function trust(): array {
		return array(
			El::box(
				array(
					'surface' => 'card',
					'tag'     => 'footer',
					'set'     => array( 'css_classes' => 'stx-foot stx-bar--line-top' ),
				),
				array(
					El::box(
						array(
							'boxed'      => 1280,
							'dir'        => 'row',
							'wrap'       => 'wrap',
							'gap'        => array( 28, 32 ),
							'pad'        => array( 44, 20, 28 ),
							'pad_mobile' => array( 32, 16, 20 ),
						),
						array(
							El::box(
								array(
									'surface'      => 'page',
									'width'        => 32,
									'width_tablet' => 100,
									'gap'          => 14,
									'pad'          => 24,
								),
								array(
									Blocks::heading( __( 'Need help?', 'studiare-extensions' ), 'sm' ),
									self::contact_list(),
									Blocks::button( __( 'Send a ticket', 'studiare-extensions' ), '#', 'accent', array( 'size' => 'sm' ) ),
								)
							),
							El::box(
								array(
									'width'        => 18,
									'width_tablet' => 30,
									'width_mobile' => 100,
									'gap'          => 14,
								),
								array( self::col_title( __( 'Quick links', 'studiare-extensions' ) ), self::links() )
							),
							El::box(
								array(
									'width'        => 18,
									'width_tablet' => 30,
									'width_mobile' => 100,
									'gap'          => 14,
								),
								array( self::col_title( __( 'Categories', 'studiare-extensions' ) ), self::links( 'product_cat' ) )
							),
							El::box(
								array(
									'width'        => 24,
									'width_tablet' => 30,
									'width_mobile' => 100,
									'gap'          => 14,
								),
								array(
									self::col_title( __( 'Trust badges', 'studiare-extensions' ) ),
									El::w( 'stx-trust-badges', array( 'size' => El::px( 104 ) ) ),
								)
							),
						)
					),
					El::box(
						array(
							'boxed' => 1280,
							'set'   => array( 'css_classes' => 'stx-bar--line-top' ),
						),
						array(
							El::box(
								array(
									'dir'        => 'row',
									'dir_mobile' => 'column',
									'justify'    => 'space-between',
									'align'      => 'center',
									'gap'        => 12,
									'pad'        => array( 16, 20 ),
								),
								array(
									self::copyright(),
									self::social(),
								)
							),
						)
					),
				)
			),
		);
	}
}
