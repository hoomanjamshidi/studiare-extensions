<?php
/**
 * Front-end assets shared by every template and widget, plus the brand
 * tokens (`--stx-*` custom properties) they are styled with.
 *
 * @package StudiareExt
 */

namespace StudiareExt\Modules\Builder;

defined( 'ABSPATH' ) || exit;

final class Assets {

	public const HANDLE = 'stx-builder';

	/** @var Module */
	private $module;

	/** @var bool */
	private $registered = false;

	/**
	 * @param Module $module Owning module.
	 */
	public function __construct( Module $module ) {
		$this->module = $module;
	}

	public function register(): void {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 1 );
		add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_assets' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_assets' ) );
	}

	public function register_assets(): void {
		if ( $this->registered ) {
			return;
		}
		$this->registered = true;

		wp_register_style( self::HANDLE, STUDIARE_EXT_URL . 'assets/modules/builder/css/builder.css', array(), STUDIARE_EXT_VERSION );
		wp_add_inline_style( self::HANDLE, $this->tokens_css() );

		wp_register_script(
			self::HANDLE,
			STUDIARE_EXT_URL . 'assets/modules/builder/js/builder.js',
			array(),
			STUDIARE_EXT_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_add_inline_script(
			self::HANDLE,
			'window.stxBuilder = ' . wp_json_encode(
				array(
					'breakpoint' => (int) $this->module->settings()['breakpoint'],
					'i18n'       => array(
						'close'    => __( 'Close', 'studiare-extensions' ),
						'expand'   => __( 'Show more', 'studiare-extensions' ),
						'collapse' => __( 'Show less', 'studiare-extensions' ),
					),
				)
			) . ';',
			'before'
		);
	}

	/** `:root` custom properties from the brand settings. */
	public function tokens_css(): string {
		$brand = $this->module->settings()['brand'];
		$vars  = array();

		foreach ( Schema::BRAND_DEFAULTS as $key => $fallback ) {
			$value  = '' !== $brand[ $key ] ? $brand[ $key ] : $fallback;
			$vars[] = '--stx-' . str_replace( '_', '-', $key ) . ':' . $value;
		}

		$vars[] = '--stx-radius:' . (int) $brand['radius'] . 'px';
		$vars[] = '--stx-bp:' . (int) $this->module->settings()['breakpoint'] . 'px';

		return ':root{' . implode( ';', $vars ) . '}';
	}
}
