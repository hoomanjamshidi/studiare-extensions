<?php
/**
 * Wireframe thumbnails for the admin cards (RTL, like the designs).
 * The live preview shows the real rendering; these are the quick glance.
 *
 * @package StudiareExt
 */

namespace StudiareExt\Modules\Builder;

defined( 'ABSPATH' ) || exit;

final class Thumbs {

	private const INK    = '#2e373c';
	private const MUTED  = '#c9d1d6';
	private const LINE   = '#d5dce0';
	private const BG     = '#f4f6f7';
	private const MEDIA  = '#dde3e7';
	private const ACCENT = '#f8b000';
	private const WHITE  = '#ffffff';

	/**
	 * SVG markup for a preset key, a template kind or `theme`.
	 *
	 * @param string $key Preset key / kind.
	 */
	public static function svg( string $key ): string {
		$method = 'draw_' . str_replace( '-', '_', $key );
		$body   = method_exists( self::class, $method ) ? self::$method() : self::generic( $key );

		return '<svg class="stx-thumb" viewBox="0 0 240 150" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">' . $body . '</svg>';
	}

	/**
	 * @param float  $x      X.
	 * @param float  $y      Y.
	 * @param float  $w      Width.
	 * @param float  $h      Height.
	 * @param string $fill   Fill.
	 * @param float  $rx     Radius.
	 * @param string $stroke Stroke colour ('' for none).
	 */
	private static function r( $x, $y, $w, $h, string $fill, $rx = 2, string $stroke = '' ): string {
		return sprintf(
			'<rect x="%s" y="%s" width="%s" height="%s" rx="%s" fill="%s"%s/>',
			$x,
			$y,
			$w,
			$h,
			$rx,
			$fill,
			'' !== $stroke ? ' stroke="' . $stroke . '" stroke-width="1"' : ''
		);
	}

	/**
	 * @param float  $cx   X.
	 * @param float  $cy   Y.
	 * @param float  $r    Radius.
	 * @param string $fill Fill.
	 */
	private static function c( $cx, $cy, $r, string $fill ): string {
		return sprintf( '<circle cx="%s" cy="%s" r="%s" fill="%s"/>', $cx, $cy, $r, $fill );
	}

	/** Text lines, right-aligned (RTL). */
	private static function lines( $right, $y, array $widths, string $fill = self::MUTED, $gap = 7, $h = 3.5 ): string {
		$out = '';
		foreach ( $widths as $i => $w ) {
			$out .= self::r( $right - $w, $y + $i * $gap, $w, $h, $fill, 1.5 );
		}

		return $out;
	}

	private static function play( $cx, $cy ): string {
		return self::c( $cx, $cy, 9, 'rgba(15,19,21,.55)' ) . sprintf( '<path d="M%1$s %2$sl7 4.5-7 4.5z" fill="#fff"/>', $cx - 2.5, $cy - 4.5 );
	}

	/** A faded page body under a header, or above a footer. */
	private static function page_body( $y, $h ): string {
		return self::r( 0, $y, 240, $h, self::BG, 0 )
			. self::r( 20, $y + 12, 200, 34, self::MEDIA, 6 )
			. self::lines( 220, $y + 54, array( 150, 120, 136 ) );
	}

	/* ---------------------------------------------------------------------
	 * Courses
	 * ------------------------------------------------------------------- */

	private static function draw_course_classic(): string {
		return self::r( 0, 0, 240, 150, self::BG, 0 )
			. self::lines( 232, 7, array( 70 ) )
			. self::r( 88, 17, 144, 70, self::MEDIA, 7 ) . self::play( 160, 52 )
			. self::r( 150, 93, 82, 7, self::INK ) . self::lines( 232, 105, array( 118, 96 ) )
			. self::r( 88, 124, 144, 18, self::WHITE, 5, self::LINE ) . self::r( 200, 139, 30, 2, self::ACCENT, 1 )
			. self::r( 8, 17, 74, 94, self::WHITE, 8, self::LINE )
			. self::r( 40, 26, 34, 7, self::INK ) . self::r( 56, 37, 18, 3.5, self::MUTED )
			. self::r( 15, 48, 60, 11, self::ACCENT, 4 ) . self::lines( 75, 67, array( 60, 60, 60, 44 ), self::MUTED, 9, 3 )
			. self::r( 8, 117, 74, 25, self::INK, 6 );
	}

	private static function draw_course_spotlight(): string {
		return self::r( 0, 0, 240, 150, self::BG, 0 )
			. self::r( 0, 0, 240, 72, self::INK, 0 )
			. self::r( 118, 18, 114, 9, self::WHITE ) . self::lines( 232, 32, array( 104, 84 ), '#8a959b' )
			. self::c( 224, 56, 6, self::MUTED ) . self::r( 170, 53, 46, 5, '#8a959b' )
			. self::r( 10, 22, 88, 118, self::WHITE, 8, self::LINE ) . self::r( 16, 28, 76, 42, self::MEDIA, 5 ) . self::play( 54, 49 )
			. self::r( 54, 78, 38, 7, self::INK ) . self::r( 16, 92, 76, 11, self::ACCENT, 4 ) . self::lines( 92, 110, array( 76, 60, 70 ), self::MUTED, 8, 3 )
			. self::r( 106, 80, 126, 26, self::WHITE, 6, self::LINE )
			. self::r( 106, 112, 126, 9, self::WHITE, 4, self::LINE ) . self::r( 106, 124, 126, 9, self::WHITE, 4, self::LINE ) . self::r( 106, 136, 126, 9, self::WHITE, 4, self::LINE );
	}

	private static function draw_course_landing(): string {
		return self::r( 0, 0, 240, 150, self::BG, 0 )
			. self::r( 60, 10, 120, 9, self::INK ) . self::r( 78, 24, 84, 4, self::MUTED ) . self::r( 90, 31, 60, 4, self::MUTED )
			. self::r( 124, 39, 36, 9, self::INK ) . self::r( 80, 38, 40, 11, self::ACCENT, 4 )
			. self::r( 36, 56, 168, 52, self::MEDIA, 8 ) . self::play( 120, 82 )
			. self::r( 36, 114, 39, 18, self::WHITE, 5, self::LINE ) . self::r( 79, 114, 39, 18, self::WHITE, 5, self::LINE ) . self::r( 122, 114, 39, 18, self::WHITE, 5, self::LINE ) . self::r( 165, 114, 39, 18, self::WHITE, 5, self::LINE )
			. self::r( 36, 138, 168, 10, '#fff5de', 4 );
	}

	/* ---------------------------------------------------------------------
	 * Products
	 * ------------------------------------------------------------------- */

	private static function draw_product_shop(): string {
		return self::r( 0, 0, 240, 150, self::BG, 0 )
			. self::r( 8, 10, 224, 88, self::WHITE, 8, self::LINE )
			. self::r( 150, 16, 76, 58, '#eef1f3', 6 ) . self::r( 150, 78, 17, 14, '#eef1f3', 3 ) . self::r( 170, 78, 17, 14, '#eef1f3', 3 ) . self::r( 190, 78, 17, 14, '#eef1f3', 3 ) . self::r( 210, 78, 16, 14, '#eef1f3', 3 )
			. self::r( 80, 18, 62, 7, self::INK ) . self::r( 110, 29, 32, 4, self::ACCENT )
			. self::r( 16, 38, 126, 30, self::BG, 5 ) . self::r( 106, 43, 30, 7, self::INK ) . self::r( 22, 55, 114, 9, self::ACCENT, 3 )
			. self::r( 16, 74, 40, 18, self::WHITE, 4, self::LINE ) . self::r( 59, 74, 40, 18, self::WHITE, 4, self::LINE ) . self::r( 102, 74, 40, 18, self::WHITE, 4, self::LINE )
			. self::r( 82, 104, 150, 40, self::WHITE, 7, self::LINE ) . self::r( 196, 112, 28, 3, self::ACCENT ) . self::lines( 224, 122, array( 130, 110 ) )
			. self::r( 8, 104, 68, 40, self::INK, 7 ) . self::r( 16, 128, 52, 9, self::ACCENT, 3 );
	}

	private static function draw_product_showcase(): string {
		return self::r( 0, 0, 240, 150, self::BG, 0 )
			. self::r( 100, 10, 116, 90, self::MEDIA, 7 ) . self::r( 220, 10, 12, 16, self::MEDIA, 3 ) . self::r( 220, 30, 12, 16, self::MEDIA, 3 ) . self::r( 220, 50, 12, 16, self::MEDIA, 3 )
			. self::r( 20, 14, 72, 7, self::INK ) . self::r( 60, 25, 32, 4, self::ACCENT ) . self::r( 56, 34, 36, 7, self::INK )
			. self::lines( 92, 46, array( 72, 60 ) ) . self::r( 10, 62, 82, 11, self::ACCENT, 4 ) . self::r( 10, 78, 82, 22, self::WHITE, 4, self::LINE )
			. self::r( 40, 110, 160, 10, self::WHITE, 5, self::LINE ) . self::r( 168, 117, 26, 2, self::ACCENT )
			. self::lines( 200, 128, array( 160, 140 ) );
	}

	private static function draw_product_editorial(): string {
		return self::r( 0, 0, 240, 150, self::BG, 0 )
			. self::r( 0, 0, 240, 84, '#fff5de', 0 )
			. self::r( 136, 16, 96, 10, self::INK ) . self::lines( 232, 32, array( 90, 70 ) ) . self::r( 196, 48, 36, 7, self::INK ) . self::r( 150, 60, 82, 11, self::ACCENT, 4 )
			. self::r( 12, 10, 112, 64, self::WHITE, 7 )
			. self::r( 12, 92, 68, 22, self::WHITE, 5, self::LINE ) . self::r( 86, 92, 68, 22, self::WHITE, 5, self::LINE ) . self::r( 160, 92, 68, 22, self::WHITE, 5, self::LINE )
			. self::r( 40, 122, 160, 9, self::WHITE, 4, self::LINE ) . self::r( 40, 135, 160, 9, self::WHITE, 4, self::LINE );
	}

	/* ---------------------------------------------------------------------
	 * Headers
	 * ------------------------------------------------------------------- */

	private static function draw_header_classic(): string {
		return self::page_body( 30, 120 )
			. self::r( 0, 0, 240, 30, self::BG, 0 ) . self::r( 0, 29, 240, 1, self::LINE, 0 )
			. self::r( 198, 11, 34, 8, self::INK )
			. self::lines( 188, 13, array( 18 ), self::INK, 0, 4 ) . self::r( 170, 19, 18, 1.5, self::ACCENT ) . self::lines( 162, 13, array( 16 ), self::MUTED, 0, 4 ) . self::lines( 140, 13, array( 16 ), self::MUTED, 0, 4 )
			. self::r( 66, 9, 12, 12, self::WHITE, 3, self::LINE ) . self::r( 36, 9, 26, 12, self::WHITE, 3, self::LINE ) . self::r( 8, 9, 24, 12, self::INK, 3 );
	}

	private static function draw_header_centered(): string {
		return self::page_body( 40, 110 )
			. self::r( 0, 0, 240, 40, self::WHITE, 0 ) . self::r( 0, 39, 240, 1, self::LINE, 0 )
			. self::r( 100, 7, 40, 10, self::INK ) . self::r( 168, 7, 64, 11, self::BG, 4, self::LINE )
			. self::r( 22, 7, 28, 11, self::WHITE, 3, self::LINE ) . self::r( 8, 7, 11, 11, self::INK, 3 )
			. self::r( 128, 26, 22, 8, '#fff5de', 4 ) . self::lines( 122, 28, array( 18 ), self::MUTED, 0, 4 ) . self::lines( 100, 28, array( 18 ), self::MUTED, 0, 4 ) . self::lines( 172, 28, array( 18 ), self::MUTED, 0, 4 );
	}

	private static function draw_header_topbar(): string {
		return self::page_body( 38, 112 )
			. self::r( 0, 0, 240, 11, self::INK, 0 ) . self::r( 190, 4, 42, 3, '#8a959b' ) . self::c( 12, 5.5, 2.5, '#8a959b' ) . self::c( 20, 5.5, 2.5, '#8a959b' ) . self::c( 28, 5.5, 2.5, '#8a959b' )
			. self::r( 0, 11, 240, 27, self::WHITE, 0 ) . self::r( 0, 37, 240, 1, self::LINE, 0 )
			. self::r( 198, 20, 34, 8, self::INK ) . self::r( 158, 20, 26, 9, '#fff5de', 4 ) . self::lines( 152, 22, array( 18 ), self::MUTED, 0, 4 ) . self::lines( 130, 22, array( 18 ), self::MUTED, 0, 4 )
			. self::r( 40, 18, 40, 12, self::ACCENT, 4 ) . self::r( 24, 18, 12, 12, self::WHITE, 3, self::LINE ) . self::r( 8, 18, 12, 12, self::WHITE, 3, self::LINE );
	}

	private static function draw_header_market(): string {
		return self::page_body( 44, 106 )
			. self::r( 0, 0, 240, 44, self::WHITE, 0 ) . self::r( 0, 43, 240, 1, self::LINE, 0 ) . self::r( 0, 28, 240, 1, self::LINE, 0 )
			. self::r( 202, 9, 30, 9, self::INK ) . self::r( 70, 7, 124, 13, self::BG, 5, self::LINE )
			. self::r( 38, 7, 26, 13, self::WHITE, 4, self::LINE ) . self::r( 8, 7, 26, 13, self::ACCENT, 4 )
			. self::r( 204, 32, 28, 8, '#fff5de', 4 ) . self::lines( 198, 34, array( 22 ), self::MUTED, 0, 4 ) . self::lines( 172, 34, array( 22 ), self::MUTED, 0, 4 ) . self::lines( 146, 34, array( 22 ), self::MUTED, 0, 4 );
	}

	private static function draw_header_floating(): string {
		return self::page_body( 0, 150 )
			. '<rect x="10" y="7" width="220" height="24" rx="12" fill="#0f1315" opacity=".08" transform="translate(0 3)"/>'
			. self::r( 10, 6, 220, 24, self::WHITE, 12, self::LINE )
			. self::r( 196, 14, 26, 8, self::INK ) . self::r( 122, 14, 22, 8, '#fff5de', 4 ) . self::lines( 116, 16, array( 16 ), self::MUTED, 0, 4 ) . self::lines( 170, 16, array( 16 ), self::MUTED, 0, 4 )
			. self::c( 54, 18, 5.5, self::BG ) . self::r( 16, 12, 30, 12, self::ACCENT, 6 );
	}

	/* ---------------------------------------------------------------------
	 * Footers
	 * ------------------------------------------------------------------- */

	private static function draw_footer_columns(): string {
		return self::page_body( 0, 78 )
			. self::r( 0, 78, 240, 72, self::WHITE, 0 ) . self::r( 0, 78, 240, 2.5, self::ACCENT, 0 )
			. self::r( 196, 88, 36, 8, self::INK ) . self::lines( 232, 100, array( 62, 50 ) ) . self::c( 226, 118, 4, self::BG ) . self::c( 216, 118, 4, self::BG ) . self::c( 206, 118, 4, self::BG )
			. self::r( 138, 88, 30, 5, self::INK ) . self::lines( 168, 98, array( 26, 22, 28 ) )
			. self::r( 90, 88, 30, 5, self::INK ) . self::lines( 120, 98, array( 26, 22, 28 ) )
			. self::r( 36, 88, 38, 5, self::INK ) . self::lines( 74, 98, array( 36, 34, 30 ) )
			. self::r( 0, 132, 240, 1, self::LINE, 0 ) . self::r( 170, 139, 62, 4, self::MUTED ) . self::r( 10, 136, 12, 10, self::BG, 2 ) . self::r( 26, 136, 12, 10, self::BG, 2 );
	}

	private static function draw_footer_dark(): string {
		return self::page_body( 0, 76 )
			. self::r( 0, 86, 240, 64, self::INK, 0 )
			. self::r( 18, 70, 204, 26, self::ACCENT, 8 ) . self::r( 130, 77, 84, 6, self::INK ) . self::r( 150, 86, 64, 3.5, '#8a5e00' ) . self::r( 26, 77, 44, 12, self::INK, 4 )
			. self::r( 196, 106, 36, 7, '#eaedef' ) . self::lines( 232, 117, array( 60, 48 ), '#6b7780' )
			. self::r( 118, 106, 30, 5, '#eaedef' ) . self::lines( 148, 116, array( 26, 22 ), '#6b7780' )
			. self::r( 40, 106, 34, 5, '#eaedef' ) . self::lines( 74, 116, array( 32, 28 ), '#6b7780' )
			. self::r( 0, 136, 240, 1, '#434d53', 0 ) . self::r( 170, 141, 62, 3.5, '#6b7780' );
	}

	private static function draw_footer_minimal(): string {
		return self::page_body( 0, 118 )
			. self::r( 0, 118, 240, 32, self::WHITE, 0 ) . self::r( 0, 118, 240, 1, self::LINE, 0 )
			. self::r( 200, 130, 30, 8, self::INK ) . self::lines( 150, 132, array( 16 ), self::MUTED, 0, 4 ) . self::lines( 130, 132, array( 16 ), self::MUTED, 0, 4 ) . self::lines( 110, 132, array( 16 ), self::MUTED, 0, 4 )
			. self::r( 10, 132, 54, 4, self::MUTED );
	}

	private static function draw_footer_centered(): string {
		return self::page_body( 0, 76 )
			. self::r( 0, 76, 240, 74, self::BG, 0 ) . self::r( 0, 76, 240, 1, self::LINE, 0 )
			. self::r( 102, 86, 36, 8, self::INK ) . self::r( 70, 100, 100, 3.5, self::MUTED ) . self::r( 84, 106, 72, 3.5, self::MUTED )
			. self::c( 104, 118, 4.5, self::WHITE ) . self::c( 116, 118, 4.5, self::WHITE ) . self::c( 128, 118, 4.5, self::WHITE ) . self::c( 140, 118, 4.5, self::WHITE )
			. self::lines( 170, 128, array( 20 ), self::MUTED, 0, 4 ) . self::lines( 144, 128, array( 20 ), self::MUTED, 0, 4 ) . self::lines( 118, 128, array( 20 ), self::MUTED, 0, 4 ) . self::lines( 92, 128, array( 20 ), self::MUTED, 0, 4 )
			. self::r( 90, 140, 60, 3.5, self::MUTED );
	}

	private static function draw_footer_trust(): string {
		return self::page_body( 0, 76 )
			. self::r( 0, 76, 240, 74, self::WHITE, 0 ) . self::r( 0, 76, 240, 1, self::LINE, 0 )
			. self::r( 150, 84, 82, 44, self::BG, 6 ) . self::r( 196, 90, 30, 6, self::INK ) . self::lines( 226, 100, array( 50, 44, 40 ) ) . self::r( 186, 119, 40, 6, self::ACCENT, 3 )
			. self::r( 112, 86, 28, 5, self::INK ) . self::lines( 140, 96, array( 26, 22, 24 ) )
			. self::r( 72, 86, 28, 5, self::INK ) . self::lines( 100, 96, array( 26, 22, 24 ) )
			. self::r( 10, 86, 24, 24, self::BG, 4, self::LINE ) . self::r( 38, 86, 24, 24, self::BG, 4, self::LINE )
			. self::r( 0, 134, 240, 1, self::LINE, 0 ) . self::r( 170, 140, 62, 3.5, self::MUTED );
	}

	/* ---------------------------------------------------------------------
	 * Generic
	 * ------------------------------------------------------------------- */

	/**
	 * Custom templates and the theme option.
	 *
	 * @param string $key Kind or `theme`.
	 */
	private static function generic( string $key ): string {
		if ( 'theme' === $key ) {
			return self::r( 0, 0, 240, 150, '#eef6f5', 0 )
				. self::r( 70, 40, 100, 70, self::WHITE, 10, '#b9d9d5' )
				. '<path d="M104 88l16-26 16 26z" fill="#26a69a" opacity=".85"/><circle cx="136" cy="62" r="6" fill="#26a69a" opacity=".6"/>';
		}

		if ( 'none' === $key ) {
			return self::r( 0, 0, 240, 150, self::BG, 0 ) . '<path d="M100 55l40 40M140 55l-40 40" stroke="#b6c0c6" stroke-width="6" stroke-linecap="round"/>';
		}

		if ( 'same' === $key ) {
			return self::r( 0, 0, 240, 150, self::BG, 0 )
				. self::r( 38, 34, 104, 70, self::WHITE, 7, self::LINE ) . self::r( 38, 34, 104, 14, self::INK, 7 )
				. self::r( 152, 44, 50, 80, self::WHITE, 8, self::LINE ) . self::r( 152, 44, 50, 14, self::INK, 8 );
		}

		// Custom template: blank page with the Elementor "e".
		return self::r( 0, 0, 240, 150, self::BG, 0 )
			. self::r( 80, 35, 80, 80, self::WHITE, 40, self::LINE )
			. '<path d="M107 60h6v30h-6zM118 60h16v6h-16zM118 72h16v6h-16zM118 84h16v6h-16z" fill="#92003b"/>';
	}
}
