<?php
/**
 * Live search results, returned by Live_Search and placed under the search
 * field of the search sheet.
 *
 * @var \StudiareExt\Modules\Bottom_Nav\Renderer $renderer
 * @var array<int, array>                        $results View models: title, url, thumb, type, price.
 * @var string                                   $term    Search term.
 *
 * @package StudiareExt
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- included from a class method, so variables are local.
?>
<?php if ( ! $results ) : ?>
	<p class="stx-results__note">
		<?php
		/* translators: %s: search term. */
		echo esc_html( sprintf( __( 'Nothing found for “%s”.', 'studiare-extensions' ), $term ) );
		?>
	</p>
<?php else : ?>
	<ul class="stx-results">
		<?php foreach ( $results as $result ) : ?>
			<li class="stx-results__item">
				<a class="stx-results__link" href="<?php echo esc_url( $result['url'] ); ?>">
					<span class="stx-results__media" aria-hidden="true">
						<?php echo '' !== $result['thumb'] ? $result['thumb'] : $renderer->result_placeholder_icon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core thumbnail markup or bundled SVG. ?>
					</span>
					<span class="stx-results__text">
						<span class="stx-results__title"><?php echo esc_html( $result['title'] ); ?></span>
						<?php if ( '' !== $result['type'] || '' !== $result['price'] ) : ?>
							<span class="stx-results__meta">
								<?php if ( '' !== $result['type'] ) : ?>
									<span class="stx-results__type"><?php echo esc_html( $result['type'] ); ?></span>
								<?php endif; ?>
								<?php if ( '' !== $result['price'] ) : ?>
									<span class="stx-results__price"><?php echo wp_kses_post( $result['price'] ); ?></span>
								<?php endif; ?>
							</span>
						<?php endif; ?>
					</span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
<?php endif; ?>
