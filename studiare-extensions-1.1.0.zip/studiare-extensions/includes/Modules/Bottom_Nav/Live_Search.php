<?php
/**
 * AJAX endpoint behind the live results of the search sheet.
 *
 * admin-ajax is used (like the settings screen) because hosts and security
 * plugins often restrict the REST API, and admin-ajax responses are never
 * served from a page cache.
 *
 * @package StudiareExt
 */

namespace StudiareExt\Modules\Bottom_Nav;

defined( 'ABSPATH' ) || exit;

final class Live_Search {

	public const ACTION = 'stx_live_search';

	/** Shorter terms return nothing; bottom-nav.js does not send them. */
	public const MIN_CHARS = 2;

	private const MAX_CHARS = 100;

	private const RESULTS = 8;

	/** @var Module */
	private $module;

	/**
	 * @param Module $module Owning module.
	 */
	public function __construct( Module $module ) {
		$this->module = $module;
	}

	public function register(): void {
		add_action( 'wp_ajax_' . self::ACTION, array( $this, 'handle' ) );
		add_action( 'wp_ajax_nopriv_' . self::ACTION, array( $this, 'handle' ) );
	}

	/** Endpoint URL for bottom-nav.js; relative, so it is always same-origin. */
	public static function url(): string {
		return add_query_arg( 'action', self::ACTION, admin_url( 'admin-ajax.php', 'relative' ) );
	}

	/**
	 * Responds with rendered results for `term` within search item `item`.
	 *
	 * There is no nonce on purpose: the endpoint is read-only and returns the
	 * same published content as `/?s=`, while a nonce baked into a cached page
	 * would expire and break search for visitors. The request only names the
	 * item; its post types come from the saved settings, so a request cannot
	 * widen the search.
	 */
	public function handle(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- public read-only endpoint, see above.
		$item_id = isset( $_GET['item'] ) ? sanitize_key( wp_unslash( $_GET['item'] ) ) : '';
		$term    = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';
		// phpcs:enable

		$item = $this->find_item( $item_id );
		if ( null === $item ) {
			wp_send_json_error( null, 404 );
		}

		$term = mb_substr( trim( $term ), 0, self::MAX_CHARS );
		if ( mb_strlen( $term ) < self::MIN_CHARS ) {
			wp_send_json_success(
				array(
					'html'    => '',
					'message' => '',
				)
			);
		}

		$post_types = Search_Scope::post_types( $item );
		$show_type  = 1 !== count( $post_types );
		$results    = array_map(
			function ( $post ) use ( $show_type ) {
				return $this->result( $post, $show_type );
			},
			$this->query( $term, $post_types, $item )
		);

		$renderer = new Renderer( $this->module->settings(), array() );

		wp_send_json_success(
			array(
				'html'    => $renderer->search_results( $results, $term ),
				'message' => $results
					/* translators: %d: number of search results. */
					? sprintf( _n( '%d result', '%d results', count( $results ), 'studiare-extensions' ), count( $results ) )
					/* translators: %s: search term. */
					: sprintf( __( 'Nothing found for “%s”.', 'studiare-extensions' ), $term ),
			)
		);
	}

	/**
	 * The enabled search item with live results, or null.
	 *
	 * @param string $id Item id.
	 */
	private function find_item( string $id ): ?array {
		foreach ( $this->module->settings()['items'] as $item ) {
			if ( $id === $item['id'] && 'search' === $item['type'] && $item['enabled'] && $item['search_live'] ) {
				return $item;
			}
		}

		return null;
	}

	/**
	 * @param string   $term       Search term.
	 * @param string[] $post_types Validated post types; empty means all searchable ones.
	 * @param array    $item       Search item, passed to the filter.
	 * @return \WP_Post[]
	 */
	private function query( string $term, array $post_types, array $item ): array {
		$types = $post_types ? $post_types : array_keys( Search_Scope::choices() );
		$args  = array(
			's'                      => $term,
			'post_type'              => $types,
			'post_status'            => 'publish',
			'posts_per_page'         => self::RESULTS,
			'ignore_sticky_posts'    => true,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
		);

		if ( in_array( 'product', $types, true ) && function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			$args['tax_query'] = self::product_visibility_query(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- same query WooCommerce runs on its search page.
		}

		/**
		 * Filters the WP_Query arguments of the live search.
		 *
		 * @param array $args Query arguments.
		 * @param array $item Search item settings.
		 */
		$args = (array) apply_filters( 'studiare_ext_live_search_args', $args, $item );

		return ( new \WP_Query( $args ) )->posts;
	}

	/**
	 * Hides products the store keeps out of search (catalog visibility
	 * "Shop only" or "Hidden", and out-of-stock items when the store hides
	 * them), as WooCommerce does on its own search page. Posts and pages have
	 * no visibility terms, so `NOT IN` keeps them.
	 */
	private static function product_visibility_query(): array {
		$term_ids = wc_get_product_visibility_term_ids();
		$excluded = array( $term_ids['exclude-from-search'] ?? 0 );

		if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
			$excluded[] = $term_ids['outofstock'] ?? 0;
		}

		return array(
			array(
				'taxonomy' => 'product_visibility',
				'field'    => 'term_taxonomy_id',
				'terms'    => array_values( array_filter( $excluded ) ),
				'operator' => 'NOT IN',
			),
		);
	}

	/**
	 * View model of one result for views/search-results.php.
	 *
	 * @param \WP_Post $post      Found post.
	 * @param bool     $show_type Label the post type (when several can match).
	 */
	private function result( \WP_Post $post, bool $show_type ): array {
		$type    = get_post_type_object( $post->post_type );
		$product = 'product' === $post->post_type && function_exists( 'wc_get_product' ) ? wc_get_product( $post ) : null;

		return array(
			'title' => wp_strip_all_tags( get_the_title( $post ) ),
			'url'   => (string) get_permalink( $post ),
			'thumb' => get_the_post_thumbnail(
				$post,
				'thumbnail',
				array(
					'class'   => 'stx-results__img',
					'alt'     => '',
					'loading' => 'lazy',
				)
			),
			'type'  => $show_type && $type ? $type->labels->singular_name : '',
			'price' => $product ? (string) $product->get_price_html() : '',
		);
	}
}
