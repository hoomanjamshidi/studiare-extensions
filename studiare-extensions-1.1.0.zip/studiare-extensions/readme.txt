=== Studiare Extensions ===
Tags: studiare, bottom navigation, elementor, woocommerce, rtl
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Extra features for the Studiare LMS theme: a customizable mobile bottom navigation and Elementor page templates for courses, products, headers and footers.

== Description ==

= Mobile bottom navigation =

* Five styles: Classic, Floating glass, Center button (notch), Bubble and Expanding pill — each with a live preview.
* Any number of buttons (up to 8); the layout adapts so it always looks balanced.
* Button types: home, custom link, search sheet, cart (live WooCommerce count, opens the Studiare mini cart), account (avatar and guest label), menu, content sheet (Elementor/shortcode), back to top, dark mode, and "click an element".
* Six bundled SVG icon packs (Lucide, Tabler, Phosphor, Phosphor Duotone, Heroicons, Bootstrap Icons) plus Studiare's Font Awesome, custom images or custom SVG per button.
* Colours, fonts and dark mode follow the Studiare theme by default; every colour, size and font can be overridden.
* Cache friendly (no server-side device detection), accessible (keyboard, screen readers, reduced motion) and RTL-first.

= Page templates (Elementor) =

* 16 ready-made designs, installed as normal Elementor templates: 3 course pages, 3 product pages, 5 headers and 5 footers.
* Use Studiare's own layout or a template — for all courses/products, per product category (with or without subcategories), or per product from its edit screen.
* Separate header and footer for desktop and for phones/tablets (template, the theme's own, or nothing). Both are printed and switched with CSS, so page caching keeps working.
* 31 Elementor widgets in a "Studiare+" category: product title, price, add to cart (variations, quantity, "already enrolled", "in cart"), gallery with the course intro video, course facts, curriculum from Studiare's lessons, teacher, tabs, reviews, related products, mobile buy bar, logo, menu with mobile drawer, search, cart, login, dark mode switch, copyright (Solar Hijri year) and e-Namad badges.
* Persian-first: RTL layouts, Persian digits and separators, widgets inherit the site's Persian font instead of Elementor's default fonts.
* Brand colours in one place (with Studiare dark mode); container "brand surface" and "sticky" options in Elementor.
* Live preview of every design on desktop, tablet and phone before saving.
* Needs Elementor (free) 3.16 or newer with Flexbox Containers; tested with Elementor 3.35 and 4.3 and WooCommerce 11.

== Installation ==

1. Upload the `studiare-extensions` folder to `/wp-content/plugins/`.
2. Activate the plugin.
3. Open **Studiare+ → Mobile bottom navigation** or **Studiare+ → Page templates** in the admin menu.

== Changelog ==

= 1.1.0 =
* New: Page templates — Elementor designs for course pages, product pages, headers and footers, with category rules, per-device headers/footers and live previews.

= 1.0.0 =
* First release: mobile bottom navigation.

== Credits ==

* Vazirmatn font — SIL Open Font License 1.1 (assets/admin/fonts/OFL.txt).
* Icons: Lucide (ISC), Tabler Icons (MIT), Phosphor Icons (MIT), Heroicons (MIT), Bootstrap Icons (MIT).
